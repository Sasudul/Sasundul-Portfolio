import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/HeroID.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useRef = __vite__cjsImport1_react["useRef"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
const PROFILE_IMAGE_URL = "/image.png";
const TECH_BADGES = ["React.js", "Spring Boot", "Next.js", "Tailwind CSS", "Figma"];
const FLOATING_SHAPES = [
  { src: "/shapes/shape1.png", finalX: -350, finalY: -220, size: 140, delay: 0 },
  { src: "/shapes/shape2.png", finalX: 320, finalY: -200, size: 120, delay: 0.08 },
  { src: "/shapes/Shape3.png", finalX: -380, finalY: 40, size: 110, delay: 0.16 },
  { src: "/shapes/shape4.png", finalX: 360, finalY: 50, size: 120, delay: 0.24 },
  { src: "/shapes/shape5.png", finalX: -300, finalY: 220, size: 110, delay: 0.32 },
  { src: "/shapes/shape6.png", finalX: 300, finalY: 230, size: 140, delay: 0.4 }
];
function Barcode() {
  const bars = [];
  for (let i = 0; i < 40; i++) {
    const w = Math.random() > 0.5 ? 3 : 2;
    const h = 24 + Math.random() * 12;
    bars.push(/* @__PURE__ */ jsxDEV("span", { className: "id-card__barcode-bar", style: { width: w, height: h } }, i, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
      lineNumber: 25,
      columnNumber: 15
    }, this));
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex gap-[1px] justify-center", children: bars }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
    lineNumber: 27,
    columnNumber: 10
  }, this);
}
_c = Barcode;
export default function HeroID() {
  _s();
  const sectionRef = useRef(null);
  const cardRef = useRef(null);
  const shapesReleasedRef = useRef(false);
  const floatingTweensRef = useRef([]);
  useGSAP(() => {
    gsap.from(cardRef.current, {
      y: 80,
      opacity: 0,
      scale: 0.9,
      duration: 1.2,
      ease: "power4.out",
      delay: 0.2
    });
    gsap.to(cardRef.current, {
      y: -10,
      duration: 2.5,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });
    gsap.set(".hero-float-icon", {
      xPercent: -50,
      yPercent: -50,
      scale: 0,
      opacity: 0,
      rotation: 0
    });
  }, { scope: sectionRef });
  const releaseShapes = useCallback(() => {
    if (shapesReleasedRef.current) return;
    shapesReleasedRef.current = true;
    floatingTweensRef.current.forEach((t) => t.kill());
    floatingTweensRef.current = [];
    const shapes = gsap.utils.toArray(".hero-float-icon");
    shapes.forEach((el, i) => {
      const data = FLOATING_SHAPES[i];
      if (!data) return;
      const randomOffsetX = gsap.utils.random(-40, 40);
      const randomOffsetY = gsap.utils.random(-30, 30);
      gsap.to(el, {
        x: data.finalX + randomOffsetX,
        y: data.finalY + randomOffsetY,
        scale: 1,
        opacity: 1,
        rotation: gsap.utils.random(-25, 25),
        duration: 1.2,
        delay: data.delay,
        ease: "back.out(1.2)",
        onComplete: () => {
          const floatX = gsap.to(el, {
            x: `+=${gsap.utils.random(-80, 80)}`,
            y: `+=${gsap.utils.random(-60, 60)}`,
            rotation: `+=${gsap.utils.random(-30, 30)}`,
            duration: gsap.utils.random(3, 5),
            repeat: -1,
            yoyo: true,
            ease: "sine.inOut"
          });
          floatingTweensRef.current.push(floatX);
        }
      });
    });
  }, []);
  const retractShapes = useCallback(() => {
    if (!shapesReleasedRef.current) return;
    shapesReleasedRef.current = false;
    floatingTweensRef.current.forEach((t) => t.kill());
    floatingTweensRef.current = [];
    const shapes = gsap.utils.toArray(".hero-float-icon");
    shapes.forEach((el, i) => {
      const data = FLOATING_SHAPES[i];
      if (!data) return;
      gsap.to(el, {
        x: 0,
        y: 0,
        scale: 0,
        opacity: 0,
        rotation: 0,
        duration: 0.8,
        delay: i * 0.04,
        ease: "power3.in"
      });
    });
  }, []);
  const handleMouseMove = (e) => {
    if (!sectionRef.current) return;
    const rect = sectionRef.current.getBoundingClientRect();
    const xPos = (e.clientX - rect.left) / rect.width - 0.5;
    const yPos = (e.clientY - rect.top) / rect.height - 0.5;
    gsap.to(cardRef.current, {
      x: xPos * 30,
      y: -10 + yPos * 20,
      rotateY: xPos * 8,
      rotateX: -yPos * 8,
      duration: 1,
      ease: "power3.out",
      transformPerspective: 1200
    });
  };
  const handleMouseLeave = () => {
    gsap.to(cardRef.current, {
      x: 0,
      rotateY: 0,
      rotateX: 0,
      duration: 1.5,
      ease: "elastic.out(1, 0.5)"
    });
    retractShapes();
  };
  return /* @__PURE__ */ jsxDEV(
    "section",
    {
      ref: sectionRef,
      id: "hero",
      className: "relative min-h-screen flex items-center justify-center overflow-hidden",
      onMouseMove: handleMouseMove,
      onMouseLeave: handleMouseLeave,
      children: [
        FLOATING_SHAPES.map(
          (shape, i) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "hero-float-icon",
              style: {
                position: "absolute",
                top: "50%",
                left: "50%",
                zIndex: 5,
                pointerEvents: "none",
                willChange: "transform, opacity"
              },
              children: /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: shape.src,
                  alt: "",
                  width: shape.size,
                  height: shape.size,
                  style: {
                    width: shape.size,
                    height: shape.size,
                    objectFit: "contain",
                    filter: "drop-shadow(0 4px 12px rgba(0,0,0,0.3))"
                  }
                },
                void 0,
                false,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                  lineNumber: 192,
                  columnNumber: 11
                },
                this
              )
            },
            i,
            false,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
              lineNumber: 180,
              columnNumber: 7
            },
            this
          )
        ),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            ref: cardRef,
            className: "id-card relative z-10",
            style: { transformStyle: "preserve-3d" },
            onMouseEnter: releaseShapes,
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "id-card__notch" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 215,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "id-card__photo-frame", children: [
                /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: PROFILE_IMAGE_URL,
                    alt: "Sasundul Wanasinghe",
                    className: "w-full h-full object-cover"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                    lineNumber: 219,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-4 left-4 bg-white text-black px-3 py-1 text-[10px] font-mono font-bold uppercase tracking-widest shadow-md -rotate-3", children: "HELLO" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                  lineNumber: 225,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 218,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "id-card__title text-2xl font-display font-bold uppercase tracking-tight mt-2", children: "Sasundul Wanasinghe" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 231,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "id-card__subtitle text-xs font-mono uppercase tracking-widest mt-1", children: "[ Designer / Developer ]" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 234,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-4", children: TECH_BADGES.map(
                (tech) => /* @__PURE__ */ jsxDEV("span", { className: "id-card__badge text-[10px] font-mono uppercase tracking-wider px-3 py-1 rounded-full border", children: tech }, tech, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                  lineNumber: 241,
                  columnNumber: 11
                }, this)
              ) }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 239,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "id-card__separator border-t border-dashed mt-4 pt-3", children: /* @__PURE__ */ jsxDEV(Barcode, {}, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 249,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 248,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "id-card__footer flex justify-between items-center mt-3 text-[9px] font-mono uppercase tracking-widest", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "CODE BY SASUNDUL©" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                  lineNumber: 254,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: (/* @__PURE__ */ new Date()).getFullYear() }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                  lineNumber: 255,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
                lineNumber: 253,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
            lineNumber: 208,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx",
      lineNumber: 171,
      columnNumber: 5
    },
    this
  );
}
_s(HeroID, "Imm+TEBTOYMPsPPhB4zAtaZ/YnM=", false, function() {
  return [useGSAP];
});
_c2 = HeroID;
var _c, _c2;
$RefreshReg$(_c, "Barcode");
$RefreshReg$(_c2, "HeroID");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HeroID.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JjOztBQXhCZCxTQUFTQSxRQUFRQyxtQkFBbUI7QUFDcEMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLG9CQUFvQjtBQUUxQixNQUFNQyxjQUFjLENBQUMsWUFBWSxlQUFlLFdBQVcsZ0JBQWdCLE9BQU87QUFHbEYsTUFBTUMsa0JBQWtCO0FBQUEsRUFDdEIsRUFBRUMsS0FBSyxzQkFBc0JDLFFBQVEsTUFBTUMsUUFBUSxNQUFNQyxNQUFNLEtBQUtDLE9BQU8sRUFBRTtBQUFBLEVBQzdFLEVBQUVKLEtBQUssc0JBQXNCQyxRQUFRLEtBQUtDLFFBQVEsTUFBTUMsTUFBTSxLQUFLQyxPQUFPLEtBQUs7QUFBQSxFQUMvRSxFQUFFSixLQUFLLHNCQUFzQkMsUUFBUSxNQUFNQyxRQUFRLElBQUlDLE1BQU0sS0FBS0MsT0FBTyxLQUFLO0FBQUEsRUFDOUUsRUFBRUosS0FBSyxzQkFBc0JDLFFBQVEsS0FBS0MsUUFBUSxJQUFJQyxNQUFNLEtBQUtDLE9BQU8sS0FBSztBQUFBLEVBQzdFLEVBQUVKLEtBQUssc0JBQXNCQyxRQUFRLE1BQU1DLFFBQVEsS0FBS0MsTUFBTSxLQUFLQyxPQUFPLEtBQUs7QUFBQSxFQUMvRSxFQUFFSixLQUFLLHNCQUFzQkMsUUFBUSxLQUFLQyxRQUFRLEtBQUtDLE1BQU0sS0FBS0MsT0FBTyxJQUFLO0FBQUM7QUFJakYsU0FBU0MsVUFBVTtBQUNqQixRQUFNQyxPQUFPO0FBQ2IsV0FBU0MsSUFBSSxHQUFHQSxJQUFJLElBQUlBLEtBQUs7QUFDM0IsVUFBTUMsSUFBSUMsS0FBS0MsT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUNwQyxVQUFNQyxJQUFJLEtBQUtGLEtBQUtDLE9BQU8sSUFBSTtBQUMvQkosU0FBS00sS0FBSyx1QkFBQyxVQUFhLFdBQVUsd0JBQXVCLE9BQU8sRUFBRUMsT0FBT0wsR0FBR00sUUFBUUgsRUFBRSxLQUFqRUosR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThFLENBQUc7QUFBQSxFQUM3RjtBQUNBLFNBQU8sdUJBQUMsU0FBSSxXQUFVLGlDQUFpQ0Qsa0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUQ7QUFDOUQ7QUFBQ1MsS0FSUVY7QUFVVCx3QkFBd0JXLFNBQVM7QUFBQUMsS0FBQTtBQUMvQixRQUFNQyxhQUFhekIsT0FBb0IsSUFBSTtBQUMzQyxRQUFNMEIsVUFBVTFCLE9BQXVCLElBQUk7QUFDM0MsUUFBTTJCLG9CQUFvQjNCLE9BQU8sS0FBSztBQUN0QyxRQUFNNEIsb0JBQW9CNUIsT0FBMEIsRUFBRTtBQUV0REUsVUFBUSxNQUFNO0FBRVpDLFNBQUswQixLQUFLSCxRQUFRSSxTQUFTO0FBQUEsTUFDekJDLEdBQUc7QUFBQSxNQUNIQyxTQUFTO0FBQUEsTUFDVEMsT0FBTztBQUFBLE1BQ1BDLFVBQVU7QUFBQSxNQUNWQyxNQUFNO0FBQUEsTUFDTnhCLE9BQU87QUFBQSxJQUNULENBQUM7QUFHRFIsU0FBS2lDLEdBQUdWLFFBQVFJLFNBQVM7QUFBQSxNQUN2QkMsR0FBRztBQUFBLE1BQ0hHLFVBQVU7QUFBQSxNQUNWRyxRQUFRO0FBQUEsTUFDUkMsTUFBTTtBQUFBLE1BQ05ILE1BQU07QUFBQSxJQUNSLENBQUM7QUFHRGhDLFNBQUtvQyxJQUFJLG9CQUFvQjtBQUFBLE1BQzNCQyxVQUFVO0FBQUEsTUFDVkMsVUFBVTtBQUFBLE1BQ1ZSLE9BQU87QUFBQSxNQUNQRCxTQUFTO0FBQUEsTUFDVFUsVUFBVTtBQUFBLElBQ1osQ0FBQztBQUFBLEVBQ0gsR0FBRyxFQUFFQyxPQUFPbEIsV0FBVyxDQUFDO0FBRXhCLFFBQU1tQixnQkFBZ0IzQyxZQUFZLE1BQU07QUFDdEMsUUFBSTBCLGtCQUFrQkcsUUFBUztBQUMvQkgsc0JBQWtCRyxVQUFVO0FBRzVCRixzQkFBa0JFLFFBQVFlLFFBQVEsQ0FBQUMsTUFBS0EsRUFBRUMsS0FBSyxDQUFDO0FBQy9DbkIsc0JBQWtCRSxVQUFVO0FBRTVCLFVBQU1rQixTQUFTN0MsS0FBSzhDLE1BQU1DLFFBQXFCLGtCQUFrQjtBQUVqRUYsV0FBT0gsUUFBUSxDQUFDTSxJQUFJckMsTUFBTTtBQUN4QixZQUFNc0MsT0FBTzlDLGdCQUFnQlEsQ0FBQztBQUM5QixVQUFJLENBQUNzQyxLQUFNO0FBR1gsWUFBTUMsZ0JBQWdCbEQsS0FBSzhDLE1BQU1oQyxPQUFPLEtBQUssRUFBRTtBQUMvQyxZQUFNcUMsZ0JBQWdCbkQsS0FBSzhDLE1BQU1oQyxPQUFPLEtBQUssRUFBRTtBQUcvQ2QsV0FBS2lDLEdBQUdlLElBQUk7QUFBQSxRQUNWSSxHQUFHSCxLQUFLNUMsU0FBUzZDO0FBQUFBLFFBQ2pCdEIsR0FBR3FCLEtBQUszQyxTQUFTNkM7QUFBQUEsUUFDakJyQixPQUFPO0FBQUEsUUFDUEQsU0FBUztBQUFBLFFBQ1RVLFVBQVV2QyxLQUFLOEMsTUFBTWhDLE9BQU8sS0FBSyxFQUFFO0FBQUEsUUFDbkNpQixVQUFVO0FBQUEsUUFDVnZCLE9BQU95QyxLQUFLekM7QUFBQUEsUUFDWndCLE1BQU07QUFBQSxRQUNOcUIsWUFBWUEsTUFBTTtBQUVoQixnQkFBTUMsU0FBU3RELEtBQUtpQyxHQUFHZSxJQUFJO0FBQUEsWUFDekJJLEdBQUcsS0FBS3BELEtBQUs4QyxNQUFNaEMsT0FBTyxLQUFLLEVBQUUsQ0FBQztBQUFBLFlBQ2xDYyxHQUFHLEtBQUs1QixLQUFLOEMsTUFBTWhDLE9BQU8sS0FBSyxFQUFFLENBQUM7QUFBQSxZQUNsQ3lCLFVBQVUsS0FBS3ZDLEtBQUs4QyxNQUFNaEMsT0FBTyxLQUFLLEVBQUUsQ0FBQztBQUFBLFlBQ3pDaUIsVUFBVS9CLEtBQUs4QyxNQUFNaEMsT0FBTyxHQUFHLENBQUM7QUFBQSxZQUNoQ29CLFFBQVE7QUFBQSxZQUNSQyxNQUFNO0FBQUEsWUFDTkgsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUNEUCw0QkFBa0JFLFFBQVFYLEtBQUtzQyxNQUFNO0FBQUEsUUFDdkM7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNILEdBQUcsRUFBRTtBQUVMLFFBQU1DLGdCQUFnQnpELFlBQVksTUFBTTtBQUN0QyxRQUFJLENBQUMwQixrQkFBa0JHLFFBQVM7QUFDaENILHNCQUFrQkcsVUFBVTtBQUc1QkYsc0JBQWtCRSxRQUFRZSxRQUFRLENBQUFDLE1BQUtBLEVBQUVDLEtBQUssQ0FBQztBQUMvQ25CLHNCQUFrQkUsVUFBVTtBQUU1QixVQUFNa0IsU0FBUzdDLEtBQUs4QyxNQUFNQyxRQUFxQixrQkFBa0I7QUFFakVGLFdBQU9ILFFBQVEsQ0FBQ00sSUFBSXJDLE1BQU07QUFDeEIsWUFBTXNDLE9BQU85QyxnQkFBZ0JRLENBQUM7QUFDOUIsVUFBSSxDQUFDc0MsS0FBTTtBQUdYakQsV0FBS2lDLEdBQUdlLElBQUk7QUFBQSxRQUNWSSxHQUFHO0FBQUEsUUFDSHhCLEdBQUc7QUFBQSxRQUNIRSxPQUFPO0FBQUEsUUFDUEQsU0FBUztBQUFBLFFBQ1RVLFVBQVU7QUFBQSxRQUNWUixVQUFVO0FBQUEsUUFDVnZCLE9BQU9HLElBQUk7QUFBQSxRQUNYcUIsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsR0FBRyxFQUFFO0FBR0wsUUFBTXdCLGtCQUFrQkEsQ0FBQ0MsTUFBd0I7QUFDL0MsUUFBSSxDQUFDbkMsV0FBV0ssUUFBUztBQUN6QixVQUFNK0IsT0FBT3BDLFdBQVdLLFFBQVFnQyxzQkFBc0I7QUFDdEQsVUFBTUMsUUFBUUgsRUFBRUksVUFBVUgsS0FBS0ksUUFBUUosS0FBS3pDLFFBQVE7QUFDcEQsVUFBTThDLFFBQVFOLEVBQUVPLFVBQVVOLEtBQUtPLE9BQU9QLEtBQUt4QyxTQUFTO0FBRXBEbEIsU0FBS2lDLEdBQUdWLFFBQVFJLFNBQVM7QUFBQSxNQUN2QnlCLEdBQUdRLE9BQU87QUFBQSxNQUNWaEMsR0FBRyxNQUFNbUMsT0FBTztBQUFBLE1BQ2hCRyxTQUFTTixPQUFPO0FBQUEsTUFDaEJPLFNBQVMsQ0FBQ0osT0FBTztBQUFBLE1BQ2pCaEMsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxNQUNOb0Msc0JBQXNCO0FBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNQyxtQkFBbUJBLE1BQU07QUFDN0JyRSxTQUFLaUMsR0FBR1YsUUFBUUksU0FBUztBQUFBLE1BQ3ZCeUIsR0FBRztBQUFBLE1BQ0hjLFNBQVM7QUFBQSxNQUNUQyxTQUFTO0FBQUEsTUFDVHBDLFVBQVU7QUFBQSxNQUNWQyxNQUFNO0FBQUEsSUFDUixDQUFDO0FBR0R1QixrQkFBYztBQUFBLEVBQ2hCO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsS0FBS2pDO0FBQUFBLE1BQ0wsSUFBRztBQUFBLE1BQ0gsV0FBVTtBQUFBLE1BQ1YsYUFBYWtDO0FBQUFBLE1BQ2IsY0FBY2E7QUFBQUEsTUFHYmxFO0FBQUFBLHdCQUFnQm1FO0FBQUFBLFVBQUksQ0FBQ0MsT0FBTzVELE1BQzNCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FDVixPQUFPO0FBQUEsZ0JBQ0w2RCxVQUFVO0FBQUEsZ0JBQ1ZQLEtBQUs7QUFBQSxnQkFDTEgsTUFBTTtBQUFBLGdCQUNOVyxRQUFRO0FBQUEsZ0JBQ1JDLGVBQWU7QUFBQSxnQkFDZkMsWUFBWTtBQUFBLGNBQ2Q7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLEtBQUtKLE1BQU1uRTtBQUFBQSxrQkFDWCxLQUFJO0FBQUEsa0JBQ0osT0FBT21FLE1BQU1oRTtBQUFBQSxrQkFDYixRQUFRZ0UsTUFBTWhFO0FBQUFBLGtCQUNkLE9BQU87QUFBQSxvQkFDTFUsT0FBT3NELE1BQU1oRTtBQUFBQSxvQkFDYlcsUUFBUXFELE1BQU1oRTtBQUFBQSxvQkFDZHFFLFdBQVc7QUFBQSxvQkFDWEMsUUFBUTtBQUFBLGtCQUNWO0FBQUE7QUFBQSxnQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVSTtBQUFBO0FBQUEsWUFyQkNsRTtBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF3QkE7QUFBQSxRQUNEO0FBQUEsUUFHRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsS0FBS1k7QUFBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUV1RCxnQkFBZ0IsY0FBYztBQUFBLFlBQ3ZDLGNBQWNyQztBQUFBQSxZQUdkO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9CQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FHL0IsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsS0FBS3hDO0FBQUFBLG9CQUNMLEtBQUk7QUFBQSxvQkFDSixXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR3dDO0FBQUEsZ0JBR3hDLHVCQUFDLFNBQUksV0FBVSx3SUFBc0kscUJBQXJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FHQSx1QkFBQyxRQUFHLFdBQVUsZ0ZBQThFLG1DQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsc0VBQW9FLHdDQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1pDLHNCQUFZb0U7QUFBQUEsZ0JBQUksQ0FBQVMsU0FDZix1QkFBQyxVQUFnQixXQUFVLCtGQUN4QkEsa0JBRFFBLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsdURBQ2IsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFRLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLHlHQUNiO0FBQUEsdUNBQUMsVUFBSyxpQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QjtBQUFBLGdCQUN2Qix1QkFBQyxVQUFNLCtCQUFJQyxLQUFLLEdBQUVDLFlBQVksS0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBO0FBQUE7QUFBQSxVQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpREE7QUFBQTtBQUFBO0FBQUEsSUF0RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBdUZBO0FBRUo7QUFBQzVELEdBdE91QkQsUUFBTTtBQUFBLFVBTTVCckIsT0FBTztBQUFBO0FBQUFtRixNQU5lOUQ7QUFBTSxJQUFBRCxJQUFBK0Q7QUFBQUMsYUFBQWhFLElBQUE7QUFBQWdFLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VSZWYiLCJ1c2VDYWxsYmFjayIsInVzZUdTQVAiLCJnc2FwIiwiUFJPRklMRV9JTUFHRV9VUkwiLCJURUNIX0JBREdFUyIsIkZMT0FUSU5HX1NIQVBFUyIsInNyYyIsImZpbmFsWCIsImZpbmFsWSIsInNpemUiLCJkZWxheSIsIkJhcmNvZGUiLCJiYXJzIiwiaSIsInciLCJNYXRoIiwicmFuZG9tIiwiaCIsInB1c2giLCJ3aWR0aCIsImhlaWdodCIsIl9jIiwiSGVyb0lEIiwiX3MiLCJzZWN0aW9uUmVmIiwiY2FyZFJlZiIsInNoYXBlc1JlbGVhc2VkUmVmIiwiZmxvYXRpbmdUd2VlbnNSZWYiLCJmcm9tIiwiY3VycmVudCIsInkiLCJvcGFjaXR5Iiwic2NhbGUiLCJkdXJhdGlvbiIsImVhc2UiLCJ0byIsInJlcGVhdCIsInlveW8iLCJzZXQiLCJ4UGVyY2VudCIsInlQZXJjZW50Iiwicm90YXRpb24iLCJzY29wZSIsInJlbGVhc2VTaGFwZXMiLCJmb3JFYWNoIiwidCIsImtpbGwiLCJzaGFwZXMiLCJ1dGlscyIsInRvQXJyYXkiLCJlbCIsImRhdGEiLCJyYW5kb21PZmZzZXRYIiwicmFuZG9tT2Zmc2V0WSIsIngiLCJvbkNvbXBsZXRlIiwiZmxvYXRYIiwicmV0cmFjdFNoYXBlcyIsImhhbmRsZU1vdXNlTW92ZSIsImUiLCJyZWN0IiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwieFBvcyIsImNsaWVudFgiLCJsZWZ0IiwieVBvcyIsImNsaWVudFkiLCJ0b3AiLCJyb3RhdGVZIiwicm90YXRlWCIsInRyYW5zZm9ybVBlcnNwZWN0aXZlIiwiaGFuZGxlTW91c2VMZWF2ZSIsIm1hcCIsInNoYXBlIiwicG9zaXRpb24iLCJ6SW5kZXgiLCJwb2ludGVyRXZlbnRzIiwid2lsbENoYW5nZSIsIm9iamVjdEZpdCIsImZpbHRlciIsInRyYW5zZm9ybVN0eWxlIiwidGVjaCIsIkRhdGUiLCJnZXRGdWxsWWVhciIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIZXJvSUQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJlZiwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VHU0FQIH0gZnJvbSAnQGdzYXAvcmVhY3QnO1xuaW1wb3J0IGdzYXAgZnJvbSAnZ3NhcCc7XG5cbmNvbnN0IFBST0ZJTEVfSU1BR0VfVVJMID0gXCIvaW1hZ2UucG5nXCI7XG5cbmNvbnN0IFRFQ0hfQkFER0VTID0gWydSZWFjdC5qcycsICdTcHJpbmcgQm9vdCcsICdOZXh0LmpzJywgJ1RhaWx3aW5kIENTUycsICdGaWdtYSddO1xuXG4vLyA2IGltYWdlIHNoYXBlcyDigJQgcG9zaXRpb25lZDogc2hhcGUxIHRvcC1sZWZ0IOKGkiBzaGFwZTYgYm90dG9tLXJpZ2h0XG5jb25zdCBGTE9BVElOR19TSEFQRVMgPSBbXG4gIHsgc3JjOiAnL3NoYXBlcy9zaGFwZTEucG5nJywgZmluYWxYOiAtMzUwLCBmaW5hbFk6IC0yMjAsIHNpemU6IDE0MCwgZGVsYXk6IDAgfSxcbiAgeyBzcmM6ICcvc2hhcGVzL3NoYXBlMi5wbmcnLCBmaW5hbFg6IDMyMCwgZmluYWxZOiAtMjAwLCBzaXplOiAxMjAsIGRlbGF5OiAwLjA4IH0sXG4gIHsgc3JjOiAnL3NoYXBlcy9TaGFwZTMucG5nJywgZmluYWxYOiAtMzgwLCBmaW5hbFk6IDQwLCBzaXplOiAxMTAsIGRlbGF5OiAwLjE2IH0sXG4gIHsgc3JjOiAnL3NoYXBlcy9zaGFwZTQucG5nJywgZmluYWxYOiAzNjAsIGZpbmFsWTogNTAsIHNpemU6IDEyMCwgZGVsYXk6IDAuMjQgfSxcbiAgeyBzcmM6ICcvc2hhcGVzL3NoYXBlNS5wbmcnLCBmaW5hbFg6IC0zMDAsIGZpbmFsWTogMjIwLCBzaXplOiAxMTAsIGRlbGF5OiAwLjMyIH0sXG4gIHsgc3JjOiAnL3NoYXBlcy9zaGFwZTYucG5nJywgZmluYWxYOiAzMDAsIGZpbmFsWTogMjMwLCBzaXplOiAxNDAsIGRlbGF5OiAwLjQwIH0sXG5dO1xuXG4vLyBCYXJjb2RlIGdlbmVyYXRvclxuZnVuY3Rpb24gQmFyY29kZSgpIHtcbiAgY29uc3QgYmFycyA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDQwOyBpKyspIHtcbiAgICBjb25zdCB3ID0gTWF0aC5yYW5kb20oKSA+IDAuNSA/IDMgOiAyO1xuICAgIGNvbnN0IGggPSAyNCArIE1hdGgucmFuZG9tKCkgKiAxMjtcbiAgICBiYXJzLnB1c2goPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJpZC1jYXJkX19iYXJjb2RlLWJhclwiIHN0eWxlPXt7IHdpZHRoOiB3LCBoZWlnaHQ6IGggfX0gLz4pO1xuICB9XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLVsxcHhdIGp1c3RpZnktY2VudGVyXCI+e2JhcnN9PC9kaXY+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIZXJvSUQoKSB7XG4gIGNvbnN0IHNlY3Rpb25SZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBjYXJkUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3Qgc2hhcGVzUmVsZWFzZWRSZWYgPSB1c2VSZWYoZmFsc2UpO1xuICBjb25zdCBmbG9hdGluZ1R3ZWVuc1JlZiA9IHVzZVJlZjxnc2FwLmNvcmUuVHdlZW5bXT4oW10pO1xuXG4gIHVzZUdTQVAoKCkgPT4ge1xuICAgIC8vIENhcmQgZW50cmFuY2VcbiAgICBnc2FwLmZyb20oY2FyZFJlZi5jdXJyZW50LCB7XG4gICAgICB5OiA4MCxcbiAgICAgIG9wYWNpdHk6IDAsXG4gICAgICBzY2FsZTogMC45LFxuICAgICAgZHVyYXRpb246IDEuMixcbiAgICAgIGVhc2U6ICdwb3dlcjQub3V0JyxcbiAgICAgIGRlbGF5OiAwLjIsXG4gICAgfSk7XG5cbiAgICAvLyBDb250aW51b3VzIGNhcmQgZmxvYXRcbiAgICBnc2FwLnRvKGNhcmRSZWYuY3VycmVudCwge1xuICAgICAgeTogLTEwLFxuICAgICAgZHVyYXRpb246IDIuNSxcbiAgICAgIHJlcGVhdDogLTEsXG4gICAgICB5b3lvOiB0cnVlLFxuICAgICAgZWFzZTogJ3NpbmUuaW5PdXQnLFxuICAgIH0pO1xuXG4gICAgLy8gSW5pdGlhbGl6ZSBhbGwgc2hhcGVzOiBoaWRkZW4gYXQgY2VudGVyIG9mIGNhcmRcbiAgICBnc2FwLnNldCgnLmhlcm8tZmxvYXQtaWNvbicsIHtcbiAgICAgIHhQZXJjZW50OiAtNTAsXG4gICAgICB5UGVyY2VudDogLTUwLFxuICAgICAgc2NhbGU6IDAsXG4gICAgICBvcGFjaXR5OiAwLFxuICAgICAgcm90YXRpb246IDAsXG4gICAgfSk7XG4gIH0sIHsgc2NvcGU6IHNlY3Rpb25SZWYgfSk7XG5cbiAgY29uc3QgcmVsZWFzZVNoYXBlcyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAoc2hhcGVzUmVsZWFzZWRSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIHNoYXBlc1JlbGVhc2VkUmVmLmN1cnJlbnQgPSB0cnVlO1xuXG4gICAgLy8gS2lsbCBhbnkgcmV0cmFjdCB0d2VlbnMgdGhhdCBtaWdodCBiZSBydW5uaW5nXG4gICAgZmxvYXRpbmdUd2VlbnNSZWYuY3VycmVudC5mb3JFYWNoKHQgPT4gdC5raWxsKCkpO1xuICAgIGZsb2F0aW5nVHdlZW5zUmVmLmN1cnJlbnQgPSBbXTtcblxuICAgIGNvbnN0IHNoYXBlcyA9IGdzYXAudXRpbHMudG9BcnJheTxIVE1MRWxlbWVudD4oJy5oZXJvLWZsb2F0LWljb24nKTtcblxuICAgIHNoYXBlcy5mb3JFYWNoKChlbCwgaSkgPT4ge1xuICAgICAgY29uc3QgZGF0YSA9IEZMT0FUSU5HX1NIQVBFU1tpXTtcbiAgICAgIGlmICghZGF0YSkgcmV0dXJuO1xuXG4gICAgICAvLyBSYW5kb20gb2Zmc2V0IHNvIHRoZXkgZG9uJ3QgYWxsIGdvIHRvIHRoZSBleGFjdCBzYW1lIHNwb3RcbiAgICAgIGNvbnN0IHJhbmRvbU9mZnNldFggPSBnc2FwLnV0aWxzLnJhbmRvbSgtNDAsIDQwKTtcbiAgICAgIGNvbnN0IHJhbmRvbU9mZnNldFkgPSBnc2FwLnV0aWxzLnJhbmRvbSgtMzAsIDMwKTtcblxuICAgICAgLy8gQnVyc3Qgb3V0IGZyb20gY2VudGVyIHdpdGggc3RhZ2dlclxuICAgICAgZ3NhcC50byhlbCwge1xuICAgICAgICB4OiBkYXRhLmZpbmFsWCArIHJhbmRvbU9mZnNldFgsXG4gICAgICAgIHk6IGRhdGEuZmluYWxZICsgcmFuZG9tT2Zmc2V0WSxcbiAgICAgICAgc2NhbGU6IDEsXG4gICAgICAgIG9wYWNpdHk6IDEsXG4gICAgICAgIHJvdGF0aW9uOiBnc2FwLnV0aWxzLnJhbmRvbSgtMjUsIDI1KSxcbiAgICAgICAgZHVyYXRpb246IDEuMixcbiAgICAgICAgZGVsYXk6IGRhdGEuZGVsYXksXG4gICAgICAgIGVhc2U6ICdiYWNrLm91dCgxLjIpJyxcbiAgICAgICAgb25Db21wbGV0ZTogKCkgPT4ge1xuICAgICAgICAgIC8vIFN0YXJ0IGNvbnRpbnVvdXMgYm91bmNpbmcgLyBmbG9hdGluZyBtb3Rpb25cbiAgICAgICAgICBjb25zdCBmbG9hdFggPSBnc2FwLnRvKGVsLCB7XG4gICAgICAgICAgICB4OiBgKz0ke2dzYXAudXRpbHMucmFuZG9tKC04MCwgODApfWAsXG4gICAgICAgICAgICB5OiBgKz0ke2dzYXAudXRpbHMucmFuZG9tKC02MCwgNjApfWAsXG4gICAgICAgICAgICByb3RhdGlvbjogYCs9JHtnc2FwLnV0aWxzLnJhbmRvbSgtMzAsIDMwKX1gLFxuICAgICAgICAgICAgZHVyYXRpb246IGdzYXAudXRpbHMucmFuZG9tKDMsIDUpLFxuICAgICAgICAgICAgcmVwZWF0OiAtMSxcbiAgICAgICAgICAgIHlveW86IHRydWUsXG4gICAgICAgICAgICBlYXNlOiAnc2luZS5pbk91dCcsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZmxvYXRpbmdUd2VlbnNSZWYuY3VycmVudC5wdXNoKGZsb2F0WCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgcmV0cmFjdFNoYXBlcyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAoIXNoYXBlc1JlbGVhc2VkUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBzaGFwZXNSZWxlYXNlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG5cbiAgICAvLyBLaWxsIGFsbCBmbG9hdGluZyB0d2VlbnNcbiAgICBmbG9hdGluZ1R3ZWVuc1JlZi5jdXJyZW50LmZvckVhY2godCA9PiB0LmtpbGwoKSk7XG4gICAgZmxvYXRpbmdUd2VlbnNSZWYuY3VycmVudCA9IFtdO1xuXG4gICAgY29uc3Qgc2hhcGVzID0gZ3NhcC51dGlscy50b0FycmF5PEhUTUxFbGVtZW50PignLmhlcm8tZmxvYXQtaWNvbicpO1xuXG4gICAgc2hhcGVzLmZvckVhY2goKGVsLCBpKSA9PiB7XG4gICAgICBjb25zdCBkYXRhID0gRkxPQVRJTkdfU0hBUEVTW2ldO1xuICAgICAgaWYgKCFkYXRhKSByZXR1cm47XG5cbiAgICAgIC8vIFNtb290aGx5IHJldHJhY3QgYmFjayB0byBjZW50ZXIgKGJlaGluZCB0aGUgY2FyZClcbiAgICAgIGdzYXAudG8oZWwsIHtcbiAgICAgICAgeDogMCxcbiAgICAgICAgeTogMCxcbiAgICAgICAgc2NhbGU6IDAsXG4gICAgICAgIG9wYWNpdHk6IDAsXG4gICAgICAgIHJvdGF0aW9uOiAwLFxuICAgICAgICBkdXJhdGlvbjogMC44LFxuICAgICAgICBkZWxheTogaSAqIDAuMDQsXG4gICAgICAgIGVhc2U6ICdwb3dlcjMuaW4nLFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sIFtdKTtcblxuICAvLyBNb3VzZSBwYXJhbGxheFxuICBjb25zdCBoYW5kbGVNb3VzZU1vdmUgPSAoZTogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xuICAgIGlmICghc2VjdGlvblJlZi5jdXJyZW50KSByZXR1cm47XG4gICAgY29uc3QgcmVjdCA9IHNlY3Rpb25SZWYuY3VycmVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCB4UG9zID0gKGUuY2xpZW50WCAtIHJlY3QubGVmdCkgLyByZWN0LndpZHRoIC0gMC41O1xuICAgIGNvbnN0IHlQb3MgPSAoZS5jbGllbnRZIC0gcmVjdC50b3ApIC8gcmVjdC5oZWlnaHQgLSAwLjU7XG5cbiAgICBnc2FwLnRvKGNhcmRSZWYuY3VycmVudCwge1xuICAgICAgeDogeFBvcyAqIDMwLFxuICAgICAgeTogLTEwICsgeVBvcyAqIDIwLFxuICAgICAgcm90YXRlWTogeFBvcyAqIDgsXG4gICAgICByb3RhdGVYOiAteVBvcyAqIDgsXG4gICAgICBkdXJhdGlvbjogMSxcbiAgICAgIGVhc2U6ICdwb3dlcjMub3V0JyxcbiAgICAgIHRyYW5zZm9ybVBlcnNwZWN0aXZlOiAxMjAwLFxuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU1vdXNlTGVhdmUgPSAoKSA9PiB7XG4gICAgZ3NhcC50byhjYXJkUmVmLmN1cnJlbnQsIHtcbiAgICAgIHg6IDAsXG4gICAgICByb3RhdGVZOiAwLFxuICAgICAgcm90YXRlWDogMCxcbiAgICAgIGR1cmF0aW9uOiAxLjUsXG4gICAgICBlYXNlOiAnZWxhc3RpYy5vdXQoMSwgMC41KScsXG4gICAgfSk7XG5cbiAgICAvLyBSZXRyYWN0IHNoYXBlcyB3aGVuIGN1cnNvciBsZWF2ZXMgdGhlIGhlcm8gc2VjdGlvblxuICAgIHJldHJhY3RTaGFwZXMoKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uXG4gICAgICByZWY9e3NlY3Rpb25SZWZ9XG4gICAgICBpZD1cImhlcm9cIlxuICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWluLWgtc2NyZWVuIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWhpZGRlblwiXG4gICAgICBvbk1vdXNlTW92ZT17aGFuZGxlTW91c2VNb3ZlfVxuICAgICAgb25Nb3VzZUxlYXZlPXtoYW5kbGVNb3VzZUxlYXZlfVxuICAgID5cbiAgICAgIHsvKiBGbG9hdGluZyBpbWFnZSBzaGFwZXMg4oCUIHBvc2l0aW9uZWQgYXQgY2VudGVyLCBoaWRkZW4gdW50aWwgY2FyZCBob3ZlciAqL31cbiAgICAgIHtGTE9BVElOR19TSEFQRVMubWFwKChzaGFwZSwgaSkgPT4gKFxuICAgICAgICA8ZGl2XG4gICAgICAgICAga2V5PXtpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImhlcm8tZmxvYXQtaWNvblwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICAgICAgdG9wOiAnNTAlJyxcbiAgICAgICAgICAgIGxlZnQ6ICc1MCUnLFxuICAgICAgICAgICAgekluZGV4OiA1LFxuICAgICAgICAgICAgcG9pbnRlckV2ZW50czogJ25vbmUnLFxuICAgICAgICAgICAgd2lsbENoYW5nZTogJ3RyYW5zZm9ybSwgb3BhY2l0eScsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgIHNyYz17c2hhcGUuc3JjfVxuICAgICAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgICAgIHdpZHRoPXtzaGFwZS5zaXplfVxuICAgICAgICAgICAgaGVpZ2h0PXtzaGFwZS5zaXplfVxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgd2lkdGg6IHNoYXBlLnNpemUsXG4gICAgICAgICAgICAgIGhlaWdodDogc2hhcGUuc2l6ZSxcbiAgICAgICAgICAgICAgb2JqZWN0Rml0OiAnY29udGFpbicsXG4gICAgICAgICAgICAgIGZpbHRlcjogJ2Ryb3Atc2hhZG93KDAgNHB4IDEycHggcmdiYSgwLDAsMCwwLjMpKScsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSl9XG5cbiAgICAgIHsvKiBJRCBDYXJkICovfVxuICAgICAgPGRpdlxuICAgICAgICByZWY9e2NhcmRSZWZ9XG4gICAgICAgIGNsYXNzTmFtZT1cImlkLWNhcmQgcmVsYXRpdmUgei0xMFwiXG4gICAgICAgIHN0eWxlPXt7IHRyYW5zZm9ybVN0eWxlOiAncHJlc2VydmUtM2QnIH19XG4gICAgICAgIG9uTW91c2VFbnRlcj17cmVsZWFzZVNoYXBlc31cbiAgICAgID5cbiAgICAgICAgey8qIE5vdGNoICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlkLWNhcmRfX25vdGNoXCIgLz5cblxuICAgICAgICB7LyogUGhvdG8gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWQtY2FyZF9fcGhvdG8tZnJhbWVcIj5cbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICBzcmM9e1BST0ZJTEVfSU1BR0VfVVJMfVxuICAgICAgICAgICAgYWx0PVwiU2FzdW5kdWwgV2FuYXNpbmdoZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICB7LyogSEVMTE8gc3RpY2tlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS00IGxlZnQtNCBiZy13aGl0ZSB0ZXh0LWJsYWNrIHB4LTMgcHktMSB0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3Qgc2hhZG93LW1kIC1yb3RhdGUtM1wiPlxuICAgICAgICAgICAgSEVMTE9cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE5hbWUgKi99XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJpZC1jYXJkX190aXRsZSB0ZXh0LTJ4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy10aWdodCBtdC0yXCI+XG4gICAgICAgICAgU2FzdW5kdWwgV2FuYXNpbmdoZVxuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJpZC1jYXJkX19zdWJ0aXRsZSB0ZXh0LXhzIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IG10LTFcIj5cbiAgICAgICAgICBbIERlc2lnbmVyIC8gRGV2ZWxvcGVyIF1cbiAgICAgICAgPC9wPlxuXG4gICAgICAgIHsvKiBUZWNoIEJhZGdlcyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtdC00XCI+XG4gICAgICAgICAge1RFQ0hfQkFER0VTLm1hcCh0ZWNoID0+IChcbiAgICAgICAgICAgIDxzcGFuIGtleT17dGVjaH0gY2xhc3NOYW1lPVwiaWQtY2FyZF9fYmFkZ2UgdGV4dC1bMTBweF0gZm9udC1tb25vIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlclwiPlxuICAgICAgICAgICAgICB7dGVjaH1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIERhc2hlZCBzZXBhcmF0b3IgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWQtY2FyZF9fc2VwYXJhdG9yIGJvcmRlci10IGJvcmRlci1kYXNoZWQgbXQtNCBwdC0zXCI+XG4gICAgICAgICAgPEJhcmNvZGUgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpZC1jYXJkX19mb290ZXIgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG10LTMgdGV4dC1bOXB4XSBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPlxuICAgICAgICAgIDxzcGFuPkNPREUgQlkgU0FTVU5EVUzCqTwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj57bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L1dvcmsvU2FzdWR1bC9zYXNhL3Nhc3VuZHVsLXBvcnRmb2xpby9jb21wb25lbnRzL0hlcm9JRC50c3gifQ==