import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/CvModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import QRCode from "/node_modules/.vite/deps/react-qr-code.js?v=5088fc54";
export default function CvModal() {
  _s();
  const [isOpen, setIsOpen] = useState(false);
  const overlayRef = useRef(null);
  const contentRef = useRef(null);
  useEffect(() => {
    if (isOpen) {
      gsap.to(overlayRef.current, { opacity: 1, duration: 0.4, ease: "power2.out", display: "flex" });
      gsap.fromTo(
        contentRef.current,
        { y: 50, opacity: 0, scale: 0.95 },
        { y: 0, opacity: 1, scale: 1, duration: 0.5, ease: "back.out(1.5)", delay: 0.1 }
      );
    } else {
      gsap.to(contentRef.current, { y: 20, opacity: 0, scale: 0.95, duration: 0.3, ease: "power2.in" });
      gsap.to(overlayRef.current, { opacity: 0, duration: 0.4, ease: "power2.in", onComplete: () => {
        if (overlayRef.current) overlayRef.current.style.display = "none";
      } });
    }
  }, [isOpen]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => setIsOpen(true),
        className: "fixed bottom-8 left-8 z-30 px-6 py-3 bg-white text-black font-mono text-sm tracking-widest uppercase rounded-full shadow-2xl hover:scale-105 transition-transform cursor-pointer",
        children: "Get CV"
      },
      void 0,
      false,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
        lineNumber: 27,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        ref: overlayRef,
        className: "fixed inset-0 z-50 hidden items-center justify-center bg-black/60 backdrop-blur-md",
        onClick: () => setIsOpen(false),
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            ref: contentRef,
            className: "relative flex flex-col items-center gap-8 p-10 bg-[#0d0d0d] border border-white/10 rounded-3xl shadow-2xl",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setIsOpen(false),
                  className: "absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors",
                  children: "✕"
                },
                void 0,
                false,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                  lineNumber: 46,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-medium tracking-widest text-white", children: "SCAN FOR CV" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                lineNumber: 53,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row gap-8 items-center", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs tracking-widest uppercase opacity-60 font-mono text-white", children: "QR Code" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                    lineNumber: 58,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white rounded-xl shadow-inner", children: /* @__PURE__ */ jsxDEV(QRCode, { value: "https://tinyurl.com/3c4vevb9", size: 160 }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                    lineNumber: 60,
                    columnNumber: 17
                  }, this) }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                    lineNumber: 59,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                  lineNumber: 57,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center gap-3 w-48", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs tracking-widest uppercase opacity-60 font-mono text-white text-center", children: "or Download directly" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                    lineNumber: 66,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "a",
                    {
                      href: "https://www.dropbox.com/scl/fi/qn0un34g4gtqh03ip6aqo/Sasundul_Wanasinghe_Outcome_Based_CV.pdf?rlkey=lydcz8ke4k2rhxzdl742e3gfk&st=va4vb2xi&dl=1",
                      className: "w-full py-4 bg-white/10 hover:bg-white text-white hover:text-black transition-colors rounded-xl font-mono text-sm tracking-widest uppercase flex items-center justify-center gap-2 border border-white/20 hover:border-transparent",
                      children: [
                        /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" }, void 0, false, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                          lineNumber: 72,
                          columnNumber: 19
                        }, this) }, void 0, false, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                          lineNumber: 71,
                          columnNumber: 17
                        }, this),
                        "Download PDF"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                      lineNumber: 67,
                      columnNumber: 15
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                  lineNumber: 65,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
                lineNumber: 55,
                columnNumber: 11
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
            lineNumber: 40,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
        lineNumber: 35,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx",
    lineNumber: 25,
    columnNumber: 5
  }, this);
}
_s(CvModal, "lGg/5dFIAandM6/u6mfeoQ62Cxw=");
_c = CvModal;
var _c;
$RefreshReg$(_c, "CvModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CvModal.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JJLG1CQUVFLGNBRkY7O0FBeEJKLFNBQVNBLFVBQVVDLFFBQVFDLGlCQUFpQjtBQUM1QyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLFlBQVk7QUFDbkIsd0JBQXdCQyxVQUFVO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlSLFNBQVMsS0FBSztBQUMxQyxRQUFNUyxhQUFhUixPQUF1QixJQUFJO0FBQzlDLFFBQU1TLGFBQWFULE9BQXVCLElBQUk7QUFFOUNDLFlBQVUsTUFBTTtBQUNkLFFBQUlLLFFBQVE7QUFDVkosV0FBS1EsR0FBR0YsV0FBV0csU0FBUyxFQUFFQyxTQUFTLEdBQUdDLFVBQVUsS0FBS0MsTUFBTSxjQUFjQyxTQUFTLE9BQU8sQ0FBQztBQUM5RmIsV0FBS2M7QUFBQUEsUUFBT1AsV0FBV0U7QUFBQUEsUUFDckIsRUFBRU0sR0FBRyxJQUFJTCxTQUFTLEdBQUdNLE9BQU8sS0FBSztBQUFBLFFBQ2pDLEVBQUVELEdBQUcsR0FBR0wsU0FBUyxHQUFHTSxPQUFPLEdBQUdMLFVBQVUsS0FBS0MsTUFBTSxpQkFBaUJLLE9BQU8sSUFBSTtBQUFBLE1BQ2pGO0FBQUEsSUFDRixPQUFPO0FBQ0xqQixXQUFLUSxHQUFHRCxXQUFXRSxTQUFTLEVBQUVNLEdBQUcsSUFBSUwsU0FBUyxHQUFHTSxPQUFPLE1BQU1MLFVBQVUsS0FBS0MsTUFBTSxZQUFZLENBQUM7QUFDaEdaLFdBQUtRLEdBQUdGLFdBQVdHLFNBQVMsRUFBRUMsU0FBUyxHQUFHQyxVQUFVLEtBQUtDLE1BQU0sYUFBYU0sWUFBWUEsTUFBTTtBQUM1RixZQUFJWixXQUFXRyxRQUFTSCxZQUFXRyxRQUFRVSxNQUFNTixVQUFVO0FBQUEsTUFDN0QsRUFBRSxDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0YsR0FBRyxDQUFDVCxNQUFNLENBQUM7QUFFWCxTQUNFLG1DQUVFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsTUFBTUMsVUFBVSxJQUFJO0FBQUEsUUFDN0IsV0FBVTtBQUFBLFFBQWtMO0FBQUE7QUFBQSxNQUY5TDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLEtBQUtDO0FBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNRCxVQUFVLEtBQUs7QUFBQSxRQUU5QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsS0FBS0U7QUFBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixTQUFTLENBQUNhLE1BQU1BLEVBQUVDLGdCQUFnQjtBQUFBLFlBR2xDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNaEIsVUFBVSxLQUFLO0FBQUEsa0JBQzlCLFdBQVU7QUFBQSxrQkFBeUk7QUFBQTtBQUFBLGdCQUZySjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUEsdUJBQUMsUUFBRyxXQUFVLGtEQUFpRCwyQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQSxjQUUxRSx1QkFBQyxTQUFJLFdBQVUsZ0RBRWI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUscUVBQW9FLHVCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRjtBQUFBLGtCQUMzRix1QkFBQyxTQUFJLFdBQVUsd0NBQ2IsaUNBQUMsVUFBTyxPQUFNLGdDQUErQixNQUFNLE9BQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVELEtBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLGlGQUFnRixvQ0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0g7QUFBQSxrQkFDcEg7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFBWSxPQUFNLDhCQUNuRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLG9FQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxSSxLQUR2STtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQUs7QUFBQTtBQUFBO0FBQUEsb0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVFBO0FBQUEscUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLG1CQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBO0FBQUE7QUFBQSxVQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFzQ0E7QUFBQTtBQUFBLE1BM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRDQTtBQUFBLE9BdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1REE7QUFFSjtBQUFDRixHQTlFdUJELFNBQU87QUFBQW9CLEtBQVBwQjtBQUFPLElBQUFvQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJnc2FwIiwiUVJDb2RlIiwiQ3ZNb2RhbCIsIl9zIiwiaXNPcGVuIiwic2V0SXNPcGVuIiwib3ZlcmxheVJlZiIsImNvbnRlbnRSZWYiLCJ0byIsImN1cnJlbnQiLCJvcGFjaXR5IiwiZHVyYXRpb24iLCJlYXNlIiwiZGlzcGxheSIsImZyb21UbyIsInkiLCJzY2FsZSIsImRlbGF5Iiwib25Db21wbGV0ZSIsInN0eWxlIiwiZSIsInN0b3BQcm9wYWdhdGlvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkN2TW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBnc2FwIGZyb20gJ2dzYXAnO1xuaW1wb3J0IFFSQ29kZSBmcm9tICdyZWFjdC1xci1jb2RlJztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEN2TW9kYWwoKSB7XG4gIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IG92ZXJsYXlSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBjb250ZW50UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc09wZW4pIHtcbiAgICAgIGdzYXAudG8ob3ZlcmxheVJlZi5jdXJyZW50LCB7IG9wYWNpdHk6IDEsIGR1cmF0aW9uOiAwLjQsIGVhc2U6ICdwb3dlcjIub3V0JywgZGlzcGxheTogJ2ZsZXgnIH0pO1xuICAgICAgZ3NhcC5mcm9tVG8oY29udGVudFJlZi5jdXJyZW50LCBcbiAgICAgICAgeyB5OiA1MCwgb3BhY2l0eTogMCwgc2NhbGU6IDAuOTUgfSxcbiAgICAgICAgeyB5OiAwLCBvcGFjaXR5OiAxLCBzY2FsZTogMSwgZHVyYXRpb246IDAuNSwgZWFzZTogJ2JhY2sub3V0KDEuNSknLCBkZWxheTogMC4xIH1cbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGdzYXAudG8oY29udGVudFJlZi5jdXJyZW50LCB7IHk6IDIwLCBvcGFjaXR5OiAwLCBzY2FsZTogMC45NSwgZHVyYXRpb246IDAuMywgZWFzZTogJ3Bvd2VyMi5pbicgfSk7XG4gICAgICBnc2FwLnRvKG92ZXJsYXlSZWYuY3VycmVudCwgeyBvcGFjaXR5OiAwLCBkdXJhdGlvbjogMC40LCBlYXNlOiAncG93ZXIyLmluJywgb25Db21wbGV0ZTogKCkgPT4ge1xuICAgICAgICBpZiAob3ZlcmxheVJlZi5jdXJyZW50KSBvdmVybGF5UmVmLmN1cnJlbnQuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgIH0gfSk7XG4gICAgfVxuICB9LCBbaXNPcGVuXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgey8qIEZsb2F0aW5nIEFjdGlvbiBCdXR0b24gKi99XG4gICAgICA8YnV0dG9uXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzT3Blbih0cnVlKX1cbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgYm90dG9tLTggbGVmdC04IHotMzAgcHgtNiBweS0zIGJnLXdoaXRlIHRleHQtYmxhY2sgZm9udC1tb25vIHRleHQtc20gdHJhY2tpbmctd2lkZXN0IHVwcGVyY2FzZSByb3VuZGVkLWZ1bGwgc2hhZG93LTJ4bCBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgPlxuICAgICAgICBHZXQgQ1ZcbiAgICAgIDwvYnV0dG9uPlxuXG4gICAgICB7LyogTW9kYWwgT3ZlcmxheSAqL31cbiAgICAgIDxkaXYgXG4gICAgICAgIHJlZj17b3ZlcmxheVJlZn1cbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGhpZGRlbiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNjAgYmFja2Ryb3AtYmx1ci1tZFwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzT3BlbihmYWxzZSl9XG4gICAgICA+XG4gICAgICAgIDxkaXYgXG4gICAgICAgICAgcmVmPXtjb250ZW50UmVmfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC04IHAtMTAgYmctWyMwZDBkMGRdIGJvcmRlciBib3JkZXItd2hpdGUvMTAgcm91bmRlZC0zeGwgc2hhZG93LTJ4bFwiXG4gICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICAgID5cbiAgICAgICAgICB7LyogQ2xvc2UgQnV0dG9uICovfVxuICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc09wZW4oZmFsc2UpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCB3LTggaC04IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy13aGl0ZS8xMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLXdoaXRlLzIwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDinJVcbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtbWVkaXVtIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXdoaXRlXCI+U0NBTiBGT1IgQ1Y8L2gzPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGdhcC04IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgey8qIFFSIENvZGUgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdHJhY2tpbmctd2lkZXN0IHVwcGVyY2FzZSBvcGFjaXR5LTYwIGZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+UVIgQ29kZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgICAgICA8UVJDb2RlIHZhbHVlPVwiaHR0cHM6Ly90aW55dXJsLmNvbS8zYzR2ZXZiOVwiIHNpemU9ezE2MH0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIERpcmVjdCBEb3dubG9hZCBCdXR0b24gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHctNDhcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlIG9wYWNpdHktNjAgZm9udC1tb25vIHRleHQtd2hpdGUgdGV4dC1jZW50ZXJcIj5vciBEb3dubG9hZCBkaXJlY3RseTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGEgXG4gICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vd3d3LmRyb3Bib3guY29tL3NjbC9maS9xbjB1bjM0ZzRndHFoMDNpcDZhcW8vU2FzdW5kdWxfV2FuYXNpbmdoZV9PdXRjb21lX0Jhc2VkX0NWLnBkZj9ybGtleT1seWRjejhrZTRrMnJoeHpkbDc0MmUzZ2ZrJnN0PXZhNHZiMnhpJmRsPTFcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS00IGJnLXdoaXRlLzEwIGhvdmVyOmJnLXdoaXRlIHRleHQtd2hpdGUgaG92ZXI6dGV4dC1ibGFjayB0cmFuc2l0aW9uLWNvbG9ycyByb3VuZGVkLXhsIGZvbnQtbW9ubyB0ZXh0LXNtIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2UgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgYm9yZGVyIGJvcmRlci13aGl0ZS8yMCBob3Zlcjpib3JkZXItdHJhbnNwYXJlbnRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTQgMTZ2MWEzIDMgMCAwMDMgM2gxMGEzIDMgMCAwMDMtM3YtMW0tNC00bC00IDRtMCAwbC00LTRtNCA0VjRcIiAvPlxuICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgIERvd25sb2FkIFBERlxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovV29yay9TYXN1ZHVsL3Nhc2Evc2FzdW5kdWwtcG9ydGZvbGlvL2NvbXBvbmVudHMvQ3ZNb2RhbC50c3gifQ==