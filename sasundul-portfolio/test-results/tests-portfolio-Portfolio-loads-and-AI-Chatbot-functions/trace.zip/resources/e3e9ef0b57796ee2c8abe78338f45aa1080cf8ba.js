import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Navigation.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Sun, Moon } from "/node_modules/.vite/deps/lucide-react.js?v=5088fc54";
export default function Navigation({ isOpen, onToggle, theme, onThemeToggle, onNavigate }) {
  const navItems = [
    { label: "Home", section: "hero" },
    { label: "What I Make", section: "work" },
    { label: "Let's Talk", section: "contact" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { "data-nav-open": isOpen ? "true" : "false", children: [
    isOpen && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "fixed inset-0 z-[998] bg-black/30 transition-opacity",
        onClick: onToggle
      },
      void 0,
      false,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
        lineNumber: 22,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "nav__panel-bg" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "nav__panel", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-mono uppercase tracking-widest mb-6", style: { color: "var(--text-muted)" }, children: "Menu" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "space-y-4", children: [
        navItems.map(
          (item) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                onNavigate(item.section);
                onToggle();
              },
              className: "flex items-center justify-between w-full group",
              children: [
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: "text-xl font-display font-semibold uppercase tracking-wide transition-opacity hover:opacity-60",
                    style: { color: "var(--text)" },
                    children: item.label
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
                    lineNumber: 41,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full opacity-0 group-hover:opacity-25 transition-opacity", style: { background: "var(--text)" } }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
                  lineNumber: 47,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
              lineNumber: 37,
              columnNumber: 15
            },
            this
          ) }, item.section, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
            lineNumber: 36,
            columnNumber: 11
          }, this)
        ),
        /* @__PURE__ */ jsxDEV("li", { className: "pt-2", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: onThemeToggle,
            className: "p-2 rounded-full transition-colors",
            style: { color: "var(--text)" },
            "aria-label": "Toggle theme",
            children: theme === "light" ? /* @__PURE__ */ jsxDEV(Sun, { size: 20 }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
              lineNumber: 58,
              columnNumber: 36
            }, this) : /* @__PURE__ */ jsxDEV(Moon, { size: 20 }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
              lineNumber: 58,
              columnNumber: 56
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
            lineNumber: 52,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
          lineNumber: 51,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "nav__toggle", onClick: onToggle, "aria-label": "Toggle menu", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "nav__toggle-bar" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "nav__toggle-bar" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx",
    lineNumber: 19,
    columnNumber: 5
  }, this);
}
_c = Navigation;
var _c;
$RefreshReg$(_c, "Navigation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Navigation.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJRO0FBckJSLFNBQVNBLEtBQUtDLFlBQVk7QUFVMUIsd0JBQXdCQyxXQUFXLEVBQUVDLFFBQVFDLFVBQVVDLE9BQU9DLGVBQWVDLFdBQTRCLEdBQUc7QUFDMUcsUUFBTUMsV0FBVztBQUFBLElBQ2YsRUFBRUMsT0FBTyxRQUFRQyxTQUFTLE9BQU87QUFBQSxJQUNqQyxFQUFFRCxPQUFPLGVBQWVDLFNBQVMsT0FBTztBQUFBLElBQ3hDLEVBQUVELE9BQU8sY0FBY0MsU0FBUyxVQUFVO0FBQUEsRUFBQztBQUc3QyxTQUNFLHVCQUFDLFNBQUksaUJBQWVQLFNBQVMsU0FBUyxTQUVuQ0E7QUFBQUEsY0FDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsU0FBU0M7QUFBQUE7QUFBQUEsTUFGWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFb0I7QUFBQSxJQUt0Qix1QkFBQyxTQUFJLFdBQVUsbUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QjtBQUFBLElBRzlCLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLG9EQUFtRCxPQUFPLEVBQUVPLE9BQU8sb0JBQW9CLEdBQUcsb0JBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkc7QUFBQSxNQUMzRyx1QkFBQyxRQUFHLFdBQVUsYUFDWEg7QUFBQUEsaUJBQVNJO0FBQUFBLFVBQUksQ0FBQ0MsU0FDYix1QkFBQyxRQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFBRU4sMkJBQVdNLEtBQUtILE9BQU87QUFBR04seUJBQVM7QUFBQSxjQUFHO0FBQUEsY0FDdkQsV0FBVTtBQUFBLGNBRVY7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxFQUFFTyxPQUFPLGNBQWM7QUFBQSxvQkFFN0JFLGVBQUtKO0FBQUFBO0FBQUFBLGtCQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSw0RUFBMkUsT0FBTyxFQUFFSyxZQUFZLGNBQWMsS0FBOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0k7QUFBQTtBQUFBO0FBQUEsWUFWbEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0EsS0FaT0QsS0FBS0gsU0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsUUFDRDtBQUFBLFFBQ0QsdUJBQUMsUUFBRyxXQUFVLFFBQ1o7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNKO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQ1YsT0FBTyxFQUFFSyxPQUFPLGNBQWM7QUFBQSxZQUM5QixjQUFXO0FBQUEsWUFFVk4sb0JBQVUsVUFBVSx1QkFBQyxPQUFJLE1BQU0sTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjLElBQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZTtBQUFBO0FBQUEsVUFOMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsU0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLElBR0EsdUJBQUMsWUFBTyxXQUFVLGVBQWMsU0FBU0QsVUFBVSxjQUFXLGVBQzVEO0FBQUEsNkJBQUMsVUFBSyxXQUFVLHFCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsVUFBSyxXQUFVLHFCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsU0FGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtEQTtBQUVKO0FBQUNXLEtBNUR1QmI7QUFBVSxJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiU3VuIiwiTW9vbiIsIk5hdmlnYXRpb24iLCJpc09wZW4iLCJvblRvZ2dsZSIsInRoZW1lIiwib25UaGVtZVRvZ2dsZSIsIm9uTmF2aWdhdGUiLCJuYXZJdGVtcyIsImxhYmVsIiwic2VjdGlvbiIsImNvbG9yIiwibWFwIiwiaXRlbSIsImJhY2tncm91bmQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOYXZpZ2F0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdW4sIE1vb24gfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xyXG5cclxuaW50ZXJmYWNlIE5hdmlnYXRpb25Qcm9wcyB7XHJcbiAgaXNPcGVuOiBib29sZWFuO1xyXG4gIG9uVG9nZ2xlOiAoKSA9PiB2b2lkO1xyXG4gIHRoZW1lOiAnbGlnaHQnIHwgJ2RhcmsnO1xyXG4gIG9uVGhlbWVUb2dnbGU6ICgpID0+IHZvaWQ7XHJcbiAgb25OYXZpZ2F0ZTogKHNlY3Rpb246IHN0cmluZykgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTmF2aWdhdGlvbih7IGlzT3Blbiwgb25Ub2dnbGUsIHRoZW1lLCBvblRoZW1lVG9nZ2xlLCBvbk5hdmlnYXRlIH06IE5hdmlnYXRpb25Qcm9wcykge1xyXG4gIGNvbnN0IG5hdkl0ZW1zID0gW1xyXG4gICAgeyBsYWJlbDogJ0hvbWUnLCBzZWN0aW9uOiAnaGVybycgfSxcclxuICAgIHsgbGFiZWw6ICdXaGF0IEkgTWFrZScsIHNlY3Rpb246ICd3b3JrJyB9LFxyXG4gICAgeyBsYWJlbDogXCJMZXQncyBUYWxrXCIsIHNlY3Rpb246ICdjb250YWN0JyB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGRhdGEtbmF2LW9wZW49e2lzT3BlbiA/ICd0cnVlJyA6ICdmYWxzZSd9PlxyXG4gICAgICB7LyogRGFyayBvdmVybGF5ICovfVxyXG4gICAgICB7aXNPcGVuICYmIChcclxuICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OThdIGJnLWJsYWNrLzMwIHRyYW5zaXRpb24tb3BhY2l0eVwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtvblRvZ2dsZX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIFBhbmVsIGJhY2tncm91bmQgKHNjYWxlcyBmcm9tIHRvZ2dsZSBwb3NpdGlvbikgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmF2X19wYW5lbC1iZ1wiIC8+XHJcblxyXG4gICAgICB7LyogUGFuZWwgY29udGVudCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXZfX3BhbmVsXCI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBtYi02XCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScgfX0+TWVudTwvcD5cclxuICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICB7bmF2SXRlbXMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgIDxsaSBrZXk9e2l0ZW0uc2VjdGlvbn0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBvbk5hdmlnYXRlKGl0ZW0uc2VjdGlvbik7IG9uVG9nZ2xlKCk7IH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIGdyb3VwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWRpc3BsYXkgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0cmFuc2l0aW9uLW9wYWNpdHkgaG92ZXI6b3BhY2l0eS02MFwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tdGV4dCknIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMjUgdHJhbnNpdGlvbi1vcGFjaXR5XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXRleHQpJyB9fSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwicHQtMlwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b25UaGVtZVRvZ2dsZX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQpJyB9fVxyXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgdGhlbWVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3RoZW1lID09PSAnbGlnaHQnID8gPFN1biBzaXplPXsyMH0gLz4gOiA8TW9vbiBzaXplPXsyMH0gLz59XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9saT5cclxuICAgICAgICA8L3VsPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBUb2dnbGUgYnV0dG9uICovfVxyXG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cIm5hdl9fdG9nZ2xlXCIgb25DbGljaz17b25Ub2dnbGV9IGFyaWEtbGFiZWw9XCJUb2dnbGUgbWVudVwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm5hdl9fdG9nZ2xlLWJhclwiIC8+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibmF2X190b2dnbGUtYmFyXCIgLz5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiRDovV29yay9TYXN1ZHVsL3Nhc2Evc2FzdW5kdWwtcG9ydGZvbGlvL2NvbXBvbmVudHMvTmF2aWdhdGlvbi50c3gifQ==