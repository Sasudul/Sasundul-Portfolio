import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/PixelBlast.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Effect, EffectComposer, EffectPass, RenderPass } from "/node_modules/.vite/deps/postprocessing.js?v=5088fc54";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"];
import * as THREE from "/node_modules/.vite/deps/three.js?v=5088fc54";
import "/components/PixelBlast.css";
const createTouchTexture = () => {
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("2D context not available");
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  const texture = new THREE.Texture(canvas);
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = false;
  const trail = [];
  let last = null;
  const maxAge = 64;
  let radius = 0.1 * size;
  const speed = 1 / maxAge;
  const clear = () => {
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };
  const drawPoint = (p) => {
    const pos = { x: p.x * size, y: (1 - p.y) * size };
    let intensity = 1;
    const easeOutSine = (t) => Math.sin(t * Math.PI / 2);
    const easeOutQuad = (t) => -t * (t - 2);
    if (p.age < maxAge * 0.3) intensity = easeOutSine(p.age / (maxAge * 0.3));
    else
      intensity = easeOutQuad(1 - (p.age - maxAge * 0.3) / (maxAge * 0.7)) || 0;
    intensity *= p.force;
    const color = `${(p.vx + 1) / 2 * 255}, ${(p.vy + 1) / 2 * 255}, ${intensity * 255}`;
    const offset = size * 5;
    ctx.shadowOffsetX = offset;
    ctx.shadowOffsetY = offset;
    ctx.shadowBlur = radius;
    ctx.shadowColor = `rgba(${color},${0.22 * intensity})`;
    ctx.beginPath();
    ctx.fillStyle = "rgba(255,0,0,1)";
    ctx.arc(pos.x - offset, pos.y - offset, radius, 0, Math.PI * 2);
    ctx.fill();
  };
  const addTouch = (norm) => {
    let force = 0;
    let vx = 0;
    let vy = 0;
    if (last) {
      const dx = norm.x - last.x;
      const dy = norm.y - last.y;
      if (dx === 0 && dy === 0) return;
      const dd = dx * dx + dy * dy;
      const d = Math.sqrt(dd);
      vx = dx / (d || 1);
      vy = dy / (d || 1);
      force = Math.min(dd * 1e4, 1);
    }
    last = { x: norm.x, y: norm.y };
    trail.push({ x: norm.x, y: norm.y, age: 0, force, vx, vy });
  };
  const update = () => {
    clear();
    for (let i = trail.length - 1; i >= 0; i--) {
      const point = trail[i];
      const f = point.force * speed * (1 - point.age / maxAge);
      point.x += point.vx * f;
      point.y += point.vy * f;
      point.age++;
      if (point.age > maxAge) trail.splice(i, 1);
    }
    for (let i = 0; i < trail.length; i++) drawPoint(trail[i]);
    texture.needsUpdate = true;
  };
  return {
    canvas,
    texture,
    addTouch,
    update,
    set radiusScale(v) {
      radius = 0.1 * size * v;
    },
    get radiusScale() {
      return radius / (0.1 * size);
    },
    size
  };
};
const createLiquidEffect = (texture, opts) => {
  const fragment = `
    uniform sampler2D uTexture;
    uniform float uStrength;
    uniform float uTime;
    uniform float uFreq;

    void mainUv(inout vec2 uv) {
      vec4 tex = texture2D(uTexture, uv);
      float vx = tex.r * 2.0 - 1.0;
      float vy = tex.g * 2.0 - 1.0;
      float intensity = tex.b;

      float wave = 0.5 + 0.5 * sin(uTime * uFreq + intensity * 6.2831853);

      float amt = uStrength * intensity * wave;

      uv += vec2(vx, vy) * amt;
    }
    `;
  return new Effect("LiquidEffect", fragment, {
    uniforms: /* @__PURE__ */ new Map(
      [
        ["uTexture", new THREE.Uniform(texture)],
        ["uStrength", new THREE.Uniform(opts?.strength ?? 0.025)],
        ["uTime", new THREE.Uniform(0)],
        ["uFreq", new THREE.Uniform(opts?.freq ?? 4.5)]
      ]
    )
  });
};
const SHAPE_MAP = {
  square: 0,
  circle: 1,
  triangle: 2,
  diamond: 3
};
const VERTEX_SRC = `
void main() {
  gl_Position = vec4(position, 1.0);
}
`;
const FRAGMENT_SRC = `
precision highp float;

uniform vec3  uColor;
uniform vec2  uResolution;
uniform float uTime;
uniform float uPixelSize;
uniform float uScale;
uniform float uDensity;
uniform float uPixelJitter;
uniform int   uEnableRipples;
uniform float uRippleSpeed;
uniform float uRippleThickness;
uniform float uRippleIntensity;
uniform float uEdgeFade;

uniform int   uShapeType;
const int SHAPE_SQUARE   = 0;
const int SHAPE_CIRCLE   = 1;
const int SHAPE_TRIANGLE = 2;
const int SHAPE_DIAMOND  = 3;

const int   MAX_CLICKS = 10;

uniform vec2  uClickPos  [MAX_CLICKS];
uniform float uClickTimes[MAX_CLICKS];

out vec4 fragColor;

float Bayer2(vec2 a) {
  a = floor(a);
  return fract(a.x / 2. + a.y * a.y * .75);
}
#define Bayer4(a) (Bayer2(.5*(a))*0.25 + Bayer2(a))
#define Bayer8(a) (Bayer4(.5*(a))*0.25 + Bayer2(a))

#define FBM_OCTAVES     5
#define FBM_LACUNARITY  1.25
#define FBM_GAIN        1.0

float hash11(float n){ return fract(sin(n)*43758.5453); }

float vnoise(vec3 p){
  vec3 ip = floor(p);
  vec3 fp = fract(p);
  float n000 = hash11(dot(ip + vec3(0.0,0.0,0.0), vec3(1.0,57.0,113.0)));
  float n100 = hash11(dot(ip + vec3(1.0,0.0,0.0), vec3(1.0,57.0,113.0)));
  float n010 = hash11(dot(ip + vec3(0.0,1.0,0.0), vec3(1.0,57.0,113.0)));
  float n110 = hash11(dot(ip + vec3(1.0,1.0,0.0), vec3(1.0,57.0,113.0)));
  float n001 = hash11(dot(ip + vec3(0.0,0.0,1.0), vec3(1.0,57.0,113.0)));
  float n101 = hash11(dot(ip + vec3(1.0,0.0,1.0), vec3(1.0,57.0,113.0)));
  float n011 = hash11(dot(ip + vec3(0.0,1.0,1.0), vec3(1.0,57.0,113.0)));
  float n111 = hash11(dot(ip + vec3(1.0,1.0,1.0), vec3(1.0,57.0,113.0)));
  vec3 w = fp*fp*fp*(fp*(fp*6.0-15.0)+10.0);
  float x00 = mix(n000, n100, w.x);
  float x10 = mix(n010, n110, w.x);
  float x01 = mix(n001, n101, w.x);
  float x11 = mix(n011, n111, w.x);
  float y0  = mix(x00, x10, w.y);
  float y1  = mix(x01, x11, w.y);
  return mix(y0, y1, w.z) * 2.0 - 1.0;
}

float fbm2(vec2 uv, float t){
  vec3 p = vec3(uv * uScale, t);
  float amp = 1.0;
  float freq = 1.0;
  float sum = 1.0;
  for (int i = 0; i < FBM_OCTAVES; ++i){
    sum  += amp * vnoise(p * freq);
    freq *= FBM_LACUNARITY;
    amp  *= FBM_GAIN;
  }
  return sum * 0.5 + 0.5;
}

float maskCircle(vec2 p, float cov){
  float r = sqrt(cov) * .25;
  float d = length(p - 0.5) - r;
  float aa = 0.5 * fwidth(d);
  return cov * (1.0 - smoothstep(-aa, aa, d * 2.0));
}

float maskTriangle(vec2 p, vec2 id, float cov){
  bool flip = mod(id.x + id.y, 2.0) > 0.5;
  if (flip) p.x = 1.0 - p.x;
  float r = sqrt(cov);
  float d  = p.y - r*(1.0 - p.x);
  float aa = fwidth(d);
  return cov * clamp(0.5 - d/aa, 0.0, 1.0);
}

float maskDiamond(vec2 p, float cov){
  float r = sqrt(cov) * 0.564;
  return step(abs(p.x - 0.49) + abs(p.y - 0.49), r);
}

void main(){
  float pixelSize = uPixelSize;
  vec2 fragCoord = gl_FragCoord.xy - uResolution * .5;
  float aspectRatio = uResolution.x / uResolution.y;

  vec2 pixelId = floor(fragCoord / pixelSize);
  vec2 pixelUV = fract(fragCoord / pixelSize);

  float cellPixelSize = 8.0 * pixelSize;
  vec2 cellId = floor(fragCoord / cellPixelSize);
  vec2 cellCoord = cellId * cellPixelSize;
  vec2 uv = cellCoord / uResolution * vec2(aspectRatio, 1.0);

  float base = fbm2(uv, uTime * 0.05);
  base = base * 0.5 - 0.65;

  float feed = base + (uDensity - 0.5) * 0.3;

  float speed     = uRippleSpeed;
  float thickness = uRippleThickness;
  const float dampT     = 1.0;
  const float dampR     = 10.0;

  if (uEnableRipples == 1) {
    for (int i = 0; i < MAX_CLICKS; ++i){
      vec2 pos = uClickPos[i];
      if (pos.x < 0.0) continue;
      float cellPixelSize = 8.0 * pixelSize;
      vec2 cuv = (((pos - uResolution * .5 - cellPixelSize * .5) / (uResolution))) * vec2(aspectRatio, 1.0);
      float t = max(uTime - uClickTimes[i], 0.0);
      float r = distance(uv, cuv);
      float waveR = speed * t;
      float ring  = exp(-pow((r - waveR) / thickness, 2.0));
      float atten = exp(-dampT * t) * exp(-dampR * r);
      feed = max(feed, ring * atten * uRippleIntensity);
    }
  }

  float bayer = Bayer8(fragCoord / uPixelSize) - 0.5;
  float bw = step(0.5, feed + bayer);

  float h = fract(sin(dot(floor(fragCoord / uPixelSize), vec2(127.1, 311.7))) * 43758.5453);
  float jitterScale = 1.0 + (h - 0.5) * uPixelJitter;
  float coverage = bw * jitterScale;
  float M;
  if      (uShapeType == SHAPE_CIRCLE)   M = maskCircle (pixelUV, coverage);
  else if (uShapeType == SHAPE_TRIANGLE) M = maskTriangle(pixelUV, pixelId, coverage);
  else if (uShapeType == SHAPE_DIAMOND)  M = maskDiamond(pixelUV, coverage);
  else                                   M = coverage;

  if (uEdgeFade > 0.0) {
    vec2 norm = gl_FragCoord.xy / uResolution;
    float edge = min(min(norm.x, norm.y), min(1.0 - norm.x, 1.0 - norm.y));
    float fade = smoothstep(0.0, uEdgeFade, edge);
    M *= fade;
  }

  vec3 color = uColor;

  // sRGB gamma correction - convert linear to sRGB for accurate color output
  vec3 srgbColor = mix(
    color * 12.92,
    1.055 * pow(color, vec3(1.0 / 2.4)) - 0.055,
    step(0.0031308, color)
  );

  fragColor = vec4(srgbColor, M);
}
`;
const MAX_CLICKS = 10;
const PixelBlast = ({
  variant = "square",
  pixelSize = 3,
  color = "#B497CF",
  className,
  style,
  antialias = true,
  patternScale = 2.5,
  patternDensity = 1,
  liquid = false,
  liquidStrength = 0.1,
  liquidRadius = 1,
  pixelSizeJitter = 0,
  enableRipples = true,
  rippleIntensityScale = 1,
  rippleThickness = 0.1,
  rippleSpeed = 0.3,
  liquidWobbleSpeed = 4.5,
  autoPauseOffscreen = true,
  speed = 0.5,
  transparent = true,
  edgeFade = 0.5,
  noiseAmount = 0
}) => {
  _s();
  const containerRef = useRef(null);
  const visibilityRef = useRef({ visible: true });
  const speedRef = useRef(speed);
  const threeRef = useRef(null);
  const prevConfigRef = useRef(null);
  useEffect(
    () => {
      const container = containerRef.current;
      if (!container) return;
      speedRef.current = speed;
      const needsReinitKeys = ["antialias", "liquid", "noiseAmount"];
      const cfg = { antialias, liquid, noiseAmount };
      let mustReinit = false;
      if (!threeRef.current) mustReinit = true;
      else if (prevConfigRef.current) {
        for (const k of needsReinitKeys)
          if (prevConfigRef.current[k] !== cfg[k]) {
            mustReinit = true;
            break;
          }
      }
      if (mustReinit) {
        if (threeRef.current) {
          const t = threeRef.current;
          t.resizeObserver?.disconnect();
          cancelAnimationFrame(t.raf);
          t.quad?.geometry.dispose();
          t.material.dispose();
          t.composer?.dispose();
          t.renderer.dispose();
          t.renderer.forceContextLoss();
          if (t.renderer.domElement.parentElement === container) container.removeChild(t.renderer.domElement);
          threeRef.current = null;
        }
        const canvas = document.createElement("canvas");
        const renderer = new THREE.WebGLRenderer({
          canvas,
          antialias,
          alpha: true,
          powerPreference: "high-performance"
        });
        renderer.domElement.style.width = "100%";
        renderer.domElement.style.height = "100%";
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        container.appendChild(renderer.domElement);
        if (transparent) renderer.setClearAlpha(0);
        else
          renderer.setClearColor(0, 1);
        const uniforms = {
          uResolution: { value: new THREE.Vector2(0, 0) },
          uTime: { value: 0 },
          uColor: { value: new THREE.Color(color) },
          uClickPos: {
            value: Array.from({ length: MAX_CLICKS }, () => new THREE.Vector2(-1, -1))
          },
          uClickTimes: { value: new Float32Array(MAX_CLICKS) },
          uShapeType: { value: SHAPE_MAP[variant] ?? 0 },
          uPixelSize: { value: pixelSize * renderer.getPixelRatio() },
          uScale: { value: patternScale },
          uDensity: { value: patternDensity },
          uPixelJitter: { value: pixelSizeJitter },
          uEnableRipples: { value: enableRipples ? 1 : 0 },
          uRippleSpeed: { value: rippleSpeed },
          uRippleThickness: { value: rippleThickness },
          uRippleIntensity: { value: rippleIntensityScale },
          uEdgeFade: { value: edgeFade }
        };
        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        const material = new THREE.ShaderMaterial({
          vertexShader: VERTEX_SRC,
          fragmentShader: FRAGMENT_SRC,
          uniforms,
          transparent: true,
          depthTest: false,
          depthWrite: false,
          glslVersion: THREE.GLSL3
        });
        const quadGeom = new THREE.PlaneGeometry(2, 2);
        const quad = new THREE.Mesh(quadGeom, material);
        scene.add(quad);
        const clock = new THREE.Clock();
        const setSize = () => {
          const w = container.clientWidth || 1;
          const h = container.clientHeight || 1;
          renderer.setSize(w, h, false);
          uniforms.uResolution.value.set(renderer.domElement.width, renderer.domElement.height);
          if (threeRef.current?.composer)
            threeRef.current.composer.setSize(renderer.domElement.width, renderer.domElement.height);
          uniforms.uPixelSize.value = pixelSize * renderer.getPixelRatio();
        };
        setSize();
        const ro = new ResizeObserver(setSize);
        ro.observe(container);
        const randomFloat = () => {
          if (typeof window !== "undefined" && window.crypto?.getRandomValues) {
            const u32 = new Uint32Array(1);
            window.crypto.getRandomValues(u32);
            return u32[0] / 4294967295;
          }
          return Math.random();
        };
        const timeOffset = randomFloat() * 1e3;
        let composer;
        let touch;
        let liquidEffect;
        if (liquid) {
          touch = createTouchTexture();
          touch.radiusScale = liquidRadius;
          composer = new EffectComposer(renderer);
          const renderPass = new RenderPass(scene, camera);
          liquidEffect = createLiquidEffect(touch.texture, {
            strength: liquidStrength,
            freq: liquidWobbleSpeed
          });
          const effectPass = new EffectPass(camera, liquidEffect);
          effectPass.renderToScreen = true;
          composer.addPass(renderPass);
          composer.addPass(effectPass);
        }
        if (noiseAmount > 0) {
          if (!composer) {
            composer = new EffectComposer(renderer);
            composer.addPass(new RenderPass(scene, camera));
          }
          const noiseEffect = new Effect(
            "NoiseEffect",
            `uniform float uTime; uniform float uAmount; float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7))) * 43758.5453);} void mainUv(inout vec2 uv){} void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){ float n=hash(floor(uv*vec2(1920.0,1080.0))+floor(uTime*60.0)); float g=(n-0.5)*uAmount; outputColor=inputColor+vec4(vec3(g),0.0);} `,
            {
              uniforms: /* @__PURE__ */ new Map(
                [
                  ["uTime", new THREE.Uniform(0)],
                  ["uAmount", new THREE.Uniform(noiseAmount)]
                ]
              )
            }
          );
          const noisePass = new EffectPass(camera, noiseEffect);
          noisePass.renderToScreen = true;
          if (composer && composer.passes.length > 0) composer.passes.forEach((p) => p.renderToScreen = false);
          composer.addPass(noisePass);
        }
        if (composer) composer.setSize(renderer.domElement.width, renderer.domElement.height);
        const mapToPixels = (e) => {
          const rect = renderer.domElement.getBoundingClientRect();
          const scaleX = renderer.domElement.width / rect.width;
          const scaleY = renderer.domElement.height / rect.height;
          const fx = (e.clientX - rect.left) * scaleX;
          const fy = (rect.height - (e.clientY - rect.top)) * scaleY;
          return {
            fx,
            fy,
            w: renderer.domElement.width,
            h: renderer.domElement.height
          };
        };
        const onPointerDown = (e) => {
          const { fx, fy } = mapToPixels(e);
          const ix = threeRef.current?.clickIx ?? 0;
          uniforms.uClickPos.value[ix].set(fx, fy);
          uniforms.uClickTimes.value[ix] = uniforms.uTime.value;
          if (threeRef.current) threeRef.current.clickIx = (ix + 1) % MAX_CLICKS;
        };
        const onPointerMove = (e) => {
          if (!touch) return;
          const { fx, fy, w, h } = mapToPixels(e);
          touch.addTouch({ x: fx / w, y: fy / h });
        };
        renderer.domElement.addEventListener("pointerdown", onPointerDown, {
          passive: true
        });
        renderer.domElement.addEventListener("pointermove", onPointerMove, {
          passive: true
        });
        let raf = 0;
        const animate = () => {
          if (autoPauseOffscreen && !visibilityRef.current.visible) {
            raf = requestAnimationFrame(animate);
            return;
          }
          uniforms.uTime.value = timeOffset + clock.getElapsedTime() * speedRef.current;
          if (liquidEffect) liquidEffect.uniforms.get("uTime").value = uniforms.uTime.value;
          if (composer) {
            if (touch) touch.update();
            composer.passes.forEach((p) => {
              const effs = p.effects;
              if (effs)
                effs.forEach((eff) => {
                  const u = eff.uniforms?.get("uTime");
                  if (u) u.value = uniforms.uTime.value;
                });
            });
            composer.render();
          } else renderer.render(scene, camera);
          raf = requestAnimationFrame(animate);
        };
        raf = requestAnimationFrame(animate);
        threeRef.current = {
          renderer,
          scene,
          camera,
          material,
          clock,
          clickIx: 0,
          uniforms,
          resizeObserver: ro,
          raf,
          quad,
          timeOffset,
          composer,
          touch,
          liquidEffect
        };
      } else {
        const t = threeRef.current;
        t.uniforms.uShapeType.value = SHAPE_MAP[variant] ?? 0;
        t.uniforms.uPixelSize.value = pixelSize * t.renderer.getPixelRatio();
        t.uniforms.uColor.value.set(color);
        t.uniforms.uScale.value = patternScale;
        t.uniforms.uDensity.value = patternDensity;
        t.uniforms.uPixelJitter.value = pixelSizeJitter;
        t.uniforms.uEnableRipples.value = enableRipples ? 1 : 0;
        t.uniforms.uRippleIntensity.value = rippleIntensityScale;
        t.uniforms.uRippleThickness.value = rippleThickness;
        t.uniforms.uRippleSpeed.value = rippleSpeed;
        t.uniforms.uEdgeFade.value = edgeFade;
        if (transparent) t.renderer.setClearAlpha(0);
        else
          t.renderer.setClearColor(0, 1);
        if (t.liquidEffect) {
          const uStrength = t.liquidEffect;
          if (uStrength) uStrength.value = liquidStrength;
          const uFreq = t.liquidEffect.uniforms.get("uFreq");
          if (uFreq) uFreq.value = liquidWobbleSpeed;
        }
        if (t.touch) t.touch.radiusScale = liquidRadius;
      }
      prevConfigRef.current = cfg;
      return () => {
        if (threeRef.current && mustReinit) return;
        if (!threeRef.current) return;
        const t = threeRef.current;
        t.resizeObserver?.disconnect();
        cancelAnimationFrame(t.raf);
        t.quad?.geometry.dispose();
        t.material.dispose();
        t.composer?.dispose();
        t.renderer.dispose();
        t.renderer.forceContextLoss();
        if (t.renderer.domElement.parentElement === container) container.removeChild(t.renderer.domElement);
        threeRef.current = null;
      };
    },
    [
      antialias,
      liquid,
      noiseAmount,
      pixelSize,
      patternScale,
      patternDensity,
      enableRipples,
      rippleIntensityScale,
      rippleThickness,
      rippleSpeed,
      pixelSizeJitter,
      edgeFade,
      transparent,
      liquidStrength,
      liquidRadius,
      liquidWobbleSpeed,
      autoPauseOffscreen,
      variant,
      color,
      speed
    ]
  );
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: containerRef,
      className: `pixel-blast-container ${className ?? ""}`,
      style,
      "aria-label": "PixelBlast interactive background"
    },
    void 0,
    false,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/PixelBlast.tsx",
      lineNumber: 601,
      columnNumber: 5
    },
    this
  );
};
_s(PixelBlast, "4/F70/x0+L7nAfXxnp+Tig683DM=");
_c = PixelBlast;
export default PixelBlast;
var _c;
$RefreshReg$(_c, "PixelBlast");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/PixelBlast.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/PixelBlast.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/PixelBlast.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd2xCSTs7QUF4bEJKLFNBQVNBLFFBQVFDLGdCQUFnQkMsWUFBWUMsa0JBQWtCO0FBQy9ELFNBQVNDLFdBQVdDLGNBQWM7QUFDbEMsWUFBWUMsV0FBVztBQUN2QixPQUFPO0FBRVAsTUFBTUMscUJBQXFCQSxNQUFNO0FBQy9CLFFBQU1DLE9BQU87QUFDYixRQUFNQyxTQUFTQyxTQUFTQyxjQUFjLFFBQVE7QUFDOUNGLFNBQU9HLFFBQVFKO0FBQ2ZDLFNBQU9JLFNBQVNMO0FBQ2hCLFFBQU1NLE1BQU1MLE9BQU9NLFdBQVcsSUFBSTtBQUNsQyxNQUFJLENBQUNELElBQUssT0FBTSxJQUFJRSxNQUFNLDBCQUEwQjtBQUNwREYsTUFBSUcsWUFBWTtBQUNoQkgsTUFBSUksU0FBUyxHQUFHLEdBQUdULE9BQU9HLE9BQU9ILE9BQU9JLE1BQU07QUFDOUMsUUFBTU0sVUFBVSxJQUFJYixNQUFNYyxRQUFRWCxNQUFNO0FBQ3hDVSxVQUFRRSxZQUFZZixNQUFNZ0I7QUFDMUJILFVBQVFJLFlBQVlqQixNQUFNZ0I7QUFDMUJILFVBQVFLLGtCQUFrQjtBQUMxQixRQUFNQyxRQUFlO0FBQ3JCLE1BQUlDLE9BQVk7QUFDaEIsUUFBTUMsU0FBUztBQUNmLE1BQUlDLFNBQVMsTUFBTXBCO0FBQ25CLFFBQU1xQixRQUFRLElBQUlGO0FBQ2xCLFFBQU1HLFFBQVFBLE1BQU07QUFDbEJoQixRQUFJRyxZQUFZO0FBQ2hCSCxRQUFJSSxTQUFTLEdBQUcsR0FBR1QsT0FBT0csT0FBT0gsT0FBT0ksTUFBTTtBQUFBLEVBQ2hEO0FBQ0EsUUFBTWtCLFlBQVlBLENBQUNDLE1BQVc7QUFDNUIsVUFBTUMsTUFBTSxFQUFFQyxHQUFHRixFQUFFRSxJQUFJMUIsTUFBTTJCLElBQUksSUFBSUgsRUFBRUcsS0FBSzNCLEtBQUs7QUFDakQsUUFBSTRCLFlBQVk7QUFDaEIsVUFBTUMsY0FBY0EsQ0FBQ0MsTUFBY0MsS0FBS0MsSUFBS0YsSUFBSUMsS0FBS0UsS0FBTSxDQUFDO0FBQzdELFVBQU1DLGNBQWNBLENBQUNKLE1BQWMsQ0FBQ0EsS0FBS0EsSUFBSTtBQUM3QyxRQUFJTixFQUFFVyxNQUFNaEIsU0FBUyxJQUFLUyxhQUFZQyxZQUFZTCxFQUFFVyxPQUFPaEIsU0FBUyxJQUFJO0FBQUE7QUFDbkVTLGtCQUFZTSxZQUFZLEtBQUtWLEVBQUVXLE1BQU1oQixTQUFTLFFBQVFBLFNBQVMsSUFBSSxLQUFLO0FBQzdFUyxpQkFBYUosRUFBRVk7QUFDZixVQUFNQyxRQUFRLElBQUtiLEVBQUVjLEtBQUssS0FBSyxJQUFLLEdBQUcsTUFBT2QsRUFBRWUsS0FBSyxLQUFLLElBQUssR0FBRyxLQUFLWCxZQUFZLEdBQUc7QUFDdEYsVUFBTVksU0FBU3hDLE9BQU87QUFDdEJNLFFBQUltQyxnQkFBZ0JEO0FBQ3BCbEMsUUFBSW9DLGdCQUFnQkY7QUFDcEJsQyxRQUFJcUMsYUFBYXZCO0FBQ2pCZCxRQUFJc0MsY0FBYyxRQUFRUCxLQUFLLElBQUksT0FBT1QsU0FBUztBQUNuRHRCLFFBQUl1QyxVQUFVO0FBQ2R2QyxRQUFJRyxZQUFZO0FBQ2hCSCxRQUFJd0MsSUFBSXJCLElBQUlDLElBQUljLFFBQVFmLElBQUlFLElBQUlhLFFBQVFwQixRQUFRLEdBQUdXLEtBQUtFLEtBQUssQ0FBQztBQUM5RDNCLFFBQUl5QyxLQUFLO0FBQUEsRUFDWDtBQUNBLFFBQU1DLFdBQVdBLENBQUNDLFNBQWM7QUFDOUIsUUFBSWIsUUFBUTtBQUNaLFFBQUlFLEtBQUs7QUFDVCxRQUFJQyxLQUFLO0FBQ1QsUUFBSXJCLE1BQU07QUFDUixZQUFNZ0MsS0FBS0QsS0FBS3ZCLElBQUlSLEtBQUtRO0FBQ3pCLFlBQU15QixLQUFLRixLQUFLdEIsSUFBSVQsS0FBS1M7QUFDekIsVUFBSXVCLE9BQU8sS0FBS0MsT0FBTyxFQUFHO0FBQzFCLFlBQU1DLEtBQUtGLEtBQUtBLEtBQUtDLEtBQUtBO0FBQzFCLFlBQU1FLElBQUl0QixLQUFLdUIsS0FBS0YsRUFBRTtBQUN0QmQsV0FBS1ksTUFBTUcsS0FBSztBQUNoQmQsV0FBS1ksTUFBTUUsS0FBSztBQUNoQmpCLGNBQVFMLEtBQUt3QixJQUFJSCxLQUFLLEtBQU8sQ0FBQztBQUFBLElBQ2hDO0FBQ0FsQyxXQUFPLEVBQUVRLEdBQUd1QixLQUFLdkIsR0FBR0MsR0FBR3NCLEtBQUt0QixFQUFFO0FBQzlCVixVQUFNdUMsS0FBSyxFQUFFOUIsR0FBR3VCLEtBQUt2QixHQUFHQyxHQUFHc0IsS0FBS3RCLEdBQUdRLEtBQUssR0FBR0MsT0FBT0UsSUFBSUMsR0FBRyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxRQUFNa0IsU0FBU0EsTUFBTTtBQUNuQm5DLFVBQU07QUFDTixhQUFTb0MsSUFBSXpDLE1BQU0wQyxTQUFTLEdBQUdELEtBQUssR0FBR0EsS0FBSztBQUMxQyxZQUFNRSxRQUFRM0MsTUFBTXlDLENBQUM7QUFDckIsWUFBTUcsSUFBSUQsTUFBTXhCLFFBQVFmLFNBQVMsSUFBSXVDLE1BQU16QixNQUFNaEI7QUFDakR5QyxZQUFNbEMsS0FBS2tDLE1BQU10QixLQUFLdUI7QUFDdEJELFlBQU1qQyxLQUFLaUMsTUFBTXJCLEtBQUtzQjtBQUN0QkQsWUFBTXpCO0FBQ04sVUFBSXlCLE1BQU16QixNQUFNaEIsT0FBUUYsT0FBTTZDLE9BQU9KLEdBQUcsQ0FBQztBQUFBLElBQzNDO0FBQ0EsYUFBU0EsSUFBSSxHQUFHQSxJQUFJekMsTUFBTTBDLFFBQVFELElBQUtuQyxXQUFVTixNQUFNeUMsQ0FBQyxDQUFDO0FBQ3pEL0MsWUFBUW9ELGNBQWM7QUFBQSxFQUN4QjtBQUNBLFNBQU87QUFBQSxJQUNMOUQ7QUFBQUEsSUFDQVU7QUFBQUEsSUFDQXFDO0FBQUFBLElBQ0FTO0FBQUFBLElBQ0EsSUFBSU8sWUFBWUMsR0FBRztBQUNqQjdDLGVBQVMsTUFBTXBCLE9BQU9pRTtBQUFBQSxJQUN4QjtBQUFBLElBQ0EsSUFBSUQsY0FBYztBQUNoQixhQUFPNUMsVUFBVSxNQUFNcEI7QUFBQUEsSUFDekI7QUFBQSxJQUNBQTtBQUFBQSxFQUNGO0FBQ0Y7QUFFQSxNQUFNa0UscUJBQXFCQSxDQUFDdkQsU0FBY3dELFNBQWM7QUFDdEQsUUFBTUMsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQW1CakIsU0FBTyxJQUFJNUUsT0FBTyxnQkFBZ0I0RSxVQUFVO0FBQUEsSUFDMUNDLFVBQVUsb0JBQUlDO0FBQUFBLE1BQUk7QUFBQSxRQUNoQixDQUFDLFlBQVksSUFBSXhFLE1BQU15RSxRQUFRNUQsT0FBTyxDQUFDO0FBQUEsUUFDdkMsQ0FBQyxhQUFhLElBQUliLE1BQU15RSxRQUFRSixNQUFNSyxZQUFZLEtBQUssQ0FBQztBQUFBLFFBQ3hELENBQUMsU0FBUyxJQUFJMUUsTUFBTXlFLFFBQVEsQ0FBQyxDQUFDO0FBQUEsUUFDOUIsQ0FBQyxTQUFTLElBQUl6RSxNQUFNeUUsUUFBUUosTUFBTU0sUUFBUSxHQUFHLENBQUM7QUFBQSxNQUFDO0FBQUEsSUFDaEQ7QUFBQSxFQUNILENBQUM7QUFDSDtBQUVBLE1BQU1DLFlBQWlCO0FBQUEsRUFDckJDLFFBQVE7QUFBQSxFQUNSQyxRQUFRO0FBQUEsRUFDUkMsVUFBVTtBQUFBLEVBQ1ZDLFNBQVM7QUFDWDtBQUVBLE1BQU1DLGFBQWE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU1uQixNQUFNQyxlQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBdUtyQixNQUFNQyxhQUFhO0FBRW5CLE1BQU1DLGFBQWFBLENBQUM7QUFBQSxFQUNsQkMsVUFBVTtBQUFBLEVBQ1ZDLFlBQVk7QUFBQSxFQUNaL0MsUUFBUTtBQUFBLEVBQ1JnRDtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxZQUFZO0FBQUEsRUFDWkMsZUFBZTtBQUFBLEVBQ2ZDLGlCQUFpQjtBQUFBLEVBQ2pCQyxTQUFTO0FBQUEsRUFDVEMsaUJBQWlCO0FBQUEsRUFDakJDLGVBQWU7QUFBQSxFQUNmQyxrQkFBa0I7QUFBQSxFQUNsQkMsZ0JBQWdCO0FBQUEsRUFDaEJDLHVCQUF1QjtBQUFBLEVBQ3ZCQyxrQkFBa0I7QUFBQSxFQUNsQkMsY0FBYztBQUFBLEVBQ2RDLG9CQUFvQjtBQUFBLEVBQ3BCQyxxQkFBcUI7QUFBQSxFQUNyQjlFLFFBQVE7QUFBQSxFQUNSK0UsY0FBYztBQUFBLEVBQ2RDLFdBQVc7QUFBQSxFQUNYQyxjQUFjO0FBQ1gsTUFBTTtBQUFBQyxLQUFBO0FBQ1QsUUFBTUMsZUFBZTNHLE9BQXVCLElBQUk7QUFDaEQsUUFBTTRHLGdCQUFnQjVHLE9BQU8sRUFBRTZHLFNBQVMsS0FBSyxDQUFDO0FBQzlDLFFBQU1DLFdBQVc5RyxPQUFPd0IsS0FBSztBQUU3QixRQUFNdUYsV0FBVy9HLE9BQVksSUFBSTtBQUNqQyxRQUFNZ0gsZ0JBQWdCaEgsT0FBWSxJQUFJO0FBRXRDRDtBQUFBQSxJQUFVLE1BQU07QUFDZCxZQUFNa0gsWUFBWU4sYUFBYU87QUFDL0IsVUFBSSxDQUFDRCxVQUFXO0FBQ2hCSCxlQUFTSSxVQUFVMUY7QUFDbkIsWUFBTTJGLGtCQUFrQixDQUFDLGFBQWEsVUFBVSxhQUFhO0FBQzdELFlBQU1DLE1BQVcsRUFBRTFCLFdBQVdHLFFBQVFZLFlBQVk7QUFDbEQsVUFBSVksYUFBYTtBQUNqQixVQUFJLENBQUNOLFNBQVNHLFFBQVNHLGNBQWE7QUFBQSxlQUMzQkwsY0FBY0UsU0FBUztBQUM5QixtQkFBV0ksS0FBS0g7QUFDZCxjQUFJSCxjQUFjRSxRQUFRSSxDQUFDLE1BQU1GLElBQUlFLENBQUMsR0FBRztBQUN2Q0QseUJBQWE7QUFDYjtBQUFBLFVBQ0Y7QUFBQSxNQUNKO0FBQ0EsVUFBSUEsWUFBWTtBQUNkLFlBQUlOLFNBQVNHLFNBQVM7QUFDcEIsZ0JBQU1qRixJQUFJOEUsU0FBU0c7QUFDbkJqRixZQUFFc0YsZ0JBQWdCQyxXQUFXO0FBQzdCQywrQkFBcUJ4RixFQUFFeUYsR0FBRztBQUMxQnpGLFlBQUUwRixNQUFNQyxTQUFTQyxRQUFRO0FBQ3pCNUYsWUFBRTZGLFNBQVNELFFBQVE7QUFDbkI1RixZQUFFOEYsVUFBVUYsUUFBUTtBQUNwQjVGLFlBQUUrRixTQUFTSCxRQUFRO0FBQ25CNUYsWUFBRStGLFNBQVNDLGlCQUFpQjtBQUM1QixjQUFJaEcsRUFBRStGLFNBQVNFLFdBQVdDLGtCQUFrQmxCLFVBQVdBLFdBQVVtQixZQUFZbkcsRUFBRStGLFNBQVNFLFVBQVU7QUFDbEduQixtQkFBU0csVUFBVTtBQUFBLFFBQ3JCO0FBQ0EsY0FBTTlHLFNBQVNDLFNBQVNDLGNBQWMsUUFBUTtBQUM5QyxjQUFNMEgsV0FBVyxJQUFJL0gsTUFBTW9JLGNBQWM7QUFBQSxVQUN2Q2pJO0FBQUFBLFVBQ0FzRjtBQUFBQSxVQUNBNEMsT0FBTztBQUFBLFVBQ1BDLGlCQUFpQjtBQUFBLFFBQ25CLENBQUM7QUFDRFAsaUJBQVNFLFdBQVd6QyxNQUFNbEYsUUFBUTtBQUNsQ3lILGlCQUFTRSxXQUFXekMsTUFBTWpGLFNBQVM7QUFDbkN3SCxpQkFBU1EsY0FBY3RHLEtBQUt3QixJQUFJK0UsT0FBT0Msb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO0FBQ2hFekIsa0JBQVUwQixZQUFZWCxTQUFTRSxVQUFVO0FBQ3pDLFlBQUkzQixZQUFheUIsVUFBU1ksY0FBYyxDQUFDO0FBQUE7QUFDcENaLG1CQUFTYSxjQUFjLEdBQVUsQ0FBQztBQUN2QyxjQUFNckUsV0FBVztBQUFBLFVBQ2ZzRSxhQUFhLEVBQUVDLE9BQU8sSUFBSTlJLE1BQU0rSSxRQUFRLEdBQUcsQ0FBQyxFQUFFO0FBQUEsVUFDOUNDLE9BQU8sRUFBRUYsT0FBTyxFQUFFO0FBQUEsVUFDbEJHLFFBQVEsRUFBRUgsT0FBTyxJQUFJOUksTUFBTWtKLE1BQU0zRyxLQUFLLEVBQUU7QUFBQSxVQUN4QzRHLFdBQVc7QUFBQSxZQUNUTCxPQUFPTSxNQUFNQyxLQUFLLEVBQUV4RixRQUFRc0IsV0FBVyxHQUFHLE1BQU0sSUFBSW5GLE1BQU0rSSxRQUFRLElBQUksRUFBRSxDQUFDO0FBQUEsVUFDM0U7QUFBQSxVQUNBTyxhQUFhLEVBQUVSLE9BQU8sSUFBSVMsYUFBYXBFLFVBQVUsRUFBRTtBQUFBLFVBQ25EcUUsWUFBWSxFQUFFVixPQUFPbEUsVUFBVVMsT0FBTyxLQUFLLEVBQUU7QUFBQSxVQUM3Q29FLFlBQVksRUFBRVgsT0FBT3hELFlBQVl5QyxTQUFTMkIsY0FBYyxFQUFFO0FBQUEsVUFDMURDLFFBQVEsRUFBRWIsT0FBT3BELGFBQWE7QUFBQSxVQUM5QmtFLFVBQVUsRUFBRWQsT0FBT25ELGVBQWU7QUFBQSxVQUNsQ2tFLGNBQWMsRUFBRWYsT0FBTy9DLGdCQUFnQjtBQUFBLFVBQ3ZDK0QsZ0JBQWdCLEVBQUVoQixPQUFPOUMsZ0JBQWdCLElBQUksRUFBRTtBQUFBLFVBQy9DK0QsY0FBYyxFQUFFakIsT0FBTzNDLFlBQVk7QUFBQSxVQUNuQzZELGtCQUFrQixFQUFFbEIsT0FBTzVDLGdCQUFnQjtBQUFBLFVBQzNDK0Qsa0JBQWtCLEVBQUVuQixPQUFPN0MscUJBQXFCO0FBQUEsVUFDaERpRSxXQUFXLEVBQUVwQixPQUFPdkMsU0FBUztBQUFBLFFBQy9CO0FBQ0EsY0FBTTRELFFBQVEsSUFBSW5LLE1BQU1vSyxNQUFNO0FBQzlCLGNBQU1DLFNBQVMsSUFBSXJLLE1BQU1zSyxtQkFBbUIsSUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUM7QUFDOUQsY0FBTXpDLFdBQVcsSUFBSTdILE1BQU11SyxlQUFlO0FBQUEsVUFDeENDLGNBQWN2RjtBQUFBQSxVQUNkd0YsZ0JBQWdCdkY7QUFBQUEsVUFDaEJYO0FBQUFBLFVBQ0ErQixhQUFhO0FBQUEsVUFDYm9FLFdBQVc7QUFBQSxVQUNYQyxZQUFZO0FBQUEsVUFDWkMsYUFBYTVLLE1BQU02SztBQUFBQSxRQUNyQixDQUFDO0FBQ0QsY0FBTUMsV0FBVyxJQUFJOUssTUFBTStLLGNBQWMsR0FBRyxDQUFDO0FBQzdDLGNBQU1yRCxPQUFPLElBQUkxSCxNQUFNZ0wsS0FBS0YsVUFBVWpELFFBQVE7QUFDOUNzQyxjQUFNYyxJQUFJdkQsSUFBSTtBQUNkLGNBQU13RCxRQUFRLElBQUlsTCxNQUFNbUwsTUFBTTtBQUM5QixjQUFNQyxVQUFVQSxNQUFNO0FBQ3BCLGdCQUFNQyxJQUFJckUsVUFBVXNFLGVBQWU7QUFDbkMsZ0JBQU1DLElBQUl2RSxVQUFVd0UsZ0JBQWdCO0FBQ3BDekQsbUJBQVNxRCxRQUFRQyxHQUFHRSxHQUFHLEtBQUs7QUFDNUJoSCxtQkFBU3NFLFlBQVlDLE1BQU0yQyxJQUFJMUQsU0FBU0UsV0FBVzNILE9BQU95SCxTQUFTRSxXQUFXMUgsTUFBTTtBQUNwRixjQUFJdUcsU0FBU0csU0FBU2E7QUFDcEJoQixxQkFBU0csUUFBUWEsU0FBU3NELFFBQVFyRCxTQUFTRSxXQUFXM0gsT0FBT3lILFNBQVNFLFdBQVcxSCxNQUFNO0FBQ3pGZ0UsbUJBQVNrRixXQUFXWCxRQUFReEQsWUFBWXlDLFNBQVMyQixjQUFjO0FBQUEsUUFDakU7QUFDQTBCLGdCQUFRO0FBQ1IsY0FBTU0sS0FBSyxJQUFJQyxlQUFlUCxPQUFPO0FBQ3JDTSxXQUFHRSxRQUFRNUUsU0FBUztBQUNwQixjQUFNNkUsY0FBY0EsTUFBTTtBQUN4QixjQUFJLE9BQU9yRCxXQUFXLGVBQWVBLE9BQU9zRCxRQUFRQyxpQkFBaUI7QUFDbkUsa0JBQU1DLE1BQU0sSUFBSUMsWUFBWSxDQUFDO0FBQzdCekQsbUJBQU9zRCxPQUFPQyxnQkFBZ0JDLEdBQUc7QUFDakMsbUJBQU9BLElBQUksQ0FBQyxJQUFJO0FBQUEsVUFDbEI7QUFDQSxpQkFBTy9KLEtBQUtpSyxPQUFPO0FBQUEsUUFDckI7QUFDQSxjQUFNQyxhQUFhTixZQUFZLElBQUk7QUFDbkMsWUFBSS9EO0FBQ0osWUFBSXNFO0FBQ0osWUFBSUM7QUFDSixZQUFJekcsUUFBUTtBQUNWd0csa0JBQVFuTSxtQkFBbUI7QUFDM0JtTSxnQkFBTWxJLGNBQWM0QjtBQUNwQmdDLHFCQUFXLElBQUluSSxlQUFlb0ksUUFBUTtBQUN0QyxnQkFBTXVFLGFBQWEsSUFBSXpNLFdBQVdzSyxPQUFPRSxNQUFNO0FBQy9DZ0MseUJBQWVqSSxtQkFBbUJnSSxNQUFNdkwsU0FBUztBQUFBLFlBQy9DNkQsVUFBVW1CO0FBQUFBLFlBQ1ZsQixNQUFNeUI7QUFBQUEsVUFDUixDQUFDO0FBQ0QsZ0JBQU1tRyxhQUFhLElBQUkzTSxXQUFXeUssUUFBUWdDLFlBQVk7QUFDdERFLHFCQUFXQyxpQkFBaUI7QUFDNUIxRSxtQkFBUzJFLFFBQVFILFVBQVU7QUFDM0J4RSxtQkFBUzJFLFFBQVFGLFVBQVU7QUFBQSxRQUM3QjtBQUNBLFlBQUkvRixjQUFjLEdBQUc7QUFDbkIsY0FBSSxDQUFDc0IsVUFBVTtBQUNiQSx1QkFBVyxJQUFJbkksZUFBZW9JLFFBQVE7QUFDdENELHFCQUFTMkUsUUFBUSxJQUFJNU0sV0FBV3NLLE9BQU9FLE1BQU0sQ0FBQztBQUFBLFVBQ2hEO0FBQ0EsZ0JBQU1xQyxjQUFjLElBQUloTjtBQUFBQSxZQUN0QjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsY0FDRTZFLFVBQVUsb0JBQUlDO0FBQUFBLGdCQUFJO0FBQUEsa0JBQ2hCLENBQUMsU0FBUyxJQUFJeEUsTUFBTXlFLFFBQVEsQ0FBQyxDQUFDO0FBQUEsa0JBQzlCLENBQUMsV0FBVyxJQUFJekUsTUFBTXlFLFFBQVErQixXQUFXLENBQUM7QUFBQSxnQkFBQztBQUFBLGNBQzVDO0FBQUEsWUFDSDtBQUFBLFVBQ0Y7QUFDQSxnQkFBTW1HLFlBQVksSUFBSS9NLFdBQVd5SyxRQUFRcUMsV0FBVztBQUNwREMsb0JBQVVILGlCQUFpQjtBQUMzQixjQUFJMUUsWUFBWUEsU0FBUzhFLE9BQU8vSSxTQUFTLEVBQUdpRSxVQUFTOEUsT0FBT0MsUUFBUSxDQUFDbkwsTUFBWUEsRUFBRThLLGlCQUFpQixLQUFNO0FBQzFHMUUsbUJBQVMyRSxRQUFRRSxTQUFTO0FBQUEsUUFDNUI7QUFDQSxZQUFJN0UsU0FBVUEsVUFBU3NELFFBQVFyRCxTQUFTRSxXQUFXM0gsT0FBT3lILFNBQVNFLFdBQVcxSCxNQUFNO0FBQ3BGLGNBQU11TSxjQUFjQSxDQUFDQyxNQUFXO0FBQzlCLGdCQUFNQyxPQUFPakYsU0FBU0UsV0FBV2dGLHNCQUFzQjtBQUN2RCxnQkFBTUMsU0FBU25GLFNBQVNFLFdBQVczSCxRQUFRME0sS0FBSzFNO0FBQ2hELGdCQUFNNk0sU0FBU3BGLFNBQVNFLFdBQVcxSCxTQUFTeU0sS0FBS3pNO0FBQ2pELGdCQUFNNk0sTUFBTUwsRUFBRU0sVUFBVUwsS0FBS00sUUFBUUo7QUFDckMsZ0JBQU1LLE1BQU1QLEtBQUt6TSxVQUFVd00sRUFBRVMsVUFBVVIsS0FBS1MsUUFBUU47QUFDcEQsaUJBQU87QUFBQSxZQUNMQztBQUFBQSxZQUNBRztBQUFBQSxZQUNBbEMsR0FBR3RELFNBQVNFLFdBQVczSDtBQUFBQSxZQUN2QmlMLEdBQUd4RCxTQUFTRSxXQUFXMUg7QUFBQUEsVUFDekI7QUFBQSxRQUNGO0FBQ0EsY0FBTW1OLGdCQUFnQkEsQ0FBQ1gsTUFBVztBQUNoQyxnQkFBTSxFQUFFSyxJQUFJRyxHQUFHLElBQUlULFlBQVlDLENBQUM7QUFDaEMsZ0JBQU1ZLEtBQUs3RyxTQUFTRyxTQUFTMkcsV0FBVztBQUN4Q3JKLG1CQUFTNEUsVUFBVUwsTUFBTTZFLEVBQUUsRUFBRWxDLElBQUkyQixJQUFJRyxFQUFFO0FBQ3ZDaEosbUJBQVMrRSxZQUFZUixNQUFNNkUsRUFBRSxJQUFJcEosU0FBU3lFLE1BQU1GO0FBQ2hELGNBQUloQyxTQUFTRyxRQUFTSCxVQUFTRyxRQUFRMkcsV0FBV0QsS0FBSyxLQUFLeEk7QUFBQUEsUUFDOUQ7QUFDQSxjQUFNMEksZ0JBQWdCQSxDQUFDZCxNQUFXO0FBQ2hDLGNBQUksQ0FBQ1gsTUFBTztBQUNaLGdCQUFNLEVBQUVnQixJQUFJRyxJQUFJbEMsR0FBR0UsRUFBRSxJQUFJdUIsWUFBWUMsQ0FBQztBQUN0Q1gsZ0JBQU1sSixTQUFTLEVBQUV0QixHQUFHd0wsS0FBSy9CLEdBQUd4SixHQUFHMEwsS0FBS2hDLEVBQUUsQ0FBQztBQUFBLFFBQ3pDO0FBQ0F4RCxpQkFBU0UsV0FBVzZGLGlCQUFpQixlQUFlSixlQUFlO0FBQUEsVUFDakVLLFNBQVM7QUFBQSxRQUNYLENBQUM7QUFDRGhHLGlCQUFTRSxXQUFXNkYsaUJBQWlCLGVBQWVELGVBQWU7QUFBQSxVQUNqRUUsU0FBUztBQUFBLFFBQ1gsQ0FBQztBQUNELFlBQUl0RyxNQUFNO0FBQ1YsY0FBTXVHLFVBQVVBLE1BQU07QUFDcEIsY0FBSTNILHNCQUFzQixDQUFDTSxjQUFjTSxRQUFRTCxTQUFTO0FBQ3hEYSxrQkFBTXdHLHNCQUFzQkQsT0FBTztBQUNuQztBQUFBLFVBQ0Y7QUFDQXpKLG1CQUFTeUUsTUFBTUYsUUFBUXFELGFBQWFqQixNQUFNZ0QsZUFBZSxJQUFJckgsU0FBU0k7QUFDdEUsY0FBSW9GLGFBQWNBLGNBQWE5SCxTQUFTNEosSUFBSSxPQUFPLEVBQUVyRixRQUFRdkUsU0FBU3lFLE1BQU1GO0FBQzVFLGNBQUloQixVQUFVO0FBQ1osZ0JBQUlzRSxNQUFPQSxPQUFNekksT0FBTztBQUN4Qm1FLHFCQUFTOEUsT0FBT0MsUUFBUSxDQUFDbkwsTUFBVztBQUNsQyxvQkFBTTBNLE9BQU8xTSxFQUFFMk07QUFDZixrQkFBSUQ7QUFDRkEscUJBQUt2QixRQUFRLENBQUN5QixRQUFhO0FBQ3pCLHdCQUFNQyxJQUFJRCxJQUFJL0osVUFBVTRKLElBQUksT0FBTztBQUNuQyxzQkFBSUksRUFBR0EsR0FBRXpGLFFBQVF2RSxTQUFTeUUsTUFBTUY7QUFBQUEsZ0JBQ2xDLENBQUM7QUFBQSxZQUNMLENBQUM7QUFDRGhCLHFCQUFTMEcsT0FBTztBQUFBLFVBQ2xCLE1BQU96RyxVQUFTeUcsT0FBT3JFLE9BQU9FLE1BQU07QUFDcEM1QyxnQkFBTXdHLHNCQUFzQkQsT0FBTztBQUFBLFFBQ3JDO0FBQ0F2RyxjQUFNd0csc0JBQXNCRCxPQUFPO0FBQ25DbEgsaUJBQVNHLFVBQVU7QUFBQSxVQUNqQmM7QUFBQUEsVUFDQW9DO0FBQUFBLFVBQ0FFO0FBQUFBLFVBQ0F4QztBQUFBQSxVQUNBcUQ7QUFBQUEsVUFDQTBDLFNBQVM7QUFBQSxVQUNUcko7QUFBQUEsVUFDQStDLGdCQUFnQm9FO0FBQUFBLFVBQ2hCakU7QUFBQUEsVUFDQUM7QUFBQUEsVUFDQXlFO0FBQUFBLFVBQ0FyRTtBQUFBQSxVQUNBc0U7QUFBQUEsVUFDQUM7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU1ySyxJQUFJOEUsU0FBU0c7QUFDbkJqRixVQUFFdUMsU0FBU2lGLFdBQVdWLFFBQVFsRSxVQUFVUyxPQUFPLEtBQUs7QUFDcERyRCxVQUFFdUMsU0FBU2tGLFdBQVdYLFFBQVF4RCxZQUFZdEQsRUFBRStGLFNBQVMyQixjQUFjO0FBQ25FMUgsVUFBRXVDLFNBQVMwRSxPQUFPSCxNQUFNMkMsSUFBSWxKLEtBQUs7QUFDakNQLFVBQUV1QyxTQUFTb0YsT0FBT2IsUUFBUXBEO0FBQzFCMUQsVUFBRXVDLFNBQVNxRixTQUFTZCxRQUFRbkQ7QUFDNUIzRCxVQUFFdUMsU0FBU3NGLGFBQWFmLFFBQVEvQztBQUNoQy9ELFVBQUV1QyxTQUFTdUYsZUFBZWhCLFFBQVE5QyxnQkFBZ0IsSUFBSTtBQUN0RGhFLFVBQUV1QyxTQUFTMEYsaUJBQWlCbkIsUUFBUTdDO0FBQ3BDakUsVUFBRXVDLFNBQVN5RixpQkFBaUJsQixRQUFRNUM7QUFDcENsRSxVQUFFdUMsU0FBU3dGLGFBQWFqQixRQUFRM0M7QUFDaENuRSxVQUFFdUMsU0FBUzJGLFVBQVVwQixRQUFRdkM7QUFDN0IsWUFBSUQsWUFBYXRFLEdBQUUrRixTQUFTWSxjQUFjLENBQUM7QUFBQTtBQUN0QzNHLFlBQUUrRixTQUFTYSxjQUFjLEdBQVUsQ0FBQztBQUN6QyxZQUFJNUcsRUFBRXFLLGNBQWM7QUFDbEIsZ0JBQU1vQyxZQUFZek0sRUFBRXFLO0FBQ3BCLGNBQUlvQyxVQUFXQSxXQUFVM0YsUUFBUWpEO0FBQ2pDLGdCQUFNNkksUUFBUTFNLEVBQUVxSyxhQUFhOUgsU0FBUzRKLElBQUksT0FBTztBQUNqRCxjQUFJTyxNQUFPQSxPQUFNNUYsUUFBUTFDO0FBQUFBLFFBQzNCO0FBQ0EsWUFBSXBFLEVBQUVvSyxNQUFPcEssR0FBRW9LLE1BQU1sSSxjQUFjNEI7QUFBQUEsTUFDckM7QUFDQWlCLG9CQUFjRSxVQUFVRTtBQUN4QixhQUFPLE1BQU07QUFDWCxZQUFJTCxTQUFTRyxXQUFXRyxXQUFZO0FBQ3BDLFlBQUksQ0FBQ04sU0FBU0csUUFBUztBQUN2QixjQUFNakYsSUFBSThFLFNBQVNHO0FBQ25CakYsVUFBRXNGLGdCQUFnQkMsV0FBVztBQUM3QkMsNkJBQXFCeEYsRUFBRXlGLEdBQUc7QUFDMUJ6RixVQUFFMEYsTUFBTUMsU0FBU0MsUUFBUTtBQUN6QjVGLFVBQUU2RixTQUFTRCxRQUFRO0FBQ25CNUYsVUFBRThGLFVBQVVGLFFBQVE7QUFDcEI1RixVQUFFK0YsU0FBU0gsUUFBUTtBQUNuQjVGLFVBQUUrRixTQUFTQyxpQkFBaUI7QUFDNUIsWUFBSWhHLEVBQUUrRixTQUFTRSxXQUFXQyxrQkFBa0JsQixVQUFXQSxXQUFVbUIsWUFBWW5HLEVBQUUrRixTQUFTRSxVQUFVO0FBQ2xHbkIsaUJBQVNHLFVBQVU7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFBQSxJQUFHO0FBQUEsTUFDRHhCO0FBQUFBLE1BQ0FHO0FBQUFBLE1BQ0FZO0FBQUFBLE1BQ0FsQjtBQUFBQSxNQUNBSTtBQUFBQSxNQUNBQztBQUFBQSxNQUNBSztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBSjtBQUFBQSxNQUNBUTtBQUFBQSxNQUNBRDtBQUFBQSxNQUNBVDtBQUFBQSxNQUNBQztBQUFBQSxNQUNBTTtBQUFBQSxNQUNBQztBQUFBQSxNQUNBaEI7QUFBQUEsTUFDQTlDO0FBQUFBLE1BQ0FoQjtBQUFBQSxJQUFLO0FBQUEsRUFDTjtBQUVELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUttRjtBQUFBQSxNQUNMLFdBQVcseUJBQXlCbkIsYUFBYSxFQUFFO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLGNBQVc7QUFBQTtBQUFBLElBSmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSWdEO0FBR3BEO0FBQUVrQixHQWhUSXJCLFlBQVU7QUFBQXVKLEtBQVZ2SjtBQWtUTixlQUFlQTtBQUFXLElBQUF1SjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRWZmZWN0IiwiRWZmZWN0Q29tcG9zZXIiLCJFZmZlY3RQYXNzIiwiUmVuZGVyUGFzcyIsInVzZUVmZmVjdCIsInVzZVJlZiIsIlRIUkVFIiwiY3JlYXRlVG91Y2hUZXh0dXJlIiwic2l6ZSIsImNhbnZhcyIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsIndpZHRoIiwiaGVpZ2h0IiwiY3R4IiwiZ2V0Q29udGV4dCIsIkVycm9yIiwiZmlsbFN0eWxlIiwiZmlsbFJlY3QiLCJ0ZXh0dXJlIiwiVGV4dHVyZSIsIm1pbkZpbHRlciIsIkxpbmVhckZpbHRlciIsIm1hZ0ZpbHRlciIsImdlbmVyYXRlTWlwbWFwcyIsInRyYWlsIiwibGFzdCIsIm1heEFnZSIsInJhZGl1cyIsInNwZWVkIiwiY2xlYXIiLCJkcmF3UG9pbnQiLCJwIiwicG9zIiwieCIsInkiLCJpbnRlbnNpdHkiLCJlYXNlT3V0U2luZSIsInQiLCJNYXRoIiwic2luIiwiUEkiLCJlYXNlT3V0UXVhZCIsImFnZSIsImZvcmNlIiwiY29sb3IiLCJ2eCIsInZ5Iiwib2Zmc2V0Iiwic2hhZG93T2Zmc2V0WCIsInNoYWRvd09mZnNldFkiLCJzaGFkb3dCbHVyIiwic2hhZG93Q29sb3IiLCJiZWdpblBhdGgiLCJhcmMiLCJmaWxsIiwiYWRkVG91Y2giLCJub3JtIiwiZHgiLCJkeSIsImRkIiwiZCIsInNxcnQiLCJtaW4iLCJwdXNoIiwidXBkYXRlIiwiaSIsImxlbmd0aCIsInBvaW50IiwiZiIsInNwbGljZSIsIm5lZWRzVXBkYXRlIiwicmFkaXVzU2NhbGUiLCJ2IiwiY3JlYXRlTGlxdWlkRWZmZWN0Iiwib3B0cyIsImZyYWdtZW50IiwidW5pZm9ybXMiLCJNYXAiLCJVbmlmb3JtIiwic3RyZW5ndGgiLCJmcmVxIiwiU0hBUEVfTUFQIiwic3F1YXJlIiwiY2lyY2xlIiwidHJpYW5nbGUiLCJkaWFtb25kIiwiVkVSVEVYX1NSQyIsIkZSQUdNRU5UX1NSQyIsIk1BWF9DTElDS1MiLCJQaXhlbEJsYXN0IiwidmFyaWFudCIsInBpeGVsU2l6ZSIsImNsYXNzTmFtZSIsInN0eWxlIiwiYW50aWFsaWFzIiwicGF0dGVyblNjYWxlIiwicGF0dGVybkRlbnNpdHkiLCJsaXF1aWQiLCJsaXF1aWRTdHJlbmd0aCIsImxpcXVpZFJhZGl1cyIsInBpeGVsU2l6ZUppdHRlciIsImVuYWJsZVJpcHBsZXMiLCJyaXBwbGVJbnRlbnNpdHlTY2FsZSIsInJpcHBsZVRoaWNrbmVzcyIsInJpcHBsZVNwZWVkIiwibGlxdWlkV29iYmxlU3BlZWQiLCJhdXRvUGF1c2VPZmZzY3JlZW4iLCJ0cmFuc3BhcmVudCIsImVkZ2VGYWRlIiwibm9pc2VBbW91bnQiLCJfcyIsImNvbnRhaW5lclJlZiIsInZpc2liaWxpdHlSZWYiLCJ2aXNpYmxlIiwic3BlZWRSZWYiLCJ0aHJlZVJlZiIsInByZXZDb25maWdSZWYiLCJjb250YWluZXIiLCJjdXJyZW50IiwibmVlZHNSZWluaXRLZXlzIiwiY2ZnIiwibXVzdFJlaW5pdCIsImsiLCJyZXNpemVPYnNlcnZlciIsImRpc2Nvbm5lY3QiLCJjYW5jZWxBbmltYXRpb25GcmFtZSIsInJhZiIsInF1YWQiLCJnZW9tZXRyeSIsImRpc3Bvc2UiLCJtYXRlcmlhbCIsImNvbXBvc2VyIiwicmVuZGVyZXIiLCJmb3JjZUNvbnRleHRMb3NzIiwiZG9tRWxlbWVudCIsInBhcmVudEVsZW1lbnQiLCJyZW1vdmVDaGlsZCIsIldlYkdMUmVuZGVyZXIiLCJhbHBoYSIsInBvd2VyUHJlZmVyZW5jZSIsInNldFBpeGVsUmF0aW8iLCJ3aW5kb3ciLCJkZXZpY2VQaXhlbFJhdGlvIiwiYXBwZW5kQ2hpbGQiLCJzZXRDbGVhckFscGhhIiwic2V0Q2xlYXJDb2xvciIsInVSZXNvbHV0aW9uIiwidmFsdWUiLCJWZWN0b3IyIiwidVRpbWUiLCJ1Q29sb3IiLCJDb2xvciIsInVDbGlja1BvcyIsIkFycmF5IiwiZnJvbSIsInVDbGlja1RpbWVzIiwiRmxvYXQzMkFycmF5IiwidVNoYXBlVHlwZSIsInVQaXhlbFNpemUiLCJnZXRQaXhlbFJhdGlvIiwidVNjYWxlIiwidURlbnNpdHkiLCJ1UGl4ZWxKaXR0ZXIiLCJ1RW5hYmxlUmlwcGxlcyIsInVSaXBwbGVTcGVlZCIsInVSaXBwbGVUaGlja25lc3MiLCJ1UmlwcGxlSW50ZW5zaXR5IiwidUVkZ2VGYWRlIiwic2NlbmUiLCJTY2VuZSIsImNhbWVyYSIsIk9ydGhvZ3JhcGhpY0NhbWVyYSIsIlNoYWRlck1hdGVyaWFsIiwidmVydGV4U2hhZGVyIiwiZnJhZ21lbnRTaGFkZXIiLCJkZXB0aFRlc3QiLCJkZXB0aFdyaXRlIiwiZ2xzbFZlcnNpb24iLCJHTFNMMyIsInF1YWRHZW9tIiwiUGxhbmVHZW9tZXRyeSIsIk1lc2giLCJhZGQiLCJjbG9jayIsIkNsb2NrIiwic2V0U2l6ZSIsInciLCJjbGllbnRXaWR0aCIsImgiLCJjbGllbnRIZWlnaHQiLCJzZXQiLCJybyIsIlJlc2l6ZU9ic2VydmVyIiwib2JzZXJ2ZSIsInJhbmRvbUZsb2F0IiwiY3J5cHRvIiwiZ2V0UmFuZG9tVmFsdWVzIiwidTMyIiwiVWludDMyQXJyYXkiLCJyYW5kb20iLCJ0aW1lT2Zmc2V0IiwidG91Y2giLCJsaXF1aWRFZmZlY3QiLCJyZW5kZXJQYXNzIiwiZWZmZWN0UGFzcyIsInJlbmRlclRvU2NyZWVuIiwiYWRkUGFzcyIsIm5vaXNlRWZmZWN0Iiwibm9pc2VQYXNzIiwicGFzc2VzIiwiZm9yRWFjaCIsIm1hcFRvUGl4ZWxzIiwiZSIsInJlY3QiLCJnZXRCb3VuZGluZ0NsaWVudFJlY3QiLCJzY2FsZVgiLCJzY2FsZVkiLCJmeCIsImNsaWVudFgiLCJsZWZ0IiwiZnkiLCJjbGllbnRZIiwidG9wIiwib25Qb2ludGVyRG93biIsIml4IiwiY2xpY2tJeCIsIm9uUG9pbnRlck1vdmUiLCJhZGRFdmVudExpc3RlbmVyIiwicGFzc2l2ZSIsImFuaW1hdGUiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJnZXRFbGFwc2VkVGltZSIsImdldCIsImVmZnMiLCJlZmZlY3RzIiwiZWZmIiwidSIsInJlbmRlciIsInVTdHJlbmd0aCIsInVGcmVxIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGl4ZWxCbGFzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRWZmZWN0LCBFZmZlY3RDb21wb3NlciwgRWZmZWN0UGFzcywgUmVuZGVyUGFzcyB9IGZyb20gJ3Bvc3Rwcm9jZXNzaW5nJztcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgVEhSRUUgZnJvbSAndGhyZWUnO1xuaW1wb3J0ICcuL1BpeGVsQmxhc3QuY3NzJztcblxuY29uc3QgY3JlYXRlVG91Y2hUZXh0dXJlID0gKCkgPT4ge1xuICBjb25zdCBzaXplID0gNjQ7XG4gIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICBjYW52YXMud2lkdGggPSBzaXplO1xuICBjYW52YXMuaGVpZ2h0ID0gc2l6ZTtcbiAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gIGlmICghY3R4KSB0aHJvdyBuZXcgRXJyb3IoJzJEIGNvbnRleHQgbm90IGF2YWlsYWJsZScpO1xuICBjdHguZmlsbFN0eWxlID0gJ2JsYWNrJztcbiAgY3R4LmZpbGxSZWN0KDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG4gIGNvbnN0IHRleHR1cmUgPSBuZXcgVEhSRUUuVGV4dHVyZShjYW52YXMpO1xuICB0ZXh0dXJlLm1pbkZpbHRlciA9IFRIUkVFLkxpbmVhckZpbHRlcjtcbiAgdGV4dHVyZS5tYWdGaWx0ZXIgPSBUSFJFRS5MaW5lYXJGaWx0ZXI7XG4gIHRleHR1cmUuZ2VuZXJhdGVNaXBtYXBzID0gZmFsc2U7XG4gIGNvbnN0IHRyYWlsOiBhbnlbXSA9IFtdO1xuICBsZXQgbGFzdDogYW55ID0gbnVsbDtcbiAgY29uc3QgbWF4QWdlID0gNjQ7XG4gIGxldCByYWRpdXMgPSAwLjEgKiBzaXplO1xuICBjb25zdCBzcGVlZCA9IDEgLyBtYXhBZ2U7XG4gIGNvbnN0IGNsZWFyID0gKCkgPT4ge1xuICAgIGN0eC5maWxsU3R5bGUgPSAnYmxhY2snO1xuICAgIGN0eC5maWxsUmVjdCgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICB9O1xuICBjb25zdCBkcmF3UG9pbnQgPSAocDogYW55KSA9PiB7XG4gICAgY29uc3QgcG9zID0geyB4OiBwLnggKiBzaXplLCB5OiAoMSAtIHAueSkgKiBzaXplIH07XG4gICAgbGV0IGludGVuc2l0eSA9IDE7XG4gICAgY29uc3QgZWFzZU91dFNpbmUgPSAodDogbnVtYmVyKSA9PiBNYXRoLnNpbigodCAqIE1hdGguUEkpIC8gMik7XG4gICAgY29uc3QgZWFzZU91dFF1YWQgPSAodDogbnVtYmVyKSA9PiAtdCAqICh0IC0gMik7XG4gICAgaWYgKHAuYWdlIDwgbWF4QWdlICogMC4zKSBpbnRlbnNpdHkgPSBlYXNlT3V0U2luZShwLmFnZSAvIChtYXhBZ2UgKiAwLjMpKTtcbiAgICBlbHNlIGludGVuc2l0eSA9IGVhc2VPdXRRdWFkKDEgLSAocC5hZ2UgLSBtYXhBZ2UgKiAwLjMpIC8gKG1heEFnZSAqIDAuNykpIHx8IDA7XG4gICAgaW50ZW5zaXR5ICo9IHAuZm9yY2U7XG4gICAgY29uc3QgY29sb3IgPSBgJHsoKHAudnggKyAxKSAvIDIpICogMjU1fSwgJHsoKHAudnkgKyAxKSAvIDIpICogMjU1fSwgJHtpbnRlbnNpdHkgKiAyNTV9YDtcbiAgICBjb25zdCBvZmZzZXQgPSBzaXplICogNTtcbiAgICBjdHguc2hhZG93T2Zmc2V0WCA9IG9mZnNldDtcbiAgICBjdHguc2hhZG93T2Zmc2V0WSA9IG9mZnNldDtcbiAgICBjdHguc2hhZG93Qmx1ciA9IHJhZGl1cztcbiAgICBjdHguc2hhZG93Q29sb3IgPSBgcmdiYSgke2NvbG9yfSwkezAuMjIgKiBpbnRlbnNpdHl9KWA7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSgyNTUsMCwwLDEpJztcbiAgICBjdHguYXJjKHBvcy54IC0gb2Zmc2V0LCBwb3MueSAtIG9mZnNldCwgcmFkaXVzLCAwLCBNYXRoLlBJICogMik7XG4gICAgY3R4LmZpbGwoKTtcbiAgfTtcbiAgY29uc3QgYWRkVG91Y2ggPSAobm9ybTogYW55KSA9PiB7XG4gICAgbGV0IGZvcmNlID0gMDtcbiAgICBsZXQgdnggPSAwO1xuICAgIGxldCB2eSA9IDA7XG4gICAgaWYgKGxhc3QpIHtcbiAgICAgIGNvbnN0IGR4ID0gbm9ybS54IC0gbGFzdC54O1xuICAgICAgY29uc3QgZHkgPSBub3JtLnkgLSBsYXN0Lnk7XG4gICAgICBpZiAoZHggPT09IDAgJiYgZHkgPT09IDApIHJldHVybjtcbiAgICAgIGNvbnN0IGRkID0gZHggKiBkeCArIGR5ICogZHk7XG4gICAgICBjb25zdCBkID0gTWF0aC5zcXJ0KGRkKTtcbiAgICAgIHZ4ID0gZHggLyAoZCB8fCAxKTtcbiAgICAgIHZ5ID0gZHkgLyAoZCB8fCAxKTtcbiAgICAgIGZvcmNlID0gTWF0aC5taW4oZGQgKiAxMDAwMCwgMSk7XG4gICAgfVxuICAgIGxhc3QgPSB7IHg6IG5vcm0ueCwgeTogbm9ybS55IH07XG4gICAgdHJhaWwucHVzaCh7IHg6IG5vcm0ueCwgeTogbm9ybS55LCBhZ2U6IDAsIGZvcmNlLCB2eCwgdnkgfSk7XG4gIH07XG4gIGNvbnN0IHVwZGF0ZSA9ICgpID0+IHtcbiAgICBjbGVhcigpO1xuICAgIGZvciAobGV0IGkgPSB0cmFpbC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgY29uc3QgcG9pbnQgPSB0cmFpbFtpXTtcbiAgICAgIGNvbnN0IGYgPSBwb2ludC5mb3JjZSAqIHNwZWVkICogKDEgLSBwb2ludC5hZ2UgLyBtYXhBZ2UpO1xuICAgICAgcG9pbnQueCArPSBwb2ludC52eCAqIGY7XG4gICAgICBwb2ludC55ICs9IHBvaW50LnZ5ICogZjtcbiAgICAgIHBvaW50LmFnZSsrO1xuICAgICAgaWYgKHBvaW50LmFnZSA+IG1heEFnZSkgdHJhaWwuc3BsaWNlKGksIDEpO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRyYWlsLmxlbmd0aDsgaSsrKSBkcmF3UG9pbnQodHJhaWxbaV0pO1xuICAgIHRleHR1cmUubmVlZHNVcGRhdGUgPSB0cnVlO1xuICB9O1xuICByZXR1cm4ge1xuICAgIGNhbnZhcyxcbiAgICB0ZXh0dXJlLFxuICAgIGFkZFRvdWNoLFxuICAgIHVwZGF0ZSxcbiAgICBzZXQgcmFkaXVzU2NhbGUodikge1xuICAgICAgcmFkaXVzID0gMC4xICogc2l6ZSAqIHY7XG4gICAgfSxcbiAgICBnZXQgcmFkaXVzU2NhbGUoKSB7XG4gICAgICByZXR1cm4gcmFkaXVzIC8gKDAuMSAqIHNpemUpO1xuICAgIH0sXG4gICAgc2l6ZVxuICB9O1xufTtcblxuY29uc3QgY3JlYXRlTGlxdWlkRWZmZWN0ID0gKHRleHR1cmU6IGFueSwgb3B0czogYW55KSA9PiB7XG4gIGNvbnN0IGZyYWdtZW50ID0gYFxuICAgIHVuaWZvcm0gc2FtcGxlcjJEIHVUZXh0dXJlO1xuICAgIHVuaWZvcm0gZmxvYXQgdVN0cmVuZ3RoO1xuICAgIHVuaWZvcm0gZmxvYXQgdVRpbWU7XG4gICAgdW5pZm9ybSBmbG9hdCB1RnJlcTtcblxuICAgIHZvaWQgbWFpblV2KGlub3V0IHZlYzIgdXYpIHtcbiAgICAgIHZlYzQgdGV4ID0gdGV4dHVyZTJEKHVUZXh0dXJlLCB1dik7XG4gICAgICBmbG9hdCB2eCA9IHRleC5yICogMi4wIC0gMS4wO1xuICAgICAgZmxvYXQgdnkgPSB0ZXguZyAqIDIuMCAtIDEuMDtcbiAgICAgIGZsb2F0IGludGVuc2l0eSA9IHRleC5iO1xuXG4gICAgICBmbG9hdCB3YXZlID0gMC41ICsgMC41ICogc2luKHVUaW1lICogdUZyZXEgKyBpbnRlbnNpdHkgKiA2LjI4MzE4NTMpO1xuXG4gICAgICBmbG9hdCBhbXQgPSB1U3RyZW5ndGggKiBpbnRlbnNpdHkgKiB3YXZlO1xuXG4gICAgICB1diArPSB2ZWMyKHZ4LCB2eSkgKiBhbXQ7XG4gICAgfVxuICAgIGA7XG4gIHJldHVybiBuZXcgRWZmZWN0KCdMaXF1aWRFZmZlY3QnLCBmcmFnbWVudCwge1xuICAgIHVuaWZvcm1zOiBuZXcgTWFwKFtcbiAgICAgIFsndVRleHR1cmUnLCBuZXcgVEhSRUUuVW5pZm9ybSh0ZXh0dXJlKV0sXG4gICAgICBbJ3VTdHJlbmd0aCcsIG5ldyBUSFJFRS5Vbmlmb3JtKG9wdHM/LnN0cmVuZ3RoID8/IDAuMDI1KV0sXG4gICAgICBbJ3VUaW1lJywgbmV3IFRIUkVFLlVuaWZvcm0oMCldLFxuICAgICAgWyd1RnJlcScsIG5ldyBUSFJFRS5Vbmlmb3JtKG9wdHM/LmZyZXEgPz8gNC41KV1cbiAgICBdKVxuICB9KTtcbn07XG5cbmNvbnN0IFNIQVBFX01BUDogYW55ID0ge1xuICBzcXVhcmU6IDAsXG4gIGNpcmNsZTogMSxcbiAgdHJpYW5nbGU6IDIsXG4gIGRpYW1vbmQ6IDNcbn07XG5cbmNvbnN0IFZFUlRFWF9TUkMgPSBgXG52b2lkIG1haW4oKSB7XG4gIGdsX1Bvc2l0aW9uID0gdmVjNChwb3NpdGlvbiwgMS4wKTtcbn1cbmA7XG5cbmNvbnN0IEZSQUdNRU5UX1NSQyA9IGBcbnByZWNpc2lvbiBoaWdocCBmbG9hdDtcblxudW5pZm9ybSB2ZWMzICB1Q29sb3I7XG51bmlmb3JtIHZlYzIgIHVSZXNvbHV0aW9uO1xudW5pZm9ybSBmbG9hdCB1VGltZTtcbnVuaWZvcm0gZmxvYXQgdVBpeGVsU2l6ZTtcbnVuaWZvcm0gZmxvYXQgdVNjYWxlO1xudW5pZm9ybSBmbG9hdCB1RGVuc2l0eTtcbnVuaWZvcm0gZmxvYXQgdVBpeGVsSml0dGVyO1xudW5pZm9ybSBpbnQgICB1RW5hYmxlUmlwcGxlcztcbnVuaWZvcm0gZmxvYXQgdVJpcHBsZVNwZWVkO1xudW5pZm9ybSBmbG9hdCB1UmlwcGxlVGhpY2tuZXNzO1xudW5pZm9ybSBmbG9hdCB1UmlwcGxlSW50ZW5zaXR5O1xudW5pZm9ybSBmbG9hdCB1RWRnZUZhZGU7XG5cbnVuaWZvcm0gaW50ICAgdVNoYXBlVHlwZTtcbmNvbnN0IGludCBTSEFQRV9TUVVBUkUgICA9IDA7XG5jb25zdCBpbnQgU0hBUEVfQ0lSQ0xFICAgPSAxO1xuY29uc3QgaW50IFNIQVBFX1RSSUFOR0xFID0gMjtcbmNvbnN0IGludCBTSEFQRV9ESUFNT05EICA9IDM7XG5cbmNvbnN0IGludCAgIE1BWF9DTElDS1MgPSAxMDtcblxudW5pZm9ybSB2ZWMyICB1Q2xpY2tQb3MgIFtNQVhfQ0xJQ0tTXTtcbnVuaWZvcm0gZmxvYXQgdUNsaWNrVGltZXNbTUFYX0NMSUNLU107XG5cbm91dCB2ZWM0IGZyYWdDb2xvcjtcblxuZmxvYXQgQmF5ZXIyKHZlYzIgYSkge1xuICBhID0gZmxvb3IoYSk7XG4gIHJldHVybiBmcmFjdChhLnggLyAyLiArIGEueSAqIGEueSAqIC43NSk7XG59XG4jZGVmaW5lIEJheWVyNChhKSAoQmF5ZXIyKC41KihhKSkqMC4yNSArIEJheWVyMihhKSlcbiNkZWZpbmUgQmF5ZXI4KGEpIChCYXllcjQoLjUqKGEpKSowLjI1ICsgQmF5ZXIyKGEpKVxuXG4jZGVmaW5lIEZCTV9PQ1RBVkVTICAgICA1XG4jZGVmaW5lIEZCTV9MQUNVTkFSSVRZICAxLjI1XG4jZGVmaW5lIEZCTV9HQUlOICAgICAgICAxLjBcblxuZmxvYXQgaGFzaDExKGZsb2F0IG4peyByZXR1cm4gZnJhY3Qoc2luKG4pKjQzNzU4LjU0NTMpOyB9XG5cbmZsb2F0IHZub2lzZSh2ZWMzIHApe1xuICB2ZWMzIGlwID0gZmxvb3IocCk7XG4gIHZlYzMgZnAgPSBmcmFjdChwKTtcbiAgZmxvYXQgbjAwMCA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDAuMCwwLjAsMC4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgZmxvYXQgbjEwMCA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDEuMCwwLjAsMC4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgZmxvYXQgbjAxMCA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDAuMCwxLjAsMC4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgZmxvYXQgbjExMCA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDEuMCwxLjAsMC4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgZmxvYXQgbjAwMSA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDAuMCwwLjAsMS4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgZmxvYXQgbjEwMSA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDEuMCwwLjAsMS4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgZmxvYXQgbjAxMSA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDAuMCwxLjAsMS4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgZmxvYXQgbjExMSA9IGhhc2gxMShkb3QoaXAgKyB2ZWMzKDEuMCwxLjAsMS4wKSwgdmVjMygxLjAsNTcuMCwxMTMuMCkpKTtcbiAgdmVjMyB3ID0gZnAqZnAqZnAqKGZwKihmcCo2LjAtMTUuMCkrMTAuMCk7XG4gIGZsb2F0IHgwMCA9IG1peChuMDAwLCBuMTAwLCB3LngpO1xuICBmbG9hdCB4MTAgPSBtaXgobjAxMCwgbjExMCwgdy54KTtcbiAgZmxvYXQgeDAxID0gbWl4KG4wMDEsIG4xMDEsIHcueCk7XG4gIGZsb2F0IHgxMSA9IG1peChuMDExLCBuMTExLCB3LngpO1xuICBmbG9hdCB5MCAgPSBtaXgoeDAwLCB4MTAsIHcueSk7XG4gIGZsb2F0IHkxICA9IG1peCh4MDEsIHgxMSwgdy55KTtcbiAgcmV0dXJuIG1peCh5MCwgeTEsIHcueikgKiAyLjAgLSAxLjA7XG59XG5cbmZsb2F0IGZibTIodmVjMiB1diwgZmxvYXQgdCl7XG4gIHZlYzMgcCA9IHZlYzModXYgKiB1U2NhbGUsIHQpO1xuICBmbG9hdCBhbXAgPSAxLjA7XG4gIGZsb2F0IGZyZXEgPSAxLjA7XG4gIGZsb2F0IHN1bSA9IDEuMDtcbiAgZm9yIChpbnQgaSA9IDA7IGkgPCBGQk1fT0NUQVZFUzsgKytpKXtcbiAgICBzdW0gICs9IGFtcCAqIHZub2lzZShwICogZnJlcSk7XG4gICAgZnJlcSAqPSBGQk1fTEFDVU5BUklUWTtcbiAgICBhbXAgICo9IEZCTV9HQUlOO1xuICB9XG4gIHJldHVybiBzdW0gKiAwLjUgKyAwLjU7XG59XG5cbmZsb2F0IG1hc2tDaXJjbGUodmVjMiBwLCBmbG9hdCBjb3Ype1xuICBmbG9hdCByID0gc3FydChjb3YpICogLjI1O1xuICBmbG9hdCBkID0gbGVuZ3RoKHAgLSAwLjUpIC0gcjtcbiAgZmxvYXQgYWEgPSAwLjUgKiBmd2lkdGgoZCk7XG4gIHJldHVybiBjb3YgKiAoMS4wIC0gc21vb3Roc3RlcCgtYWEsIGFhLCBkICogMi4wKSk7XG59XG5cbmZsb2F0IG1hc2tUcmlhbmdsZSh2ZWMyIHAsIHZlYzIgaWQsIGZsb2F0IGNvdil7XG4gIGJvb2wgZmxpcCA9IG1vZChpZC54ICsgaWQueSwgMi4wKSA+IDAuNTtcbiAgaWYgKGZsaXApIHAueCA9IDEuMCAtIHAueDtcbiAgZmxvYXQgciA9IHNxcnQoY292KTtcbiAgZmxvYXQgZCAgPSBwLnkgLSByKigxLjAgLSBwLngpO1xuICBmbG9hdCBhYSA9IGZ3aWR0aChkKTtcbiAgcmV0dXJuIGNvdiAqIGNsYW1wKDAuNSAtIGQvYWEsIDAuMCwgMS4wKTtcbn1cblxuZmxvYXQgbWFza0RpYW1vbmQodmVjMiBwLCBmbG9hdCBjb3Ype1xuICBmbG9hdCByID0gc3FydChjb3YpICogMC41NjQ7XG4gIHJldHVybiBzdGVwKGFicyhwLnggLSAwLjQ5KSArIGFicyhwLnkgLSAwLjQ5KSwgcik7XG59XG5cbnZvaWQgbWFpbigpe1xuICBmbG9hdCBwaXhlbFNpemUgPSB1UGl4ZWxTaXplO1xuICB2ZWMyIGZyYWdDb29yZCA9IGdsX0ZyYWdDb29yZC54eSAtIHVSZXNvbHV0aW9uICogLjU7XG4gIGZsb2F0IGFzcGVjdFJhdGlvID0gdVJlc29sdXRpb24ueCAvIHVSZXNvbHV0aW9uLnk7XG5cbiAgdmVjMiBwaXhlbElkID0gZmxvb3IoZnJhZ0Nvb3JkIC8gcGl4ZWxTaXplKTtcbiAgdmVjMiBwaXhlbFVWID0gZnJhY3QoZnJhZ0Nvb3JkIC8gcGl4ZWxTaXplKTtcblxuICBmbG9hdCBjZWxsUGl4ZWxTaXplID0gOC4wICogcGl4ZWxTaXplO1xuICB2ZWMyIGNlbGxJZCA9IGZsb29yKGZyYWdDb29yZCAvIGNlbGxQaXhlbFNpemUpO1xuICB2ZWMyIGNlbGxDb29yZCA9IGNlbGxJZCAqIGNlbGxQaXhlbFNpemU7XG4gIHZlYzIgdXYgPSBjZWxsQ29vcmQgLyB1UmVzb2x1dGlvbiAqIHZlYzIoYXNwZWN0UmF0aW8sIDEuMCk7XG5cbiAgZmxvYXQgYmFzZSA9IGZibTIodXYsIHVUaW1lICogMC4wNSk7XG4gIGJhc2UgPSBiYXNlICogMC41IC0gMC42NTtcblxuICBmbG9hdCBmZWVkID0gYmFzZSArICh1RGVuc2l0eSAtIDAuNSkgKiAwLjM7XG5cbiAgZmxvYXQgc3BlZWQgICAgID0gdVJpcHBsZVNwZWVkO1xuICBmbG9hdCB0aGlja25lc3MgPSB1UmlwcGxlVGhpY2tuZXNzO1xuICBjb25zdCBmbG9hdCBkYW1wVCAgICAgPSAxLjA7XG4gIGNvbnN0IGZsb2F0IGRhbXBSICAgICA9IDEwLjA7XG5cbiAgaWYgKHVFbmFibGVSaXBwbGVzID09IDEpIHtcbiAgICBmb3IgKGludCBpID0gMDsgaSA8IE1BWF9DTElDS1M7ICsraSl7XG4gICAgICB2ZWMyIHBvcyA9IHVDbGlja1Bvc1tpXTtcbiAgICAgIGlmIChwb3MueCA8IDAuMCkgY29udGludWU7XG4gICAgICBmbG9hdCBjZWxsUGl4ZWxTaXplID0gOC4wICogcGl4ZWxTaXplO1xuICAgICAgdmVjMiBjdXYgPSAoKChwb3MgLSB1UmVzb2x1dGlvbiAqIC41IC0gY2VsbFBpeGVsU2l6ZSAqIC41KSAvICh1UmVzb2x1dGlvbikpKSAqIHZlYzIoYXNwZWN0UmF0aW8sIDEuMCk7XG4gICAgICBmbG9hdCB0ID0gbWF4KHVUaW1lIC0gdUNsaWNrVGltZXNbaV0sIDAuMCk7XG4gICAgICBmbG9hdCByID0gZGlzdGFuY2UodXYsIGN1dik7XG4gICAgICBmbG9hdCB3YXZlUiA9IHNwZWVkICogdDtcbiAgICAgIGZsb2F0IHJpbmcgID0gZXhwKC1wb3coKHIgLSB3YXZlUikgLyB0aGlja25lc3MsIDIuMCkpO1xuICAgICAgZmxvYXQgYXR0ZW4gPSBleHAoLWRhbXBUICogdCkgKiBleHAoLWRhbXBSICogcik7XG4gICAgICBmZWVkID0gbWF4KGZlZWQsIHJpbmcgKiBhdHRlbiAqIHVSaXBwbGVJbnRlbnNpdHkpO1xuICAgIH1cbiAgfVxuXG4gIGZsb2F0IGJheWVyID0gQmF5ZXI4KGZyYWdDb29yZCAvIHVQaXhlbFNpemUpIC0gMC41O1xuICBmbG9hdCBidyA9IHN0ZXAoMC41LCBmZWVkICsgYmF5ZXIpO1xuXG4gIGZsb2F0IGggPSBmcmFjdChzaW4oZG90KGZsb29yKGZyYWdDb29yZCAvIHVQaXhlbFNpemUpLCB2ZWMyKDEyNy4xLCAzMTEuNykpKSAqIDQzNzU4LjU0NTMpO1xuICBmbG9hdCBqaXR0ZXJTY2FsZSA9IDEuMCArIChoIC0gMC41KSAqIHVQaXhlbEppdHRlcjtcbiAgZmxvYXQgY292ZXJhZ2UgPSBidyAqIGppdHRlclNjYWxlO1xuICBmbG9hdCBNO1xuICBpZiAgICAgICh1U2hhcGVUeXBlID09IFNIQVBFX0NJUkNMRSkgICBNID0gbWFza0NpcmNsZSAocGl4ZWxVViwgY292ZXJhZ2UpO1xuICBlbHNlIGlmICh1U2hhcGVUeXBlID09IFNIQVBFX1RSSUFOR0xFKSBNID0gbWFza1RyaWFuZ2xlKHBpeGVsVVYsIHBpeGVsSWQsIGNvdmVyYWdlKTtcbiAgZWxzZSBpZiAodVNoYXBlVHlwZSA9PSBTSEFQRV9ESUFNT05EKSAgTSA9IG1hc2tEaWFtb25kKHBpeGVsVVYsIGNvdmVyYWdlKTtcbiAgZWxzZSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTSA9IGNvdmVyYWdlO1xuXG4gIGlmICh1RWRnZUZhZGUgPiAwLjApIHtcbiAgICB2ZWMyIG5vcm0gPSBnbF9GcmFnQ29vcmQueHkgLyB1UmVzb2x1dGlvbjtcbiAgICBmbG9hdCBlZGdlID0gbWluKG1pbihub3JtLngsIG5vcm0ueSksIG1pbigxLjAgLSBub3JtLngsIDEuMCAtIG5vcm0ueSkpO1xuICAgIGZsb2F0IGZhZGUgPSBzbW9vdGhzdGVwKDAuMCwgdUVkZ2VGYWRlLCBlZGdlKTtcbiAgICBNICo9IGZhZGU7XG4gIH1cblxuICB2ZWMzIGNvbG9yID0gdUNvbG9yO1xuXG4gIC8vIHNSR0IgZ2FtbWEgY29ycmVjdGlvbiAtIGNvbnZlcnQgbGluZWFyIHRvIHNSR0IgZm9yIGFjY3VyYXRlIGNvbG9yIG91dHB1dFxuICB2ZWMzIHNyZ2JDb2xvciA9IG1peChcbiAgICBjb2xvciAqIDEyLjkyLFxuICAgIDEuMDU1ICogcG93KGNvbG9yLCB2ZWMzKDEuMCAvIDIuNCkpIC0gMC4wNTUsXG4gICAgc3RlcCgwLjAwMzEzMDgsIGNvbG9yKVxuICApO1xuXG4gIGZyYWdDb2xvciA9IHZlYzQoc3JnYkNvbG9yLCBNKTtcbn1cbmA7XG5cbmNvbnN0IE1BWF9DTElDS1MgPSAxMDtcblxuY29uc3QgUGl4ZWxCbGFzdCA9ICh7XG4gIHZhcmlhbnQgPSAnc3F1YXJlJyxcbiAgcGl4ZWxTaXplID0gMyxcbiAgY29sb3IgPSAnI0I0OTdDRicsXG4gIGNsYXNzTmFtZSxcbiAgc3R5bGUsXG4gIGFudGlhbGlhcyA9IHRydWUsXG4gIHBhdHRlcm5TY2FsZSA9IDIuNSxcbiAgcGF0dGVybkRlbnNpdHkgPSAxLjAsXG4gIGxpcXVpZCA9IGZhbHNlLFxuICBsaXF1aWRTdHJlbmd0aCA9IDAuMSxcbiAgbGlxdWlkUmFkaXVzID0gMSxcbiAgcGl4ZWxTaXplSml0dGVyID0gMCxcbiAgZW5hYmxlUmlwcGxlcyA9IHRydWUsXG4gIHJpcHBsZUludGVuc2l0eVNjYWxlID0gMSxcbiAgcmlwcGxlVGhpY2tuZXNzID0gMC4xLFxuICByaXBwbGVTcGVlZCA9IDAuMyxcbiAgbGlxdWlkV29iYmxlU3BlZWQgPSA0LjUsXG4gIGF1dG9QYXVzZU9mZnNjcmVlbiA9IHRydWUsXG4gIHNwZWVkID0gMC41LFxuICB0cmFuc3BhcmVudCA9IHRydWUsXG4gIGVkZ2VGYWRlID0gMC41LFxuICBub2lzZUFtb3VudCA9IDBcbn06IGFueSkgPT4ge1xuICBjb25zdCBjb250YWluZXJSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCB2aXNpYmlsaXR5UmVmID0gdXNlUmVmKHsgdmlzaWJsZTogdHJ1ZSB9KTtcbiAgY29uc3Qgc3BlZWRSZWYgPSB1c2VSZWYoc3BlZWQpO1xuXG4gIGNvbnN0IHRocmVlUmVmID0gdXNlUmVmPGFueT4obnVsbCk7XG4gIGNvbnN0IHByZXZDb25maWdSZWYgPSB1c2VSZWY8YW55PihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGNvbnRhaW5lclJlZi5jdXJyZW50O1xuICAgIGlmICghY29udGFpbmVyKSByZXR1cm47XG4gICAgc3BlZWRSZWYuY3VycmVudCA9IHNwZWVkO1xuICAgIGNvbnN0IG5lZWRzUmVpbml0S2V5cyA9IFsnYW50aWFsaWFzJywgJ2xpcXVpZCcsICdub2lzZUFtb3VudCddO1xuICAgIGNvbnN0IGNmZzogYW55ID0geyBhbnRpYWxpYXMsIGxpcXVpZCwgbm9pc2VBbW91bnQgfTtcbiAgICBsZXQgbXVzdFJlaW5pdCA9IGZhbHNlO1xuICAgIGlmICghdGhyZWVSZWYuY3VycmVudCkgbXVzdFJlaW5pdCA9IHRydWU7XG4gICAgZWxzZSBpZiAocHJldkNvbmZpZ1JlZi5jdXJyZW50KSB7XG4gICAgICBmb3IgKGNvbnN0IGsgb2YgbmVlZHNSZWluaXRLZXlzKVxuICAgICAgICBpZiAocHJldkNvbmZpZ1JlZi5jdXJyZW50W2tdICE9PSBjZmdba10pIHtcbiAgICAgICAgICBtdXN0UmVpbml0ID0gdHJ1ZTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAobXVzdFJlaW5pdCkge1xuICAgICAgaWYgKHRocmVlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29uc3QgdCA9IHRocmVlUmVmLmN1cnJlbnQ7XG4gICAgICAgIHQucmVzaXplT2JzZXJ2ZXI/LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUodC5yYWYpO1xuICAgICAgICB0LnF1YWQ/Lmdlb21ldHJ5LmRpc3Bvc2UoKTtcbiAgICAgICAgdC5tYXRlcmlhbC5kaXNwb3NlKCk7XG4gICAgICAgIHQuY29tcG9zZXI/LmRpc3Bvc2UoKTtcbiAgICAgICAgdC5yZW5kZXJlci5kaXNwb3NlKCk7XG4gICAgICAgIHQucmVuZGVyZXIuZm9yY2VDb250ZXh0TG9zcygpO1xuICAgICAgICBpZiAodC5yZW5kZXJlci5kb21FbGVtZW50LnBhcmVudEVsZW1lbnQgPT09IGNvbnRhaW5lcikgY29udGFpbmVyLnJlbW92ZUNoaWxkKHQucmVuZGVyZXIuZG9tRWxlbWVudCk7XG4gICAgICAgIHRocmVlUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICBjb25zdCByZW5kZXJlciA9IG5ldyBUSFJFRS5XZWJHTFJlbmRlcmVyKHtcbiAgICAgICAgY2FudmFzLFxuICAgICAgICBhbnRpYWxpYXMsXG4gICAgICAgIGFscGhhOiB0cnVlLFxuICAgICAgICBwb3dlclByZWZlcmVuY2U6ICdoaWdoLXBlcmZvcm1hbmNlJ1xuICAgICAgfSk7XG4gICAgICByZW5kZXJlci5kb21FbGVtZW50LnN0eWxlLndpZHRoID0gJzEwMCUnO1xuICAgICAgcmVuZGVyZXIuZG9tRWxlbWVudC5zdHlsZS5oZWlnaHQgPSAnMTAwJSc7XG4gICAgICByZW5kZXJlci5zZXRQaXhlbFJhdGlvKE1hdGgubWluKHdpbmRvdy5kZXZpY2VQaXhlbFJhdGlvIHx8IDEsIDIpKTtcbiAgICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChyZW5kZXJlci5kb21FbGVtZW50KTtcbiAgICAgIGlmICh0cmFuc3BhcmVudCkgcmVuZGVyZXIuc2V0Q2xlYXJBbHBoYSgwKTtcbiAgICAgIGVsc2UgcmVuZGVyZXIuc2V0Q2xlYXJDb2xvcigweDAwMDAwMCwgMSk7XG4gICAgICBjb25zdCB1bmlmb3JtcyA9IHtcbiAgICAgICAgdVJlc29sdXRpb246IHsgdmFsdWU6IG5ldyBUSFJFRS5WZWN0b3IyKDAsIDApIH0sXG4gICAgICAgIHVUaW1lOiB7IHZhbHVlOiAwIH0sXG4gICAgICAgIHVDb2xvcjogeyB2YWx1ZTogbmV3IFRIUkVFLkNvbG9yKGNvbG9yKSB9LFxuICAgICAgICB1Q2xpY2tQb3M6IHtcbiAgICAgICAgICB2YWx1ZTogQXJyYXkuZnJvbSh7IGxlbmd0aDogTUFYX0NMSUNLUyB9LCAoKSA9PiBuZXcgVEhSRUUuVmVjdG9yMigtMSwgLTEpKVxuICAgICAgICB9LFxuICAgICAgICB1Q2xpY2tUaW1lczogeyB2YWx1ZTogbmV3IEZsb2F0MzJBcnJheShNQVhfQ0xJQ0tTKSB9LFxuICAgICAgICB1U2hhcGVUeXBlOiB7IHZhbHVlOiBTSEFQRV9NQVBbdmFyaWFudF0gPz8gMCB9LFxuICAgICAgICB1UGl4ZWxTaXplOiB7IHZhbHVlOiBwaXhlbFNpemUgKiByZW5kZXJlci5nZXRQaXhlbFJhdGlvKCkgfSxcbiAgICAgICAgdVNjYWxlOiB7IHZhbHVlOiBwYXR0ZXJuU2NhbGUgfSxcbiAgICAgICAgdURlbnNpdHk6IHsgdmFsdWU6IHBhdHRlcm5EZW5zaXR5IH0sXG4gICAgICAgIHVQaXhlbEppdHRlcjogeyB2YWx1ZTogcGl4ZWxTaXplSml0dGVyIH0sXG4gICAgICAgIHVFbmFibGVSaXBwbGVzOiB7IHZhbHVlOiBlbmFibGVSaXBwbGVzID8gMSA6IDAgfSxcbiAgICAgICAgdVJpcHBsZVNwZWVkOiB7IHZhbHVlOiByaXBwbGVTcGVlZCB9LFxuICAgICAgICB1UmlwcGxlVGhpY2tuZXNzOiB7IHZhbHVlOiByaXBwbGVUaGlja25lc3MgfSxcbiAgICAgICAgdVJpcHBsZUludGVuc2l0eTogeyB2YWx1ZTogcmlwcGxlSW50ZW5zaXR5U2NhbGUgfSxcbiAgICAgICAgdUVkZ2VGYWRlOiB7IHZhbHVlOiBlZGdlRmFkZSB9XG4gICAgICB9O1xuICAgICAgY29uc3Qgc2NlbmUgPSBuZXcgVEhSRUUuU2NlbmUoKTtcbiAgICAgIGNvbnN0IGNhbWVyYSA9IG5ldyBUSFJFRS5PcnRob2dyYXBoaWNDYW1lcmEoLTEsIDEsIDEsIC0xLCAwLCAxKTtcbiAgICAgIGNvbnN0IG1hdGVyaWFsID0gbmV3IFRIUkVFLlNoYWRlck1hdGVyaWFsKHtcbiAgICAgICAgdmVydGV4U2hhZGVyOiBWRVJURVhfU1JDLFxuICAgICAgICBmcmFnbWVudFNoYWRlcjogRlJBR01FTlRfU1JDLFxuICAgICAgICB1bmlmb3JtcyxcbiAgICAgICAgdHJhbnNwYXJlbnQ6IHRydWUsXG4gICAgICAgIGRlcHRoVGVzdDogZmFsc2UsXG4gICAgICAgIGRlcHRoV3JpdGU6IGZhbHNlLFxuICAgICAgICBnbHNsVmVyc2lvbjogVEhSRUUuR0xTTDNcbiAgICAgIH0pO1xuICAgICAgY29uc3QgcXVhZEdlb20gPSBuZXcgVEhSRUUuUGxhbmVHZW9tZXRyeSgyLCAyKTtcbiAgICAgIGNvbnN0IHF1YWQgPSBuZXcgVEhSRUUuTWVzaChxdWFkR2VvbSwgbWF0ZXJpYWwpO1xuICAgICAgc2NlbmUuYWRkKHF1YWQpO1xuICAgICAgY29uc3QgY2xvY2sgPSBuZXcgVEhSRUUuQ2xvY2soKTtcbiAgICAgIGNvbnN0IHNldFNpemUgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHcgPSBjb250YWluZXIuY2xpZW50V2lkdGggfHwgMTtcbiAgICAgICAgY29uc3QgaCA9IGNvbnRhaW5lci5jbGllbnRIZWlnaHQgfHwgMTtcbiAgICAgICAgcmVuZGVyZXIuc2V0U2l6ZSh3LCBoLCBmYWxzZSk7XG4gICAgICAgIHVuaWZvcm1zLnVSZXNvbHV0aW9uLnZhbHVlLnNldChyZW5kZXJlci5kb21FbGVtZW50LndpZHRoLCByZW5kZXJlci5kb21FbGVtZW50LmhlaWdodCk7XG4gICAgICAgIGlmICh0aHJlZVJlZi5jdXJyZW50Py5jb21wb3NlcilcbiAgICAgICAgICB0aHJlZVJlZi5jdXJyZW50LmNvbXBvc2VyLnNldFNpemUocmVuZGVyZXIuZG9tRWxlbWVudC53aWR0aCwgcmVuZGVyZXIuZG9tRWxlbWVudC5oZWlnaHQpO1xuICAgICAgICB1bmlmb3Jtcy51UGl4ZWxTaXplLnZhbHVlID0gcGl4ZWxTaXplICogcmVuZGVyZXIuZ2V0UGl4ZWxSYXRpbygpO1xuICAgICAgfTtcbiAgICAgIHNldFNpemUoKTtcbiAgICAgIGNvbnN0IHJvID0gbmV3IFJlc2l6ZU9ic2VydmVyKHNldFNpemUpO1xuICAgICAgcm8ub2JzZXJ2ZShjb250YWluZXIpO1xuICAgICAgY29uc3QgcmFuZG9tRmxvYXQgPSAoKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cuY3J5cHRvPy5nZXRSYW5kb21WYWx1ZXMpIHtcbiAgICAgICAgICBjb25zdCB1MzIgPSBuZXcgVWludDMyQXJyYXkoMSk7XG4gICAgICAgICAgd2luZG93LmNyeXB0by5nZXRSYW5kb21WYWx1ZXModTMyKTtcbiAgICAgICAgICByZXR1cm4gdTMyWzBdIC8gMHhmZmZmZmZmZjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTWF0aC5yYW5kb20oKTtcbiAgICAgIH07XG4gICAgICBjb25zdCB0aW1lT2Zmc2V0ID0gcmFuZG9tRmxvYXQoKSAqIDEwMDA7XG4gICAgICBsZXQgY29tcG9zZXI6IGFueTtcbiAgICAgIGxldCB0b3VjaDogYW55O1xuICAgICAgbGV0IGxpcXVpZEVmZmVjdDogYW55O1xuICAgICAgaWYgKGxpcXVpZCkge1xuICAgICAgICB0b3VjaCA9IGNyZWF0ZVRvdWNoVGV4dHVyZSgpO1xuICAgICAgICB0b3VjaC5yYWRpdXNTY2FsZSA9IGxpcXVpZFJhZGl1cztcbiAgICAgICAgY29tcG9zZXIgPSBuZXcgRWZmZWN0Q29tcG9zZXIocmVuZGVyZXIpO1xuICAgICAgICBjb25zdCByZW5kZXJQYXNzID0gbmV3IFJlbmRlclBhc3Moc2NlbmUsIGNhbWVyYSk7XG4gICAgICAgIGxpcXVpZEVmZmVjdCA9IGNyZWF0ZUxpcXVpZEVmZmVjdCh0b3VjaC50ZXh0dXJlLCB7XG4gICAgICAgICAgc3RyZW5ndGg6IGxpcXVpZFN0cmVuZ3RoLFxuICAgICAgICAgIGZyZXE6IGxpcXVpZFdvYmJsZVNwZWVkXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBlZmZlY3RQYXNzID0gbmV3IEVmZmVjdFBhc3MoY2FtZXJhLCBsaXF1aWRFZmZlY3QpO1xuICAgICAgICBlZmZlY3RQYXNzLnJlbmRlclRvU2NyZWVuID0gdHJ1ZTtcbiAgICAgICAgY29tcG9zZXIuYWRkUGFzcyhyZW5kZXJQYXNzKTtcbiAgICAgICAgY29tcG9zZXIuYWRkUGFzcyhlZmZlY3RQYXNzKTtcbiAgICAgIH1cbiAgICAgIGlmIChub2lzZUFtb3VudCA+IDApIHtcbiAgICAgICAgaWYgKCFjb21wb3Nlcikge1xuICAgICAgICAgIGNvbXBvc2VyID0gbmV3IEVmZmVjdENvbXBvc2VyKHJlbmRlcmVyKTtcbiAgICAgICAgICBjb21wb3Nlci5hZGRQYXNzKG5ldyBSZW5kZXJQYXNzKHNjZW5lLCBjYW1lcmEpKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBub2lzZUVmZmVjdCA9IG5ldyBFZmZlY3QoXG4gICAgICAgICAgJ05vaXNlRWZmZWN0JyxcbiAgICAgICAgICBgdW5pZm9ybSBmbG9hdCB1VGltZTsgdW5pZm9ybSBmbG9hdCB1QW1vdW50OyBmbG9hdCBoYXNoKHZlYzIgcCl7IHJldHVybiBmcmFjdChzaW4oZG90KHAsIHZlYzIoMTI3LjEsMzExLjcpKSkgKiA0Mzc1OC41NDUzKTt9IHZvaWQgbWFpblV2KGlub3V0IHZlYzIgdXYpe30gdm9pZCBtYWluSW1hZ2UoY29uc3QgaW4gdmVjNCBpbnB1dENvbG9yLGNvbnN0IGluIHZlYzIgdXYsb3V0IHZlYzQgb3V0cHV0Q29sb3IpeyBmbG9hdCBuPWhhc2goZmxvb3IodXYqdmVjMigxOTIwLjAsMTA4MC4wKSkrZmxvb3IodVRpbWUqNjAuMCkpOyBmbG9hdCBnPShuLTAuNSkqdUFtb3VudDsgb3V0cHV0Q29sb3I9aW5wdXRDb2xvcit2ZWM0KHZlYzMoZyksMC4wKTt9IGAsXG4gICAgICAgICAge1xuICAgICAgICAgICAgdW5pZm9ybXM6IG5ldyBNYXAoW1xuICAgICAgICAgICAgICBbJ3VUaW1lJywgbmV3IFRIUkVFLlVuaWZvcm0oMCldLFxuICAgICAgICAgICAgICBbJ3VBbW91bnQnLCBuZXcgVEhSRUUuVW5pZm9ybShub2lzZUFtb3VudCldXG4gICAgICAgICAgICBdKVxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgY29uc3Qgbm9pc2VQYXNzID0gbmV3IEVmZmVjdFBhc3MoY2FtZXJhLCBub2lzZUVmZmVjdCk7XG4gICAgICAgIG5vaXNlUGFzcy5yZW5kZXJUb1NjcmVlbiA9IHRydWU7XG4gICAgICAgIGlmIChjb21wb3NlciAmJiBjb21wb3Nlci5wYXNzZXMubGVuZ3RoID4gMCkgY29tcG9zZXIucGFzc2VzLmZvckVhY2goKHA6IGFueSkgPT4gKHAucmVuZGVyVG9TY3JlZW4gPSBmYWxzZSkpO1xuICAgICAgICBjb21wb3Nlci5hZGRQYXNzKG5vaXNlUGFzcyk7XG4gICAgICB9XG4gICAgICBpZiAoY29tcG9zZXIpIGNvbXBvc2VyLnNldFNpemUocmVuZGVyZXIuZG9tRWxlbWVudC53aWR0aCwgcmVuZGVyZXIuZG9tRWxlbWVudC5oZWlnaHQpO1xuICAgICAgY29uc3QgbWFwVG9QaXhlbHMgPSAoZTogYW55KSA9PiB7XG4gICAgICAgIGNvbnN0IHJlY3QgPSByZW5kZXJlci5kb21FbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICBjb25zdCBzY2FsZVggPSByZW5kZXJlci5kb21FbGVtZW50LndpZHRoIC8gcmVjdC53aWR0aDtcbiAgICAgICAgY29uc3Qgc2NhbGVZID0gcmVuZGVyZXIuZG9tRWxlbWVudC5oZWlnaHQgLyByZWN0LmhlaWdodDtcbiAgICAgICAgY29uc3QgZnggPSAoZS5jbGllbnRYIC0gcmVjdC5sZWZ0KSAqIHNjYWxlWDtcbiAgICAgICAgY29uc3QgZnkgPSAocmVjdC5oZWlnaHQgLSAoZS5jbGllbnRZIC0gcmVjdC50b3ApKSAqIHNjYWxlWTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBmeCxcbiAgICAgICAgICBmeSxcbiAgICAgICAgICB3OiByZW5kZXJlci5kb21FbGVtZW50LndpZHRoLFxuICAgICAgICAgIGg6IHJlbmRlcmVyLmRvbUVsZW1lbnQuaGVpZ2h0XG4gICAgICAgIH07XG4gICAgICB9O1xuICAgICAgY29uc3Qgb25Qb2ludGVyRG93biA9IChlOiBhbnkpID0+IHtcbiAgICAgICAgY29uc3QgeyBmeCwgZnkgfSA9IG1hcFRvUGl4ZWxzKGUpO1xuICAgICAgICBjb25zdCBpeCA9IHRocmVlUmVmLmN1cnJlbnQ/LmNsaWNrSXggPz8gMDtcbiAgICAgICAgdW5pZm9ybXMudUNsaWNrUG9zLnZhbHVlW2l4XS5zZXQoZngsIGZ5KTtcbiAgICAgICAgdW5pZm9ybXMudUNsaWNrVGltZXMudmFsdWVbaXhdID0gdW5pZm9ybXMudVRpbWUudmFsdWU7XG4gICAgICAgIGlmICh0aHJlZVJlZi5jdXJyZW50KSB0aHJlZVJlZi5jdXJyZW50LmNsaWNrSXggPSAoaXggKyAxKSAlIE1BWF9DTElDS1M7XG4gICAgICB9O1xuICAgICAgY29uc3Qgb25Qb2ludGVyTW92ZSA9IChlOiBhbnkpID0+IHtcbiAgICAgICAgaWYgKCF0b3VjaCkgcmV0dXJuO1xuICAgICAgICBjb25zdCB7IGZ4LCBmeSwgdywgaCB9ID0gbWFwVG9QaXhlbHMoZSk7XG4gICAgICAgIHRvdWNoLmFkZFRvdWNoKHsgeDogZnggLyB3LCB5OiBmeSAvIGggfSk7XG4gICAgICB9O1xuICAgICAgcmVuZGVyZXIuZG9tRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCdwb2ludGVyZG93bicsIG9uUG9pbnRlckRvd24sIHtcbiAgICAgICAgcGFzc2l2ZTogdHJ1ZVxuICAgICAgfSk7XG4gICAgICByZW5kZXJlci5kb21FbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3BvaW50ZXJtb3ZlJywgb25Qb2ludGVyTW92ZSwge1xuICAgICAgICBwYXNzaXZlOiB0cnVlXG4gICAgICB9KTtcbiAgICAgIGxldCByYWYgPSAwO1xuICAgICAgY29uc3QgYW5pbWF0ZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKGF1dG9QYXVzZU9mZnNjcmVlbiAmJiAhdmlzaWJpbGl0eVJlZi5jdXJyZW50LnZpc2libGUpIHtcbiAgICAgICAgICByYWYgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoYW5pbWF0ZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHVuaWZvcm1zLnVUaW1lLnZhbHVlID0gdGltZU9mZnNldCArIGNsb2NrLmdldEVsYXBzZWRUaW1lKCkgKiBzcGVlZFJlZi5jdXJyZW50O1xuICAgICAgICBpZiAobGlxdWlkRWZmZWN0KSBsaXF1aWRFZmZlY3QudW5pZm9ybXMuZ2V0KCd1VGltZScpLnZhbHVlID0gdW5pZm9ybXMudVRpbWUudmFsdWU7XG4gICAgICAgIGlmIChjb21wb3Nlcikge1xuICAgICAgICAgIGlmICh0b3VjaCkgdG91Y2gudXBkYXRlKCk7XG4gICAgICAgICAgY29tcG9zZXIucGFzc2VzLmZvckVhY2goKHA6IGFueSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZWZmcyA9IHAuZWZmZWN0cztcbiAgICAgICAgICAgIGlmIChlZmZzKVxuICAgICAgICAgICAgICBlZmZzLmZvckVhY2goKGVmZjogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdSA9IGVmZi51bmlmb3Jtcz8uZ2V0KCd1VGltZScpO1xuICAgICAgICAgICAgICAgIGlmICh1KSB1LnZhbHVlID0gdW5pZm9ybXMudVRpbWUudmFsdWU7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbXBvc2VyLnJlbmRlcigpO1xuICAgICAgICB9IGVsc2UgcmVuZGVyZXIucmVuZGVyKHNjZW5lLCBjYW1lcmEpO1xuICAgICAgICByYWYgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoYW5pbWF0ZSk7XG4gICAgICB9O1xuICAgICAgcmFmID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGFuaW1hdGUpO1xuICAgICAgdGhyZWVSZWYuY3VycmVudCA9IHtcbiAgICAgICAgcmVuZGVyZXIsXG4gICAgICAgIHNjZW5lLFxuICAgICAgICBjYW1lcmEsXG4gICAgICAgIG1hdGVyaWFsLFxuICAgICAgICBjbG9jayxcbiAgICAgICAgY2xpY2tJeDogMCxcbiAgICAgICAgdW5pZm9ybXMsXG4gICAgICAgIHJlc2l6ZU9ic2VydmVyOiBybyxcbiAgICAgICAgcmFmLFxuICAgICAgICBxdWFkLFxuICAgICAgICB0aW1lT2Zmc2V0LFxuICAgICAgICBjb21wb3NlcixcbiAgICAgICAgdG91Y2gsXG4gICAgICAgIGxpcXVpZEVmZmVjdFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgdCA9IHRocmVlUmVmLmN1cnJlbnQ7XG4gICAgICB0LnVuaWZvcm1zLnVTaGFwZVR5cGUudmFsdWUgPSBTSEFQRV9NQVBbdmFyaWFudF0gPz8gMDtcbiAgICAgIHQudW5pZm9ybXMudVBpeGVsU2l6ZS52YWx1ZSA9IHBpeGVsU2l6ZSAqIHQucmVuZGVyZXIuZ2V0UGl4ZWxSYXRpbygpO1xuICAgICAgdC51bmlmb3Jtcy51Q29sb3IudmFsdWUuc2V0KGNvbG9yKTtcbiAgICAgIHQudW5pZm9ybXMudVNjYWxlLnZhbHVlID0gcGF0dGVyblNjYWxlO1xuICAgICAgdC51bmlmb3Jtcy51RGVuc2l0eS52YWx1ZSA9IHBhdHRlcm5EZW5zaXR5O1xuICAgICAgdC51bmlmb3Jtcy51UGl4ZWxKaXR0ZXIudmFsdWUgPSBwaXhlbFNpemVKaXR0ZXI7XG4gICAgICB0LnVuaWZvcm1zLnVFbmFibGVSaXBwbGVzLnZhbHVlID0gZW5hYmxlUmlwcGxlcyA/IDEgOiAwO1xuICAgICAgdC51bmlmb3Jtcy51UmlwcGxlSW50ZW5zaXR5LnZhbHVlID0gcmlwcGxlSW50ZW5zaXR5U2NhbGU7XG4gICAgICB0LnVuaWZvcm1zLnVSaXBwbGVUaGlja25lc3MudmFsdWUgPSByaXBwbGVUaGlja25lc3M7XG4gICAgICB0LnVuaWZvcm1zLnVSaXBwbGVTcGVlZC52YWx1ZSA9IHJpcHBsZVNwZWVkO1xuICAgICAgdC51bmlmb3Jtcy51RWRnZUZhZGUudmFsdWUgPSBlZGdlRmFkZTtcbiAgICAgIGlmICh0cmFuc3BhcmVudCkgdC5yZW5kZXJlci5zZXRDbGVhckFscGhhKDApO1xuICAgICAgZWxzZSB0LnJlbmRlcmVyLnNldENsZWFyQ29sb3IoMHgwMDAwMDAsIDEpO1xuICAgICAgaWYgKHQubGlxdWlkRWZmZWN0KSB7XG4gICAgICAgIGNvbnN0IHVTdHJlbmd0aCA9IHQubGlxdWlkRWZmZWN0O1xuICAgICAgICBpZiAodVN0cmVuZ3RoKSB1U3RyZW5ndGgudmFsdWUgPSBsaXF1aWRTdHJlbmd0aDtcbiAgICAgICAgY29uc3QgdUZyZXEgPSB0LmxpcXVpZEVmZmVjdC51bmlmb3Jtcy5nZXQoJ3VGcmVxJyk7XG4gICAgICAgIGlmICh1RnJlcSkgdUZyZXEudmFsdWUgPSBsaXF1aWRXb2JibGVTcGVlZDtcbiAgICAgIH1cbiAgICAgIGlmICh0LnRvdWNoKSB0LnRvdWNoLnJhZGl1c1NjYWxlID0gbGlxdWlkUmFkaXVzO1xuICAgIH1cbiAgICBwcmV2Q29uZmlnUmVmLmN1cnJlbnQgPSBjZmc7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmICh0aHJlZVJlZi5jdXJyZW50ICYmIG11c3RSZWluaXQpIHJldHVybjtcbiAgICAgIGlmICghdGhyZWVSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgY29uc3QgdCA9IHRocmVlUmVmLmN1cnJlbnQ7XG4gICAgICB0LnJlc2l6ZU9ic2VydmVyPy5kaXNjb25uZWN0KCk7XG4gICAgICBjYW5jZWxBbmltYXRpb25GcmFtZSh0LnJhZik7XG4gICAgICB0LnF1YWQ/Lmdlb21ldHJ5LmRpc3Bvc2UoKTtcbiAgICAgIHQubWF0ZXJpYWwuZGlzcG9zZSgpO1xuICAgICAgdC5jb21wb3Nlcj8uZGlzcG9zZSgpO1xuICAgICAgdC5yZW5kZXJlci5kaXNwb3NlKCk7XG4gICAgICB0LnJlbmRlcmVyLmZvcmNlQ29udGV4dExvc3MoKTtcbiAgICAgIGlmICh0LnJlbmRlcmVyLmRvbUVsZW1lbnQucGFyZW50RWxlbWVudCA9PT0gY29udGFpbmVyKSBjb250YWluZXIucmVtb3ZlQ2hpbGQodC5yZW5kZXJlci5kb21FbGVtZW50KTtcbiAgICAgIHRocmVlUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH07XG4gIH0sIFtcbiAgICBhbnRpYWxpYXMsXG4gICAgbGlxdWlkLFxuICAgIG5vaXNlQW1vdW50LFxuICAgIHBpeGVsU2l6ZSxcbiAgICBwYXR0ZXJuU2NhbGUsXG4gICAgcGF0dGVybkRlbnNpdHksXG4gICAgZW5hYmxlUmlwcGxlcyxcbiAgICByaXBwbGVJbnRlbnNpdHlTY2FsZSxcbiAgICByaXBwbGVUaGlja25lc3MsXG4gICAgcmlwcGxlU3BlZWQsXG4gICAgcGl4ZWxTaXplSml0dGVyLFxuICAgIGVkZ2VGYWRlLFxuICAgIHRyYW5zcGFyZW50LFxuICAgIGxpcXVpZFN0cmVuZ3RoLFxuICAgIGxpcXVpZFJhZGl1cyxcbiAgICBsaXF1aWRXb2JibGVTcGVlZCxcbiAgICBhdXRvUGF1c2VPZmZzY3JlZW4sXG4gICAgdmFyaWFudCxcbiAgICBjb2xvcixcbiAgICBzcGVlZFxuICBdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHJlZj17Y29udGFpbmVyUmVmfVxuICAgICAgY2xhc3NOYW1lPXtgcGl4ZWwtYmxhc3QtY29udGFpbmVyICR7Y2xhc3NOYW1lID8/ICcnfWB9XG4gICAgICBzdHlsZT17c3R5bGV9XG4gICAgICBhcmlhLWxhYmVsPVwiUGl4ZWxCbGFzdCBpbnRlcmFjdGl2ZSBiYWNrZ3JvdW5kXCJcbiAgICAvPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUGl4ZWxCbGFzdDtcbiJdLCJmaWxlIjoiRDovV29yay9TYXN1ZHVsL3Nhc2Evc2FzdW5kdWwtcG9ydGZvbGlvL2NvbXBvbmVudHMvUGl4ZWxCbGFzdC50c3gifQ==