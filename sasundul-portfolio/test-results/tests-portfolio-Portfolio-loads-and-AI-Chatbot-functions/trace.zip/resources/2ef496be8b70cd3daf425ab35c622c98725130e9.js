import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];
function getSpeechRecognition() {
  const w = window;
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}
export function useVoice(options) {
  const [state, setState] = useState({
    isListening: false,
    isSpeaking: false,
    isSupported: typeof window !== "undefined" && Boolean(getSpeechRecognition()),
    transcript: "",
    error: null
  });
  const recognitionRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animFrameRef = useRef(0);
  const audioLevelRef = useRef(0);
  const isSpeakingRef = useRef(false);
  const optionsRef = useRef(options);
  useEffect(() => {
    optionsRef.current = options;
  }, [options]);
  useEffect(() => {
    return () => {
      stopListening();
      stopSpeaking();
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current?.state !== "closed") {
        audioContextRef.current?.close();
      }
    };
  }, []);
  const stopSpeaking = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    isSpeakingRef.current = false;
    setState((s) => ({ ...s, isSpeaking: false }));
  }, []);
  const startListening = useCallback(() => {
    const SRConstructor = getSpeechRecognition();
    if (!SRConstructor) {
      setState((s) => ({ ...s, error: "Voice input not supported in this browser" }));
      return;
    }
    if (window.speechSynthesis?.speaking || isSpeakingRef.current) {
      stopSpeaking();
      optionsRef.current?.onInterrupted?.();
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {
      }
    }
    const recognition = new SRConstructor();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "en-US";
    recognition.maxAlternatives = 1;
    recognition.onstart = () => {
      setState((s) => ({ ...s, isListening: true, transcript: "", error: null }));
    };
    recognition.onresult = (event) => {
      if (window.speechSynthesis?.speaking || isSpeakingRef.current) {
        stopSpeaking();
        optionsRef.current?.onInterrupted?.();
      }
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      const lower = transcript.trim().toLowerCase();
      if (["stop", "quiet", "be quiet", "shut up", "hold on", "pause"].includes(lower)) {
        stopSpeaking();
        recognition.stop();
        setState((s) => ({ ...s, isListening: false, transcript: "" }));
        return;
      }
      setState((s) => ({ ...s, transcript }));
    };
    recognition.onerror = (event) => {
      const errorMsg = event.error === "not-allowed" ? "Microphone access denied" : event.error === "no-speech" ? "" : `Voice error: ${event.error}`;
      setState((s) => ({ ...s, error: errorMsg || null, isListening: false }));
    };
    recognition.onend = () => {
      setState((s) => ({ ...s, isListening: false }));
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
      }
    };
    recognitionRef.current = recognition;
    try {
      recognition.start();
    } catch (e) {
      console.warn("Recognition start error:", e);
    }
    startAudioAnalysis();
  }, [stopSpeaking]);
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
      }
      recognitionRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setState((s) => ({ ...s, isListening: false }));
  }, []);
  const startAudioAnalysis = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      const ctx = new AudioContext();
      audioContextRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        const sum = dataArray.reduce((a, b) => a + b, 0);
        const avg = sum / dataArray.length / 255;
        audioLevelRef.current = avg;
        animFrameRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch {
    }
  }, []);
  const speak = useCallback((text) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    let cleanText = text.replace(/```[\s\S]*?```/g, "code block").replace(/`([^`]+)`/g, "$1").replace(/[*_~#]/g, "").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/\n+/g, ". ").trim();
    const sentences = cleanText.match(/[^.!?]+[.!?]+/g) || [cleanText];
    if (sentences.length > 2) {
      cleanText = sentences.slice(0, 2).join(" ");
    } else if (cleanText.length > 220) {
      cleanText = cleanText.slice(0, 220) + "...";
    }
    cleanText = cleanText.replace(/Sasundul Wanasinghe/gi, "Suh-soon-dool Wahn-uh-sing-heh").replace(/Sasundul's/gi, "Suh-soon-doolz").replace(/Sasundul/gi, "Suh-soon-dool").replace(/Sasa's/gi, "Sah-sahz").replace(/\bSasa\b/gi, "Sah-sah");
    if (!cleanText) return;
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.05;
    utterance.pitch = 1;
    utterance.volume = 1;
    const voices = window.speechSynthesis.getVoices();
    const preferred = [
      "Google UK English Male",
      "Daniel",
      "Microsoft David",
      "Alex",
      "English United Kingdom"
    ];
    let selectedVoice = voices.find(
      (v) => preferred.some((p) => v.name.includes(p)) && v.lang.startsWith("en")
    );
    if (!selectedVoice) {
      selectedVoice = voices.find((v) => v.lang.startsWith("en") && v.name.toLowerCase().includes("male"));
    }
    if (!selectedVoice) {
      selectedVoice = voices.find((v) => v.lang.startsWith("en"));
    }
    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }
    utterance.onstart = () => {
      isSpeakingRef.current = true;
      setState((s) => ({ ...s, isSpeaking: true }));
    };
    utterance.onend = () => {
      isSpeakingRef.current = false;
      setState((s) => ({ ...s, isSpeaking: false }));
      optionsRef.current?.onSpeechEnd?.();
    };
    utterance.onerror = () => {
      isSpeakingRef.current = false;
      setState((s) => ({ ...s, isSpeaking: false }));
    };
    isSpeakingRef.current = true;
    setState((s) => ({ ...s, isSpeaking: true }));
    window.speechSynthesis.speak(utterance);
  }, []);
  return {
    ...state,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    getAudioLevel: () => audioLevelRef.current
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZVZvaWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkFxuLy8gVk9JQ0UgRU5HSU5FIOKAlCBTaXJpLWxpa2UgVm9pY2UgRW5naW5lIHdpdGggUmVhbC1UaW1lIEludGVycnVwdGlvbiAoQmFyZ2UtSW4pXG4vLyBXaXRoIFBob25ldGljIE5hbWUgUHJvbnVuY2lhdGlvbiAmIEF1ZGlvIEFuYWx5c2lzXG4vLyDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZBcblxuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUNhbGxiYWNrLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcblxuZnVuY3Rpb24gZ2V0U3BlZWNoUmVjb2duaXRpb24oKTogKG5ldyAoKSA9PiBTcGVlY2hSZWNvZ25pdGlvbikgfCBudWxsIHtcbiAgY29uc3QgdyA9IHdpbmRvdyBhcyBhbnk7XG4gIHJldHVybiB3LlNwZWVjaFJlY29nbml0aW9uIHx8IHcud2Via2l0U3BlZWNoUmVjb2duaXRpb24gfHwgbnVsbDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBWb2ljZVN0YXRlIHtcbiAgaXNMaXN0ZW5pbmc6IGJvb2xlYW47XG4gIGlzU3BlYWtpbmc6IGJvb2xlYW47XG4gIGlzU3VwcG9ydGVkOiBib29sZWFuO1xuICB0cmFuc2NyaXB0OiBzdHJpbmc7XG4gIGVycm9yOiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFVzZVZvaWNlT3B0aW9ucyB7XG4gIG9uU3BlZWNoRW5kPzogKCkgPT4gdm9pZDtcbiAgb25JbnRlcnJ1cHRlZD86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VWb2ljZShvcHRpb25zPzogVXNlVm9pY2VPcHRpb25zKSB7XG4gIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGU8Vm9pY2VTdGF0ZT4oe1xuICAgIGlzTGlzdGVuaW5nOiBmYWxzZSxcbiAgICBpc1NwZWFraW5nOiBmYWxzZSxcbiAgICBpc1N1cHBvcnRlZDogdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgQm9vbGVhbihnZXRTcGVlY2hSZWNvZ25pdGlvbigpKSxcbiAgICB0cmFuc2NyaXB0OiAnJyxcbiAgICBlcnJvcjogbnVsbCxcbiAgfSk7XG5cbiAgY29uc3QgcmVjb2duaXRpb25SZWYgPSB1c2VSZWY8U3BlZWNoUmVjb2duaXRpb24gfCBudWxsPihudWxsKTtcbiAgY29uc3QgbWVkaWFTdHJlYW1SZWYgPSB1c2VSZWY8TWVkaWFTdHJlYW0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgYXVkaW9Db250ZXh0UmVmID0gdXNlUmVmPEF1ZGlvQ29udGV4dCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBhbmFseXNlclJlZiA9IHVzZVJlZjxBbmFseXNlck5vZGUgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYW5pbUZyYW1lUmVmID0gdXNlUmVmPG51bWJlcj4oMCk7XG4gIGNvbnN0IGF1ZGlvTGV2ZWxSZWYgPSB1c2VSZWY8bnVtYmVyPigwKTtcbiAgY29uc3QgaXNTcGVha2luZ1JlZiA9IHVzZVJlZihmYWxzZSk7XG5cbiAgLy8gS2VlcCBvcHRpb25zIGluIHJlZlxuICBjb25zdCBvcHRpb25zUmVmID0gdXNlUmVmKG9wdGlvbnMpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG9wdGlvbnNSZWYuY3VycmVudCA9IG9wdGlvbnM7XG4gIH0sIFtvcHRpb25zXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc3RvcExpc3RlbmluZygpO1xuICAgICAgc3RvcFNwZWFraW5nKCk7XG4gICAgICBpZiAoYW5pbUZyYW1lUmVmLmN1cnJlbnQpIGNhbmNlbEFuaW1hdGlvbkZyYW1lKGFuaW1GcmFtZVJlZi5jdXJyZW50KTtcbiAgICAgIGlmIChhdWRpb0NvbnRleHRSZWYuY3VycmVudD8uc3RhdGUgIT09ICdjbG9zZWQnKSB7XG4gICAgICAgIGF1ZGlvQ29udGV4dFJlZi5jdXJyZW50Py5jbG9zZSgpO1xuICAgICAgfVxuICAgIH07XG4gIH0sIFtdKTtcblxuICAvLyDilIDilIAgU1RPUCBTUEVBS0lORyBJTlNUQU5UTFkgKEJhcmdlLWluIC8gSW50ZXJydXB0aW9uKSDilIDilIBcbiAgY29uc3Qgc3RvcFNwZWFraW5nID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmICh3aW5kb3cuc3BlZWNoU3ludGhlc2lzKSB7XG4gICAgICB3aW5kb3cuc3BlZWNoU3ludGhlc2lzLmNhbmNlbCgpO1xuICAgIH1cbiAgICBpc1NwZWFraW5nUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICBzZXRTdGF0ZShzID0+ICh7IC4uLnMsIGlzU3BlYWtpbmc6IGZhbHNlIH0pKTtcbiAgfSwgW10pO1xuXG4gIC8vIOKUgOKUgCBTUEVFQ0gtVE8tVEVYVCAoTGlzdGVuaW5nIHdpdGggU3BlZWNoIEludGVycnVwdGlvbikg4pSA4pSAXG4gIGNvbnN0IHN0YXJ0TGlzdGVuaW5nID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IFNSQ29uc3RydWN0b3IgPSBnZXRTcGVlY2hSZWNvZ25pdGlvbigpO1xuICAgIGlmICghU1JDb25zdHJ1Y3Rvcikge1xuICAgICAgc2V0U3RhdGUocyA9PiAoeyAuLi5zLCBlcnJvcjogJ1ZvaWNlIGlucHV0IG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBicm93c2VyJyB9KSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQkFSR0UtSU46IElmIEFJIGlzIGN1cnJlbnRseSBzcGVha2luZyBhbmQgdXNlciB0cmlnZ2VycyBtaWMsIFNUT1Agc3BlYWtpbmcgaW1tZWRpYXRlbHkhXG4gICAgaWYgKHdpbmRvdy5zcGVlY2hTeW50aGVzaXM/LnNwZWFraW5nIHx8IGlzU3BlYWtpbmdSZWYuY3VycmVudCkge1xuICAgICAgc3RvcFNwZWFraW5nKCk7XG4gICAgICBvcHRpb25zUmVmLmN1cnJlbnQ/Lm9uSW50ZXJydXB0ZWQ/LigpO1xuICAgIH1cblxuICAgIGlmIChyZWNvZ25pdGlvblJlZi5jdXJyZW50KSB7XG4gICAgICB0cnkgeyByZWNvZ25pdGlvblJlZi5jdXJyZW50LmFib3J0KCk7IH0gY2F0Y2gge31cbiAgICB9XG5cbiAgICBjb25zdCByZWNvZ25pdGlvbiA9IG5ldyBTUkNvbnN0cnVjdG9yKCk7XG4gICAgcmVjb2duaXRpb24uY29udGludW91cyA9IGZhbHNlO1xuICAgIHJlY29nbml0aW9uLmludGVyaW1SZXN1bHRzID0gdHJ1ZTtcbiAgICByZWNvZ25pdGlvbi5sYW5nID0gJ2VuLVVTJztcbiAgICByZWNvZ25pdGlvbi5tYXhBbHRlcm5hdGl2ZXMgPSAxO1xuXG4gICAgcmVjb2duaXRpb24ub25zdGFydCA9ICgpID0+IHtcbiAgICAgIHNldFN0YXRlKHMgPT4gKHsgLi4ucywgaXNMaXN0ZW5pbmc6IHRydWUsIHRyYW5zY3JpcHQ6ICcnLCBlcnJvcjogbnVsbCB9KSk7XG4gICAgfTtcblxuICAgIHJlY29nbml0aW9uLm9ucmVzdWx0ID0gKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgIC8vIEJBUkdFLUlOOiBJZiBBSSBpcyBzcGVha2luZyB3aGlsZSB1c2VyIHNwZWFrcywgc3RvcCBBSSBzcGVlY2ggaW5zdGFudGx5IVxuICAgICAgaWYgKHdpbmRvdy5zcGVlY2hTeW50aGVzaXM/LnNwZWFraW5nIHx8IGlzU3BlYWtpbmdSZWYuY3VycmVudCkge1xuICAgICAgICBzdG9wU3BlYWtpbmcoKTtcbiAgICAgICAgb3B0aW9uc1JlZi5jdXJyZW50Py5vbkludGVycnVwdGVkPy4oKTtcbiAgICAgIH1cblxuICAgICAgbGV0IHRyYW5zY3JpcHQgPSAnJztcbiAgICAgIGZvciAobGV0IGkgPSBldmVudC5yZXN1bHRJbmRleDsgaSA8IGV2ZW50LnJlc3VsdHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdHJhbnNjcmlwdCArPSBldmVudC5yZXN1bHRzW2ldWzBdLnRyYW5zY3JpcHQ7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIElmIHVzZXIgc2F5cyBcInN0b3BcIiwgXCJxdWlldFwiLCBcImJlIHF1aWV0XCIsIFwic2h1dCB1cFwiLCBcImhvbGQgb25cIlxuICAgICAgY29uc3QgbG93ZXIgPSB0cmFuc2NyaXB0LnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKFsnc3RvcCcsICdxdWlldCcsICdiZSBxdWlldCcsICdzaHV0IHVwJywgJ2hvbGQgb24nLCAncGF1c2UnXS5pbmNsdWRlcyhsb3dlcikpIHtcbiAgICAgICAgc3RvcFNwZWFraW5nKCk7XG4gICAgICAgIHJlY29nbml0aW9uLnN0b3AoKTtcbiAgICAgICAgc2V0U3RhdGUocyA9PiAoeyAuLi5zLCBpc0xpc3RlbmluZzogZmFsc2UsIHRyYW5zY3JpcHQ6ICcnIH0pKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBzZXRTdGF0ZShzID0+ICh7IC4uLnMsIHRyYW5zY3JpcHQgfSkpO1xuICAgIH07XG5cbiAgICByZWNvZ25pdGlvbi5vbmVycm9yID0gKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgIGNvbnN0IGVycm9yTXNnID0gZXZlbnQuZXJyb3IgPT09ICdub3QtYWxsb3dlZCdcbiAgICAgICAgPyAnTWljcm9waG9uZSBhY2Nlc3MgZGVuaWVkJ1xuICAgICAgICA6IGV2ZW50LmVycm9yID09PSAnbm8tc3BlZWNoJ1xuICAgICAgICA/ICcnXG4gICAgICAgIDogYFZvaWNlIGVycm9yOiAke2V2ZW50LmVycm9yfWA7XG4gICAgICBcbiAgICAgIHNldFN0YXRlKHMgPT4gKHsgLi4ucywgZXJyb3I6IGVycm9yTXNnIHx8IG51bGwsIGlzTGlzdGVuaW5nOiBmYWxzZSB9KSk7XG4gICAgfTtcblxuICAgIHJlY29nbml0aW9uLm9uZW5kID0gKCkgPT4ge1xuICAgICAgc2V0U3RhdGUocyA9PiAoeyAuLi5zLCBpc0xpc3RlbmluZzogZmFsc2UgfSkpO1xuICAgICAgaWYgKG1lZGlhU3RyZWFtUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgbWVkaWFTdHJlYW1SZWYuY3VycmVudC5nZXRUcmFja3MoKS5mb3JFYWNoKHQgPT4gdC5zdG9wKCkpO1xuICAgICAgICBtZWRpYVN0cmVhbVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgcmVjb2duaXRpb25SZWYuY3VycmVudCA9IHJlY29nbml0aW9uO1xuICAgIHRyeSB7XG4gICAgICByZWNvZ25pdGlvbi5zdGFydCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUud2FybignUmVjb2duaXRpb24gc3RhcnQgZXJyb3I6JywgZSk7XG4gICAgfVxuXG4gICAgc3RhcnRBdWRpb0FuYWx5c2lzKCk7XG4gIH0sIFtzdG9wU3BlYWtpbmddKTtcblxuICBjb25zdCBzdG9wTGlzdGVuaW5nID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmIChyZWNvZ25pdGlvblJlZi5jdXJyZW50KSB7XG4gICAgICB0cnkgeyByZWNvZ25pdGlvblJlZi5jdXJyZW50LnN0b3AoKTsgfSBjYXRjaCB7fVxuICAgICAgcmVjb2duaXRpb25SZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmIChtZWRpYVN0cmVhbVJlZi5jdXJyZW50KSB7XG4gICAgICBtZWRpYVN0cmVhbVJlZi5jdXJyZW50LmdldFRyYWNrcygpLmZvckVhY2godCA9PiB0LnN0b3AoKSk7XG4gICAgICBtZWRpYVN0cmVhbVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgc2V0U3RhdGUocyA9PiAoeyAuLi5zLCBpc0xpc3RlbmluZzogZmFsc2UgfSkpO1xuICB9LCBbXSk7XG5cbiAgLy8g4pSA4pSAIEF1ZGlvIExldmVsIEFuYWx5c2lzIGZvciBXYXZlZm9ybSDilIDilIBcbiAgY29uc3Qgc3RhcnRBdWRpb0FuYWx5c2lzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYSh7IGF1ZGlvOiB0cnVlIH0pO1xuICAgICAgbWVkaWFTdHJlYW1SZWYuY3VycmVudCA9IHN0cmVhbTtcblxuICAgICAgY29uc3QgY3R4ID0gbmV3IEF1ZGlvQ29udGV4dCgpO1xuICAgICAgYXVkaW9Db250ZXh0UmVmLmN1cnJlbnQgPSBjdHg7XG4gICAgICBjb25zdCBzb3VyY2UgPSBjdHguY3JlYXRlTWVkaWFTdHJlYW1Tb3VyY2Uoc3RyZWFtKTtcbiAgICAgIGNvbnN0IGFuYWx5c2VyID0gY3R4LmNyZWF0ZUFuYWx5c2VyKCk7XG4gICAgICBhbmFseXNlci5mZnRTaXplID0gMjU2O1xuICAgICAgc291cmNlLmNvbm5lY3QoYW5hbHlzZXIpO1xuICAgICAgYW5hbHlzZXJSZWYuY3VycmVudCA9IGFuYWx5c2VyO1xuXG4gICAgICBjb25zdCBkYXRhQXJyYXkgPSBuZXcgVWludDhBcnJheShhbmFseXNlci5mcmVxdWVuY3lCaW5Db3VudCk7XG5cbiAgICAgIGNvbnN0IHRpY2sgPSAoKSA9PiB7XG4gICAgICAgIGlmICghYW5hbHlzZXJSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgICBhbmFseXNlclJlZi5jdXJyZW50LmdldEJ5dGVGcmVxdWVuY3lEYXRhKGRhdGFBcnJheSk7XG4gICAgICAgIGNvbnN0IHN1bSA9IGRhdGFBcnJheS5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiLCAwKTtcbiAgICAgICAgY29uc3QgYXZnID0gc3VtIC8gZGF0YUFycmF5Lmxlbmd0aCAvIDI1NTtcbiAgICAgICAgYXVkaW9MZXZlbFJlZi5jdXJyZW50ID0gYXZnO1xuICAgICAgICBhbmltRnJhbWVSZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKTtcbiAgICAgIH07XG4gICAgICB0aWNrKCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBNaWMgcGVybWlzc2lvbiBlcnJvciBoYW5kbGUgc2lsZW50bHlcbiAgICB9XG4gIH0sIFtdKTtcblxuICAvLyDilIDilIAgVEVYVC1UTy1TUEVFQ0ggKFNwZWFraW5nIHdpdGggUGhvbmV0aWMgQ29ycmVjdGlvbnMgJiBTaG9ydCBUcmltbWluZykg4pSA4pSAXG4gIGNvbnN0IHNwZWFrID0gdXNlQ2FsbGJhY2soKHRleHQ6IHN0cmluZykgPT4ge1xuICAgIGlmICghd2luZG93LnNwZWVjaFN5bnRoZXNpcykgcmV0dXJuO1xuXG4gICAgd2luZG93LnNwZWVjaFN5bnRoZXNpcy5jYW5jZWwoKTtcblxuICAgIC8vIDEuIENsZWFuIG1hcmtkb3duIGZvcm1hdHRpbmcgc3ltYm9sc1xuICAgIGxldCBjbGVhblRleHQgPSB0ZXh0XG4gICAgICAucmVwbGFjZSgvYGBgW1xcc1xcU10qP2BgYC9nLCAnY29kZSBibG9jaycpXG4gICAgICAucmVwbGFjZSgvYChbXmBdKylgL2csICckMScpXG4gICAgICAucmVwbGFjZSgvWypffiNdL2csICcnKVxuICAgICAgLnJlcGxhY2UoL1xcWyhbXlxcXV0rKVxcXVxcKFteKV0rXFwpL2csICckMScpXG4gICAgICAucmVwbGFjZSgvXFxuKy9nLCAnLiAnKVxuICAgICAgLnRyaW0oKTtcblxuICAgIC8vIDIuIFNIT1JUIFNQRUVDSCBUUklNOiBUYWtlIGZpcnN0IDIgc2VudGVuY2VzIG1heCAodW5kZXIgMTgwIGNoYXJzKSBmb3Igc3BlZWNoIG91dHB1dFxuICAgIGNvbnN0IHNlbnRlbmNlcyA9IGNsZWFuVGV4dC5tYXRjaCgvW14uIT9dK1suIT9dKy9nKSB8fCBbY2xlYW5UZXh0XTtcbiAgICBpZiAoc2VudGVuY2VzLmxlbmd0aCA+IDIpIHtcbiAgICAgIGNsZWFuVGV4dCA9IHNlbnRlbmNlcy5zbGljZSgwLCAyKS5qb2luKCcgJyk7XG4gICAgfSBlbHNlIGlmIChjbGVhblRleHQubGVuZ3RoID4gMjIwKSB7XG4gICAgICBjbGVhblRleHQgPSBjbGVhblRleHQuc2xpY2UoMCwgMjIwKSArICcuLi4nO1xuICAgIH1cblxuICAgIC8vIDMuIFBob25ldGljIE5hbWUgUmVwbGFjZW1lbnRcbiAgICBjbGVhblRleHQgPSBjbGVhblRleHRcbiAgICAgIC5yZXBsYWNlKC9TYXN1bmR1bCBXYW5hc2luZ2hlL2dpLCAnU3VoLXNvb24tZG9vbCBXYWhuLXVoLXNpbmctaGVoJylcbiAgICAgIC5yZXBsYWNlKC9TYXN1bmR1bCdzL2dpLCAnU3VoLXNvb24tZG9vbHonKVxuICAgICAgLnJlcGxhY2UoL1Nhc3VuZHVsL2dpLCAnU3VoLXNvb24tZG9vbCcpXG4gICAgICAucmVwbGFjZSgvU2FzYSdzL2dpLCAnU2FoLXNhaHonKVxuICAgICAgLnJlcGxhY2UoL1xcYlNhc2FcXGIvZ2ksICdTYWgtc2FoJyk7XG5cbiAgICBpZiAoIWNsZWFuVGV4dCkgcmV0dXJuO1xuXG4gICAgY29uc3QgdXR0ZXJhbmNlID0gbmV3IFNwZWVjaFN5bnRoZXNpc1V0dGVyYW5jZShjbGVhblRleHQpO1xuICAgIHV0dGVyYW5jZS5yYXRlID0gMS4wNTtcbiAgICB1dHRlcmFuY2UucGl0Y2ggPSAxLjA7XG4gICAgdXR0ZXJhbmNlLnZvbHVtZSA9IDEuMDtcblxuICAgIGNvbnN0IHZvaWNlcyA9IHdpbmRvdy5zcGVlY2hTeW50aGVzaXMuZ2V0Vm9pY2VzKCk7XG4gICAgY29uc3QgcHJlZmVycmVkID0gW1xuICAgICAgJ0dvb2dsZSBVSyBFbmdsaXNoIE1hbGUnLFxuICAgICAgJ0RhbmllbCcsXG4gICAgICAnTWljcm9zb2Z0IERhdmlkJyxcbiAgICAgICdBbGV4JyxcbiAgICAgICdFbmdsaXNoIFVuaXRlZCBLaW5nZG9tJyxcbiAgICBdO1xuXG4gICAgbGV0IHNlbGVjdGVkVm9pY2UgPSB2b2ljZXMuZmluZCh2ID0+XG4gICAgICBwcmVmZXJyZWQuc29tZShwID0+IHYubmFtZS5pbmNsdWRlcyhwKSkgJiYgdi5sYW5nLnN0YXJ0c1dpdGgoJ2VuJylcbiAgICApO1xuXG4gICAgaWYgKCFzZWxlY3RlZFZvaWNlKSB7XG4gICAgICBzZWxlY3RlZFZvaWNlID0gdm9pY2VzLmZpbmQodiA9PiB2Lmxhbmcuc3RhcnRzV2l0aCgnZW4nKSAmJiB2Lm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygnbWFsZScpKTtcbiAgICB9XG4gICAgaWYgKCFzZWxlY3RlZFZvaWNlKSB7XG4gICAgICBzZWxlY3RlZFZvaWNlID0gdm9pY2VzLmZpbmQodiA9PiB2Lmxhbmcuc3RhcnRzV2l0aCgnZW4nKSk7XG4gICAgfVxuXG4gICAgaWYgKHNlbGVjdGVkVm9pY2UpIHtcbiAgICAgIHV0dGVyYW5jZS52b2ljZSA9IHNlbGVjdGVkVm9pY2U7XG4gICAgfVxuXG4gICAgdXR0ZXJhbmNlLm9uc3RhcnQgPSAoKSA9PiB7XG4gICAgICBpc1NwZWFraW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgc2V0U3RhdGUocyA9PiAoeyAuLi5zLCBpc1NwZWFraW5nOiB0cnVlIH0pKTtcbiAgICB9O1xuICAgIFxuICAgIHV0dGVyYW5jZS5vbmVuZCA9ICgpID0+IHtcbiAgICAgIGlzU3BlYWtpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgc2V0U3RhdGUocyA9PiAoeyAuLi5zLCBpc1NwZWFraW5nOiBmYWxzZSB9KSk7XG4gICAgICBvcHRpb25zUmVmLmN1cnJlbnQ/Lm9uU3BlZWNoRW5kPy4oKTtcbiAgICB9O1xuXG4gICAgdXR0ZXJhbmNlLm9uZXJyb3IgPSAoKSA9PiB7XG4gICAgICBpc1NwZWFraW5nUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIHNldFN0YXRlKHMgPT4gKHsgLi4ucywgaXNTcGVha2luZzogZmFsc2UgfSkpO1xuICAgIH07XG5cbiAgICBpc1NwZWFraW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIHNldFN0YXRlKHMgPT4gKHsgLi4ucywgaXNTcGVha2luZzogdHJ1ZSB9KSk7XG4gICAgd2luZG93LnNwZWVjaFN5bnRoZXNpcy5zcGVhayh1dHRlcmFuY2UpO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIHtcbiAgICAuLi5zdGF0ZSxcbiAgICBzdGFydExpc3RlbmluZyxcbiAgICBzdG9wTGlzdGVuaW5nLFxuICAgIHNwZWFrLFxuICAgIHN0b3BTcGVha2luZyxcbiAgICBnZXRBdWRpb0xldmVsOiAoKSA9PiBhdWRpb0xldmVsUmVmLmN1cnJlbnQsXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUtBLFNBQVMsVUFBVSxhQUFhLFFBQVEsaUJBQWlCO0FBRXpELFNBQVMsdUJBQTZEO0FBQ3BFLFFBQU0sSUFBSTtBQUNWLFNBQU8sRUFBRSxxQkFBcUIsRUFBRSwyQkFBMkI7QUFDN0Q7QUFlTyxnQkFBUyxTQUFTLFNBQTJCO0FBQ2xELFFBQU0sQ0FBQyxPQUFPLFFBQVEsSUFBSSxTQUFxQjtBQUFBLElBQzdDLGFBQWE7QUFBQSxJQUNiLFlBQVk7QUFBQSxJQUNaLGFBQWEsT0FBTyxXQUFXLGVBQWUsUUFBUSxxQkFBcUIsQ0FBQztBQUFBLElBQzVFLFlBQVk7QUFBQSxJQUNaLE9BQU87QUFBQSxFQUNULENBQUM7QUFFRCxRQUFNLGlCQUFpQixPQUFpQyxJQUFJO0FBQzVELFFBQU0saUJBQWlCLE9BQTJCLElBQUk7QUFDdEQsUUFBTSxrQkFBa0IsT0FBNEIsSUFBSTtBQUN4RCxRQUFNLGNBQWMsT0FBNEIsSUFBSTtBQUNwRCxRQUFNLGVBQWUsT0FBZSxDQUFDO0FBQ3JDLFFBQU0sZ0JBQWdCLE9BQWUsQ0FBQztBQUN0QyxRQUFNLGdCQUFnQixPQUFPLEtBQUs7QUFHbEMsUUFBTSxhQUFhLE9BQU8sT0FBTztBQUNqQyxZQUFVLE1BQU07QUFDZCxlQUFXLFVBQVU7QUFBQSxFQUN2QixHQUFHLENBQUMsT0FBTyxDQUFDO0FBRVosWUFBVSxNQUFNO0FBQ2QsV0FBTyxNQUFNO0FBQ1gsb0JBQWM7QUFDZCxtQkFBYTtBQUNiLFVBQUksYUFBYSxRQUFTLHNCQUFxQixhQUFhLE9BQU87QUFDbkUsVUFBSSxnQkFBZ0IsU0FBUyxVQUFVLFVBQVU7QUFDL0Msd0JBQWdCLFNBQVMsTUFBTTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDLENBQUM7QUFHTCxRQUFNLGVBQWUsWUFBWSxNQUFNO0FBQ3JDLFFBQUksT0FBTyxpQkFBaUI7QUFDMUIsYUFBTyxnQkFBZ0IsT0FBTztBQUFBLElBQ2hDO0FBQ0Esa0JBQWMsVUFBVTtBQUN4QixhQUFTLFFBQU0sRUFBRSxHQUFHLEdBQUcsWUFBWSxNQUFNLEVBQUU7QUFBQSxFQUM3QyxHQUFHLENBQUMsQ0FBQztBQUdMLFFBQU0saUJBQWlCLFlBQVksTUFBTTtBQUN2QyxVQUFNLGdCQUFnQixxQkFBcUI7QUFDM0MsUUFBSSxDQUFDLGVBQWU7QUFDbEIsZUFBUyxRQUFNLEVBQUUsR0FBRyxHQUFHLE9BQU8sNENBQTRDLEVBQUU7QUFDNUU7QUFBQSxJQUNGO0FBR0EsUUFBSSxPQUFPLGlCQUFpQixZQUFZLGNBQWMsU0FBUztBQUM3RCxtQkFBYTtBQUNiLGlCQUFXLFNBQVMsZ0JBQWdCO0FBQUEsSUFDdEM7QUFFQSxRQUFJLGVBQWUsU0FBUztBQUMxQixVQUFJO0FBQUUsdUJBQWUsUUFBUSxNQUFNO0FBQUEsTUFBRyxRQUFRO0FBQUEsTUFBQztBQUFBLElBQ2pEO0FBRUEsVUFBTSxjQUFjLElBQUksY0FBYztBQUN0QyxnQkFBWSxhQUFhO0FBQ3pCLGdCQUFZLGlCQUFpQjtBQUM3QixnQkFBWSxPQUFPO0FBQ25CLGdCQUFZLGtCQUFrQjtBQUU5QixnQkFBWSxVQUFVLE1BQU07QUFDMUIsZUFBUyxRQUFNLEVBQUUsR0FBRyxHQUFHLGFBQWEsTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLEVBQUU7QUFBQSxJQUMxRTtBQUVBLGdCQUFZLFdBQVcsQ0FBQyxVQUFlO0FBRXJDLFVBQUksT0FBTyxpQkFBaUIsWUFBWSxjQUFjLFNBQVM7QUFDN0QscUJBQWE7QUFDYixtQkFBVyxTQUFTLGdCQUFnQjtBQUFBLE1BQ3RDO0FBRUEsVUFBSSxhQUFhO0FBQ2pCLGVBQVMsSUFBSSxNQUFNLGFBQWEsSUFBSSxNQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzdELHNCQUFjLE1BQU0sUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFFO0FBQUEsTUFDcEM7QUFHQSxZQUFNLFFBQVEsV0FBVyxLQUFLLEVBQUUsWUFBWTtBQUM1QyxVQUFJLENBQUMsUUFBUSxTQUFTLFlBQVksV0FBVyxXQUFXLE9BQU8sRUFBRSxTQUFTLEtBQUssR0FBRztBQUNoRixxQkFBYTtBQUNiLG9CQUFZLEtBQUs7QUFDakIsaUJBQVMsUUFBTSxFQUFFLEdBQUcsR0FBRyxhQUFhLE9BQU8sWUFBWSxHQUFHLEVBQUU7QUFDNUQ7QUFBQSxNQUNGO0FBRUEsZUFBUyxRQUFNLEVBQUUsR0FBRyxHQUFHLFdBQVcsRUFBRTtBQUFBLElBQ3RDO0FBRUEsZ0JBQVksVUFBVSxDQUFDLFVBQWU7QUFDcEMsWUFBTSxXQUFXLE1BQU0sVUFBVSxnQkFDN0IsNkJBQ0EsTUFBTSxVQUFVLGNBQ2hCLEtBQ0EsZ0JBQWdCLE1BQU0sS0FBSztBQUUvQixlQUFTLFFBQU0sRUFBRSxHQUFHLEdBQUcsT0FBTyxZQUFZLE1BQU0sYUFBYSxNQUFNLEVBQUU7QUFBQSxJQUN2RTtBQUVBLGdCQUFZLFFBQVEsTUFBTTtBQUN4QixlQUFTLFFBQU0sRUFBRSxHQUFHLEdBQUcsYUFBYSxNQUFNLEVBQUU7QUFDNUMsVUFBSSxlQUFlLFNBQVM7QUFDMUIsdUJBQWUsUUFBUSxVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsS0FBSyxDQUFDO0FBQ3hELHVCQUFlLFVBQVU7QUFBQSxNQUMzQjtBQUFBLElBQ0Y7QUFFQSxtQkFBZSxVQUFVO0FBQ3pCLFFBQUk7QUFDRixrQkFBWSxNQUFNO0FBQUEsSUFDcEIsU0FBUyxHQUFHO0FBQ1YsY0FBUSxLQUFLLDRCQUE0QixDQUFDO0FBQUEsSUFDNUM7QUFFQSx1QkFBbUI7QUFBQSxFQUNyQixHQUFHLENBQUMsWUFBWSxDQUFDO0FBRWpCLFFBQU0sZ0JBQWdCLFlBQVksTUFBTTtBQUN0QyxRQUFJLGVBQWUsU0FBUztBQUMxQixVQUFJO0FBQUUsdUJBQWUsUUFBUSxLQUFLO0FBQUEsTUFBRyxRQUFRO0FBQUEsTUFBQztBQUM5QyxxQkFBZSxVQUFVO0FBQUEsSUFDM0I7QUFDQSxRQUFJLGVBQWUsU0FBUztBQUMxQixxQkFBZSxRQUFRLFVBQVUsRUFBRSxRQUFRLE9BQUssRUFBRSxLQUFLLENBQUM7QUFDeEQscUJBQWUsVUFBVTtBQUFBLElBQzNCO0FBQ0EsYUFBUyxRQUFNLEVBQUUsR0FBRyxHQUFHLGFBQWEsTUFBTSxFQUFFO0FBQUEsRUFDOUMsR0FBRyxDQUFDLENBQUM7QUFHTCxRQUFNLHFCQUFxQixZQUFZLFlBQVk7QUFDakQsUUFBSTtBQUNGLFlBQU0sU0FBUyxNQUFNLFVBQVUsYUFBYSxhQUFhLEVBQUUsT0FBTyxLQUFLLENBQUM7QUFDeEUscUJBQWUsVUFBVTtBQUV6QixZQUFNLE1BQU0sSUFBSSxhQUFhO0FBQzdCLHNCQUFnQixVQUFVO0FBQzFCLFlBQU0sU0FBUyxJQUFJLHdCQUF3QixNQUFNO0FBQ2pELFlBQU0sV0FBVyxJQUFJLGVBQWU7QUFDcEMsZUFBUyxVQUFVO0FBQ25CLGFBQU8sUUFBUSxRQUFRO0FBQ3ZCLGtCQUFZLFVBQVU7QUFFdEIsWUFBTSxZQUFZLElBQUksV0FBVyxTQUFTLGlCQUFpQjtBQUUzRCxZQUFNLE9BQU8sTUFBTTtBQUNqQixZQUFJLENBQUMsWUFBWSxRQUFTO0FBQzFCLG9CQUFZLFFBQVEscUJBQXFCLFNBQVM7QUFDbEQsY0FBTSxNQUFNLFVBQVUsT0FBTyxDQUFDLEdBQUcsTUFBTSxJQUFJLEdBQUcsQ0FBQztBQUMvQyxjQUFNLE1BQU0sTUFBTSxVQUFVLFNBQVM7QUFDckMsc0JBQWMsVUFBVTtBQUN4QixxQkFBYSxVQUFVLHNCQUFzQixJQUFJO0FBQUEsTUFDbkQ7QUFDQSxXQUFLO0FBQUEsSUFDUCxRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0YsR0FBRyxDQUFDLENBQUM7QUFHTCxRQUFNLFFBQVEsWUFBWSxDQUFDLFNBQWlCO0FBQzFDLFFBQUksQ0FBQyxPQUFPLGdCQUFpQjtBQUU3QixXQUFPLGdCQUFnQixPQUFPO0FBRzlCLFFBQUksWUFBWSxLQUNiLFFBQVEsbUJBQW1CLFlBQVksRUFDdkMsUUFBUSxjQUFjLElBQUksRUFDMUIsUUFBUSxXQUFXLEVBQUUsRUFDckIsUUFBUSwwQkFBMEIsSUFBSSxFQUN0QyxRQUFRLFFBQVEsSUFBSSxFQUNwQixLQUFLO0FBR1IsVUFBTSxZQUFZLFVBQVUsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLFNBQVM7QUFDakUsUUFBSSxVQUFVLFNBQVMsR0FBRztBQUN4QixrQkFBWSxVQUFVLE1BQU0sR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHO0FBQUEsSUFDNUMsV0FBVyxVQUFVLFNBQVMsS0FBSztBQUNqQyxrQkFBWSxVQUFVLE1BQU0sR0FBRyxHQUFHLElBQUk7QUFBQSxJQUN4QztBQUdBLGdCQUFZLFVBQ1QsUUFBUSx5QkFBeUIsZ0NBQWdDLEVBQ2pFLFFBQVEsZ0JBQWdCLGdCQUFnQixFQUN4QyxRQUFRLGNBQWMsZUFBZSxFQUNyQyxRQUFRLFlBQVksVUFBVSxFQUM5QixRQUFRLGNBQWMsU0FBUztBQUVsQyxRQUFJLENBQUMsVUFBVztBQUVoQixVQUFNLFlBQVksSUFBSSx5QkFBeUIsU0FBUztBQUN4RCxjQUFVLE9BQU87QUFDakIsY0FBVSxRQUFRO0FBQ2xCLGNBQVUsU0FBUztBQUVuQixVQUFNLFNBQVMsT0FBTyxnQkFBZ0IsVUFBVTtBQUNoRCxVQUFNLFlBQVk7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBRUEsUUFBSSxnQkFBZ0IsT0FBTztBQUFBLE1BQUssT0FDOUIsVUFBVSxLQUFLLE9BQUssRUFBRSxLQUFLLFNBQVMsQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSTtBQUFBLElBQ25FO0FBRUEsUUFBSSxDQUFDLGVBQWU7QUFDbEIsc0JBQWdCLE9BQU8sS0FBSyxPQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksS0FBSyxFQUFFLEtBQUssWUFBWSxFQUFFLFNBQVMsTUFBTSxDQUFDO0FBQUEsSUFDbkc7QUFDQSxRQUFJLENBQUMsZUFBZTtBQUNsQixzQkFBZ0IsT0FBTyxLQUFLLE9BQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxDQUFDO0FBQUEsSUFDMUQ7QUFFQSxRQUFJLGVBQWU7QUFDakIsZ0JBQVUsUUFBUTtBQUFBLElBQ3BCO0FBRUEsY0FBVSxVQUFVLE1BQU07QUFDeEIsb0JBQWMsVUFBVTtBQUN4QixlQUFTLFFBQU0sRUFBRSxHQUFHLEdBQUcsWUFBWSxLQUFLLEVBQUU7QUFBQSxJQUM1QztBQUVBLGNBQVUsUUFBUSxNQUFNO0FBQ3RCLG9CQUFjLFVBQVU7QUFDeEIsZUFBUyxRQUFNLEVBQUUsR0FBRyxHQUFHLFlBQVksTUFBTSxFQUFFO0FBQzNDLGlCQUFXLFNBQVMsY0FBYztBQUFBLElBQ3BDO0FBRUEsY0FBVSxVQUFVLE1BQU07QUFDeEIsb0JBQWMsVUFBVTtBQUN4QixlQUFTLFFBQU0sRUFBRSxHQUFHLEdBQUcsWUFBWSxNQUFNLEVBQUU7QUFBQSxJQUM3QztBQUVBLGtCQUFjLFVBQVU7QUFDeEIsYUFBUyxRQUFNLEVBQUUsR0FBRyxHQUFHLFlBQVksS0FBSyxFQUFFO0FBQzFDLFdBQU8sZ0JBQWdCLE1BQU0sU0FBUztBQUFBLEVBQ3hDLEdBQUcsQ0FBQyxDQUFDO0FBRUwsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0g7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLGVBQWUsTUFBTSxjQUFjO0FBQUEsRUFDckM7QUFDRjsiLCJuYW1lcyI6W119