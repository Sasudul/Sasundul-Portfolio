import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/CustomCursor.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
export default function CustomCursor() {
  _s();
  const dotRef = useRef(null);
  useEffect(() => {
    if (!dotRef.current) return;
    if (window.matchMedia("(hover: none)").matches) return;
    const xTo = gsap.quickTo(dotRef.current, "x", { duration: 0.15, ease: "power3" });
    const yTo = gsap.quickTo(dotRef.current, "y", { duration: 0.15, ease: "power3" });
    const onMove = (e) => {
      xTo(e.clientX);
      yTo(e.clientY);
    };
    const interactiveSelector = 'a, button, [role="button"], .cursor-pointer, input, textarea, .work__thumbnail';
    const onEnterInteractive = () => {
      gsap.to(dotRef.current, { scale: 3, opacity: 0.5, duration: 0.3, ease: "power2.out" });
    };
    const onLeaveInteractive = () => {
      gsap.to(dotRef.current, { scale: 1, opacity: 1, duration: 0.3, ease: "power2.out" });
    };
    window.addEventListener("mousemove", onMove);
    const addListeners = () => {
      document.querySelectorAll(interactiveSelector).forEach((el) => {
        el.addEventListener("mouseenter", onEnterInteractive);
        el.addEventListener("mouseleave", onLeaveInteractive);
      });
    };
    addListeners();
    const observer = new MutationObserver(addListeners);
    observer.observe(document.body, { childList: true, subtree: true });
    return () => {
      window.removeEventListener("mousemove", onMove);
      observer.disconnect();
    };
  }, []);
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: dotRef,
      className: "custom-cursor fixed top-0 left-0 w-3 h-3 rounded-full pointer-events-none z-[99999] -translate-x-1/2 -translate-y-1/2 mix-blend-difference hidden md:block",
      style: { background: "var(--text)" }
    },
    void 0,
    false,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CustomCursor.tsx",
      lineNumber: 51,
      columnNumber: 5
    },
    this
  );
}
_s(CustomCursor, "XAAx2EoAd4d8jLK0FLM05lsAH20=");
_c = CustomCursor;
var _c;
$RefreshReg$(_c, "CustomCursor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/CustomCursor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/CustomCursor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/CustomCursor.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RJOztBQWxESixTQUFTQSxXQUFXQyxjQUFjO0FBQ2xDLE9BQU9DLFVBQVU7QUFFakIsd0JBQXdCQyxlQUFlO0FBQUFDLEtBQUE7QUFDckMsUUFBTUMsU0FBU0osT0FBdUIsSUFBSTtBQUUxQ0QsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDSyxPQUFPQyxRQUFTO0FBRXJCLFFBQUlDLE9BQU9DLFdBQVcsZUFBZSxFQUFFQyxRQUFTO0FBRWhELFVBQU1DLE1BQU1SLEtBQUtTLFFBQVFOLE9BQU9DLFNBQVMsS0FBSyxFQUFFTSxVQUFVLE1BQU1DLE1BQU0sU0FBUyxDQUFDO0FBQ2hGLFVBQU1DLE1BQU1aLEtBQUtTLFFBQVFOLE9BQU9DLFNBQVMsS0FBSyxFQUFFTSxVQUFVLE1BQU1DLE1BQU0sU0FBUyxDQUFDO0FBRWhGLFVBQU1FLFNBQVNBLENBQUNDLE1BQWtCO0FBQ2hDTixVQUFJTSxFQUFFQyxPQUFPO0FBQ2JILFVBQUlFLEVBQUVFLE9BQU87QUFBQSxJQUNmO0FBRUEsVUFBTUMsc0JBQXNCO0FBRTVCLFVBQU1DLHFCQUFxQkEsTUFBTTtBQUMvQmxCLFdBQUttQixHQUFHaEIsT0FBT0MsU0FBUyxFQUFFZ0IsT0FBTyxHQUFHQyxTQUFTLEtBQUtYLFVBQVUsS0FBS0MsTUFBTSxhQUFhLENBQUM7QUFBQSxJQUN2RjtBQUVBLFVBQU1XLHFCQUFxQkEsTUFBTTtBQUMvQnRCLFdBQUttQixHQUFHaEIsT0FBT0MsU0FBUyxFQUFFZ0IsT0FBTyxHQUFHQyxTQUFTLEdBQUdYLFVBQVUsS0FBS0MsTUFBTSxhQUFhLENBQUM7QUFBQSxJQUNyRjtBQUVBTixXQUFPa0IsaUJBQWlCLGFBQWFWLE1BQU07QUFHM0MsVUFBTVcsZUFBZUEsTUFBTTtBQUN6QkMsZUFBU0MsaUJBQWlCVCxtQkFBbUIsRUFBRVUsUUFBUSxDQUFBQyxPQUFNO0FBQzNEQSxXQUFHTCxpQkFBaUIsY0FBY0wsa0JBQWtCO0FBQ3BEVSxXQUFHTCxpQkFBaUIsY0FBY0Qsa0JBQWtCO0FBQUEsTUFDdEQsQ0FBQztBQUFBLElBQ0g7QUFFQUUsaUJBQWE7QUFDYixVQUFNSyxXQUFXLElBQUlDLGlCQUFpQk4sWUFBWTtBQUNsREssYUFBU0UsUUFBUU4sU0FBU08sTUFBTSxFQUFFQyxXQUFXLE1BQU1DLFNBQVMsS0FBSyxDQUFDO0FBRWxFLFdBQU8sTUFBTTtBQUNYN0IsYUFBTzhCLG9CQUFvQixhQUFhdEIsTUFBTTtBQUM5Q2dCLGVBQVNPLFdBQVc7QUFBQSxJQUN0QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsS0FBS2pDO0FBQUFBLE1BQ0wsV0FBVTtBQUFBLE1BQ1YsT0FBTyxFQUFFa0MsWUFBWSxjQUFjO0FBQUE7QUFBQSxJQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHdUM7QUFHM0M7QUFBQ25DLEdBckR1QkQsY0FBWTtBQUFBcUMsS0FBWnJDO0FBQVksSUFBQXFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJnc2FwIiwiQ3VzdG9tQ3Vyc29yIiwiX3MiLCJkb3RSZWYiLCJjdXJyZW50Iiwid2luZG93IiwibWF0Y2hNZWRpYSIsIm1hdGNoZXMiLCJ4VG8iLCJxdWlja1RvIiwiZHVyYXRpb24iLCJlYXNlIiwieVRvIiwib25Nb3ZlIiwiZSIsImNsaWVudFgiLCJjbGllbnRZIiwiaW50ZXJhY3RpdmVTZWxlY3RvciIsIm9uRW50ZXJJbnRlcmFjdGl2ZSIsInRvIiwic2NhbGUiLCJvcGFjaXR5Iiwib25MZWF2ZUludGVyYWN0aXZlIiwiYWRkRXZlbnRMaXN0ZW5lciIsImFkZExpc3RlbmVycyIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvckFsbCIsImZvckVhY2giLCJlbCIsIm9ic2VydmVyIiwiTXV0YXRpb25PYnNlcnZlciIsIm9ic2VydmUiLCJib2R5IiwiY2hpbGRMaXN0Iiwic3VidHJlZSIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJkaXNjb25uZWN0IiwiYmFja2dyb3VuZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkN1c3RvbUN1cnNvci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBnc2FwIGZyb20gJ2dzYXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ3VzdG9tQ3Vyc29yKCkge1xyXG4gIGNvbnN0IGRvdFJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIWRvdFJlZi5jdXJyZW50KSByZXR1cm47XHJcbiAgICAvLyBDaGVjayBmb3IgdG91Y2ggZGV2aWNlXHJcbiAgICBpZiAod2luZG93Lm1hdGNoTWVkaWEoJyhob3Zlcjogbm9uZSknKS5tYXRjaGVzKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgeFRvID0gZ3NhcC5xdWlja1RvKGRvdFJlZi5jdXJyZW50LCAneCcsIHsgZHVyYXRpb246IDAuMTUsIGVhc2U6ICdwb3dlcjMnIH0pO1xyXG4gICAgY29uc3QgeVRvID0gZ3NhcC5xdWlja1RvKGRvdFJlZi5jdXJyZW50LCAneScsIHsgZHVyYXRpb246IDAuMTUsIGVhc2U6ICdwb3dlcjMnIH0pO1xyXG5cclxuICAgIGNvbnN0IG9uTW92ZSA9IChlOiBNb3VzZUV2ZW50KSA9PiB7XHJcbiAgICAgIHhUbyhlLmNsaWVudFgpO1xyXG4gICAgICB5VG8oZS5jbGllbnRZKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaW50ZXJhY3RpdmVTZWxlY3RvciA9ICdhLCBidXR0b24sIFtyb2xlPVwiYnV0dG9uXCJdLCAuY3Vyc29yLXBvaW50ZXIsIGlucHV0LCB0ZXh0YXJlYSwgLndvcmtfX3RodW1ibmFpbCc7XHJcblxyXG4gICAgY29uc3Qgb25FbnRlckludGVyYWN0aXZlID0gKCkgPT4ge1xyXG4gICAgICBnc2FwLnRvKGRvdFJlZi5jdXJyZW50LCB7IHNjYWxlOiAzLCBvcGFjaXR5OiAwLjUsIGR1cmF0aW9uOiAwLjMsIGVhc2U6ICdwb3dlcjIub3V0JyB9KTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3Qgb25MZWF2ZUludGVyYWN0aXZlID0gKCkgPT4ge1xyXG4gICAgICBnc2FwLnRvKGRvdFJlZi5jdXJyZW50LCB7IHNjYWxlOiAxLCBvcGFjaXR5OiAxLCBkdXJhdGlvbjogMC4zLCBlYXNlOiAncG93ZXIyLm91dCcgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBvbk1vdmUpO1xyXG5cclxuICAgIC8vIFVzZSBNdXRhdGlvbk9ic2VydmVyLWZyaWVuZGx5IGFwcHJvYWNoOiBkZWxlZ2F0ZVxyXG4gICAgY29uc3QgYWRkTGlzdGVuZXJzID0gKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKGludGVyYWN0aXZlU2VsZWN0b3IpLmZvckVhY2goZWwgPT4ge1xyXG4gICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZW50ZXInLCBvbkVudGVySW50ZXJhY3RpdmUpO1xyXG4gICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCBvbkxlYXZlSW50ZXJhY3RpdmUpO1xyXG4gICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgYWRkTGlzdGVuZXJzKCk7XHJcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGFkZExpc3RlbmVycyk7XHJcbiAgICBvYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHsgY2hpbGRMaXN0OiB0cnVlLCBzdWJ0cmVlOiB0cnVlIH0pO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBvbk1vdmUpO1xyXG4gICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgcmVmPXtkb3RSZWZ9XHJcbiAgICAgIGNsYXNzTmFtZT1cImN1c3RvbS1jdXJzb3IgZml4ZWQgdG9wLTAgbGVmdC0wIHctMyBoLTMgcm91bmRlZC1mdWxsIHBvaW50ZXItZXZlbnRzLW5vbmUgei1bOTk5OTldIC10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBtaXgtYmxlbmQtZGlmZmVyZW5jZSBoaWRkZW4gbWQ6YmxvY2tcIlxyXG4gICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiAndmFyKC0tdGV4dCknIH19XHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJEOi9Xb3JrL1Nhc3VkdWwvc2FzYS9zYXN1bmR1bC1wb3J0Zm9saW8vY29tcG9uZW50cy9DdXN0b21DdXJzb3IudHN4In0=