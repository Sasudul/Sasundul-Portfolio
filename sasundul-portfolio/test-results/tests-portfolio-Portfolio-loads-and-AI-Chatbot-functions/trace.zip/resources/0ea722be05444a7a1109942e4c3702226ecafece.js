import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/HorizontalScroll.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { ScrollTrigger } from "/node_modules/.vite/deps/gsap_ScrollTrigger.js?v=5088fc54";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useRef = __vite__cjsImport4_react["useRef"];
gsap.registerPlugin(ScrollTrigger);
function SplitLetters({ text, startIndex = 0 }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: text.split("").map((char, i) => {
    if (char === " ") return /* @__PURE__ */ jsxDEV("span", { className: "inline-block w-[0.25em]", children: " " }, i, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 14,
      columnNumber: 34
    }, this);
    const from = (startIndex + i) % 2 === 0 ? "up" : "down";
    return /* @__PURE__ */ jsxDEV("span", { className: "inline-block overflow-hidden", style: { verticalAlign: "bottom", paddingBottom: "0.1em", marginBottom: "-0.1em" }, children: /* @__PURE__ */ jsxDEV("span", { className: "h-word inline-block", "data-from": from, children: char }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 18,
      columnNumber: 13
    }, this) }, i, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 17,
      columnNumber: 11
    }, this);
  }) }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
    lineNumber: 11,
    columnNumber: 5
  }, this);
}
_c = SplitLetters;
const G = "#4CAF50";
const GM = "#81C784";
const GD = "#388E3C";
const P = "#9C27B0";
const PD = "#7B1FA2";
function Leaf({ cx, cy, angle, fill, s, op = 1 }) {
  return /* @__PURE__ */ jsxDEV(
    "path",
    {
      className: "hero-leaf",
      d: `M ${cx} ${cy} C ${cx - s / 2} ${cy - s} ${cx + s / 2} ${cy - s} ${cx} ${cy - s * 1.5} C ${cx + s / 2} ${cy - s / 2} ${cx + s / 2} ${cy} ${cx} ${cy}`,
      fill,
      opacity: op,
      transform: `rotate(${angle} ${cx} ${cy})`
    },
    void 0,
    false,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 47,
      columnNumber: 5
    },
    this
  );
}
_c2 = Leaf;
function Dot({ cx, cy, r, fill }) {
  return /* @__PURE__ */ jsxDEV("circle", { className: "hero-dot", cx, cy, r, fill }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
    lineNumber: 58,
    columnNumber: 10
  }, this);
}
_c3 = Dot;
function HeroI() {
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      className: "hero-i relative inline-block flex-shrink-0",
      style: { marginRight: "0.2em" },
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "heading-hero", style: { color: "var(--text, #0d0d0d)" }, children: "I" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 67,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "svg",
          {
            className: "absolute pointer-events-none z-[2]",
            style: { top: "-60%", left: "-95%", width: "290%", height: "220%", overflow: "visible" },
            viewBox: "0 0 100 100",
            fill: "none",
            children: [
              /* @__PURE__ */ jsxDEV(
                "path",
                {
                  className: "hero-stem",
                  d: "M 50 88 C 36 72 18 76 16 58 C 14 40 28 30 20 18 C 14 8 4 10 6 2",
                  stroke: G,
                  strokeWidth: "1.7",
                  strokeLinecap: "round"
                },
                void 0,
                false,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                  lineNumber: 75,
                  columnNumber: 9
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("path", { className: "hero-stem", d: "M 18 54 C 10 50 4 54 2 46", stroke: GM, strokeWidth: "1.1", strokeLinecap: "round" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 80,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Leaf, { cx: 18, cy: 64, angle: -140, fill: G, s: 9 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 82,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Leaf, { cx: 19, cy: 36, angle: -160, fill: GM, s: 8, op: 0.85 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 83,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Leaf, { cx: 8, cy: 12, angle: -120, fill: GM, s: 7, op: 0.7 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 84,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Dot, { cx: 2, cy: 46, r: 2.8, fill: GD }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 85,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Dot, { cx: 5, cy: 20, r: 2.2, fill: GD }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 86,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(
                "path",
                {
                  className: "hero-stem",
                  d: "M 50 12 C 64 28 80 24 82 42 C 84 58 70 68 80 82 C 86 92 96 88 94 98",
                  stroke: P,
                  strokeWidth: "1.7",
                  strokeLinecap: "round"
                },
                void 0,
                false,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                  lineNumber: 89,
                  columnNumber: 9
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("path", { className: "hero-stem", d: "M 82 46 C 90 50 96 46 98 54", stroke: P, strokeWidth: "1.1", strokeLinecap: "round" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 94,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Leaf, { cx: 82, cy: 36, angle: 40, fill: P, s: 9 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 96,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Leaf, { cx: 76, cy: 68, angle: 20, fill: P, s: 8, op: 0.85 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 97,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Leaf, { cx: 92, cy: 92, angle: 60, fill: P, s: 7, op: 0.7 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 98,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Dot, { cx: 98, cy: 54, r: 2.8, fill: PD }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 99,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Dot, { cx: 96, cy: 78, r: 2.2, fill: PD }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
                lineNumber: 100,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 68,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 63,
      columnNumber: 5
    },
    this
  );
}
_c4 = HeroI;
function IntroVine() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[0]", style: { top: "-80%", left: "-20%", width: "150%", height: "260%", overflow: "visible", filter: "blur(1.5px)" }, viewBox: "0 0 600 200", fill: "none", children: [
      /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV("linearGradient", { id: "vine-gradient", x1: "0", y1: "0", x2: "1", y2: "0", gradientUnits: "objectBoundingBox", children: [
        /* @__PURE__ */ jsxDEV("stop", { stopColor: "#4CAF50" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 112,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("stop", { offset: "1", stopColor: "#9C27B0" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 113,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
        lineNumber: 111,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -50 100 C 50 0, 150 0, 250 100 C 350 200, 450 200, 550 100 C 600 50, 650 50, 700 100", stroke: "url(#vine-gradient)", strokeWidth: "1.5", strokeOpacity: "0.35", strokeLinecap: "round" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[20]", style: { top: "-80%", left: "-20%", width: "150%", height: "260%", overflow: "visible", filter: "drop-shadow(0px 15px 15px rgba(0,0,0,0.9))" }, viewBox: "0 0 600 200", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -50 100 C 50 200, 150 200, 250 100 C 350 0, 450 0, 550 100 C 600 150, 650 150, 700 100", stroke: "url(#vine-gradient)", strokeWidth: "4", strokeLinecap: "round" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 121,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 119,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
    lineNumber: 108,
    columnNumber: 5
  }, this);
}
_c5 = IntroVine;
function DesignerVine() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[0]", style: { top: "-100%", left: "-30%", width: "180%", height: "300%", overflow: "visible", filter: "blur(1.5px)" }, viewBox: "0 0 500 200", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -50 100 C 50 -20, 150 -20, 250 100 C 350 220, 450 220, 550 100", stroke: "url(#vine-gradient)", strokeWidth: "1.5", strokeOpacity: "0.35", strokeLinecap: "round" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 131,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 130,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[20]", style: { top: "-100%", left: "-30%", width: "180%", height: "300%", overflow: "visible", filter: "drop-shadow(0px 15px 15px rgba(0,0,0,0.9))" }, viewBox: "0 0 500 200", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -50 100 C 50 220, 150 220, 250 100 C 350 -20, 450 -20, 550 100", stroke: "url(#vine-gradient)", strokeWidth: "4", strokeLinecap: "round" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 134,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 133,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
    lineNumber: 129,
    columnNumber: 5
  }, this);
}
_c6 = DesignerVine;
function DeveloperVine() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[0]", style: { top: "-90%", left: "-20%", width: "160%", height: "280%", overflow: "visible", filter: "blur(1.5px)" }, viewBox: "0 0 700 200", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -50 100 C 100 0, 250 0, 400 100 C 550 200, 700 200, 850 100", stroke: "url(#vine-gradient)", strokeWidth: "1.5", strokeOpacity: "0.35", strokeLinecap: "round" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 144,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[20]", style: { top: "-90%", left: "-20%", width: "160%", height: "280%", overflow: "visible", filter: "drop-shadow(0px 15px 15px rgba(0,0,0,0.9))" }, viewBox: "0 0 700 200", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -50 100 C 100 200, 250 200, 400 100 C 550 0, 700 0, 850 100", stroke: "url(#vine-gradient)", strokeWidth: "4", strokeLinecap: "round" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 147,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 146,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
    lineNumber: 142,
    columnNumber: 5
  }, this);
}
_c7 = DeveloperVine;
function WebflowVine() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[0]", style: { top: "-110%", left: "-40%", width: "200%", height: "320%", overflow: "visible", filter: "blur(1.5px)" }, viewBox: "0 0 600 200", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -100 100 C 0 -50, 200 -50, 300 100 C 400 250, 600 250, 700 100", stroke: "url(#vine-gradient)", strokeWidth: "1.5", strokeOpacity: "0.35", strokeLinecap: "round" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 157,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("svg", { className: "absolute pointer-events-none z-[20]", style: { top: "-110%", left: "-40%", width: "200%", height: "320%", overflow: "visible", filter: "drop-shadow(0px 15px 15px rgba(0,0,0,0.9))" }, viewBox: "0 0 600 200", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { className: "vine-stem opacity-0", d: "M -100 100 C 0 250, 200 250, 300 100 C 400 -50, 600 -50, 700 100", stroke: "url(#vine-gradient)", strokeWidth: "4", strokeLinecap: "round" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 160,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 159,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
    lineNumber: 155,
    columnNumber: 5
  }, this);
}
_c8 = WebflowVine;
export default function HorizontalScroll() {
  _s();
  const wrapperRef = useRef(null);
  const trackRef = useRef(null);
  useGSAP(() => {
    const track = trackRef.current;
    const wrapper = wrapperRef.current;
    if (!track || !wrapper) return;
    const totalScroll = track.scrollWidth - window.innerWidth;
    const scrollTween = gsap.to(track, {
      x: -totalScroll,
      ease: "none",
      scrollTrigger: {
        trigger: wrapper,
        pin: true,
        scrub: 1,
        end: `+=${totalScroll}`
      }
    });
    gsap.utils.toArray(".h-word").forEach((letter) => {
      const dir = letter.dataset.from === "up" ? -120 : 120;
      gsap.fromTo(
        letter,
        { yPercent: dir, opacity: 0 },
        {
          yPercent: 0,
          opacity: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: letter,
            containerAnimation: scrollTween,
            start: "left 95%",
            // Wait until it's really on screen
            end: "left 60%",
            scrub: true
          }
        }
      );
    });
    gsap.utils.toArray(".vine-stem").forEach((path) => {
      const vineWrap = path.closest(".vine-wrap");
      if (!vineWrap) return;
      const len = path.getTotalLength();
      gsap.set(path, { strokeDasharray: len + 10, strokeDashoffset: len + 10, opacity: 1 });
      gsap.to(path, {
        strokeDashoffset: 0,
        ease: "none",
        scrollTrigger: {
          trigger: vineWrap,
          containerAnimation: scrollTween,
          start: "left 90%",
          // Start drawing exactly as the word enters the screen
          end: "right 60%",
          // Finish drawing exactly as the last letter finishes its animation
          scrub: true
        }
      });
    });
    gsap.utils.toArray(".hero-stem").forEach((path) => {
      const len = path.getTotalLength();
      gsap.set(path, { strokeDasharray: len, strokeDashoffset: len });
    });
    gsap.to(".hero-stem", {
      strokeDashoffset: 0,
      duration: 1.5,
      ease: "power3.out",
      scrollTrigger: {
        trigger: wrapper,
        start: "top 60%"
      }
    });
    gsap.fromTo(
      ".hero-leaf, .hero-dot",
      { scale: 0, transformOrigin: "center" },
      {
        scale: 1,
        duration: 1,
        stagger: 0.1,
        ease: "back.out(2)",
        scrollTrigger: {
          trigger: wrapper,
          start: "top 60%"
        }
      }
    );
  }, { scope: wrapperRef });
  return /* @__PURE__ */ jsxDEV(
    "section",
    {
      ref: wrapperRef,
      className: "relative overflow-hidden",
      style: { background: "var(--bg)" },
      children: /* @__PURE__ */ jsxDEV("div", { className: "h-screen flex items-center", children: /* @__PURE__ */ jsxDEV("div", { ref: trackRef, className: "horizontal-scroll__track", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 w-[90vw]" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 277,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "relative inline-flex items-baseline vine-wrap flex-shrink-0 mx-[0.12em] mr-[0.5em]", children: [
          /* @__PURE__ */ jsxDEV(HeroI, {}, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 281,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "heading-hero relative z-10", style: { color: "var(--text)" }, children: /* @__PURE__ */ jsxDEV(SplitLetters, { text: "  CRAFT DIGITAL EXPERIENCES", startIndex: 1 }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 283,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 282,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(IntroVine, {}, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 285,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 280,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "heading-hero relative z-10 flex-shrink-0 mx-[0.12em] mr-[0.5em]", style: { color: "var(--text)" }, children: /* @__PURE__ */ jsxDEV(SplitLetters, { text: "AS A", startIndex: 27 }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 290,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 289,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "relative inline-block vine-wrap flex-shrink-0 mx-[0.12em] mr-[0.5em]", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "heading-hero relative z-10", style: { color: "var(--text)" }, children: /* @__PURE__ */ jsxDEV(SplitLetters, { text: "DESIGNER,", startIndex: 31 }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 296,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 295,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DesignerVine, {}, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 298,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 294,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "relative inline-flex items-baseline vine-wrap flex-shrink-0 mx-[0.12em] mr-[0.5em]", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "heading-hero relative z-10", style: { color: "var(--text)" }, children: /* @__PURE__ */ jsxDEV(SplitLetters, { text: "FRONTEND DEVELOPER", startIndex: 40 }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 304,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 303,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DeveloperVine, {}, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 306,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 302,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "heading-hero relative z-10 flex-shrink-0 mx-[0.12em] mr-[0.5em]", style: { color: "var(--text)" }, children: /* @__PURE__ */ jsxDEV(SplitLetters, { text: "&", startIndex: 58 }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 311,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 310,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "relative inline-flex items-baseline vine-wrap flex-shrink-0 mx-[0.12em]", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "heading-hero relative z-10", style: { color: "var(--text)" }, children: /* @__PURE__ */ jsxDEV(SplitLetters, { text: "BACKEND EXPERT.", startIndex: 59 }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 317,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 316,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(WebflowVine, {}, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
            lineNumber: 319,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 315,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 w-[80vw]" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
          lineNumber: 323,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
        lineNumber: 274,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
        lineNumber: 273,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx",
      lineNumber: 268,
      columnNumber: 5
    },
    this
  );
}
_s(HorizontalScroll, "D+l8ygtSAWLCl/sGHYNDhUE8paE=", false, function() {
  return [useGSAP];
});
_c9 = HorizontalScroll;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "SplitLetters");
$RefreshReg$(_c2, "Leaf");
$RefreshReg$(_c3, "Dot");
$RefreshReg$(_c4, "HeroI");
$RefreshReg$(_c5, "IntroVine");
$RefreshReg$(_c6, "DesignerVine");
$RefreshReg$(_c7, "DeveloperVine");
$RefreshReg$(_c8, "WebflowVine");
$RefreshReg$(_c9, "HorizontalScroll");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/HorizontalScroll.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUksbUJBRzZCLGNBSDdCOztBQVZKLFNBQVNBLGVBQWU7QUFDeEIsT0FBT0MsVUFBVTtBQUNqQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsY0FBYztBQUV2QkYsS0FBS0csZUFBZUYsYUFBYTtBQUdqQyxTQUFTRyxhQUFhLEVBQUVDLE1BQU1DLGFBQWEsRUFBeUMsR0FBRztBQUNyRixTQUNFLG1DQUNHRCxlQUFLRSxNQUFNLEVBQUUsRUFBRUMsSUFBSSxDQUFDQyxNQUFNQyxNQUFNO0FBRS9CLFFBQUlELFNBQVMsSUFBSyxRQUFPLHVCQUFDLFVBQWEsV0FBVSwyQkFBMEIsaUJBQXZDQyxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0Q7QUFDakYsVUFBTUMsUUFBUUwsYUFBYUksS0FBSyxNQUFNLElBQUksT0FBTztBQUNqRCxXQUNFLHVCQUFDLFVBQWEsV0FBVSxnQ0FBK0IsT0FBTyxFQUFFRSxlQUFlLFVBQVVDLGVBQWUsU0FBU0MsY0FBYyxTQUFTLEdBQ3RJLGlDQUFDLFVBQUssV0FBVSx1QkFBc0IsYUFBV0gsTUFDOUNGLGtCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhTQyxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLEVBRUosQ0FBQyxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBUUFLLEtBekJTWDtBQThCVCxNQUFNWSxJQUFJO0FBQ1YsTUFBTUMsS0FBSztBQUNYLE1BQU1DLEtBQUs7QUFDWCxNQUFNQyxJQUFJO0FBQ1YsTUFBTUMsS0FBSztBQUVYLFNBQVNDLEtBQUssRUFBRUMsSUFBSUMsSUFBSUMsT0FBT0MsTUFBTUMsR0FBR0MsS0FBSyxFQUFtRixHQUFHO0FBQ2pJLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLEdBQUcsS0FBS0wsRUFBRSxJQUFJQyxFQUFFLE1BQU1ELEtBQUtJLElBQUksQ0FBQyxJQUFJSCxLQUFLRyxDQUFDLElBQUlKLEtBQUtJLElBQUksQ0FBQyxJQUFJSCxLQUFLRyxDQUFDLElBQUlKLEVBQUUsSUFBSUMsS0FBS0csSUFBSSxHQUFHLE1BQU1KLEtBQUtJLElBQUksQ0FBQyxJQUFJSCxLQUFLRyxJQUFJLENBQUMsSUFBSUosS0FBS0ksSUFBSSxDQUFDLElBQUlILEVBQUUsSUFBSUQsRUFBRSxJQUFJQyxFQUFFO0FBQUEsTUFDdEo7QUFBQSxNQUNBLFNBQVNJO0FBQUFBLE1BQ1QsV0FBVyxVQUFVSCxLQUFLLElBQUlGLEVBQUUsSUFBSUMsRUFBRTtBQUFBO0FBQUEsSUFMeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSzRDO0FBR2hEO0FBQUNLLE1BVlFQO0FBWVQsU0FBU1EsSUFBSSxFQUFFUCxJQUFJQyxJQUFJTyxHQUFHTCxLQUEwRCxHQUFHO0FBQ3JGLFNBQU8sdUJBQUMsWUFBTyxXQUFVLFlBQVcsSUFBUSxJQUFRLEdBQU0sUUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE4RDtBQUN2RTtBQUFDTSxNQUZRRjtBQUlULFNBQVNHLFFBQVE7QUFDZixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFVO0FBQUEsTUFDVixPQUFPLEVBQUVDLGFBQWEsUUFBUTtBQUFBLE1BRTlCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGdCQUFlLE9BQU8sRUFBRUMsT0FBTyx1QkFBdUIsR0FBRyxpQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLFFBQzFFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUVDLEtBQUssUUFBUUMsTUFBTSxRQUFRQyxPQUFPLFFBQVFDLFFBQVEsUUFBUUMsVUFBVSxVQUFVO0FBQUEsWUFDdkYsU0FBUTtBQUFBLFlBQ1IsTUFBSztBQUFBLFlBR0w7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsR0FBRTtBQUFBLGtCQUNGLFFBQVF2QjtBQUFBQSxrQkFBRyxhQUFZO0FBQUEsa0JBQU0sZUFBYztBQUFBO0FBQUEsZ0JBSDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUdvRDtBQUFBLGNBRXBELHVCQUFDLFVBQUssV0FBVSxhQUFZLEdBQUUsNkJBQTRCLFFBQVFDLElBQUksYUFBWSxPQUFNLGVBQWMsV0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkc7QUFBQSxjQUU3Ryx1QkFBQyxRQUFLLElBQUksSUFBSSxJQUFJLElBQUksT0FBTyxNQUFNLE1BQU1ELEdBQUcsR0FBRyxLQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRDtBQUFBLGNBQ2pELHVCQUFDLFFBQUssSUFBSSxJQUFJLElBQUksSUFBSSxPQUFPLE1BQU0sTUFBTUMsSUFBSSxHQUFHLEdBQUcsSUFBSSxRQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBLGNBQzVELHVCQUFDLFFBQUssSUFBSSxHQUFHLElBQUksSUFBSSxPQUFPLE1BQU0sTUFBTUEsSUFBSSxHQUFHLEdBQUcsSUFBSSxPQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGNBQzFELHVCQUFDLE9BQUksSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLEtBQUssTUFBTUMsTUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNyQyx1QkFBQyxPQUFJLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxLQUFLLE1BQU1BLE1BQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsY0FHckM7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLEdBQUU7QUFBQSxrQkFDRixRQUFRQztBQUFBQSxrQkFBRyxhQUFZO0FBQUEsa0JBQU0sZUFBYztBQUFBO0FBQUEsZ0JBSDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUdvRDtBQUFBLGNBRXBELHVCQUFDLFVBQUssV0FBVSxhQUFZLEdBQUUsK0JBQThCLFFBQVFBLEdBQUcsYUFBWSxPQUFNLGVBQWMsV0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEc7QUFBQSxjQUU5Ryx1QkFBQyxRQUFLLElBQUksSUFBSSxJQUFJLElBQUksT0FBTyxJQUFJLE1BQU1BLEdBQUcsR0FBRyxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQy9DLHVCQUFDLFFBQUssSUFBSSxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksTUFBTUEsR0FBRyxHQUFHLEdBQUcsSUFBSSxRQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBQ3pELHVCQUFDLFFBQUssSUFBSSxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksTUFBTUEsR0FBRyxHQUFHLEdBQUcsSUFBSSxPQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQ3hELHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLEtBQUssTUFBTUMsTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0M7QUFBQSxjQUN0Qyx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxLQUFLLE1BQU1BLE1BQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUE7QUFBQTtBQUFBLFVBaEN4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpQ0E7QUFBQTtBQUFBO0FBQUEsSUF0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBdUNBO0FBRUo7QUFBQ29CLE1BM0NRUjtBQTZDVCxTQUFTUyxZQUFZO0FBQ25CLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0NBQXFDLE9BQU8sRUFBRU4sS0FBSyxRQUFRQyxNQUFNLFFBQVFDLE9BQU8sUUFBUUMsUUFBUSxRQUFRQyxVQUFVLFdBQVdHLFFBQVEsY0FBYyxHQUFHLFNBQVEsZUFBYyxNQUFLLFFBQzlMO0FBQUEsNkJBQUMsVUFDQyxpQ0FBQyxvQkFBZSxJQUFHLGlCQUFnQixJQUFHLEtBQUksSUFBRyxLQUFJLElBQUcsS0FBSSxJQUFHLEtBQUksZUFBYyxxQkFDM0U7QUFBQSwrQkFBQyxVQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQ3pCLHVCQUFDLFVBQUssUUFBTyxLQUFJLFdBQVUsYUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFdBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxXQUFVLHVCQUFzQixHQUFFLDBGQUF5RixRQUFPLHVCQUFzQixhQUFZLE9BQU0sZUFBYyxRQUFPLGVBQWMsV0FBbk47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwTjtBQUFBLFNBUjVOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUFzQyxPQUFPLEVBQUVQLEtBQUssUUFBUUMsTUFBTSxRQUFRQyxPQUFPLFFBQVFDLFFBQVEsUUFBUUMsVUFBVSxXQUFXRyxRQUFRLDZDQUE2QyxHQUFHLFNBQVEsZUFBYyxNQUFLLFFBRTlOLGlDQUFDLFVBQUssV0FBVSx1QkFBc0IsR0FBRSw0RkFBMkYsUUFBTyx1QkFBc0IsYUFBWSxLQUFJLGVBQWMsV0FBOUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxTSxLQUZ2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUVKO0FBQUNDLE1BbkJRRjtBQXFCVCxTQUFTRyxlQUFlO0FBQ3RCLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0NBQXFDLE9BQU8sRUFBRVQsS0FBSyxTQUFTQyxNQUFNLFFBQVFDLE9BQU8sUUFBUUMsUUFBUSxRQUFRQyxVQUFVLFdBQVdHLFFBQVEsY0FBYyxHQUFHLFNBQVEsZUFBYyxNQUFLLFFBQy9MLGlDQUFDLFVBQUssV0FBVSx1QkFBc0IsR0FBRSxvRUFBbUUsUUFBTyx1QkFBc0IsYUFBWSxPQUFNLGVBQWMsUUFBTyxlQUFjLFdBQTdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb00sS0FEdE07QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQXNDLE9BQU8sRUFBRVAsS0FBSyxTQUFTQyxNQUFNLFFBQVFDLE9BQU8sUUFBUUMsUUFBUSxRQUFRQyxVQUFVLFdBQVdHLFFBQVEsNkNBQTZDLEdBQUcsU0FBUSxlQUFjLE1BQUssUUFDL04saUNBQUMsVUFBSyxXQUFVLHVCQUFzQixHQUFFLG9FQUFtRSxRQUFPLHVCQUFzQixhQUFZLEtBQUksZUFBYyxXQUF0SztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZLLEtBRC9LO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BO0FBRUo7QUFBQ0csTUFYUUQ7QUFhVCxTQUFTRSxnQkFBZ0I7QUFDdkIsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVSxzQ0FBcUMsT0FBTyxFQUFFWCxLQUFLLFFBQVFDLE1BQU0sUUFBUUMsT0FBTyxRQUFRQyxRQUFRLFFBQVFDLFVBQVUsV0FBV0csUUFBUSxjQUFjLEdBQUcsU0FBUSxlQUFjLE1BQUssUUFDOUwsaUNBQUMsVUFBSyxXQUFVLHVCQUFzQixHQUFFLGlFQUFnRSxRQUFPLHVCQUFzQixhQUFZLE9BQU0sZUFBYyxRQUFPLGVBQWMsV0FBMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpTSxLQURuTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FBc0MsT0FBTyxFQUFFUCxLQUFLLFFBQVFDLE1BQU0sUUFBUUMsT0FBTyxRQUFRQyxRQUFRLFFBQVFDLFVBQVUsV0FBV0csUUFBUSw2Q0FBNkMsR0FBRyxTQUFRLGVBQWMsTUFBSyxRQUM5TixpQ0FBQyxVQUFLLFdBQVUsdUJBQXNCLEdBQUUsaUVBQWdFLFFBQU8sdUJBQXNCLGFBQVksS0FBSSxlQUFjLFdBQW5LO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEssS0FENUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFDSyxNQVhRRDtBQWFULFNBQVNFLGNBQWM7QUFDckIsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVSxzQ0FBcUMsT0FBTyxFQUFFYixLQUFLLFNBQVNDLE1BQU0sUUFBUUMsT0FBTyxRQUFRQyxRQUFRLFFBQVFDLFVBQVUsV0FBV0csUUFBUSxjQUFjLEdBQUcsU0FBUSxlQUFjLE1BQUssUUFDL0wsaUNBQUMsVUFBSyxXQUFVLHVCQUFzQixHQUFFLG9FQUFtRSxRQUFPLHVCQUFzQixhQUFZLE9BQU0sZUFBYyxRQUFPLGVBQWMsV0FBN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvTSxLQUR0TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FBc0MsT0FBTyxFQUFFUCxLQUFLLFNBQVNDLE1BQU0sUUFBUUMsT0FBTyxRQUFRQyxRQUFRLFFBQVFDLFVBQVUsV0FBV0csUUFBUSw2Q0FBNkMsR0FBRyxTQUFRLGVBQWMsTUFBSyxRQUMvTixpQ0FBQyxVQUFLLFdBQVUsdUJBQXNCLEdBQUUsb0VBQW1FLFFBQU8sdUJBQXNCLGFBQVksS0FBSSxlQUFjLFdBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkssS0FEL0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUVBTyxNQWJTRDtBQWlCVCx3QkFBd0JFLG1CQUFtQjtBQUFBQyxLQUFBO0FBQ3pDLFFBQU1DLGFBQWFsRCxPQUFvQixJQUFJO0FBQzNDLFFBQU1tRCxXQUFXbkQsT0FBdUIsSUFBSTtBQUU1Q0gsVUFBUSxNQUFNO0FBQ1osVUFBTXVELFFBQVFELFNBQVNFO0FBQ3ZCLFVBQU1DLFVBQVVKLFdBQVdHO0FBQzNCLFFBQUksQ0FBQ0QsU0FBUyxDQUFDRSxRQUFTO0FBRXhCLFVBQU1DLGNBQWNILE1BQU1JLGNBQWNDLE9BQU9DO0FBRy9DLFVBQU1DLGNBQWM3RCxLQUFLOEQsR0FBR1IsT0FBTztBQUFBLE1BQ2pDUyxHQUFHLENBQUNOO0FBQUFBLE1BQ0pPLE1BQU07QUFBQSxNQUNOQyxlQUFlO0FBQUEsUUFDYkMsU0FBU1Y7QUFBQUEsUUFDVFcsS0FBSztBQUFBLFFBQ0xDLE9BQU87QUFBQSxRQUNQQyxLQUFLLEtBQUtaLFdBQVc7QUFBQSxNQUN2QjtBQUFBLElBQ0YsQ0FBQztBQUtEekQsU0FBS3NFLE1BQU1DLFFBQXFCLFNBQVMsRUFBRUMsUUFBUSxDQUFDQyxXQUFXO0FBQzdELFlBQU1DLE1BQU1ELE9BQU9FLFFBQVFoRSxTQUFTLE9BQU8sT0FBTztBQUNsRFgsV0FBSzRFO0FBQUFBLFFBQU9IO0FBQUFBLFFBQ1YsRUFBRUksVUFBVUgsS0FBS0ksU0FBUyxFQUFFO0FBQUEsUUFDNUI7QUFBQSxVQUNFRCxVQUFVO0FBQUEsVUFDVkMsU0FBUztBQUFBLFVBQ1RkLE1BQU07QUFBQSxVQUNOQyxlQUFlO0FBQUEsWUFDYkMsU0FBU087QUFBQUEsWUFDVE0sb0JBQW9CbEI7QUFBQUEsWUFDcEJtQixPQUFPO0FBQUE7QUFBQSxZQUNQWCxLQUFLO0FBQUEsWUFDTEQsT0FBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUdEcEUsU0FBS3NFLE1BQU1DLFFBQXdCLFlBQVksRUFBRUMsUUFBUSxDQUFDUyxTQUFTO0FBQ2pFLFlBQU1DLFdBQVdELEtBQUtFLFFBQVEsWUFBWTtBQUMxQyxVQUFJLENBQUNELFNBQVU7QUFDZixZQUFNRSxNQUFNSCxLQUFLSSxlQUFlO0FBRWhDckYsV0FBS3NGLElBQUlMLE1BQU0sRUFBRU0saUJBQWlCSCxNQUFNLElBQUlJLGtCQUFrQkosTUFBTSxJQUFJTixTQUFTLEVBQUUsQ0FBQztBQUNwRjlFLFdBQUs4RCxHQUFHbUIsTUFBTTtBQUFBLFFBQ1pPLGtCQUFrQjtBQUFBLFFBQ2xCeEIsTUFBTTtBQUFBLFFBQ05DLGVBQWU7QUFBQSxVQUNiQyxTQUFTZ0I7QUFBQUEsVUFDVEgsb0JBQW9CbEI7QUFBQUEsVUFDcEJtQixPQUFPO0FBQUE7QUFBQSxVQUNQWCxLQUFLO0FBQUE7QUFBQSxVQUNMRCxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdEcEUsU0FBS3NFLE1BQU1DLFFBQXdCLFlBQVksRUFBRUMsUUFBUSxDQUFBUyxTQUFRO0FBQy9ELFlBQU1HLE1BQU1ILEtBQUtJLGVBQWU7QUFDaENyRixXQUFLc0YsSUFBSUwsTUFBTSxFQUFFTSxpQkFBaUJILEtBQUtJLGtCQUFrQkosSUFBSSxDQUFDO0FBQUEsSUFDaEUsQ0FBQztBQUVEcEYsU0FBSzhELEdBQUcsY0FBYztBQUFBLE1BQ3BCMEIsa0JBQWtCO0FBQUEsTUFDbEJDLFVBQVU7QUFBQSxNQUNWekIsTUFBTTtBQUFBLE1BQ05DLGVBQWU7QUFBQSxRQUNiQyxTQUFTVjtBQUFBQSxRQUNUd0IsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGLENBQUM7QUFFRGhGLFNBQUs0RTtBQUFBQSxNQUFPO0FBQUEsTUFDVixFQUFFYyxPQUFPLEdBQUdDLGlCQUFpQixTQUFTO0FBQUEsTUFDdEM7QUFBQSxRQUNFRCxPQUFPO0FBQUEsUUFDUEQsVUFBVTtBQUFBLFFBQ1ZHLFNBQVM7QUFBQSxRQUNUNUIsTUFBTTtBQUFBLFFBQ05DLGVBQWU7QUFBQSxVQUNiQyxTQUFTVjtBQUFBQSxVQUNUd0IsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBRUYsR0FBRyxFQUFFYSxPQUFPekMsV0FBVyxDQUFDO0FBRXhCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUtBO0FBQUFBLE1BQ0wsV0FBVTtBQUFBLE1BQ1YsT0FBTyxFQUFFMEMsWUFBWSxZQUFZO0FBQUEsTUFFakMsaUNBQUMsU0FBSSxXQUFVLDhCQUNiLGlDQUFDLFNBQUksS0FBS3pDLFVBQVUsV0FBVSw0QkFHNUI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNEJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBR3ZDLHVCQUFDLFVBQUssV0FBVSxzRkFDZDtBQUFBLGlDQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTTtBQUFBLFVBQ04sdUJBQUMsVUFBSyxXQUFVLDhCQUE2QixPQUFPLEVBQUVuQixPQUFPLGNBQWMsR0FDekUsaUNBQUMsZ0JBQWEsTUFBSywrQkFBOEIsWUFBWSxLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRCxLQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVU7QUFBQSxhQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBR0EsdUJBQUMsVUFBSyxXQUFVLG1FQUFrRSxPQUFPLEVBQUVBLE9BQU8sY0FBYyxHQUM5RyxpQ0FBQyxnQkFBYSxNQUFLLFFBQU8sWUFBWSxNQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0EsdUJBQUMsVUFBSyxXQUFVLHdFQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDhCQUE2QixPQUFPLEVBQUVBLE9BQU8sY0FBYyxHQUN6RSxpQ0FBQyxnQkFBYSxNQUFLLGFBQVksWUFBWSxNQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhO0FBQUEsYUFKZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUdBLHVCQUFDLFVBQUssV0FBVSxzRkFDZDtBQUFBLGlDQUFDLFVBQUssV0FBVSw4QkFBNkIsT0FBTyxFQUFFQSxPQUFPLGNBQWMsR0FDekUsaUNBQUMsZ0JBQWEsTUFBSyxzQkFBcUIsWUFBWSxNQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjO0FBQUEsYUFKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHQSx1QkFBQyxVQUFLLFdBQVUsbUVBQWtFLE9BQU8sRUFBRUEsT0FBTyxjQUFjLEdBQzlHLGlDQUFDLGdCQUFhLE1BQUssS0FBSSxZQUFZLE1BQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHQSx1QkFBQyxVQUFLLFdBQVUsMkVBQ2Q7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsOEJBQTZCLE9BQU8sRUFBRUEsT0FBTyxjQUFjLEdBQ3pFLGlDQUFDLGdCQUFhLE1BQUssbUJBQWtCLFlBQVksTUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0QsS0FEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBWTtBQUFBLGFBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsNEJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFdBakR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbURBLEtBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxREE7QUFBQTtBQUFBLElBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTJEQTtBQUVKO0FBQUNpQixHQS9KdUJELGtCQUFnQjtBQUFBLFVBSXRDbkQsT0FBTztBQUFBO0FBQUFnRyxNQUplN0M7QUFBZ0IsSUFBQW5DLElBQUFhLEtBQUFHLEtBQUFTLEtBQUFHLEtBQUFFLEtBQUFFLEtBQUFFLEtBQUE4QztBQUFBQyxhQUFBakYsSUFBQTtBQUFBaUYsYUFBQXBFLEtBQUE7QUFBQW9FLGFBQUFqRSxLQUFBO0FBQUFpRSxhQUFBeEQsS0FBQTtBQUFBd0QsYUFBQXJELEtBQUE7QUFBQXFELGFBQUFuRCxLQUFBO0FBQUFtRCxhQUFBakQsS0FBQTtBQUFBaUQsYUFBQS9DLEtBQUE7QUFBQStDLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VHU0FQIiwiZ3NhcCIsIlNjcm9sbFRyaWdnZXIiLCJ1c2VSZWYiLCJyZWdpc3RlclBsdWdpbiIsIlNwbGl0TGV0dGVycyIsInRleHQiLCJzdGFydEluZGV4Iiwic3BsaXQiLCJtYXAiLCJjaGFyIiwiaSIsImZyb20iLCJ2ZXJ0aWNhbEFsaWduIiwicGFkZGluZ0JvdHRvbSIsIm1hcmdpbkJvdHRvbSIsIl9jIiwiRyIsIkdNIiwiR0QiLCJQIiwiUEQiLCJMZWFmIiwiY3giLCJjeSIsImFuZ2xlIiwiZmlsbCIsInMiLCJvcCIsIl9jMiIsIkRvdCIsInIiLCJfYzMiLCJIZXJvSSIsIm1hcmdpblJpZ2h0IiwiY29sb3IiLCJ0b3AiLCJsZWZ0Iiwid2lkdGgiLCJoZWlnaHQiLCJvdmVyZmxvdyIsIl9jNCIsIkludHJvVmluZSIsImZpbHRlciIsIl9jNSIsIkRlc2lnbmVyVmluZSIsIl9jNiIsIkRldmVsb3BlclZpbmUiLCJfYzciLCJXZWJmbG93VmluZSIsIl9jOCIsIkhvcml6b250YWxTY3JvbGwiLCJfcyIsIndyYXBwZXJSZWYiLCJ0cmFja1JlZiIsInRyYWNrIiwiY3VycmVudCIsIndyYXBwZXIiLCJ0b3RhbFNjcm9sbCIsInNjcm9sbFdpZHRoIiwid2luZG93IiwiaW5uZXJXaWR0aCIsInNjcm9sbFR3ZWVuIiwidG8iLCJ4IiwiZWFzZSIsInNjcm9sbFRyaWdnZXIiLCJ0cmlnZ2VyIiwicGluIiwic2NydWIiLCJlbmQiLCJ1dGlscyIsInRvQXJyYXkiLCJmb3JFYWNoIiwibGV0dGVyIiwiZGlyIiwiZGF0YXNldCIsImZyb21UbyIsInlQZXJjZW50Iiwib3BhY2l0eSIsImNvbnRhaW5lckFuaW1hdGlvbiIsInN0YXJ0IiwicGF0aCIsInZpbmVXcmFwIiwiY2xvc2VzdCIsImxlbiIsImdldFRvdGFsTGVuZ3RoIiwic2V0Iiwic3Ryb2tlRGFzaGFycmF5Iiwic3Ryb2tlRGFzaG9mZnNldCIsImR1cmF0aW9uIiwic2NhbGUiLCJ0cmFuc2Zvcm1PcmlnaW4iLCJzdGFnZ2VyIiwic2NvcGUiLCJiYWNrZ3JvdW5kIiwiX2M5IiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkhvcml6b250YWxTY3JvbGwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUdTQVAgfSBmcm9tICdAZ3NhcC9yZWFjdCc7XG5pbXBvcnQgZ3NhcCBmcm9tICdnc2FwJztcbmltcG9ydCB7IFNjcm9sbFRyaWdnZXIgfSBmcm9tICdnc2FwL1Njcm9sbFRyaWdnZXInO1xuaW1wb3J0IHsgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuXG5nc2FwLnJlZ2lzdGVyUGx1Z2luKFNjcm9sbFRyaWdnZXIpO1xuXG4vKiDilIDilIDilIAgU3BsaXQgdGV4dCBpbnRvIGluZGl2aWR1YWwgbGV0dGVycyB3aXRoIGFsdGVybmF0aW5nIHJldmVhbCBkaXJlY3Rpb24g4pSA4pSA4pSAICovXG5mdW5jdGlvbiBTcGxpdExldHRlcnMoeyB0ZXh0LCBzdGFydEluZGV4ID0gMCB9OiB7IHRleHQ6IHN0cmluZzsgc3RhcnRJbmRleD86IG51bWJlciB9KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHt0ZXh0LnNwbGl0KCcnKS5tYXAoKGNoYXIsIGkpID0+IHtcbiAgICAgICAgLy8gUHJlc2VydmUgd29yZCBzcGFjaW5nIGNvcnJlY3RseVxuICAgICAgICBpZiAoY2hhciA9PT0gJyAnKSByZXR1cm4gPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgdy1bMC4yNWVtXVwiPiZuYnNwOzwvc3Bhbj47XG4gICAgICAgIGNvbnN0IGZyb20gPSAoc3RhcnRJbmRleCArIGkpICUgMiA9PT0gMCA/ICd1cCcgOiAnZG93bic7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgb3ZlcmZsb3ctaGlkZGVuXCIgc3R5bGU9e3sgdmVydGljYWxBbGlnbjogJ2JvdHRvbScsIHBhZGRpbmdCb3R0b206ICcwLjFlbScsIG1hcmdpbkJvdHRvbTogJy0wLjFlbScgfX0+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLXdvcmQgaW5saW5lLWJsb2NrXCIgZGF0YS1mcm9tPXtmcm9tfT5cbiAgICAgICAgICAgICAge2NoYXJ9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC8+XG4gICk7XG59XG5cbi8qIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkFxuICAgVklORSBTVkcgREVDT1JBVElPTlNcbiAgIERlbGljYXRlLCBvcmdhbmljIHZpbmVzIHdpdGggZ3JlZW4gc3RlbXMsIHNtYWxsIGxlYXZlcyxcbiAgIHB1cnBsZSBhY2NlbnQgY3VybHMgYW5kIGZsb3dlciBkb3RzLiBQb3NpdGlvbmVkIGlubGluZVxuICAgd2l0aCB0aGUgdGV4dCBzbyB0aGV5IHNjcm9sbCB0b2dldGhlci5cbiAgIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkCAqL1xuLyog4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICBIRVJPIFwiSVwiXG4gICBUd28gdmluZXMgYmxvb20gb3V0IG9mIHRoZSBsZXR0ZXIgb24gc2VjdGlvblxuICAgZW50cnkg4oCUIGJlZm9yZSB0aGUgaG9yaXpvbnRhbCBzY3JvbGwgc3RhcnRzLlxu4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5jb25zdCBHID0gJyM0Q0FGNTAnO1xuY29uc3QgR00gPSAnIzgxQzc4NCc7XG5jb25zdCBHRCA9ICcjMzg4RTNDJztcbmNvbnN0IFAgPSAnIzlDMjdCMCc7XG5jb25zdCBQRCA9ICcjN0IxRkEyJztcblxuZnVuY3Rpb24gTGVhZih7IGN4LCBjeSwgYW5nbGUsIGZpbGwsIHMsIG9wID0gMSB9OiB7IGN4OiBudW1iZXIsIGN5OiBudW1iZXIsIGFuZ2xlOiBudW1iZXIsIGZpbGw6IHN0cmluZywgczogbnVtYmVyLCBvcD86IG51bWJlciB9KSB7XG4gIHJldHVybiAoXG4gICAgPHBhdGhcbiAgICAgIGNsYXNzTmFtZT1cImhlcm8tbGVhZlwiXG4gICAgICBkPXtgTSAke2N4fSAke2N5fSBDICR7Y3ggLSBzIC8gMn0gJHtjeSAtIHN9ICR7Y3ggKyBzIC8gMn0gJHtjeSAtIHN9ICR7Y3h9ICR7Y3kgLSBzICogMS41fSBDICR7Y3ggKyBzIC8gMn0gJHtjeSAtIHMgLyAyfSAke2N4ICsgcyAvIDJ9ICR7Y3l9ICR7Y3h9ICR7Y3l9YH1cbiAgICAgIGZpbGw9e2ZpbGx9XG4gICAgICBvcGFjaXR5PXtvcH1cbiAgICAgIHRyYW5zZm9ybT17YHJvdGF0ZSgke2FuZ2xlfSAke2N4fSAke2N5fSlgfVxuICAgIC8+XG4gICk7XG59XG5cbmZ1bmN0aW9uIERvdCh7IGN4LCBjeSwgciwgZmlsbCB9OiB7IGN4OiBudW1iZXIsIGN5OiBudW1iZXIsIHI6IG51bWJlciwgZmlsbDogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIDxjaXJjbGUgY2xhc3NOYW1lPVwiaGVyby1kb3RcIiBjeD17Y3h9IGN5PXtjeX0gcj17cn0gZmlsbD17ZmlsbH0gLz47XG59XG5cbmZ1bmN0aW9uIEhlcm9JKCkge1xuICByZXR1cm4gKFxuICAgIDxzcGFuXG4gICAgICBjbGFzc05hbWU9XCJoZXJvLWkgcmVsYXRpdmUgaW5saW5lLWJsb2NrIGZsZXgtc2hyaW5rLTBcIlxuICAgICAgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICcwLjJlbScgfX1cbiAgICA+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZWFkaW5nLWhlcm9cIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQsICMwZDBkMGQpJyB9fT5JPC9zcGFuPlxuICAgICAgPHN2Z1xuICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBwb2ludGVyLWV2ZW50cy1ub25lIHotWzJdXCJcbiAgICAgICAgc3R5bGU9e3sgdG9wOiAnLTYwJScsIGxlZnQ6ICctOTUlJywgd2lkdGg6ICcyOTAlJywgaGVpZ2h0OiAnMjIwJScsIG92ZXJmbG93OiAndmlzaWJsZScgfX1cbiAgICAgICAgdmlld0JveD1cIjAgMCAxMDAgMTAwXCJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgPlxuICAgICAgICB7LyogbGVmdCB2aW5lIGNsaW1iaW5nIHVwICovfVxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGNsYXNzTmFtZT1cImhlcm8tc3RlbVwiXG4gICAgICAgICAgZD1cIk0gNTAgODggQyAzNiA3MiAxOCA3NiAxNiA1OCBDIDE0IDQwIDI4IDMwIDIwIDE4IEMgMTQgOCA0IDEwIDYgMlwiXG4gICAgICAgICAgc3Ryb2tlPXtHfSBzdHJva2VXaWR0aD1cIjEuN1wiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxwYXRoIGNsYXNzTmFtZT1cImhlcm8tc3RlbVwiIGQ9XCJNIDE4IDU0IEMgMTAgNTAgNCA1NCAyIDQ2XCIgc3Ryb2tlPXtHTX0gc3Ryb2tlV2lkdGg9XCIxLjFcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxuXG4gICAgICAgIDxMZWFmIGN4PXsxOH0gY3k9ezY0fSBhbmdsZT17LTE0MH0gZmlsbD17R30gcz17OX0gLz5cbiAgICAgICAgPExlYWYgY3g9ezE5fSBjeT17MzZ9IGFuZ2xlPXstMTYwfSBmaWxsPXtHTX0gcz17OH0gb3A9ezAuODV9IC8+XG4gICAgICAgIDxMZWFmIGN4PXs4fSBjeT17MTJ9IGFuZ2xlPXstMTIwfSBmaWxsPXtHTX0gcz17N30gb3A9ezAuN30gLz5cbiAgICAgICAgPERvdCBjeD17Mn0gY3k9ezQ2fSByPXsyLjh9IGZpbGw9e0dEfSAvPlxuICAgICAgICA8RG90IGN4PXs1fSBjeT17MjB9IHI9ezIuMn0gZmlsbD17R0R9IC8+XG5cbiAgICAgICAgey8qIHJpZ2h0IHZpbmUgZHJvcHBpbmcgZG93biAqL31cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvLXN0ZW1cIlxuICAgICAgICAgIGQ9XCJNIDUwIDEyIEMgNjQgMjggODAgMjQgODIgNDIgQyA4NCA1OCA3MCA2OCA4MCA4MiBDIDg2IDkyIDk2IDg4IDk0IDk4XCJcbiAgICAgICAgICBzdHJva2U9e1B9IHN0cm9rZVdpZHRoPVwiMS43XCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwiaGVyby1zdGVtXCIgZD1cIk0gODIgNDYgQyA5MCA1MCA5NiA0NiA5OCA1NFwiIHN0cm9rZT17UH0gc3Ryb2tlV2lkdGg9XCIxLjFcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxuXG4gICAgICAgIDxMZWFmIGN4PXs4Mn0gY3k9ezM2fSBhbmdsZT17NDB9IGZpbGw9e1B9IHM9ezl9IC8+XG4gICAgICAgIDxMZWFmIGN4PXs3Nn0gY3k9ezY4fSBhbmdsZT17MjB9IGZpbGw9e1B9IHM9ezh9IG9wPXswLjg1fSAvPlxuICAgICAgICA8TGVhZiBjeD17OTJ9IGN5PXs5Mn0gYW5nbGU9ezYwfSBmaWxsPXtQfSBzPXs3fSBvcD17MC43fSAvPlxuICAgICAgICA8RG90IGN4PXs5OH0gY3k9ezU0fSByPXsyLjh9IGZpbGw9e1BEfSAvPlxuICAgICAgICA8RG90IGN4PXs5Nn0gY3k9ezc4fSByPXsyLjJ9IGZpbGw9e1BEfSAvPlxuICAgICAgPC9zdmc+XG4gICAgPC9zcGFuPlxuICApO1xufVxuXG5mdW5jdGlvbiBJbnRyb1ZpbmUoKSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxzdmcgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcG9pbnRlci1ldmVudHMtbm9uZSB6LVswXVwiIHN0eWxlPXt7IHRvcDogJy04MCUnLCBsZWZ0OiAnLTIwJScsIHdpZHRoOiAnMTUwJScsIGhlaWdodDogJzI2MCUnLCBvdmVyZmxvdzogJ3Zpc2libGUnLCBmaWx0ZXI6ICdibHVyKDEuNXB4KScgfX0gdmlld0JveD1cIjAgMCA2MDAgMjAwXCIgZmlsbD1cIm5vbmVcIj5cbiAgICAgICAgPGRlZnM+XG4gICAgICAgICAgPGxpbmVhckdyYWRpZW50IGlkPVwidmluZS1ncmFkaWVudFwiIHgxPVwiMFwiIHkxPVwiMFwiIHgyPVwiMVwiIHkyPVwiMFwiIGdyYWRpZW50VW5pdHM9XCJvYmplY3RCb3VuZGluZ0JveFwiPlxuICAgICAgICAgICAgPHN0b3Agc3RvcENvbG9yPVwiIzRDQUY1MFwiIC8+XG4gICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIxXCIgc3RvcENvbG9yPVwiIzlDMjdCMFwiIC8+XG4gICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cbiAgICAgICAgPC9kZWZzPlxuICAgICAgICB7LyogRE5BIEhlbGl4IDEgKEJhY2tncm91bmQpICovfVxuICAgICAgICA8cGF0aCBjbGFzc05hbWU9XCJ2aW5lLXN0ZW0gb3BhY2l0eS0wXCIgZD1cIk0gLTUwIDEwMCBDIDUwIDAsIDE1MCAwLCAyNTAgMTAwIEMgMzUwIDIwMCwgNDUwIDIwMCwgNTUwIDEwMCBDIDYwMCA1MCwgNjUwIDUwLCA3MDAgMTAwXCIgc3Ryb2tlPVwidXJsKCN2aW5lLWdyYWRpZW50KVwiIHN0cm9rZVdpZHRoPVwiMS41XCIgc3Ryb2tlT3BhY2l0eT1cIjAuMzVcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxuICAgICAgPC9zdmc+XG4gICAgICA8c3ZnIGNsYXNzTmFtZT1cImFic29sdXRlIHBvaW50ZXItZXZlbnRzLW5vbmUgei1bMjBdXCIgc3R5bGU9e3sgdG9wOiAnLTgwJScsIGxlZnQ6ICctMjAlJywgd2lkdGg6ICcxNTAlJywgaGVpZ2h0OiAnMjYwJScsIG92ZXJmbG93OiAndmlzaWJsZScsIGZpbHRlcjogJ2Ryb3Atc2hhZG93KDBweCAxNXB4IDE1cHggcmdiYSgwLDAsMCwwLjkpKScgfX0gdmlld0JveD1cIjAgMCA2MDAgMjAwXCIgZmlsbD1cIm5vbmVcIj5cbiAgICAgICAgey8qIEROQSBIZWxpeCAyIChGb3JlZ3JvdW5kKSAqL31cbiAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwidmluZS1zdGVtIG9wYWNpdHktMFwiIGQ9XCJNIC01MCAxMDAgQyA1MCAyMDAsIDE1MCAyMDAsIDI1MCAxMDAgQyAzNTAgMCwgNDUwIDAsIDU1MCAxMDAgQyA2MDAgMTUwLCA2NTAgMTUwLCA3MDAgMTAwXCIgc3Ryb2tlPVwidXJsKCN2aW5lLWdyYWRpZW50KVwiIHN0cm9rZVdpZHRoPVwiNFwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG4gICAgICA8L3N2Zz5cbiAgICA8Lz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRGVzaWduZXJWaW5lKCkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8c3ZnIGNsYXNzTmFtZT1cImFic29sdXRlIHBvaW50ZXItZXZlbnRzLW5vbmUgei1bMF1cIiBzdHlsZT17eyB0b3A6ICctMTAwJScsIGxlZnQ6ICctMzAlJywgd2lkdGg6ICcxODAlJywgaGVpZ2h0OiAnMzAwJScsIG92ZXJmbG93OiAndmlzaWJsZScsIGZpbHRlcjogJ2JsdXIoMS41cHgpJyB9fSB2aWV3Qm94PVwiMCAwIDUwMCAyMDBcIiBmaWxsPVwibm9uZVwiPlxuICAgICAgICA8cGF0aCBjbGFzc05hbWU9XCJ2aW5lLXN0ZW0gb3BhY2l0eS0wXCIgZD1cIk0gLTUwIDEwMCBDIDUwIC0yMCwgMTUwIC0yMCwgMjUwIDEwMCBDIDM1MCAyMjAsIDQ1MCAyMjAsIDU1MCAxMDBcIiBzdHJva2U9XCJ1cmwoI3ZpbmUtZ3JhZGllbnQpXCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiBzdHJva2VPcGFjaXR5PVwiMC4zNVwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG4gICAgICA8L3N2Zz5cbiAgICAgIDxzdmcgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcG9pbnRlci1ldmVudHMtbm9uZSB6LVsyMF1cIiBzdHlsZT17eyB0b3A6ICctMTAwJScsIGxlZnQ6ICctMzAlJywgd2lkdGg6ICcxODAlJywgaGVpZ2h0OiAnMzAwJScsIG92ZXJmbG93OiAndmlzaWJsZScsIGZpbHRlcjogJ2Ryb3Atc2hhZG93KDBweCAxNXB4IDE1cHggcmdiYSgwLDAsMCwwLjkpKScgfX0gdmlld0JveD1cIjAgMCA1MDAgMjAwXCIgZmlsbD1cIm5vbmVcIj5cbiAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwidmluZS1zdGVtIG9wYWNpdHktMFwiIGQ9XCJNIC01MCAxMDAgQyA1MCAyMjAsIDE1MCAyMjAsIDI1MCAxMDAgQyAzNTAgLTIwLCA0NTAgLTIwLCA1NTAgMTAwXCIgc3Ryb2tlPVwidXJsKCN2aW5lLWdyYWRpZW50KVwiIHN0cm9rZVdpZHRoPVwiNFwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG4gICAgICA8L3N2Zz5cbiAgICA8Lz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRGV2ZWxvcGVyVmluZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPHN2ZyBjbGFzc05hbWU9XCJhYnNvbHV0ZSBwb2ludGVyLWV2ZW50cy1ub25lIHotWzBdXCIgc3R5bGU9e3sgdG9wOiAnLTkwJScsIGxlZnQ6ICctMjAlJywgd2lkdGg6ICcxNjAlJywgaGVpZ2h0OiAnMjgwJScsIG92ZXJmbG93OiAndmlzaWJsZScsIGZpbHRlcjogJ2JsdXIoMS41cHgpJyB9fSB2aWV3Qm94PVwiMCAwIDcwMCAyMDBcIiBmaWxsPVwibm9uZVwiPlxuICAgICAgICA8cGF0aCBjbGFzc05hbWU9XCJ2aW5lLXN0ZW0gb3BhY2l0eS0wXCIgZD1cIk0gLTUwIDEwMCBDIDEwMCAwLCAyNTAgMCwgNDAwIDEwMCBDIDU1MCAyMDAsIDcwMCAyMDAsIDg1MCAxMDBcIiBzdHJva2U9XCJ1cmwoI3ZpbmUtZ3JhZGllbnQpXCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiBzdHJva2VPcGFjaXR5PVwiMC4zNVwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG4gICAgICA8L3N2Zz5cbiAgICAgIDxzdmcgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcG9pbnRlci1ldmVudHMtbm9uZSB6LVsyMF1cIiBzdHlsZT17eyB0b3A6ICctOTAlJywgbGVmdDogJy0yMCUnLCB3aWR0aDogJzE2MCUnLCBoZWlnaHQ6ICcyODAlJywgb3ZlcmZsb3c6ICd2aXNpYmxlJywgZmlsdGVyOiAnZHJvcC1zaGFkb3coMHB4IDE1cHggMTVweCByZ2JhKDAsMCwwLDAuOSkpJyB9fSB2aWV3Qm94PVwiMCAwIDcwMCAyMDBcIiBmaWxsPVwibm9uZVwiPlxuICAgICAgICA8cGF0aCBjbGFzc05hbWU9XCJ2aW5lLXN0ZW0gb3BhY2l0eS0wXCIgZD1cIk0gLTUwIDEwMCBDIDEwMCAyMDAsIDI1MCAyMDAsIDQwMCAxMDAgQyA1NTAgMCwgNzAwIDAsIDg1MCAxMDBcIiBzdHJva2U9XCJ1cmwoI3ZpbmUtZ3JhZGllbnQpXCIgc3Ryb2tlV2lkdGg9XCI0XCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgLz5cbiAgICAgIDwvc3ZnPlxuICAgIDwvPlxuICApO1xufVxuXG5mdW5jdGlvbiBXZWJmbG93VmluZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPHN2ZyBjbGFzc05hbWU9XCJhYnNvbHV0ZSBwb2ludGVyLWV2ZW50cy1ub25lIHotWzBdXCIgc3R5bGU9e3sgdG9wOiAnLTExMCUnLCBsZWZ0OiAnLTQwJScsIHdpZHRoOiAnMjAwJScsIGhlaWdodDogJzMyMCUnLCBvdmVyZmxvdzogJ3Zpc2libGUnLCBmaWx0ZXI6ICdibHVyKDEuNXB4KScgfX0gdmlld0JveD1cIjAgMCA2MDAgMjAwXCIgZmlsbD1cIm5vbmVcIj5cbiAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwidmluZS1zdGVtIG9wYWNpdHktMFwiIGQ9XCJNIC0xMDAgMTAwIEMgMCAtNTAsIDIwMCAtNTAsIDMwMCAxMDAgQyA0MDAgMjUwLCA2MDAgMjUwLCA3MDAgMTAwXCIgc3Ryb2tlPVwidXJsKCN2aW5lLWdyYWRpZW50KVwiIHN0cm9rZVdpZHRoPVwiMS41XCIgc3Ryb2tlT3BhY2l0eT1cIjAuMzVcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxuICAgICAgPC9zdmc+XG4gICAgICA8c3ZnIGNsYXNzTmFtZT1cImFic29sdXRlIHBvaW50ZXItZXZlbnRzLW5vbmUgei1bMjBdXCIgc3R5bGU9e3sgdG9wOiAnLTExMCUnLCBsZWZ0OiAnLTQwJScsIHdpZHRoOiAnMjAwJScsIGhlaWdodDogJzMyMCUnLCBvdmVyZmxvdzogJ3Zpc2libGUnLCBmaWx0ZXI6ICdkcm9wLXNoYWRvdygwcHggMTVweCAxNXB4IHJnYmEoMCwwLDAsMC45KSknIH19IHZpZXdCb3g9XCIwIDAgNjAwIDIwMFwiIGZpbGw9XCJub25lXCI+XG4gICAgICAgIDxwYXRoIGNsYXNzTmFtZT1cInZpbmUtc3RlbSBvcGFjaXR5LTBcIiBkPVwiTSAtMTAwIDEwMCBDIDAgMjUwLCAyMDAgMjUwLCAzMDAgMTAwIEMgNDAwIC01MCwgNjAwIC01MCwgNzAwIDEwMFwiIHN0cm9rZT1cInVybCgjdmluZS1ncmFkaWVudClcIiBzdHJva2VXaWR0aD1cIjRcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiAvPlxuICAgICAgPC9zdmc+XG4gICAgPC8+XG4gICk7XG59XG5cbi8qIOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkOKVkFxuICAgSE9SSVpPTlRBTCBTQ1JPTEwgU0VDVElPTlxuICAg4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQICovXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvcml6b250YWxTY3JvbGwoKSB7XG4gIGNvbnN0IHdyYXBwZXJSZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCB0cmFja1JlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG5cbiAgdXNlR1NBUCgoKSA9PiB7XG4gICAgY29uc3QgdHJhY2sgPSB0cmFja1JlZi5jdXJyZW50O1xuICAgIGNvbnN0IHdyYXBwZXIgPSB3cmFwcGVyUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCF0cmFjayB8fCAhd3JhcHBlcikgcmV0dXJuO1xuXG4gICAgY29uc3QgdG90YWxTY3JvbGwgPSB0cmFjay5zY3JvbGxXaWR0aCAtIHdpbmRvdy5pbm5lcldpZHRoO1xuXG4gICAgLy8g4pSA4pSAIE1hc3RlciBob3Jpem9udGFsIHNjcm9sbCB0d2VlbiDilIDilIBcbiAgICBjb25zdCBzY3JvbGxUd2VlbiA9IGdzYXAudG8odHJhY2ssIHtcbiAgICAgIHg6IC10b3RhbFNjcm9sbCxcbiAgICAgIGVhc2U6ICdub25lJyxcbiAgICAgIHNjcm9sbFRyaWdnZXI6IHtcbiAgICAgICAgdHJpZ2dlcjogd3JhcHBlcixcbiAgICAgICAgcGluOiB0cnVlLFxuICAgICAgICBzY3J1YjogMSxcbiAgICAgICAgZW5kOiBgKz0ke3RvdGFsU2Nyb2xsfWAsXG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyDilIDilIAgTGV0dGVyIHJldmVhbHMg4oCUIGFsdGVybmF0aW5nIGZyb20gdXAvZG93biDilIDilIBcbiAgICAvLyBVc2VzIGNvbnRhaW5lckFuaW1hdGlvbiBzbyB0cmlnZ2VycyBmaXJlIGJhc2VkIG9uXG4gICAgLy8gaG9yaXpvbnRhbCBwb3NpdGlvbiB3aXRoaW4gdGhlIG1vdmluZyB0cmFja1xuICAgIGdzYXAudXRpbHMudG9BcnJheTxIVE1MRWxlbWVudD4oJy5oLXdvcmQnKS5mb3JFYWNoKChsZXR0ZXIpID0+IHtcbiAgICAgIGNvbnN0IGRpciA9IGxldHRlci5kYXRhc2V0LmZyb20gPT09ICd1cCcgPyAtMTIwIDogMTIwO1xuICAgICAgZ3NhcC5mcm9tVG8obGV0dGVyLFxuICAgICAgICB7IHlQZXJjZW50OiBkaXIsIG9wYWNpdHk6IDAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHlQZXJjZW50OiAwLFxuICAgICAgICAgIG9wYWNpdHk6IDEsXG4gICAgICAgICAgZWFzZTogJ3Bvd2VyMy5vdXQnLFxuICAgICAgICAgIHNjcm9sbFRyaWdnZXI6IHtcbiAgICAgICAgICAgIHRyaWdnZXI6IGxldHRlcixcbiAgICAgICAgICAgIGNvbnRhaW5lckFuaW1hdGlvbjogc2Nyb2xsVHdlZW4sXG4gICAgICAgICAgICBzdGFydDogJ2xlZnQgOTUlJywgLy8gV2FpdCB1bnRpbCBpdCdzIHJlYWxseSBvbiBzY3JlZW5cbiAgICAgICAgICAgIGVuZDogJ2xlZnQgNjAlJyxcbiAgICAgICAgICAgIHNjcnViOiB0cnVlLFxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9KTtcblxuICAgIC8vIOKUgOKUgCBWaW5lIHN0ZW1zIOKAlCBkcmF3IHdpdGggc3Ryb2tlRGFzaG9mZnNldCDilIDilIBcbiAgICBnc2FwLnV0aWxzLnRvQXJyYXk8U1ZHUGF0aEVsZW1lbnQ+KCcudmluZS1zdGVtJykuZm9yRWFjaCgocGF0aCkgPT4ge1xuICAgICAgY29uc3QgdmluZVdyYXAgPSBwYXRoLmNsb3Nlc3QoJy52aW5lLXdyYXAnKTtcbiAgICAgIGlmICghdmluZVdyYXApIHJldHVybjtcbiAgICAgIGNvbnN0IGxlbiA9IHBhdGguZ2V0VG90YWxMZW5ndGgoKTtcbiAgICAgIC8vIEFkZCBleHRyYSBsZW5ndGggdG8gYXJyYXkvb2Zmc2V0IHRvIGd1YXJhbnRlZSB0aGUgbGluZSBpcyAxMDAlIGhpZGRlbiBhdCB0aGUgc3RhcnRcbiAgICAgIGdzYXAuc2V0KHBhdGgsIHsgc3Ryb2tlRGFzaGFycmF5OiBsZW4gKyAxMCwgc3Ryb2tlRGFzaG9mZnNldDogbGVuICsgMTAsIG9wYWNpdHk6IDEgfSk7XG4gICAgICBnc2FwLnRvKHBhdGgsIHtcbiAgICAgICAgc3Ryb2tlRGFzaG9mZnNldDogMCxcbiAgICAgICAgZWFzZTogJ25vbmUnLFxuICAgICAgICBzY3JvbGxUcmlnZ2VyOiB7XG4gICAgICAgICAgdHJpZ2dlcjogdmluZVdyYXAsXG4gICAgICAgICAgY29udGFpbmVyQW5pbWF0aW9uOiBzY3JvbGxUd2VlbixcbiAgICAgICAgICBzdGFydDogJ2xlZnQgOTAlJywgLy8gU3RhcnQgZHJhd2luZyBleGFjdGx5IGFzIHRoZSB3b3JkIGVudGVycyB0aGUgc2NyZWVuXG4gICAgICAgICAgZW5kOiAncmlnaHQgNjAlJywgLy8gRmluaXNoIGRyYXdpbmcgZXhhY3RseSBhcyB0aGUgbGFzdCBsZXR0ZXIgZmluaXNoZXMgaXRzIGFuaW1hdGlvblxuICAgICAgICAgIHNjcnViOiB0cnVlLFxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIOKUgOKUgCBIZXJvIFwiSVwiIGluaXRpYWwgYmxvb20g4pSA4pSAXG4gICAgZ3NhcC51dGlscy50b0FycmF5PFNWR1BhdGhFbGVtZW50PignLmhlcm8tc3RlbScpLmZvckVhY2gocGF0aCA9PiB7XG4gICAgICBjb25zdCBsZW4gPSBwYXRoLmdldFRvdGFsTGVuZ3RoKCk7XG4gICAgICBnc2FwLnNldChwYXRoLCB7IHN0cm9rZURhc2hhcnJheTogbGVuLCBzdHJva2VEYXNob2Zmc2V0OiBsZW4gfSk7XG4gICAgfSk7XG5cbiAgICBnc2FwLnRvKCcuaGVyby1zdGVtJywge1xuICAgICAgc3Ryb2tlRGFzaG9mZnNldDogMCxcbiAgICAgIGR1cmF0aW9uOiAxLjUsXG4gICAgICBlYXNlOiAncG93ZXIzLm91dCcsXG4gICAgICBzY3JvbGxUcmlnZ2VyOiB7XG4gICAgICAgIHRyaWdnZXI6IHdyYXBwZXIsXG4gICAgICAgIHN0YXJ0OiAndG9wIDYwJScsXG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBnc2FwLmZyb21UbygnLmhlcm8tbGVhZiwgLmhlcm8tZG90JyxcbiAgICAgIHsgc2NhbGU6IDAsIHRyYW5zZm9ybU9yaWdpbjogJ2NlbnRlcicgfSxcbiAgICAgIHtcbiAgICAgICAgc2NhbGU6IDEsXG4gICAgICAgIGR1cmF0aW9uOiAxLFxuICAgICAgICBzdGFnZ2VyOiAwLjEsXG4gICAgICAgIGVhc2U6ICdiYWNrLm91dCgyKScsXG4gICAgICAgIHNjcm9sbFRyaWdnZXI6IHtcbiAgICAgICAgICB0cmlnZ2VyOiB3cmFwcGVyLFxuICAgICAgICAgIHN0YXJ0OiAndG9wIDYwJScsXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICApO1xuXG4gIH0sIHsgc2NvcGU6IHdyYXBwZXJSZWYgfSk7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvblxuICAgICAgcmVmPXt3cmFwcGVyUmVmfVxuICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCJcbiAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1iZyknIH19XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICA8ZGl2IHJlZj17dHJhY2tSZWZ9IGNsYXNzTmFtZT1cImhvcml6b250YWwtc2Nyb2xsX190cmFja1wiPlxuXG4gICAgICAgICAgey8qIExlYWRpbmcgdmlld3BvcnQgcGFkZGluZyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgdy1bOTB2d11cIiAvPlxuXG4gICAgICAgICAgey8qIOKUgOKUgCBJIENSQUZUIERJR0lUQUwgRVhQRVJJRU5DRVMsIHdpdGggdmluZSDilIDilIAgKi99XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWZsZXggaXRlbXMtYmFzZWxpbmUgdmluZS13cmFwIGZsZXgtc2hyaW5rLTAgbXgtWzAuMTJlbV0gbXItWzAuNWVtXVwiPlxuICAgICAgICAgICAgPEhlcm9JIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZWFkaW5nLWhlcm8gcmVsYXRpdmUgei0xMFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tdGV4dCknIH19PlxuICAgICAgICAgICAgICA8U3BsaXRMZXR0ZXJzIHRleHQ9XCIgIENSQUZUIERJR0lUQUwgRVhQRVJJRU5DRVNcIiBzdGFydEluZGV4PXsxfSAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPEludHJvVmluZSAvPlxuICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgIHsvKiDilIDilIAgQVMgQSDilIDilIAgKi99XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGVhZGluZy1oZXJvIHJlbGF0aXZlIHotMTAgZmxleC1zaHJpbmstMCBteC1bMC4xMmVtXSBtci1bMC41ZW1dXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS10ZXh0KScgfX0+XG4gICAgICAgICAgICA8U3BsaXRMZXR0ZXJzIHRleHQ9XCJBUyBBXCIgc3RhcnRJbmRleD17Mjd9IC8+XG4gICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgey8qIOKUgOKUgCBERVNJR05FUiwgd2l0aCB2aW5lIOKUgOKUgCAqL31cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpbmxpbmUtYmxvY2sgdmluZS13cmFwIGZsZXgtc2hyaW5rLTAgbXgtWzAuMTJlbV0gbXItWzAuNWVtXVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGVhZGluZy1oZXJvIHJlbGF0aXZlIHotMTBcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQpJyB9fT5cbiAgICAgICAgICAgICAgPFNwbGl0TGV0dGVycyB0ZXh0PVwiREVTSUdORVIsXCIgc3RhcnRJbmRleD17MzF9IC8+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8RGVzaWduZXJWaW5lIC8+XG4gICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgey8qIOKUgOKUgCBGUk9OVEVORCBERVZFTE9QRVIgd2l0aCB2aW5lIOKUgOKUgCAqL31cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpbmxpbmUtZmxleCBpdGVtcy1iYXNlbGluZSB2aW5lLXdyYXAgZmxleC1zaHJpbmstMCBteC1bMC4xMmVtXSBtci1bMC41ZW1dXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZWFkaW5nLWhlcm8gcmVsYXRpdmUgei0xMFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tdGV4dCknIH19PlxuICAgICAgICAgICAgICA8U3BsaXRMZXR0ZXJzIHRleHQ9XCJGUk9OVEVORCBERVZFTE9QRVJcIiBzdGFydEluZGV4PXs0MH0gLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxEZXZlbG9wZXJWaW5lIC8+XG4gICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgey8qIOKUgOKUgCAmIOKUgOKUgCAqL31cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZWFkaW5nLWhlcm8gcmVsYXRpdmUgei0xMCBmbGV4LXNocmluay0wIG14LVswLjEyZW1dIG1yLVswLjVlbV1cIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQpJyB9fT5cbiAgICAgICAgICAgIDxTcGxpdExldHRlcnMgdGV4dD1cIiZcIiBzdGFydEluZGV4PXs1OH0gLz5cbiAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICB7Lyog4pSA4pSAIFdFQkZMT1cgRVhQRVJULiB3aXRoIHZpbmUg4pSA4pSAICovfVxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWJhc2VsaW5lIHZpbmUtd3JhcCBmbGV4LXNocmluay0wIG14LVswLjEyZW1dXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoZWFkaW5nLWhlcm8gcmVsYXRpdmUgei0xMFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tdGV4dCknIH19PlxuICAgICAgICAgICAgICA8U3BsaXRMZXR0ZXJzIHRleHQ9XCJCQUNLRU5EIEVYUEVSVC5cIiBzdGFydEluZGV4PXs1OX0gLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxXZWJmbG93VmluZSAvPlxuICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgIHsvKiBUcmFpbGluZyB2aWV3cG9ydCBwYWRkaW5nICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCB3LVs4MHZ3XVwiIC8+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L1dvcmsvU2FzdWR1bC9zYXNhL3Nhc3VuZHVsLXBvcnRmb2xpby9jb21wb25lbnRzL0hvcml6b250YWxTY3JvbGwudHN4In0=