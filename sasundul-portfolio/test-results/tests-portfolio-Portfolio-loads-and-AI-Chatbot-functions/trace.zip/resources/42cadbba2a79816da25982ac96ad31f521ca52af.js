import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Footer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useRef = __vite__cjsImport1_react["useRef"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { ScrollTrigger } from "/node_modules/.vite/deps/gsap_ScrollTrigger.js?v=5088fc54";
gsap.registerPlugin(ScrollTrigger);
const WhatsApp = ({ size = 20 }) => /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 16 16", fill: "currentColor", width: size, height: size, children: /* @__PURE__ */ jsxDEV("path", { d: "M13.601 2.326A7.85 7.85 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.9 7.9 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.9 7.9 0 0 0 13.6 2.326zM7.994 14.521a6.6 6.6 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.56 6.56 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592m3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.73.73 0 0 0-.529.247c-.182.198-.691.677-.691 1.654s.71 1.916.81 2.049c.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232" }, void 0, false, {
  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
  lineNumber: 11,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
  lineNumber: 10,
  columnNumber: 1
}, this);
_c = WhatsApp;
export default function Footer({ onContactClick }) {
  _s();
  const footerRef = useRef(null);
  useGSAP(() => {
    gsap.fromTo(".footer-reveal", {
      y: 50,
      opacity: 0
    }, {
      y: 0,
      opacity: 1,
      stagger: 0.1,
      duration: 1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: footerRef.current,
        start: "top 80%"
      }
    });
  }, { scope: footerRef });
  return /* @__PURE__ */ jsxDEV("footer", { ref: footerRef, id: "contact", className: "relative overflow-hidden", style: { background: "var(--footer-bg)", color: "var(--footer-text)" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "py-32 md:py-48 px-6 md:px-12 text-center", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "footer-reveal text-5xl md:text-7xl lg:text-8xl font-display font-bold tracking-tighter leading-none", children: "Let's Work Together" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-12" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
        lineNumber: 47,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onContactClick,
          className: "footer-reveal btn-animated inline-flex items-center h-12 gap-0 border rounded-full overflow-hidden group",
          style: { borderColor: "rgba(255,255,255,0.2)" },
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "btn-animated__text-wrap px-8", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "btn-animated__text text-sm font-mono uppercase tracking-widest text-white", children: "Contact" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
                lineNumber: 56,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "btn-animated__text btn-animated__text--duplicate text-sm font-mono uppercase tracking-widest text-white", children: "Contact" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
                lineNumber: 57,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
              lineNumber: 55,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-full border-l flex items-center justify-center overflow-hidden", style: { borderColor: "rgba(255,255,255,0.2)" }, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "btn-animated__arrow-bg" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
                lineNumber: 60,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", className: "relative z-10 text-white transition-transform duration-500 group-hover:rotate-45", children: /* @__PURE__ */ jsxDEV("path", { d: "M7 17L17 7M17 7H7M17 7V17", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
                lineNumber: 62,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
                lineNumber: 61,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
              lineNumber: 59,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 50,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "h-12" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "footer-reveal flex gap-8 justify-center text-sm font-mono uppercase tracking-widest", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => document.getElementById("hero")?.scrollIntoView({ behavior: "smooth" }), className: "footer-link text-white/60 hover:text-white transition-colors", children: "Home" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 71,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => document.getElementById("work")?.scrollIntoView({ behavior: "smooth" }), className: "footer-link text-white/60 hover:text-white transition-colors", children: "Work" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 72,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: onContactClick, className: "footer-link text-white/60 hover:text-white transition-colors", children: "Contact" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 73,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t px-6 md:px-12 py-6 flex flex-col md:flex-row justify-between items-center gap-4", style: { borderColor: "rgba(255,255,255,0.1)" }, children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-white/40 uppercase", children: [
        (/* @__PURE__ */ new Date()).getFullYear(),
        " © Edition"
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
        lineNumber: 79,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 md:pr-36 items-center", children: [
        /* @__PURE__ */ jsxDEV("a", { href: "https://www.linkedin.com/in/sasundul/", target: "_blank", rel: "noopener noreferrer", className: "footer-link text-xs font-mono uppercase tracking-widest text-white/60 hover:text-white transition-colors", children: "LinkedIn" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 81,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "https://github.com/Sasudul", target: "_blank", rel: "noopener noreferrer", className: "footer-link text-xs font-mono uppercase tracking-widest text-white/60 hover:text-white transition-colors", children: "GitHub" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 82,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "https://wa.me/+94740629020", target: "_blank", rel: "noopener noreferrer", className: "footer-link text-xs font-mono uppercase tracking-widest text-white/60 hover:text-white transition-colors", children: "WhatsApp" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 83,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
        lineNumber: 80,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t overflow-hidden py-3", style: { borderColor: "rgba(255,255,255,0.05)" }, children: /* @__PURE__ */ jsxDEV("div", { className: "marquee__inner", style: { "--marquee-duration": "25s" }, children: [...Array(8)].map(
      (_, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 px-4 flex-shrink-0", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono uppercase tracking-widest text-white/30 whitespace-nowrap", children: "Code by Sasundul" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 92,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("svg", { width: "12", height: "10", viewBox: "0 0 125 95", fill: "none", className: "text-white/20", children: [
          /* @__PURE__ */ jsxDEV("path", { d: "M73.6748 89.7824L116.207 47.2501L73.6748 4.71783", stroke: "currentColor", strokeWidth: "12", strokeMiterlimit: "10" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
            lineNumber: 94,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("path", { d: "M116.207 47.25L0.762451 47.25", stroke: "currentColor", strokeWidth: "12", strokeMiterlimit: "10" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
            lineNumber: 95,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
          lineNumber: 93,
          columnNumber: 15
        }, this)
      ] }, i, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
        lineNumber: 91,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
}
_s(Footer, "JmXaYCaYVeGq8Dul4Rg6pFZdJjw=", false, function() {
  return [useGSAP];
});
_c2 = Footer;
var _c, _c2;
$RefreshReg$(_c, "WhatsApp");
$RefreshReg$(_c2, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Footer.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUk7O0FBVkosU0FBU0EsY0FBYztBQUN2QixTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLFVBQVU7QUFDakIsU0FBU0MscUJBQXFCO0FBRzlCRCxLQUFLRSxlQUFlRCxhQUFhO0FBRWpDLE1BQU1FLFdBQVdBLENBQUMsRUFBRUMsT0FBTyxHQUFzQixNQUMvQyx1QkFBQyxTQUFJLE9BQU0sOEJBQTZCLFNBQVEsYUFBWSxNQUFLLGdCQUFlLE9BQU9BLE1BQU0sUUFBUUEsTUFDbkcsaUNBQUMsVUFBSyxHQUFFLHVoQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQTJoQyxLQUQ3aEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBO0FBQ0FDLEtBSklGO0FBVU4sd0JBQXdCRyxPQUFPLEVBQUVDLGVBQTRCLEdBQUc7QUFBQUMsS0FBQTtBQUM5RCxRQUFNQyxZQUFZWCxPQUFvQixJQUFJO0FBRTFDQyxVQUFRLE1BQU07QUFDWkMsU0FBS1UsT0FBTyxrQkFBa0I7QUFBQSxNQUM1QkMsR0FBRztBQUFBLE1BQ0hDLFNBQVM7QUFBQSxJQUNYLEdBQUc7QUFBQSxNQUNERCxHQUFHO0FBQUEsTUFDSEMsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLE1BQ05DLGVBQWU7QUFBQSxRQUNiQyxTQUFTUixVQUFVUztBQUFBQSxRQUNuQkMsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsRUFBRUMsT0FBT1gsVUFBVSxDQUFDO0FBRXZCLFNBQ0UsdUJBQUMsWUFBTyxLQUFLQSxXQUFXLElBQUcsV0FBVSxXQUFVLDRCQUEyQixPQUFPLEVBQUVZLFlBQVksb0JBQW9CQyxPQUFPLHFCQUFxQixHQUU3STtBQUFBLDJCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx1R0FBc0csbUNBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLFVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQjtBQUFBLE1BR3JCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTZjtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUNWLE9BQU8sRUFBRWdCLGFBQWEsd0JBQXdCO0FBQUEsVUFFOUM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsNkVBQTRFLHVCQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRztBQUFBLGNBQ25HLHVCQUFDLFVBQUssV0FBVSwyR0FBMEcsdUJBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlJO0FBQUEsaUJBRm5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxrRkFBaUYsT0FBTyxFQUFFQSxhQUFhLHdCQUF3QixHQUM1STtBQUFBLHFDQUFDLFNBQUksV0FBVSw0QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQ3ZDLHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGFBQVksTUFBSyxRQUFPLFdBQVUsb0ZBQ3BFLGlDQUFDLFVBQUssR0FBRSw2QkFBNEIsUUFBTyxnQkFBZSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFdBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNILEtBRHhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUE7QUFBQTtBQUFBLFFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxVQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUI7QUFBQSxNQUdyQix1QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTUMsU0FBU0MsZUFBZSxNQUFNLEdBQUdDLGVBQWUsRUFBRUMsVUFBVSxTQUFTLENBQUMsR0FBRyxXQUFVLGdFQUErRCxvQkFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2SztBQUFBLFFBQzdLLHVCQUFDLFlBQU8sU0FBUyxNQUFNSCxTQUFTQyxlQUFlLE1BQU0sR0FBR0MsZUFBZSxFQUFFQyxVQUFVLFNBQVMsQ0FBQyxHQUFHLFdBQVUsZ0VBQStELG9CQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZLO0FBQUEsUUFDN0ssdUJBQUMsWUFBTyxTQUFTcEIsZ0JBQWdCLFdBQVUsZ0VBQStELHVCQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlIO0FBQUEsV0FIbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDRGQUEyRixPQUFPLEVBQUVnQixhQUFhLHdCQUF3QixHQUN0SjtBQUFBLDZCQUFDLFVBQUssV0FBVSw2Q0FBNkM7QUFBQSw2QkFBSUssS0FBSyxHQUFFQyxZQUFZO0FBQUEsUUFBRTtBQUFBLFdBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0c7QUFBQSxNQUNoRyx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSwrQkFBQyxPQUFFLE1BQUsseUNBQXdDLFFBQU8sVUFBUyxLQUFJLHVCQUFzQixXQUFVLDRHQUEyRyx3QkFBL007QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1TjtBQUFBLFFBQ3ZOLHVCQUFDLE9BQUUsTUFBSyw4QkFBNkIsUUFBTyxVQUFTLEtBQUksdUJBQXNCLFdBQVUsNEdBQTJHLHNCQUFwTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBNO0FBQUEsUUFDMU0sdUJBQUMsT0FBRSxNQUFLLDhCQUE2QixRQUFPLFVBQVMsS0FBSSx1QkFBc0IsV0FBVSw0R0FBMkcsd0JBQXBNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNE07QUFBQSxXQUg5TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxPQUFPLEVBQUVOLGFBQWEseUJBQXlCLEdBQzVGLGlDQUFDLFNBQUksV0FBVSxrQkFBaUIsT0FBTyxFQUFFLHNCQUFzQixNQUFNLEdBQ2xFLFdBQUMsR0FBR08sTUFBTSxDQUFDLENBQUMsRUFBRUM7QUFBQUEsTUFBSSxDQUFDQyxHQUFHQyxNQUNyQix1QkFBQyxTQUFZLFdBQVUsOENBQ3JCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLCtFQUE4RSxnQ0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RztBQUFBLFFBQzlHLHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGNBQWEsTUFBSyxRQUFPLFdBQVUsaUJBQ3JFO0FBQUEsaUNBQUMsVUFBSyxHQUFFLG9EQUFtRCxRQUFPLGdCQUFlLGFBQVksTUFBSyxrQkFBaUIsUUFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUg7QUFBQSxVQUN2SCx1QkFBQyxVQUFLLEdBQUUsaUNBQWdDLFFBQU8sZ0JBQWUsYUFBWSxNQUFLLGtCQUFpQixRQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLGFBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTFFBLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsSUFDRCxLQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLE9BNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2REE7QUFFSjtBQUFDekIsR0FwRnVCRixRQUFNO0FBQUEsVUFHNUJQLE9BQU87QUFBQTtBQUFBbUMsTUFIZTVCO0FBQU0sSUFBQUQsSUFBQTZCO0FBQUFDLGFBQUE5QixJQUFBO0FBQUE4QixhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlUmVmIiwidXNlR1NBUCIsImdzYXAiLCJTY3JvbGxUcmlnZ2VyIiwicmVnaXN0ZXJQbHVnaW4iLCJXaGF0c0FwcCIsInNpemUiLCJfYyIsIkZvb3RlciIsIm9uQ29udGFjdENsaWNrIiwiX3MiLCJmb290ZXJSZWYiLCJmcm9tVG8iLCJ5Iiwib3BhY2l0eSIsInN0YWdnZXIiLCJkdXJhdGlvbiIsImVhc2UiLCJzY3JvbGxUcmlnZ2VyIiwidHJpZ2dlciIsImN1cnJlbnQiLCJzdGFydCIsInNjb3BlIiwiYmFja2dyb3VuZCIsImNvbG9yIiwiYm9yZGVyQ29sb3IiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsIkRhdGUiLCJnZXRGdWxsWWVhciIsIkFycmF5IiwibWFwIiwiXyIsImkiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRm9vdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZUdTQVAgfSBmcm9tICdAZ3NhcC9yZWFjdCc7XHJcbmltcG9ydCBnc2FwIGZyb20gJ2dzYXAnO1xyXG5pbXBvcnQgeyBTY3JvbGxUcmlnZ2VyIH0gZnJvbSAnZ3NhcC9TY3JvbGxUcmlnZ2VyJztcclxuaW1wb3J0IHsgR2l0aHViLCBMaW5rZWRpbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcblxyXG5nc2FwLnJlZ2lzdGVyUGx1Z2luKFNjcm9sbFRyaWdnZXIpO1xyXG5cclxuY29uc3QgV2hhdHNBcHAgPSAoeyBzaXplID0gMjAgfTogeyBzaXplPzogbnVtYmVyIH0pID0+IChcclxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDE2IDE2XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIHdpZHRoPXtzaXplfSBoZWlnaHQ9e3NpemV9PlxyXG4gICAgPHBhdGggZD1cIk0xMy42MDEgMi4zMjZBNy44NSA3Ljg1IDAgMCAwIDcuOTk0IDBDMy42MjcgMCAuMDY4IDMuNTU4LjA2NCA3LjkyNmMwIDEuMzk5LjM2NiAyLjc2IDEuMDU3IDMuOTY1TDAgMTZsNC4yMDQtMS4xMDJhNy45IDcuOSAwIDAgMCAzLjc5Ljk2NWguMDA0YzQuMzY4IDAgNy45MjYtMy41NTggNy45My03LjkzQTcuOSA3LjkgMCAwIDAgMTMuNiAyLjMyNnpNNy45OTQgMTQuNTIxYTYuNiA2LjYgMCAwIDEtMy4zNTYtLjkybC0uMjQtLjE0NC0yLjQ5NC42NTQuNjY2LTIuNDMzLS4xNTYtLjI1MWE2LjU2IDYuNTYgMCAwIDEtMS4wMDctMy41MDVjMC0zLjYyNiAyLjk1Ny02LjU4NCA2LjU5MS02LjU4NGE2LjU2IDYuNTYgMCAwIDEgNC42NiAxLjkzMSA2LjU2IDYuNTYgMCAwIDEgMS45MjggNC42NmMtLjAwNCAzLjYzOS0yLjk2MSA2LjU5Mi02LjU5MiA2LjU5Mm0zLjYxNS00LjkzNGMtLjE5Ny0uMDk5LTEuMTctLjU3OC0xLjM1My0uNjQ2LS4xODItLjA2NS0uMzE1LS4wOTktLjQ0NS4wOTktLjEzMy4xOTctLjUxMy42NDYtLjYyNy43NzUtLjExNC4xMzMtLjIzMi4xNDgtLjQzLjA1LS4xOTctLjEtLjgzNi0uMzA4LTEuNTkyLS45ODUtLjU5LS41MjUtLjk4NS0xLjE3NS0xLjEwMy0xLjM3Mi0uMTE0LS4xOTgtLjAxMS0uMzA0LjA4OC0uNDAzLjA4Ny0uMDg4LjE5Ny0uMjMyLjI5Ni0uMzQ2LjEtLjExNC4xMzMtLjE5OC4xOTgtLjMzLjA2NS0uMTM0LjAzNC0uMjQ4LS4wMTUtLjM0Ny0uMDUtLjA5OS0uNDQ1LTEuMDc2LS42MTItMS40Ny0uMTYtLjM4OS0uMzIzLS4zMzUtLjQ0NS0uMzQtLjExNC0uMDA3LS4yNDctLjAwNy0uMzgtLjAwN2EuNzMuNzMgMCAwIDAtLjUyOS4yNDdjLS4xODIuMTk4LS42OTEuNjc3LS42OTEgMS42NTRzLjcxIDEuOTE2LjgxIDIuMDQ5Yy4wOTguMTMzIDEuMzk0IDIuMTMyIDMuMzgzIDIuOTkyLjQ3LjIwNS44NC4zMjYgMS4xMjkuNDE4LjQ3NS4xNTIuOTA0LjEyOSAxLjI0Ni4wOC4zOC0uMDU4IDEuMTcxLS40OCAxLjMzOC0uOTQzLjE2NC0uNDY0LjE2NC0uODYuMTE0LS45NDMtLjA0OS0uMDg0LS4xODItLjEzMy0uMzgtLjIzMlwiLz5cclxuICA8L3N2Zz5cclxuKTtcclxuXHJcbmludGVyZmFjZSBGb290ZXJQcm9wcyB7XHJcbiAgb25Db250YWN0Q2xpY2s6ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvb3Rlcih7IG9uQ29udGFjdENsaWNrIH06IEZvb3RlclByb3BzKSB7XHJcbiAgY29uc3QgZm9vdGVyUmVmID0gdXNlUmVmPEhUTUxFbGVtZW50PihudWxsKTtcclxuXHJcbiAgdXNlR1NBUCgoKSA9PiB7XHJcbiAgICBnc2FwLmZyb21UbygnLmZvb3Rlci1yZXZlYWwnLCB7XHJcbiAgICAgIHk6IDUwLFxyXG4gICAgICBvcGFjaXR5OiAwLFxyXG4gICAgfSwge1xyXG4gICAgICB5OiAwLFxyXG4gICAgICBvcGFjaXR5OiAxLFxyXG4gICAgICBzdGFnZ2VyOiAwLjEsXHJcbiAgICAgIGR1cmF0aW9uOiAxLFxyXG4gICAgICBlYXNlOiAncG93ZXIzLm91dCcsXHJcbiAgICAgIHNjcm9sbFRyaWdnZXI6IHtcclxuICAgICAgICB0cmlnZ2VyOiBmb290ZXJSZWYuY3VycmVudCxcclxuICAgICAgICBzdGFydDogJ3RvcCA4MCUnLFxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9LCB7IHNjb3BlOiBmb290ZXJSZWYgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9vdGVyIHJlZj17Zm9vdGVyUmVmfSBpZD1cImNvbnRhY3RcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAndmFyKC0tZm9vdGVyLWJnKScsIGNvbG9yOiAndmFyKC0tZm9vdGVyLXRleHQpJyB9fT5cclxuICAgICAgey8qIE1haW4gQ1RBICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTMyIG1kOnB5LTQ4IHB4LTYgbWQ6cHgtMTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9vdGVyLXJldmVhbCB0ZXh0LTV4bCBtZDp0ZXh0LTd4bCBsZzp0ZXh0LTh4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0ZXIgbGVhZGluZy1ub25lXCI+XHJcbiAgICAgICAgICBMZXQncyBXb3JrIFRvZ2V0aGVyXHJcbiAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTEyXCIgLz5cclxuXHJcbiAgICAgICAgey8qIEFuaW1hdGVkIENvbnRhY3QgQnV0dG9uICovfVxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9e29uQ29udGFjdENsaWNrfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZm9vdGVyLXJldmVhbCBidG4tYW5pbWF0ZWQgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGgtMTIgZ2FwLTAgYm9yZGVyIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIlxyXG4gICAgICAgICAgc3R5bGU9e3sgYm9yZGVyQ29sb3I6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuMiknIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidG4tYW5pbWF0ZWRfX3RleHQtd3JhcCBweC04XCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJ0bi1hbmltYXRlZF9fdGV4dCB0ZXh0LXNtIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtd2hpdGVcIj5Db250YWN0PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJidG4tYW5pbWF0ZWRfX3RleHQgYnRuLWFuaW1hdGVkX190ZXh0LS1kdXBsaWNhdGUgdGV4dC1zbSBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXdoaXRlXCI+Q29udGFjdDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTEyIGgtZnVsbCBib3JkZXItbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW5cIiBzdHlsZT17eyBib3JkZXJDb2xvcjogJ3JnYmEoMjU1LDI1NSwyNTUsMC4yKScgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnRuLWFuaW1hdGVkX19hcnJvdy1iZ1wiIC8+XHJcbiAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIxNlwiIGhlaWdodD1cIjE2XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCB0ZXh0LXdoaXRlIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMCBncm91cC1ob3Zlcjpyb3RhdGUtNDVcIj5cclxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTcgMTdMMTcgN00xNyA3SDdNMTcgN1YxN1wiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiAvPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTJcIiAvPlxyXG5cclxuICAgICAgICB7LyogRm9vdGVyIG5hdiBsaW5rcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1yZXZlYWwgZmxleCBnYXAtOCBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNtIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCI+XHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdoZXJvJyk/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pfSBjbGFzc05hbWU9XCJmb290ZXItbGluayB0ZXh0LXdoaXRlLzYwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIj5Ib21lPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd3b3JrJyk/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pfSBjbGFzc05hbWU9XCJmb290ZXItbGluayB0ZXh0LXdoaXRlLzYwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIj5Xb3JrPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ29udGFjdENsaWNrfSBjbGFzc05hbWU9XCJmb290ZXItbGluayB0ZXh0LXdoaXRlLzYwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIj5Db250YWN0PC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEJvdHRvbSBiYXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgcHgtNiBtZDpweC0xMiBweS02IGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBnYXAtNFwiIHN0eWxlPXt7IGJvcmRlckNvbG9yOiAncmdiYSgyNTUsMjU1LDI1NSwwLjEpJyB9fT5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXdoaXRlLzQwIHVwcGVyY2FzZVwiPntuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9IMKpIEVkaXRpb248L3NwYW4+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC02IG1kOnByLTM2IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vd3d3LmxpbmtlZGluLmNvbS9pbi9zYXN1bmR1bC9cIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgY2xhc3NOYW1lPVwiZm9vdGVyLWxpbmsgdGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXdoaXRlLzYwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIj5MaW5rZWRJbjwvYT5cclxuICAgICAgICAgIDxhIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vU2FzdWR1bFwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJmb290ZXItbGluayB0ZXh0LXhzIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtd2hpdGUvNjAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiPkdpdEh1YjwvYT5cclxuICAgICAgICAgIDxhIGhyZWY9XCJodHRwczovL3dhLm1lLys5NDc0MDYyOTAyMFwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJmb290ZXItbGluayB0ZXh0LXhzIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtd2hpdGUvNjAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiPldoYXRzQXBwPC9hPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBJbmZpbml0ZSBtYXJxdWVlICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IG92ZXJmbG93LWhpZGRlbiBweS0zXCIgc3R5bGU9e3sgYm9yZGVyQ29sb3I6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpJyB9fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcnF1ZWVfX2lubmVyXCIgc3R5bGU9e3sgJy0tbWFycXVlZS1kdXJhdGlvbic6ICcyNXMnIH0gYXMgYW55fT5cclxuICAgICAgICAgIHtbLi4uQXJyYXkoOCldLm1hcCgoXywgaSkgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgcHgtNCBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXdoaXRlLzMwIHdoaXRlc3BhY2Utbm93cmFwXCI+Q29kZSBieSBTYXN1bmR1bDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMTJcIiBoZWlnaHQ9XCIxMFwiIHZpZXdCb3g9XCIwIDAgMTI1IDk1XCIgZmlsbD1cIm5vbmVcIiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzIwXCI+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTczLjY3NDggODkuNzgyNEwxMTYuMjA3IDQ3LjI1MDFMNzMuNjc0OCA0LjcxNzgzXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIxMlwiIHN0cm9rZU1pdGVybGltaXQ9XCIxMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTExNi4yMDcgNDcuMjVMMC43NjI0NTEgNDcuMjVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjEyXCIgc3Ryb2tlTWl0ZXJsaW1pdD1cIjEwXCIgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Zvb3Rlcj5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiRDovV29yay9TYXN1ZHVsL3Nhc2Evc2FzdW5kdWwtcG9ydGZvbGlvL2NvbXBvbmVudHMvRm9vdGVyLnRzeCJ9