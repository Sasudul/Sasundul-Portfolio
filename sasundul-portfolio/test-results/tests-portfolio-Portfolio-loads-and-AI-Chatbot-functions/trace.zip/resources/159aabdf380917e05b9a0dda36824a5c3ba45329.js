import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Preloader.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import "/components/Preloader.css";
const COUNTER_DURATION = 4.5;
const IMAGE_STEP_FREQUENCY = 3;
const IMAGES = [
  "/Zerin.png",
  "/Vap-Construction.png",
  "/FloodNav.png",
  "/LandSlideAlert.png",
  "/FleetTracking.png",
  "/LunarwayTravels.png",
  "/E-Channeling-System.png",
  "/Pizza-Mania.png",
  "/NatoMiniMart.png",
  "/Lumina.png",
  "/Art-Gallery-01.jpeg"
];
const NAME = "CODE BY SASUNDUL®";
export default function Preloader({ onComplete }) {
  _s();
  const wrapperRef = useRef(null);
  const topImgRef = useRef(null);
  const bottomImgRef = useRef(null);
  const activeImgRef = useRef(0);
  const [isComplete, setIsComplete] = useState(false);
  useEffect(() => {
    IMAGES.forEach((src) => {
      const img = new Image();
      img.src = src;
    });
  }, []);
  const renderContent = (isTop) => /* @__PURE__ */ jsxDEV("div", { className: "preloader-content", children: [
    /* @__PURE__ */ jsxDEV("div", { className: `preloader-images preloader-images-${isTop ? "top" : "bottom"}`, children: /* @__PURE__ */ jsxDEV(
      "img",
      {
        ref: isTop ? topImgRef : bottomImgRef,
        src: IMAGES[0],
        className: "preloader-img",
        alt: ""
      },
      void 0,
      false,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
        lineNumber: 55,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `preloader-name-container preloader-name-${isTop ? "top" : "bottom"}`, children: NAME.split("").map(
      (char, i) => /* @__PURE__ */ jsxDEV("span", { className: "preloader-char-wrap", children: /* @__PURE__ */ jsxDEV("span", { className: `preloader-char preloader-char-anim ${char === "®" ? "preloader-char-reg" : ""}`, children: char === " " ? " " : char }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
        lineNumber: 67,
        columnNumber: 13
      }, this) }, i, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
        lineNumber: 66,
        columnNumber: 7
      }, this)
    ) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `preloader-counter preloader-counter-${isTop ? "top" : "bottom"}`, children: "00" }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
      lineNumber: 75,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
    lineNumber: 52,
    columnNumber: 3
  }, this);
  useGSAP(() => {
    if (!wrapperRef.current) return;
    const tl = gsap.timeline({
      onComplete: () => {
        setIsComplete(true);
        onComplete();
      }
    });
    const topCounter = wrapperRef.current.querySelector(".preloader-counter-top");
    const bottomCounter = wrapperRef.current.querySelector(".preloader-counter-bottom");
    const counterObj = { val: 0 };
    let lastVal = -1;
    tl.to(counterObj, {
      val: 100,
      duration: COUNTER_DURATION,
      ease: "power1.inOut",
      onUpdate: () => {
        const currentVal = Math.floor(counterObj.val);
        if (currentVal !== lastVal) {
          lastVal = currentVal;
          const formattedVal = currentVal < 10 ? `0${currentVal}` : currentVal.toString();
          if (topCounter) topCounter.innerHTML = formattedVal;
          if (bottomCounter) bottomCounter.innerHTML = formattedVal;
          const stepIndex = Math.floor(currentVal / IMAGE_STEP_FREQUENCY);
          const nextImgIdx = stepIndex % IMAGES.length;
          if (nextImgIdx !== activeImgRef.current) {
            activeImgRef.current = nextImgIdx;
            const newSrc = IMAGES[nextImgIdx];
            if (topImgRef.current) topImgRef.current.src = newSrc;
            if (bottomImgRef.current) bottomImgRef.current.src = newSrc;
          }
        }
      }
    }, 0);
    tl.to(".preloader-images", {
      scale: 0.8,
      opacity: 0,
      duration: 0.6,
      ease: "power2.inOut"
    }, ">");
    tl.to(".preloader-counter", {
      opacity: 0,
      duration: 0.5,
      ease: "power2.out"
    }, "<");
    const topChars = gsap.utils.toArray(".preloader-name-top .preloader-char-anim");
    const bottomChars = gsap.utils.toArray(".preloader-name-bottom .preloader-char-anim");
    tl.to(topChars, {
      y: "0%",
      duration: 0.7,
      stagger: 0.035,
      ease: "expo.out"
    }, "+=0.05");
    tl.to(bottomChars, {
      y: "0%",
      duration: 0.7,
      stagger: 0.035,
      ease: "expo.out"
    }, "<");
    tl.to({}, { duration: 0.5 });
    tl.to(".preloader-top", {
      yPercent: -100,
      duration: 1.1,
      ease: "expo.inOut"
    });
    tl.to(".preloader-bottom", {
      yPercent: 100,
      duration: 1.1,
      ease: "expo.inOut"
    }, "<");
  }, { scope: wrapperRef });
  if (isComplete) return null;
  return /* @__PURE__ */ jsxDEV("div", { ref: wrapperRef, className: "preloader-wrapper", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "preloader-half preloader-top", children: renderContent(true) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
      lineNumber: 180,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "preloader-half preloader-bottom", children: renderContent(false) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
      lineNumber: 184,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx",
    lineNumber: 178,
    columnNumber: 5
  }, this);
}
_s(Preloader, "/309x5v96f5B+faxssbsaOCMcFU=", false, function() {
  return [useGSAP];
});
_c = Preloader;
var _c;
$RefreshReg$(_c, "Preloader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/Preloader.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RROztBQXREUixTQUFTQSxRQUFRQyxVQUFVQyxpQkFBaUI7QUFDNUMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU87QUFPUCxNQUFNQyxtQkFBbUI7QUFNekIsTUFBTUMsdUJBQXVCO0FBRTdCLE1BQU1DLFNBQVM7QUFBQSxFQUNiO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFzQjtBQUd4QixNQUFNQyxPQUFPO0FBRWIsd0JBQXdCQyxVQUFVLEVBQUVDLFdBQXVDLEdBQUc7QUFBQUMsS0FBQTtBQUM1RSxRQUFNQyxhQUFhWixPQUF1QixJQUFJO0FBQzlDLFFBQU1hLFlBQVliLE9BQXlCLElBQUk7QUFDL0MsUUFBTWMsZUFBZWQsT0FBeUIsSUFBSTtBQUNsRCxRQUFNZSxlQUFlZixPQUFPLENBQUM7QUFDN0IsUUFBTSxDQUFDZ0IsWUFBWUMsYUFBYSxJQUFJaEIsU0FBUyxLQUFLO0FBR2xEQyxZQUFVLE1BQU07QUFDZEssV0FBT1csUUFBUSxDQUFBQyxRQUFPO0FBQ3BCLFlBQU1DLE1BQU0sSUFBSUMsTUFBTTtBQUN0QkQsVUFBSUQsTUFBTUE7QUFBQUEsSUFDWixDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUU7QUFHTCxRQUFNRyxnQkFBZ0JBLENBQUNDLFVBQ3JCLHVCQUFDLFNBQUksV0FBVSxxQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVyxxQ0FBcUNBLFFBQVEsUUFBUSxRQUFRLElBQzNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxLQUFLQSxRQUFRVixZQUFZQztBQUFBQSxRQUN6QixLQUFLUCxPQUFPLENBQUM7QUFBQSxRQUNiLFdBQVU7QUFBQSxRQUNWLEtBQUk7QUFBQTtBQUFBLE1BSk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSVEsS0FMVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVywyQ0FBMkNnQixRQUFRLFFBQVEsUUFBUSxJQUNoRmYsZUFBS2dCLE1BQU0sRUFBRSxFQUFFQztBQUFBQSxNQUFJLENBQUNDLE1BQU1DLE1BQ3pCLHVCQUFDLFVBQWEsV0FBVSx1QkFDdEIsaUNBQUMsVUFBSyxXQUFXLHNDQUFzQ0QsU0FBUyxNQUFNLHVCQUF1QixFQUFFLElBQzVGQSxtQkFBUyxNQUFNLE1BQVdBLFFBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhTQyxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLElBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVyx1Q0FBdUNKLFFBQVEsUUFBUSxRQUFRLElBQUcsa0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFHRnBCLFVBQVEsTUFBTTtBQUNaLFFBQUksQ0FBQ1MsV0FBV2dCLFFBQVM7QUFFekIsVUFBTUMsS0FBS3pCLEtBQUswQixTQUFTO0FBQUEsTUFDdkJwQixZQUFZQSxNQUFNO0FBQ2hCTyxzQkFBYyxJQUFJO0FBQ2xCUCxtQkFBVztBQUFBLE1BQ2I7QUFBQSxJQUNGLENBQUM7QUFFRCxVQUFNcUIsYUFBYW5CLFdBQVdnQixRQUFRSSxjQUFjLHdCQUF3QjtBQUM1RSxVQUFNQyxnQkFBZ0JyQixXQUFXZ0IsUUFBUUksY0FBYywyQkFBMkI7QUFHbEYsVUFBTUUsYUFBYSxFQUFFQyxLQUFLLEVBQUU7QUFDNUIsUUFBSUMsVUFBVTtBQUVkUCxPQUFHUSxHQUFHSCxZQUFZO0FBQUEsTUFDaEJDLEtBQUs7QUFBQSxNQUNMRyxVQUFVakM7QUFBQUEsTUFDVmtDLE1BQU07QUFBQSxNQUNOQyxVQUFVQSxNQUFNO0FBQ2QsY0FBTUMsYUFBYUMsS0FBS0MsTUFBTVQsV0FBV0MsR0FBRztBQUM1QyxZQUFJTSxlQUFlTCxTQUFTO0FBQzFCQSxvQkFBVUs7QUFHVixnQkFBTUcsZUFBZUgsYUFBYSxLQUFLLElBQUlBLFVBQVUsS0FBS0EsV0FBV0ksU0FBUztBQUM5RSxjQUFJZCxXQUFZQSxZQUFXZSxZQUFZRjtBQUN2QyxjQUFJWCxjQUFlQSxlQUFjYSxZQUFZRjtBQUc3QyxnQkFBTUcsWUFBWUwsS0FBS0MsTUFBTUYsYUFBYW5DLG9CQUFvQjtBQUM5RCxnQkFBTTBDLGFBQWFELFlBQVl4QyxPQUFPMEM7QUFFdEMsY0FBSUQsZUFBZWpDLGFBQWFhLFNBQVM7QUFDdkNiLHlCQUFhYSxVQUFVb0I7QUFDdkIsa0JBQU1FLFNBQVMzQyxPQUFPeUMsVUFBVTtBQUNoQyxnQkFBSW5DLFVBQVVlLFFBQVNmLFdBQVVlLFFBQVFULE1BQU0rQjtBQUMvQyxnQkFBSXBDLGFBQWFjLFFBQVNkLGNBQWFjLFFBQVFULE1BQU0rQjtBQUFBQSxVQUN2RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixHQUFHLENBQUM7QUFHSnJCLE9BQUdRLEdBQUcscUJBQXFCO0FBQUEsTUFDekJjLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVGQsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxJQUNSLEdBQUcsR0FBRztBQUVOVixPQUFHUSxHQUFHLHNCQUFzQjtBQUFBLE1BQzFCZSxTQUFTO0FBQUEsTUFDVGQsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxJQUNSLEdBQUcsR0FBRztBQUdOLFVBQU1jLFdBQVdqRCxLQUFLa0QsTUFBTUMsUUFBUSwwQ0FBMEM7QUFDOUUsVUFBTUMsY0FBY3BELEtBQUtrRCxNQUFNQyxRQUFRLDZDQUE2QztBQUVwRjFCLE9BQUdRLEdBQUdnQixVQUFVO0FBQUEsTUFDZEksR0FBRztBQUFBLE1BQ0huQixVQUFVO0FBQUEsTUFDVm9CLFNBQVM7QUFBQSxNQUNUbkIsTUFBTTtBQUFBLElBQ1IsR0FBRyxRQUFRO0FBRVhWLE9BQUdRLEdBQUdtQixhQUFhO0FBQUEsTUFDakJDLEdBQUc7QUFBQSxNQUNIbkIsVUFBVTtBQUFBLE1BQ1ZvQixTQUFTO0FBQUEsTUFDVG5CLE1BQU07QUFBQSxJQUNSLEdBQUcsR0FBRztBQUdOVixPQUFHUSxHQUFHLENBQUMsR0FBRyxFQUFFQyxVQUFVLElBQUksQ0FBQztBQUczQlQsT0FBR1EsR0FBRyxrQkFBa0I7QUFBQSxNQUN0QnNCLFVBQVU7QUFBQSxNQUNWckIsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxJQUNSLENBQUM7QUFDRFYsT0FBR1EsR0FBRyxxQkFBcUI7QUFBQSxNQUN6QnNCLFVBQVU7QUFBQSxNQUNWckIsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxJQUNSLEdBQUcsR0FBRztBQUFBLEVBRVIsR0FBRyxFQUFFcUIsT0FBT2hELFdBQVcsQ0FBQztBQUV4QixNQUFJSSxXQUFZLFFBQU87QUFFdkIsU0FDRSx1QkFBQyxTQUFJLEtBQUtKLFlBQVksV0FBVSxxQkFFOUI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZ0NBQ1pVLHdCQUFjLElBQUksS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ1pBLHdCQUFjLEtBQUssS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFDWCxHQTFKdUJGLFdBQVM7QUFBQSxVQThDL0JOLE9BQU87QUFBQTtBQUFBMEQsS0E5Q2VwRDtBQUFTLElBQUFvRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUmVmIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VHU0FQIiwiZ3NhcCIsIkNPVU5URVJfRFVSQVRJT04iLCJJTUFHRV9TVEVQX0ZSRVFVRU5DWSIsIklNQUdFUyIsIk5BTUUiLCJQcmVsb2FkZXIiLCJvbkNvbXBsZXRlIiwiX3MiLCJ3cmFwcGVyUmVmIiwidG9wSW1nUmVmIiwiYm90dG9tSW1nUmVmIiwiYWN0aXZlSW1nUmVmIiwiaXNDb21wbGV0ZSIsInNldElzQ29tcGxldGUiLCJmb3JFYWNoIiwic3JjIiwiaW1nIiwiSW1hZ2UiLCJyZW5kZXJDb250ZW50IiwiaXNUb3AiLCJzcGxpdCIsIm1hcCIsImNoYXIiLCJpIiwiY3VycmVudCIsInRsIiwidGltZWxpbmUiLCJ0b3BDb3VudGVyIiwicXVlcnlTZWxlY3RvciIsImJvdHRvbUNvdW50ZXIiLCJjb3VudGVyT2JqIiwidmFsIiwibGFzdFZhbCIsInRvIiwiZHVyYXRpb24iLCJlYXNlIiwib25VcGRhdGUiLCJjdXJyZW50VmFsIiwiTWF0aCIsImZsb29yIiwiZm9ybWF0dGVkVmFsIiwidG9TdHJpbmciLCJpbm5lckhUTUwiLCJzdGVwSW5kZXgiLCJuZXh0SW1nSWR4IiwibGVuZ3RoIiwibmV3U3JjIiwic2NhbGUiLCJvcGFjaXR5IiwidG9wQ2hhcnMiLCJ1dGlscyIsInRvQXJyYXkiLCJib3R0b21DaGFycyIsInkiLCJzdGFnZ2VyIiwieVBlcmNlbnQiLCJzY29wZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByZWxvYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlR1NBUCB9IGZyb20gJ0Bnc2FwL3JlYWN0JztcbmltcG9ydCBnc2FwIGZyb20gJ2dzYXAnO1xuaW1wb3J0ICcuL1ByZWxvYWRlci5jc3MnO1xuXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gUFJFTE9BREVSIFNQRUVEICYgVElNSU5HIENPTlRST0xTIChBZGp1c3QgdGhlc2UgdmFsdWVzIHRvIGZpbmUtdHVuZSBwcmVsb2FkZXIgc3BlZWQpXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gMS4gQ09VTlRFUl9EVVJBVElPTjogVG90YWwgc2Vjb25kcyBmb3IgY291bnRlciB0byBjb3VudCBmcm9tIDAwIHRvIDEwMC5cbi8vICAgIC0gSW5jcmVhc2UgdG8gc2xvdyBkb3duIG92ZXJhbGwgcHJlbG9hZGVyIChlLmcuIDUuMCA9IHNsb3csIDQuMCA9IG1lZGl1bSwgMi41ID0gZmFzdClcbmNvbnN0IENPVU5URVJfRFVSQVRJT04gPSA0LjU7XG5cbi8vIDIuIElNQUdFX1NURVBfRlJFUVVFTkNZOiBIb3cgbWFueSBudW1iZXIgaW5jcmVtZW50cyBwYXNzIGJlZm9yZSBzd2l0Y2hpbmcgaW1hZ2VzLlxuLy8gICAgLSAxID0gc3dpdGNoIGltYWdlIG9uIEVWRVJZIG51bWJlciAoMCwgMSwgMiwgMy4uLikgW0Zhc3Rlc3RdXG4vLyAgICAtIDMgPSBzd2l0Y2ggaW1hZ2UgZXZlcnkgMyBudW1iZXJzICgwLCAzLCA2LCA5Li4uKSBbTWVkaXVtXVxuLy8gICAgLSA1ID0gc3dpdGNoIGltYWdlIGV2ZXJ5IDUgbnVtYmVycyAoMCwgNSwgMTAsIDE1Li4uKSBbUGFjZWRdXG5jb25zdCBJTUFHRV9TVEVQX0ZSRVFVRU5DWSA9IDM7XG5cbmNvbnN0IElNQUdFUyA9IFtcbiAgJy9aZXJpbi5wbmcnLFxuICAnL1ZhcC1Db25zdHJ1Y3Rpb24ucG5nJyxcbiAgJy9GbG9vZE5hdi5wbmcnLFxuICAnL0xhbmRTbGlkZUFsZXJ0LnBuZycsXG4gICcvRmxlZXRUcmFja2luZy5wbmcnLFxuICAnL0x1bmFyd2F5VHJhdmVscy5wbmcnLFxuICAnL0UtQ2hhbm5lbGluZy1TeXN0ZW0ucG5nJyxcbiAgJy9QaXp6YS1NYW5pYS5wbmcnLFxuICAnL05hdG9NaW5pTWFydC5wbmcnLFxuICAnL0x1bWluYS5wbmcnLFxuICAnL0FydC1HYWxsZXJ5LTAxLmpwZWcnLFxuXTtcblxuY29uc3QgTkFNRSA9IFwiQ09ERSBCWSBTQVNVTkRVTMKuXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByZWxvYWRlcih7IG9uQ29tcGxldGUgfTogeyBvbkNvbXBsZXRlOiAoKSA9PiB2b2lkIH0pIHtcbiAgY29uc3Qgd3JhcHBlclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG4gIGNvbnN0IHRvcEltZ1JlZiA9IHVzZVJlZjxIVE1MSW1hZ2VFbGVtZW50PihudWxsKTtcbiAgY29uc3QgYm90dG9tSW1nUmVmID0gdXNlUmVmPEhUTUxJbWFnZUVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBhY3RpdmVJbWdSZWYgPSB1c2VSZWYoMCk7XG4gIGNvbnN0IFtpc0NvbXBsZXRlLCBzZXRJc0NvbXBsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBQcmVsb2FkIGFsbCBpbWFnZXMgaW1tZWRpYXRlbHkgaW50byBicm93c2VyIGNhY2hlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgSU1BR0VTLmZvckVhY2goc3JjID0+IHtcbiAgICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgICAgaW1nLnNyYyA9IHNyYztcbiAgICB9KTtcbiAgfSwgW10pO1xuXG4gIC8vIFJlbmRlciBpZGVudGljYWwgdG9wL2JvdHRvbSBjb250ZW50IGZvciBnYXRld2F5IGNsaXAtcGF0aCBzcGxpdFxuICBjb25zdCByZW5kZXJDb250ZW50ID0gKGlzVG9wOiBib29sZWFuKSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcmVsb2FkZXItY29udGVudFwiPlxuICAgICAgey8qIEltYWdlcyBDb250YWluZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YHByZWxvYWRlci1pbWFnZXMgcHJlbG9hZGVyLWltYWdlcy0ke2lzVG9wID8gJ3RvcCcgOiAnYm90dG9tJ31gfT5cbiAgICAgICAgPGltZyBcbiAgICAgICAgICByZWY9e2lzVG9wID8gdG9wSW1nUmVmIDogYm90dG9tSW1nUmVmfSBcbiAgICAgICAgICBzcmM9e0lNQUdFU1swXX0gXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHJlbG9hZGVyLWltZ1wiIFxuICAgICAgICAgIGFsdD1cIlwiIFxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBOYW1lIFJldmVhbCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcHJlbG9hZGVyLW5hbWUtY29udGFpbmVyIHByZWxvYWRlci1uYW1lLSR7aXNUb3AgPyAndG9wJyA6ICdib3R0b20nfWB9PlxuICAgICAgICB7TkFNRS5zcGxpdCgnJykubWFwKChjaGFyLCBpKSA9PiAoXG4gICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJwcmVsb2FkZXItY2hhci13cmFwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BwcmVsb2FkZXItY2hhciBwcmVsb2FkZXItY2hhci1hbmltICR7Y2hhciA9PT0gJ8KuJyA/ICdwcmVsb2FkZXItY2hhci1yZWcnIDogJyd9YH0+XG4gICAgICAgICAgICAgIHtjaGFyID09PSAnICcgPyAnXFx1MDBBMCcgOiBjaGFyfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENvdW50ZXIgTnVtYmVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BwcmVsb2FkZXItY291bnRlciBwcmVsb2FkZXItY291bnRlci0ke2lzVG9wID8gJ3RvcCcgOiAnYm90dG9tJ31gfT5cbiAgICAgICAgMDBcbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xuXG4gIHVzZUdTQVAoKCkgPT4ge1xuICAgIGlmICghd3JhcHBlclJlZi5jdXJyZW50KSByZXR1cm47XG5cbiAgICBjb25zdCB0bCA9IGdzYXAudGltZWxpbmUoe1xuICAgICAgb25Db21wbGV0ZTogKCkgPT4ge1xuICAgICAgICBzZXRJc0NvbXBsZXRlKHRydWUpO1xuICAgICAgICBvbkNvbXBsZXRlKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBjb25zdCB0b3BDb3VudGVyID0gd3JhcHBlclJlZi5jdXJyZW50LnF1ZXJ5U2VsZWN0b3IoJy5wcmVsb2FkZXItY291bnRlci10b3AnKTtcbiAgICBjb25zdCBib3R0b21Db3VudGVyID0gd3JhcHBlclJlZi5jdXJyZW50LnF1ZXJ5U2VsZWN0b3IoJy5wcmVsb2FkZXItY291bnRlci1ib3R0b20nKTtcblxuICAgIC8vIENvdW50ZXIgT2JqZWN0OiAwIHRvIDEwMFxuICAgIGNvbnN0IGNvdW50ZXJPYmogPSB7IHZhbDogMCB9O1xuICAgIGxldCBsYXN0VmFsID0gLTE7XG5cbiAgICB0bC50byhjb3VudGVyT2JqLCB7XG4gICAgICB2YWw6IDEwMCxcbiAgICAgIGR1cmF0aW9uOiBDT1VOVEVSX0RVUkFUSU9OLFxuICAgICAgZWFzZTogXCJwb3dlcjEuaW5PdXRcIixcbiAgICAgIG9uVXBkYXRlOiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRWYWwgPSBNYXRoLmZsb29yKGNvdW50ZXJPYmoudmFsKTtcbiAgICAgICAgaWYgKGN1cnJlbnRWYWwgIT09IGxhc3RWYWwpIHtcbiAgICAgICAgICBsYXN0VmFsID0gY3VycmVudFZhbDtcbiAgICAgICAgICBcbiAgICAgICAgICAvLyBVcGRhdGUgQ291bnRlciBUZXh0ICgwMCB0byAxMDApXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkVmFsID0gY3VycmVudFZhbCA8IDEwID8gYDAke2N1cnJlbnRWYWx9YCA6IGN1cnJlbnRWYWwudG9TdHJpbmcoKTtcbiAgICAgICAgICBpZiAodG9wQ291bnRlcikgdG9wQ291bnRlci5pbm5lckhUTUwgPSBmb3JtYXR0ZWRWYWw7XG4gICAgICAgICAgaWYgKGJvdHRvbUNvdW50ZXIpIGJvdHRvbUNvdW50ZXIuaW5uZXJIVE1MID0gZm9ybWF0dGVkVmFsO1xuXG4gICAgICAgICAgLy8gSW1hZ2UgY2hhbmdlIGZyZXF1ZW5jeSBjYWxjdWxhdGlvbiBiYXNlZCBvbiBJTUFHRV9TVEVQX0ZSRVFVRU5DWVxuICAgICAgICAgIGNvbnN0IHN0ZXBJbmRleCA9IE1hdGguZmxvb3IoY3VycmVudFZhbCAvIElNQUdFX1NURVBfRlJFUVVFTkNZKTtcbiAgICAgICAgICBjb25zdCBuZXh0SW1nSWR4ID0gc3RlcEluZGV4ICUgSU1BR0VTLmxlbmd0aDtcblxuICAgICAgICAgIGlmIChuZXh0SW1nSWR4ICE9PSBhY3RpdmVJbWdSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgYWN0aXZlSW1nUmVmLmN1cnJlbnQgPSBuZXh0SW1nSWR4O1xuICAgICAgICAgICAgY29uc3QgbmV3U3JjID0gSU1BR0VTW25leHRJbWdJZHhdO1xuICAgICAgICAgICAgaWYgKHRvcEltZ1JlZi5jdXJyZW50KSB0b3BJbWdSZWYuY3VycmVudC5zcmMgPSBuZXdTcmM7XG4gICAgICAgICAgICBpZiAoYm90dG9tSW1nUmVmLmN1cnJlbnQpIGJvdHRvbUltZ1JlZi5jdXJyZW50LnNyYyA9IG5ld1NyYztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LCAwKTtcblxuICAgIC8vIC0tLSBQaGFzZSAyOiBDb2xsYXBzZSBDb3VudGVyICYgSW1hZ2VzIC0tLVxuICAgIHRsLnRvKCcucHJlbG9hZGVyLWltYWdlcycsIHtcbiAgICAgIHNjYWxlOiAwLjgsXG4gICAgICBvcGFjaXR5OiAwLFxuICAgICAgZHVyYXRpb246IDAuNixcbiAgICAgIGVhc2U6IFwicG93ZXIyLmluT3V0XCJcbiAgICB9LCBcIj5cIik7XG5cbiAgICB0bC50bygnLnByZWxvYWRlci1jb3VudGVyJywge1xuICAgICAgb3BhY2l0eTogMCxcbiAgICAgIGR1cmF0aW9uOiAwLjUsXG4gICAgICBlYXNlOiBcInBvd2VyMi5vdXRcIlxuICAgIH0sIFwiPFwiKTtcblxuICAgIC8vIC0tLSBQaGFzZSAzOiBOYW1lIFJldmVhbCAtLS1cbiAgICBjb25zdCB0b3BDaGFycyA9IGdzYXAudXRpbHMudG9BcnJheSgnLnByZWxvYWRlci1uYW1lLXRvcCAucHJlbG9hZGVyLWNoYXItYW5pbScpO1xuICAgIGNvbnN0IGJvdHRvbUNoYXJzID0gZ3NhcC51dGlscy50b0FycmF5KCcucHJlbG9hZGVyLW5hbWUtYm90dG9tIC5wcmVsb2FkZXItY2hhci1hbmltJyk7XG5cbiAgICB0bC50byh0b3BDaGFycywge1xuICAgICAgeTogJzAlJyxcbiAgICAgIGR1cmF0aW9uOiAwLjcsXG4gICAgICBzdGFnZ2VyOiAwLjAzNSxcbiAgICAgIGVhc2U6IFwiZXhwby5vdXRcIlxuICAgIH0sIFwiKz0wLjA1XCIpO1xuXG4gICAgdGwudG8oYm90dG9tQ2hhcnMsIHtcbiAgICAgIHk6ICcwJScsXG4gICAgICBkdXJhdGlvbjogMC43LFxuICAgICAgc3RhZ2dlcjogMC4wMzUsXG4gICAgICBlYXNlOiBcImV4cG8ub3V0XCJcbiAgICB9LCBcIjxcIik7XG5cbiAgICAvLyBIb2xkIGJyaWVmbHkgdG8gcmVhZCB0aGUgbmFtZVxuICAgIHRsLnRvKHt9LCB7IGR1cmF0aW9uOiAwLjUgfSk7XG5cbiAgICAvLyAtLS0gUGhhc2UgNDogR2F0ZXdheSBTcGxpdCAtLS1cbiAgICB0bC50bygnLnByZWxvYWRlci10b3AnLCB7XG4gICAgICB5UGVyY2VudDogLTEwMCxcbiAgICAgIGR1cmF0aW9uOiAxLjEsXG4gICAgICBlYXNlOiBcImV4cG8uaW5PdXRcIlxuICAgIH0pO1xuICAgIHRsLnRvKCcucHJlbG9hZGVyLWJvdHRvbScsIHtcbiAgICAgIHlQZXJjZW50OiAxMDAsXG4gICAgICBkdXJhdGlvbjogMS4xLFxuICAgICAgZWFzZTogXCJleHBvLmluT3V0XCJcbiAgICB9LCBcIjxcIik7XG5cbiAgfSwgeyBzY29wZTogd3JhcHBlclJlZiB9KTtcblxuICBpZiAoaXNDb21wbGV0ZSkgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHJlZj17d3JhcHBlclJlZn0gY2xhc3NOYW1lPVwicHJlbG9hZGVyLXdyYXBwZXJcIj5cbiAgICAgIHsvKiBUb3AgSGFsZiBTbGljZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJlbG9hZGVyLWhhbGYgcHJlbG9hZGVyLXRvcFwiPlxuICAgICAgICB7cmVuZGVyQ29udGVudCh0cnVlKX1cbiAgICAgIDwvZGl2PlxuICAgICAgey8qIEJvdHRvbSBIYWxmIFNsaWNlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcmVsb2FkZXItaGFsZiBwcmVsb2FkZXItYm90dG9tXCI+XG4gICAgICAgIHtyZW5kZXJDb250ZW50KGZhbHNlKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9Xb3JrL1Nhc3VkdWwvc2FzYS9zYXN1bmR1bC1wb3J0Zm9saW8vY29tcG9uZW50cy9QcmVsb2FkZXIudHN4In0=