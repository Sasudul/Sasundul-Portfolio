import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const lazy = __vite__cjsImport1_react["lazy"]; const Suspense = __vite__cjsImport1_react["Suspense"];
import { ReactLenis } from "/node_modules/.vite/deps/lenis_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { ScrollTrigger } from "/node_modules/.vite/deps/gsap_ScrollTrigger.js?v=5088fc54";
import Preloader from "/components/Preloader.tsx";
import Navigation from "/components/Navigation.tsx";
import CustomCursor from "/components/CustomCursor.tsx";
import HeroID from "/components/HeroID.tsx";
import AboutSection from "/components/AboutSection.tsx";
import HorizontalScroll from "/components/HorizontalScroll.tsx";
import ExpertiseSection from "/components/ExpertiseSection.tsx";
import WorkShowcase from "/components/WorkShowcase.tsx";
import Footer from "/components/Footer.tsx";
import ProjectModal from "/components/ProjectModal.tsx";
import ContactForm from "/components/ContactForm.tsx?t=1786214845469";
import CvModal from "/components/CvModal.tsx";
import SocialDock from "/components/SocialDock.tsx";
const AiChatbot = lazy(_c = () => import("/components/AiChatbot.tsx?t=1786214954375"));
_c2 = AiChatbot;
gsap.registerPlugin(ScrollTrigger);
export const PROJECTS = [
  {
    id: 1,
    title: "FLOODNAV",
    category: "DISASTER RESPONSE",
    tech: "React • TypeScript • Spring Boot",
    image: "/FloodNav.png",
    year: "2025",
    liveUrl: null,
    // e.g. "https://floodnav.com" or null for Coming Soon
    githubUrl: null,
    // e.g. "https://github.com/Sasudul/FloodNav" or null for Private/Coming Soon
    description: "An AI-assisted disaster response routing system engineered to optimize emergency rescue navigation during flood events. Features real-time route mapping, hazard alerts, and multi-agency coordination."
  },
  {
    id: 2,
    title: "VAP CONSTRUCTION",
    category: "CONSTRUCTION PORTFOLIO",
    tech: "React.js • Tailwind CSS • Vite",
    image: "/Vap-Construction.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "A high-impact web presence for a premier construction enterprise. Built with modern micro-animations, interactive project showcases, structural engineering case studies, and responsive design."
  },
  {
    id: 3,
    title: "ZÉRIN.LK",
    category: "E-COMMERCE • BEAUTY",
    tech: "Next.js 16 • React 19 • TypeScript • Tailwind CSS",
    image: "/Zerin.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "A luxury e-commerce platform designed for premium cosmetics and skincare products. Features dynamic product filtering, seamless checkout, and high-performance server-side rendering."
  },
  {
    id: 4,
    title: "LANDSLIDE ALERT",
    category: "EARLY WARNING SYSTEM",
    tech: "HTML • C++ • IoT Sensors",
    image: "/LandSlideAlert.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "An integrated IoT early-warning system for monitoring soil displacement and moisture levels in landslide-prone regions, broadcasting instant emergency telemetry."
  },
  {
    id: 5,
    title: "FLEET TRACKING",
    category: "LOGISTICS & TELEMATICS",
    tech: "React • Node.js • Google Maps API",
    image: "/FleetTracking.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "A real-time telematics dashboard providing fleet managers live GPS tracking, route optimization, vehicle diagnostics, and driver performance analytics."
  },
  {
    id: 6,
    title: "LUNARWAY TRAVELS",
    category: "TRAVEL & TOURISM",
    tech: "React • Tailwind CSS • Node.js",
    image: "/LunarwayTravels.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "An immersive travel booking platform highlighting bespoke tour itineraries, interactive destination maps, and automated reservation management."
  },
  {
    id: 7,
    title: "MEDCONNECT",
    category: "HEALTHCARE PLATFORM",
    tech: "React • Spring Boot • MySQL",
    image: "/E-Channeling-System.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "A digital e-channeling and medical appointment platform connecting patients with specialist doctors across regional hospitals."
  },
  {
    id: 8,
    title: "PIZZAMANIA",
    category: "MOBILE APP",
    tech: "Java • SQLite • Firebase",
    image: "/Pizza-Mania.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "A full-featured mobile food ordering application with custom topping configuration, real-time order status tracking, and location-based delivery dispatch."
  },
  {
    id: 9,
    title: "NATO MINI MART",
    category: "POS & RETAIL SYSTEM",
    tech: "React • Express • MongoDB",
    image: "/NatoMiniMart.png",
    year: "2024",
    liveUrl: null,
    githubUrl: null,
    description: "A point-of-sale and inventory management software solution for retail stores, offering barcoding, stock auditing, and daily revenue reporting."
  },
  {
    id: 10,
    title: "LUMINA",
    category: "AUTOMOTIVE",
    tech: "Vue.js • Tailwind • Framer Motion",
    image: "/Lumina.png",
    year: "2025",
    liveUrl: null,
    githubUrl: null,
    description: "An interactive automotive showcase highlighting electric vehicle specifications, 3D configurator views, and futuristic design aesthetics."
  },
  {
    id: 11,
    title: "ART GALLERY",
    category: "ART WORK PORTFOLIO",
    tech: "React • TypeScript",
    image: "/Art-Gallery-01.jpeg",
    year: "2026",
    liveUrl: null,
    githubUrl: null,
    description: "A minimalist digital art gallery curated for showcasing high-resolution artwork, exhibitions, and limited-edition prints."
  }
];
export default function App() {
  _s();
  const [showPreloader, setShowPreloader] = useState(false);
  const [preloaderDone, setPreloaderDone] = useState(true);
  const [navOpen, setNavOpen] = useState(false);
  const [theme, setTheme] = useState("light");
  const [selectedProject, setSelectedProject] = useState(null);
  const [showContact, setShowContact] = useState(false);
  useEffect(() => {
    setShowPreloader(true);
    setPreloaderDone(false);
  }, []);
  useEffect(() => {
    const saved = localStorage.getItem("theme");
    if (saved) {
      setTheme(saved);
      document.documentElement.setAttribute("data-theme", saved);
    }
  }, []);
  const toggleTheme = () => {
    const next = theme === "light" ? "dark" : "light";
    setTheme(next);
    localStorage.setItem("theme", next);
    document.documentElement.setAttribute("data-theme", next);
  };
  const handlePreloaderComplete = () => {
    sessionStorage.setItem("preloaderPlayed", "true");
    setPreloaderDone(true);
    setTimeout(() => setShowPreloader(false), 100);
    ScrollTrigger.refresh();
  };
  const handleNavigate = (section) => {
    const el = document.getElementById(section);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };
  return /* @__PURE__ */ jsxDEV(ReactLenis, { root: true, options: { lerp: 0.08, smoothWheel: true }, children: [
    showPreloader && /* @__PURE__ */ jsxDEV(Preloader, { onComplete: handlePreloaderComplete }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 210,
      columnNumber: 25
    }, this),
    /* @__PURE__ */ jsxDEV(CustomCursor, {}, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 213,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Navigation,
      {
        isOpen: navOpen,
        onToggle: () => setNavOpen(!navOpen),
        theme,
        onThemeToggle: toggleTheme,
        onNavigate: handleNavigate
      },
      void 0,
      false,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
        lineNumber: 216,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(SocialDock, { onContactClick: () => setShowContact(true) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 225,
      columnNumber: 7
    }, this),
    preloaderDone && /* @__PURE__ */ jsxDEV("main", { children: [
      /* @__PURE__ */ jsxDEV(HeroID, {}, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
        lineNumber: 230,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(AboutSection, {}, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
        lineNumber: 231,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(HorizontalScroll, {}, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
        lineNumber: 232,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(ExpertiseSection, {}, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
        lineNumber: 233,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        WorkShowcase,
        {
          projects: PROJECTS,
          onProjectClick: (p) => setSelectedProject(p)
        },
        void 0,
        false,
        {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
          lineNumber: 234,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Footer, { onContactClick: () => setShowContact(true) }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
        lineNumber: 238,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 229,
      columnNumber: 7
    }, this),
    selectedProject && /* @__PURE__ */ jsxDEV(ProjectModal, { project: selectedProject, onClose: () => setSelectedProject(null) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 244,
      columnNumber: 7
    }, this),
    showContact && /* @__PURE__ */ jsxDEV(ContactForm, { onClose: () => setShowContact(false) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 247,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CvModal, {}, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 249,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Suspense, { fallback: null, children: /* @__PURE__ */ jsxDEV(AiChatbot, {}, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 251,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
      lineNumber: 250,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx",
    lineNumber: 208,
    columnNumber: 5
  }, this);
}
_s(App, "K5J+888d2qfj0Ib85QO95B7ZqYo=");
_c3 = App;
var _c, _c2, _c3;
$RefreshReg$(_c, "AiChatbot$lazy");
$RefreshReg$(_c2, "AiChatbot");
$RefreshReg$(_c3, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/App.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaU53Qjs7QUFqTnhCLFNBQVNBLFVBQVVDLFdBQVdDLE1BQU1DLGdCQUFnQjtBQUNwRCxTQUFTQyxrQkFBa0I7QUFDM0IsT0FBT0MsVUFBVTtBQUNqQixTQUFTQyxxQkFBcUI7QUFFOUIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxnQkFBZ0I7QUFDdkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxzQkFBc0I7QUFDN0IsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLGdCQUFnQjtBQUd2QixNQUFNQyxZQUFZbEIsS0FBSW1CLEtBQUNBLE1BQU0sT0FBTyx3QkFBd0IsQ0FBQztBQUFFQyxNQUF6REY7QUFFTmYsS0FBS2tCLGVBQWVqQixhQUFhO0FBaUIxQixhQUFNa0IsV0FBc0I7QUFBQSxFQUNqQztBQUFBLElBQ0VDLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFNBQVM7QUFBQTtBQUFBLElBQ1RDLFdBQVc7QUFBQTtBQUFBLElBQ1hDLGFBQWE7QUFBQSxFQUNmO0FBQUEsRUFDQTtBQUFBLElBQ0VSLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNBO0FBQUEsSUFDRVIsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxhQUFhO0FBQUEsRUFDZjtBQUFBLEVBQ0E7QUFBQSxJQUNFUixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLGFBQWE7QUFBQSxFQUNmO0FBQUEsRUFDQTtBQUFBLElBQ0VSLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNBO0FBQUEsSUFDRVIsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxhQUFhO0FBQUEsRUFDZjtBQUFBLEVBQ0E7QUFBQSxJQUNFUixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLGFBQWE7QUFBQSxFQUNmO0FBQUEsRUFDQTtBQUFBLElBQ0VSLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsYUFBYTtBQUFBLEVBQ2Y7QUFBQSxFQUNBO0FBQUEsSUFDRVIsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLElBQ05DLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxhQUFhO0FBQUEsRUFDZjtBQUFBLEVBQ0E7QUFBQSxJQUNFUixJQUFJO0FBQUEsSUFDSkMsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLGFBQWE7QUFBQSxFQUNmO0FBQUEsRUFDQTtBQUFBLElBQ0VSLElBQUk7QUFBQSxJQUNKQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsYUFBYTtBQUFBLEVBQ2Y7QUFBQztBQUlILHdCQUF3QkMsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlyQyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDc0MsZUFBZUMsZ0JBQWdCLElBQUl2QyxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDd0MsU0FBU0MsVUFBVSxJQUFJekMsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQzBDLE9BQU9DLFFBQVEsSUFBSTNDLFNBQTJCLE9BQU87QUFDNUQsUUFBTSxDQUFDNEMsaUJBQWlCQyxrQkFBa0IsSUFBSTdDLFNBQXlCLElBQUk7QUFDM0UsUUFBTSxDQUFDOEMsYUFBYUMsY0FBYyxJQUFJL0MsU0FBUyxLQUFLO0FBR3BEQyxZQUFVLE1BQU07QUFDZG9DLHFCQUFpQixJQUFJO0FBQ3JCRSxxQkFBaUIsS0FBSztBQUFBLEVBQ3hCLEdBQUcsRUFBRTtBQUdMdEMsWUFBVSxNQUFNO0FBQ2QsVUFBTStDLFFBQVFDLGFBQWFDLFFBQVEsT0FBTztBQUMxQyxRQUFJRixPQUFPO0FBQ1RMLGVBQVNLLEtBQUs7QUFDZEcsZUFBU0MsZ0JBQWdCQyxhQUFhLGNBQWNMLEtBQUs7QUFBQSxJQUMzRDtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTU0sY0FBY0EsTUFBTTtBQUN4QixVQUFNQyxPQUFPYixVQUFVLFVBQVUsU0FBUztBQUMxQ0MsYUFBU1ksSUFBSTtBQUNiTixpQkFBYU8sUUFBUSxTQUFTRCxJQUFJO0FBQ2xDSixhQUFTQyxnQkFBZ0JDLGFBQWEsY0FBY0UsSUFBSTtBQUFBLEVBQzFEO0FBRUEsUUFBTUUsMEJBQTBCQSxNQUFNO0FBQ3BDQyxtQkFBZUYsUUFBUSxtQkFBbUIsTUFBTTtBQUNoRGpCLHFCQUFpQixJQUFJO0FBQ3JCb0IsZUFBVyxNQUFNdEIsaUJBQWlCLEtBQUssR0FBRyxHQUFHO0FBQzdDL0Isa0JBQWNzRCxRQUFRO0FBQUEsRUFDeEI7QUFFQSxRQUFNQyxpQkFBaUJBLENBQUNDLFlBQW9CO0FBQzFDLFVBQU1DLEtBQUtaLFNBQVNhLGVBQWVGLE9BQU87QUFDMUMsUUFBSUMsR0FBSUEsSUFBR0UsZUFBZSxFQUFFQyxVQUFVLFNBQVMsQ0FBQztBQUFBLEVBQ2xEO0FBRUEsU0FDRSx1QkFBQyxjQUFXLE1BQUksTUFBQyxTQUFTLEVBQUVDLE1BQU0sTUFBTUMsYUFBYSxLQUFLLEdBRXZEaEM7QUFBQUEscUJBQWlCLHVCQUFDLGFBQVUsWUFBWXFCLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStDO0FBQUEsSUFHakUsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhO0FBQUEsSUFHYjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsUUFBUWpCO0FBQUFBLFFBQ1IsVUFBVSxNQUFNQyxXQUFXLENBQUNELE9BQU87QUFBQSxRQUNuQztBQUFBLFFBQ0EsZUFBZWM7QUFBQUEsUUFDZixZQUFZTztBQUFBQTtBQUFBQSxNQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUs2QjtBQUFBLElBSTdCLHVCQUFDLGNBQVcsZ0JBQWdCLE1BQU1kLGVBQWUsSUFBSSxLQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsSUFHdERULGlCQUNDLHVCQUFDLFVBQ0M7QUFBQSw2QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLE1BQ1AsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhO0FBQUEsTUFDYix1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFDakIsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2pCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxVQUFVZDtBQUFBQSxVQUNWLGdCQUFnQixDQUFDNkMsTUFBTXhCLG1CQUFtQndCLENBQUM7QUFBQTtBQUFBLFFBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUUrQztBQUFBLE1BRS9DLHVCQUFDLFVBQU8sZ0JBQWdCLE1BQU10QixlQUFlLElBQUksS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLFNBVHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBSURILG1CQUNDLHVCQUFDLGdCQUFhLFNBQVNBLGlCQUFpQixTQUFTLE1BQU1DLG1CQUFtQixJQUFJLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Y7QUFBQSxJQUVqRkMsZUFDQyx1QkFBQyxlQUFZLFNBQVMsTUFBTUMsZUFBZSxLQUFLLEtBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0Q7QUFBQSxJQUVwRCx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1IsdUJBQUMsWUFBUyxVQUFVLE1BQ2xCLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZDQTtBQUVKO0FBQUNaLEdBMUZ1QkQsS0FBRztBQUFBb0MsTUFBSHBDO0FBQUcsSUFBQWIsSUFBQUMsS0FBQWdEO0FBQUFDLGFBQUFsRCxJQUFBO0FBQUFrRCxhQUFBakQsS0FBQTtBQUFBaUQsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwibGF6eSIsIlN1c3BlbnNlIiwiUmVhY3RMZW5pcyIsImdzYXAiLCJTY3JvbGxUcmlnZ2VyIiwiUHJlbG9hZGVyIiwiTmF2aWdhdGlvbiIsIkN1c3RvbUN1cnNvciIsIkhlcm9JRCIsIkFib3V0U2VjdGlvbiIsIkhvcml6b250YWxTY3JvbGwiLCJFeHBlcnRpc2VTZWN0aW9uIiwiV29ya1Nob3djYXNlIiwiRm9vdGVyIiwiUHJvamVjdE1vZGFsIiwiQ29udGFjdEZvcm0iLCJDdk1vZGFsIiwiU29jaWFsRG9jayIsIkFpQ2hhdGJvdCIsIl9jIiwiX2MyIiwicmVnaXN0ZXJQbHVnaW4iLCJQUk9KRUNUUyIsImlkIiwidGl0bGUiLCJjYXRlZ29yeSIsInRlY2giLCJpbWFnZSIsInllYXIiLCJsaXZlVXJsIiwiZ2l0aHViVXJsIiwiZGVzY3JpcHRpb24iLCJBcHAiLCJfcyIsInNob3dQcmVsb2FkZXIiLCJzZXRTaG93UHJlbG9hZGVyIiwicHJlbG9hZGVyRG9uZSIsInNldFByZWxvYWRlckRvbmUiLCJuYXZPcGVuIiwic2V0TmF2T3BlbiIsInRoZW1lIiwic2V0VGhlbWUiLCJzZWxlY3RlZFByb2plY3QiLCJzZXRTZWxlY3RlZFByb2plY3QiLCJzaG93Q29udGFjdCIsInNldFNob3dDb250YWN0Iiwic2F2ZWQiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJzZXRBdHRyaWJ1dGUiLCJ0b2dnbGVUaGVtZSIsIm5leHQiLCJzZXRJdGVtIiwiaGFuZGxlUHJlbG9hZGVyQ29tcGxldGUiLCJzZXNzaW9uU3RvcmFnZSIsInNldFRpbWVvdXQiLCJyZWZyZXNoIiwiaGFuZGxlTmF2aWdhdGUiLCJzZWN0aW9uIiwiZWwiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwiYmVoYXZpb3IiLCJsZXJwIiwic21vb3RoV2hlZWwiLCJwIiwiX2MzIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgbGF6eSwgU3VzcGVuc2UgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBSZWFjdExlbmlzIH0gZnJvbSAnbGVuaXMvcmVhY3QnO1xuaW1wb3J0IGdzYXAgZnJvbSAnZ3NhcCc7XG5pbXBvcnQgeyBTY3JvbGxUcmlnZ2VyIH0gZnJvbSAnZ3NhcC9TY3JvbGxUcmlnZ2VyJztcblxuaW1wb3J0IFByZWxvYWRlciBmcm9tICcuL2NvbXBvbmVudHMvUHJlbG9hZGVyJztcbmltcG9ydCBOYXZpZ2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9OYXZpZ2F0aW9uJztcbmltcG9ydCBDdXN0b21DdXJzb3IgZnJvbSAnLi9jb21wb25lbnRzL0N1c3RvbUN1cnNvcic7XG5pbXBvcnQgSGVyb0lEIGZyb20gJy4vY29tcG9uZW50cy9IZXJvSUQnO1xuaW1wb3J0IEFib3V0U2VjdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvQWJvdXRTZWN0aW9uJztcbmltcG9ydCBIb3Jpem9udGFsU2Nyb2xsIGZyb20gJy4vY29tcG9uZW50cy9Ib3Jpem9udGFsU2Nyb2xsJztcbmltcG9ydCBFeHBlcnRpc2VTZWN0aW9uIGZyb20gJy4vY29tcG9uZW50cy9FeHBlcnRpc2VTZWN0aW9uJztcbmltcG9ydCBXb3JrU2hvd2Nhc2UgZnJvbSAnLi9jb21wb25lbnRzL1dvcmtTaG93Y2FzZSc7XG5pbXBvcnQgRm9vdGVyIGZyb20gJy4vY29tcG9uZW50cy9Gb290ZXInO1xuaW1wb3J0IFByb2plY3RNb2RhbCBmcm9tICcuL2NvbXBvbmVudHMvUHJvamVjdE1vZGFsJztcbmltcG9ydCBDb250YWN0Rm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQ29udGFjdEZvcm0nO1xuaW1wb3J0IEN2TW9kYWwgZnJvbSAnLi9jb21wb25lbnRzL0N2TW9kYWwnO1xuaW1wb3J0IFNvY2lhbERvY2sgZnJvbSAnLi9jb21wb25lbnRzL1NvY2lhbERvY2snO1xuXG4vLyBMYXp5LWxvYWQgY2hhdGJvdCDigJQgemVybyBpbXBhY3Qgb24gaW5pdGlhbCBwYWdlIGxvYWRcbmNvbnN0IEFpQ2hhdGJvdCA9IGxhenkoKCkgPT4gaW1wb3J0KCcuL2NvbXBvbmVudHMvQWlDaGF0Ym90JykpO1xuXG5nc2FwLnJlZ2lzdGVyUGx1Z2luKFNjcm9sbFRyaWdnZXIpO1xuXG5leHBvcnQgaW50ZXJmYWNlIFByb2plY3Qge1xuICBpZDogbnVtYmVyO1xuICB0aXRsZTogc3RyaW5nO1xuICBjYXRlZ29yeTogc3RyaW5nO1xuICB0ZWNoOiBzdHJpbmc7XG4gIGltYWdlOiBzdHJpbmc7XG4gIHllYXI/OiBzdHJpbmc7XG4gIGxpdmVVcmw/OiBzdHJpbmcgfCBudWxsO1xuICBnaXRodWJVcmw/OiBzdHJpbmcgfCBudWxsO1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbn1cblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PSBQUk9KRUNUIERBVEEgPT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gSW5zZXJ0IHlvdXIgbGl2ZSB3ZWJzaXRlIGxpbmtzIGFuZCBHaXRIdWIgcmVwb3NpdG9yeSBsaW5rcyBiZWxvdy5cbi8vIExlYXZlIGxpdmVVcmwgLyBnaXRodWJVcmwgYXMgbnVsbCBpZiB0aGUgcHJvamVjdCBpcyBwcml2YXRlIG9yIGNvbWluZyBzb29uIVxuZXhwb3J0IGNvbnN0IFBST0pFQ1RTOiBQcm9qZWN0W10gPSBbXG4gIHtcbiAgICBpZDogMSxcbiAgICB0aXRsZTogXCJGTE9PRE5BVlwiLFxuICAgIGNhdGVnb3J5OiBcIkRJU0FTVEVSIFJFU1BPTlNFXCIsXG4gICAgdGVjaDogXCJSZWFjdCDigKIgVHlwZVNjcmlwdCDigKIgU3ByaW5nIEJvb3RcIixcbiAgICBpbWFnZTogXCIvRmxvb2ROYXYucG5nXCIsXG4gICAgeWVhcjogXCIyMDI1XCIsXG4gICAgbGl2ZVVybDogbnVsbCwgLy8gZS5nLiBcImh0dHBzOi8vZmxvb2RuYXYuY29tXCIgb3IgbnVsbCBmb3IgQ29taW5nIFNvb25cbiAgICBnaXRodWJVcmw6IG51bGwsIC8vIGUuZy4gXCJodHRwczovL2dpdGh1Yi5jb20vU2FzdWR1bC9GbG9vZE5hdlwiIG9yIG51bGwgZm9yIFByaXZhdGUvQ29taW5nIFNvb25cbiAgICBkZXNjcmlwdGlvbjogXCJBbiBBSS1hc3Npc3RlZCBkaXNhc3RlciByZXNwb25zZSByb3V0aW5nIHN5c3RlbSBlbmdpbmVlcmVkIHRvIG9wdGltaXplIGVtZXJnZW5jeSByZXNjdWUgbmF2aWdhdGlvbiBkdXJpbmcgZmxvb2QgZXZlbnRzLiBGZWF0dXJlcyByZWFsLXRpbWUgcm91dGUgbWFwcGluZywgaGF6YXJkIGFsZXJ0cywgYW5kIG11bHRpLWFnZW5jeSBjb29yZGluYXRpb24uXCJcbiAgfSxcbiAge1xuICAgIGlkOiAyLFxuICAgIHRpdGxlOiBcIlZBUCBDT05TVFJVQ1RJT05cIixcbiAgICBjYXRlZ29yeTogXCJDT05TVFJVQ1RJT04gUE9SVEZPTElPXCIsXG4gICAgdGVjaDogXCJSZWFjdC5qcyDigKIgVGFpbHdpbmQgQ1NTIOKAoiBWaXRlXCIsXG4gICAgaW1hZ2U6IFwiL1ZhcC1Db25zdHJ1Y3Rpb24ucG5nXCIsXG4gICAgeWVhcjogXCIyMDI1XCIsXG4gICAgbGl2ZVVybDogbnVsbCxcbiAgICBnaXRodWJVcmw6IG51bGwsXG4gICAgZGVzY3JpcHRpb246IFwiQSBoaWdoLWltcGFjdCB3ZWIgcHJlc2VuY2UgZm9yIGEgcHJlbWllciBjb25zdHJ1Y3Rpb24gZW50ZXJwcmlzZS4gQnVpbHQgd2l0aCBtb2Rlcm4gbWljcm8tYW5pbWF0aW9ucywgaW50ZXJhY3RpdmUgcHJvamVjdCBzaG93Y2FzZXMsIHN0cnVjdHVyYWwgZW5naW5lZXJpbmcgY2FzZSBzdHVkaWVzLCBhbmQgcmVzcG9uc2l2ZSBkZXNpZ24uXCJcbiAgfSxcbiAge1xuICAgIGlkOiAzLFxuICAgIHRpdGxlOiBcIlrDiVJJTi5MS1wiLFxuICAgIGNhdGVnb3J5OiBcIkUtQ09NTUVSQ0Ug4oCiIEJFQVVUWVwiLFxuICAgIHRlY2g6IFwiTmV4dC5qcyAxNiDigKIgUmVhY3QgMTkg4oCiIFR5cGVTY3JpcHQg4oCiIFRhaWx3aW5kIENTU1wiLFxuICAgIGltYWdlOiBcIi9aZXJpbi5wbmdcIixcbiAgICB5ZWFyOiBcIjIwMjVcIixcbiAgICBsaXZlVXJsOiBudWxsLFxuICAgIGdpdGh1YlVybDogbnVsbCxcbiAgICBkZXNjcmlwdGlvbjogXCJBIGx1eHVyeSBlLWNvbW1lcmNlIHBsYXRmb3JtIGRlc2lnbmVkIGZvciBwcmVtaXVtIGNvc21ldGljcyBhbmQgc2tpbmNhcmUgcHJvZHVjdHMuIEZlYXR1cmVzIGR5bmFtaWMgcHJvZHVjdCBmaWx0ZXJpbmcsIHNlYW1sZXNzIGNoZWNrb3V0LCBhbmQgaGlnaC1wZXJmb3JtYW5jZSBzZXJ2ZXItc2lkZSByZW5kZXJpbmcuXCJcbiAgfSxcbiAge1xuICAgIGlkOiA0LFxuICAgIHRpdGxlOiBcIkxBTkRTTElERSBBTEVSVFwiLFxuICAgIGNhdGVnb3J5OiBcIkVBUkxZIFdBUk5JTkcgU1lTVEVNXCIsXG4gICAgdGVjaDogXCJIVE1MIOKAoiBDKysg4oCiIElvVCBTZW5zb3JzXCIsXG4gICAgaW1hZ2U6IFwiL0xhbmRTbGlkZUFsZXJ0LnBuZ1wiLFxuICAgIHllYXI6IFwiMjAyNVwiLFxuICAgIGxpdmVVcmw6IG51bGwsXG4gICAgZ2l0aHViVXJsOiBudWxsLFxuICAgIGRlc2NyaXB0aW9uOiBcIkFuIGludGVncmF0ZWQgSW9UIGVhcmx5LXdhcm5pbmcgc3lzdGVtIGZvciBtb25pdG9yaW5nIHNvaWwgZGlzcGxhY2VtZW50IGFuZCBtb2lzdHVyZSBsZXZlbHMgaW4gbGFuZHNsaWRlLXByb25lIHJlZ2lvbnMsIGJyb2FkY2FzdGluZyBpbnN0YW50IGVtZXJnZW5jeSB0ZWxlbWV0cnkuXCJcbiAgfSxcbiAge1xuICAgIGlkOiA1LFxuICAgIHRpdGxlOiBcIkZMRUVUIFRSQUNLSU5HXCIsXG4gICAgY2F0ZWdvcnk6IFwiTE9HSVNUSUNTICYgVEVMRU1BVElDU1wiLFxuICAgIHRlY2g6IFwiUmVhY3Qg4oCiIE5vZGUuanMg4oCiIEdvb2dsZSBNYXBzIEFQSVwiLFxuICAgIGltYWdlOiBcIi9GbGVldFRyYWNraW5nLnBuZ1wiLFxuICAgIHllYXI6IFwiMjAyNVwiLFxuICAgIGxpdmVVcmw6IG51bGwsXG4gICAgZ2l0aHViVXJsOiBudWxsLFxuICAgIGRlc2NyaXB0aW9uOiBcIkEgcmVhbC10aW1lIHRlbGVtYXRpY3MgZGFzaGJvYXJkIHByb3ZpZGluZyBmbGVldCBtYW5hZ2VycyBsaXZlIEdQUyB0cmFja2luZywgcm91dGUgb3B0aW1pemF0aW9uLCB2ZWhpY2xlIGRpYWdub3N0aWNzLCBhbmQgZHJpdmVyIHBlcmZvcm1hbmNlIGFuYWx5dGljcy5cIlxuICB9LFxuICB7XG4gICAgaWQ6IDYsXG4gICAgdGl0bGU6IFwiTFVOQVJXQVkgVFJBVkVMU1wiLFxuICAgIGNhdGVnb3J5OiBcIlRSQVZFTCAmIFRPVVJJU01cIixcbiAgICB0ZWNoOiBcIlJlYWN0IOKAoiBUYWlsd2luZCBDU1Mg4oCiIE5vZGUuanNcIixcbiAgICBpbWFnZTogXCIvTHVuYXJ3YXlUcmF2ZWxzLnBuZ1wiLFxuICAgIHllYXI6IFwiMjAyNVwiLFxuICAgIGxpdmVVcmw6IG51bGwsXG4gICAgZ2l0aHViVXJsOiBudWxsLFxuICAgIGRlc2NyaXB0aW9uOiBcIkFuIGltbWVyc2l2ZSB0cmF2ZWwgYm9va2luZyBwbGF0Zm9ybSBoaWdobGlnaHRpbmcgYmVzcG9rZSB0b3VyIGl0aW5lcmFyaWVzLCBpbnRlcmFjdGl2ZSBkZXN0aW5hdGlvbiBtYXBzLCBhbmQgYXV0b21hdGVkIHJlc2VydmF0aW9uIG1hbmFnZW1lbnQuXCJcbiAgfSxcbiAge1xuICAgIGlkOiA3LFxuICAgIHRpdGxlOiBcIk1FRENPTk5FQ1RcIixcbiAgICBjYXRlZ29yeTogXCJIRUFMVEhDQVJFIFBMQVRGT1JNXCIsXG4gICAgdGVjaDogXCJSZWFjdCDigKIgU3ByaW5nIEJvb3Qg4oCiIE15U1FMXCIsXG4gICAgaW1hZ2U6IFwiL0UtQ2hhbm5lbGluZy1TeXN0ZW0ucG5nXCIsXG4gICAgeWVhcjogXCIyMDI1XCIsXG4gICAgbGl2ZVVybDogbnVsbCxcbiAgICBnaXRodWJVcmw6IG51bGwsXG4gICAgZGVzY3JpcHRpb246IFwiQSBkaWdpdGFsIGUtY2hhbm5lbGluZyBhbmQgbWVkaWNhbCBhcHBvaW50bWVudCBwbGF0Zm9ybSBjb25uZWN0aW5nIHBhdGllbnRzIHdpdGggc3BlY2lhbGlzdCBkb2N0b3JzIGFjcm9zcyByZWdpb25hbCBob3NwaXRhbHMuXCJcbiAgfSxcbiAge1xuICAgIGlkOiA4LFxuICAgIHRpdGxlOiBcIlBJWlpBTUFOSUFcIixcbiAgICBjYXRlZ29yeTogXCJNT0JJTEUgQVBQXCIsXG4gICAgdGVjaDogXCJKYXZhIOKAoiBTUUxpdGUg4oCiIEZpcmViYXNlXCIsXG4gICAgaW1hZ2U6IFwiL1BpenphLU1hbmlhLnBuZ1wiLFxuICAgIHllYXI6IFwiMjAyNVwiLFxuICAgIGxpdmVVcmw6IG51bGwsXG4gICAgZ2l0aHViVXJsOiBudWxsLFxuICAgIGRlc2NyaXB0aW9uOiBcIkEgZnVsbC1mZWF0dXJlZCBtb2JpbGUgZm9vZCBvcmRlcmluZyBhcHBsaWNhdGlvbiB3aXRoIGN1c3RvbSB0b3BwaW5nIGNvbmZpZ3VyYXRpb24sIHJlYWwtdGltZSBvcmRlciBzdGF0dXMgdHJhY2tpbmcsIGFuZCBsb2NhdGlvbi1iYXNlZCBkZWxpdmVyeSBkaXNwYXRjaC5cIlxuICB9LFxuICB7XG4gICAgaWQ6IDksXG4gICAgdGl0bGU6IFwiTkFUTyBNSU5JIE1BUlRcIixcbiAgICBjYXRlZ29yeTogXCJQT1MgJiBSRVRBSUwgU1lTVEVNXCIsXG4gICAgdGVjaDogXCJSZWFjdCDigKIgRXhwcmVzcyDigKIgTW9uZ29EQlwiLFxuICAgIGltYWdlOiBcIi9OYXRvTWluaU1hcnQucG5nXCIsXG4gICAgeWVhcjogXCIyMDI0XCIsXG4gICAgbGl2ZVVybDogbnVsbCxcbiAgICBnaXRodWJVcmw6IG51bGwsXG4gICAgZGVzY3JpcHRpb246IFwiQSBwb2ludC1vZi1zYWxlIGFuZCBpbnZlbnRvcnkgbWFuYWdlbWVudCBzb2Z0d2FyZSBzb2x1dGlvbiBmb3IgcmV0YWlsIHN0b3Jlcywgb2ZmZXJpbmcgYmFyY29kaW5nLCBzdG9jayBhdWRpdGluZywgYW5kIGRhaWx5IHJldmVudWUgcmVwb3J0aW5nLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogMTAsXG4gICAgdGl0bGU6IFwiTFVNSU5BXCIsXG4gICAgY2F0ZWdvcnk6IFwiQVVUT01PVElWRVwiLFxuICAgIHRlY2g6IFwiVnVlLmpzIOKAoiBUYWlsd2luZCDigKIgRnJhbWVyIE1vdGlvblwiLFxuICAgIGltYWdlOiBcIi9MdW1pbmEucG5nXCIsXG4gICAgeWVhcjogXCIyMDI1XCIsXG4gICAgbGl2ZVVybDogbnVsbCxcbiAgICBnaXRodWJVcmw6IG51bGwsXG4gICAgZGVzY3JpcHRpb246IFwiQW4gaW50ZXJhY3RpdmUgYXV0b21vdGl2ZSBzaG93Y2FzZSBoaWdobGlnaHRpbmcgZWxlY3RyaWMgdmVoaWNsZSBzcGVjaWZpY2F0aW9ucywgM0QgY29uZmlndXJhdG9yIHZpZXdzLCBhbmQgZnV0dXJpc3RpYyBkZXNpZ24gYWVzdGhldGljcy5cIlxuICB9LFxuICB7XG4gICAgaWQ6IDExLFxuICAgIHRpdGxlOiBcIkFSVCBHQUxMRVJZXCIsXG4gICAgY2F0ZWdvcnk6IFwiQVJUIFdPUksgUE9SVEZPTElPXCIsXG4gICAgdGVjaDogXCJSZWFjdCDigKIgVHlwZVNjcmlwdFwiLFxuICAgIGltYWdlOiBcIi9BcnQtR2FsbGVyeS0wMS5qcGVnXCIsXG4gICAgeWVhcjogXCIyMDI2XCIsXG4gICAgbGl2ZVVybDogbnVsbCxcbiAgICBnaXRodWJVcmw6IG51bGwsXG4gICAgZGVzY3JpcHRpb246IFwiQSBtaW5pbWFsaXN0IGRpZ2l0YWwgYXJ0IGdhbGxlcnkgY3VyYXRlZCBmb3Igc2hvd2Nhc2luZyBoaWdoLXJlc29sdXRpb24gYXJ0d29yaywgZXhoaWJpdGlvbnMsIGFuZCBsaW1pdGVkLWVkaXRpb24gcHJpbnRzLlwiXG4gIH1cbl07XG5cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT0gQVBQID09PT09PT09PT09PT09PT09PT09PT09PT1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgW3Nob3dQcmVsb2FkZXIsIHNldFNob3dQcmVsb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcHJlbG9hZGVyRG9uZSwgc2V0UHJlbG9hZGVyRG9uZV0gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW25hdk9wZW4sIHNldE5hdk9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbdGhlbWUsIHNldFRoZW1lXSA9IHVzZVN0YXRlPCdsaWdodCcgfCAnZGFyayc+KCdsaWdodCcpO1xuICBjb25zdCBbc2VsZWN0ZWRQcm9qZWN0LCBzZXRTZWxlY3RlZFByb2plY3RdID0gdXNlU3RhdGU8UHJvamVjdCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc2hvd0NvbnRhY3QsIHNldFNob3dDb250YWN0XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBDaGVjayBpZiBwcmVsb2FkZXIgbmVlZHMgdG8gcGxheVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldFNob3dQcmVsb2FkZXIodHJ1ZSk7XG4gICAgc2V0UHJlbG9hZGVyRG9uZShmYWxzZSk7XG4gIH0sIFtdKTtcblxuICAvLyBUaGVtZSBwZXJzaXN0ZW5jZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3RoZW1lJykgYXMgJ2xpZ2h0JyB8ICdkYXJrJyB8IG51bGw7XG4gICAgaWYgKHNhdmVkKSB7XG4gICAgICBzZXRUaGVtZShzYXZlZCk7XG4gICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2V0QXR0cmlidXRlKCdkYXRhLXRoZW1lJywgc2F2ZWQpO1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIGNvbnN0IHRvZ2dsZVRoZW1lID0gKCkgPT4ge1xuICAgIGNvbnN0IG5leHQgPSB0aGVtZSA9PT0gJ2xpZ2h0JyA/ICdkYXJrJyA6ICdsaWdodCc7XG4gICAgc2V0VGhlbWUobmV4dCk7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RoZW1lJywgbmV4dCk7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS10aGVtZScsIG5leHQpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVByZWxvYWRlckNvbXBsZXRlID0gKCkgPT4ge1xuICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ3ByZWxvYWRlclBsYXllZCcsICd0cnVlJyk7XG4gICAgc2V0UHJlbG9hZGVyRG9uZSh0cnVlKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNob3dQcmVsb2FkZXIoZmFsc2UpLCAxMDApO1xuICAgIFNjcm9sbFRyaWdnZXIucmVmcmVzaCgpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU5hdmlnYXRlID0gKHNlY3Rpb246IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoc2VjdGlvbik7XG4gICAgaWYgKGVsKSBlbC5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxSZWFjdExlbmlzIHJvb3Qgb3B0aW9ucz17eyBsZXJwOiAwLjA4LCBzbW9vdGhXaGVlbDogdHJ1ZSB9fT5cbiAgICAgIHsvKiBQcmVsb2FkZXIgKi99XG4gICAgICB7c2hvd1ByZWxvYWRlciAmJiA8UHJlbG9hZGVyIG9uQ29tcGxldGU9e2hhbmRsZVByZWxvYWRlckNvbXBsZXRlfSAvPn1cblxuICAgICAgey8qIEN1c3RvbSBDdXJzb3IgKi99XG4gICAgICA8Q3VzdG9tQ3Vyc29yIC8+XG5cbiAgICAgIHsvKiBOYXZpZ2F0aW9uICovfVxuICAgICAgPE5hdmlnYXRpb25cbiAgICAgICAgaXNPcGVuPXtuYXZPcGVufVxuICAgICAgICBvblRvZ2dsZT17KCkgPT4gc2V0TmF2T3BlbighbmF2T3Blbil9XG4gICAgICAgIHRoZW1lPXt0aGVtZX1cbiAgICAgICAgb25UaGVtZVRvZ2dsZT17dG9nZ2xlVGhlbWV9XG4gICAgICAgIG9uTmF2aWdhdGU9e2hhbmRsZU5hdmlnYXRlfVxuICAgICAgLz5cblxuICAgICAgey8qIEZsb2F0aW5nIExlZnQgU29jaWFsIERvY2sgKi99XG4gICAgICA8U29jaWFsRG9jayBvbkNvbnRhY3RDbGljaz17KCkgPT4gc2V0U2hvd0NvbnRhY3QodHJ1ZSl9IC8+XG5cbiAgICAgIHsvKiBNYWluIENvbnRlbnQgKi99XG4gICAgICB7cHJlbG9hZGVyRG9uZSAmJiAoXG4gICAgICAgIDxtYWluPlxuICAgICAgICAgIDxIZXJvSUQgLz5cbiAgICAgICAgICA8QWJvdXRTZWN0aW9uIC8+XG4gICAgICAgICAgPEhvcml6b250YWxTY3JvbGwgLz5cbiAgICAgICAgICA8RXhwZXJ0aXNlU2VjdGlvbiAvPlxuICAgICAgICAgIDxXb3JrU2hvd2Nhc2VcbiAgICAgICAgICAgIHByb2plY3RzPXtQUk9KRUNUU31cbiAgICAgICAgICAgIG9uUHJvamVjdENsaWNrPXsocCkgPT4gc2V0U2VsZWN0ZWRQcm9qZWN0KHApfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPEZvb3RlciBvbkNvbnRhY3RDbGljaz17KCkgPT4gc2V0U2hvd0NvbnRhY3QodHJ1ZSl9IC8+XG4gICAgICAgIDwvbWFpbj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBPdmVybGF5cyAqL31cbiAgICAgIHtzZWxlY3RlZFByb2plY3QgJiYgKFxuICAgICAgICA8UHJvamVjdE1vZGFsIHByb2plY3Q9e3NlbGVjdGVkUHJvamVjdH0gb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRQcm9qZWN0KG51bGwpfSAvPlxuICAgICAgKX1cbiAgICAgIHtzaG93Q29udGFjdCAmJiAoXG4gICAgICAgIDxDb250YWN0Rm9ybSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93Q29udGFjdChmYWxzZSl9IC8+XG4gICAgICApfVxuICAgICAgPEN2TW9kYWwgLz5cbiAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17bnVsbH0+XG4gICAgICAgIDxBaUNoYXRib3QgLz5cbiAgICAgIDwvU3VzcGVuc2U+XG4gICAgPC9SZWFjdExlbmlzPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9Xb3JrL1Nhc3VkdWwvc2FzYS9zYXN1bmR1bC1wb3J0Zm9saW8vQXBwLnRzeCJ9