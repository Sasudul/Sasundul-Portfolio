import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/SocialDock.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export default function SocialDock({ onContactClick }) {
  return /* @__PURE__ */ jsxDEV("aside", { className: "fixed left-0 top-1/2 -translate-y-1/2 z-40 flex flex-col items-center", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-[#050505]/85 backdrop-blur-xl border border-l-0 border-white/20 rounded-r-2xl py-3 px-2 flex flex-col items-center gap-3.5 shadow-[0_10px_30px_rgba(0,0,0,0.8)]", children: [
    /* @__PURE__ */ jsxDEV(
      "a",
      {
        href: "https://wa.me/+94740629020",
        target: "_blank",
        rel: "noopener noreferrer",
        className: "group relative w-10 h-10 rounded-xl bg-[#25D366] flex items-center justify-center text-white shadow-lg hover:scale-110 hover:translate-x-1 transition-all duration-300",
        "aria-label": "WhatsApp",
        children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 fill-current", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { d: "M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 21,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 20,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "absolute left-full ml-3 px-2.5 py-1 bg-black/90 border border-white/10 text-white text-xs font-mono rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300 whitespace-nowrap shadow-xl", children: "WhatsApp" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 24,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
        lineNumber: 13,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "a",
      {
        href: "https://www.linkedin.com/in/sasundul/",
        target: "_blank",
        rel: "noopener noreferrer",
        className: "group relative w-10 h-10 rounded-xl bg-[#0A66C2] flex items-center justify-center text-white shadow-lg hover:scale-110 hover:translate-x-1 transition-all duration-300",
        "aria-label": "LinkedIn",
        children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 fill-current", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { d: "M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 38,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 37,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "absolute left-full ml-3 px-2.5 py-1 bg-black/90 border border-white/10 text-white text-xs font-mono rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300 whitespace-nowrap shadow-xl", children: "LinkedIn" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 41,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
        lineNumber: 30,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "a",
      {
        href: "https://github.com/Sasudul",
        target: "_blank",
        rel: "noopener noreferrer",
        className: "group relative w-10 h-10 rounded-xl bg-[#181717] border border-white/20 flex items-center justify-center text-white shadow-lg hover:scale-110 hover:translate-x-1 transition-all duration-300",
        "aria-label": "GitHub",
        children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 fill-current", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { d: "M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 55,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 54,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "absolute left-full ml-3 px-2.5 py-1 bg-black/90 border border-white/10 text-white text-xs font-mono rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300 whitespace-nowrap shadow-xl", children: "GitHub" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 58,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
        lineNumber: 47,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: onContactClick,
        className: "group relative w-10 h-10 rounded-xl bg-white border border-white/30 flex items-center justify-center shadow-lg hover:scale-110 hover:translate-x-1 transition-all duration-300",
        "aria-label": "Email Me",
        children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "w-5.5 h-5.5", viewBox: "0 0 24 24", fill: "none", children: [
            /* @__PURE__ */ jsxDEV("path", { d: "M22.5 6.75V17.25C22.5 18.4926 21.4926 19.5 20.25 19.5H17.25V11.25L12 15L6.75 11.25V19.5H3.75C2.50736 19.5 1.5 18.4926 1.5 17.25V6.75C1.5 5.50736 2.50736 4.5 3.75 4.5H4.875L12 9.75L19.125 4.5H20.25C21.4926 4.5 22.5 5.50736 22.5 6.75Z", fill: "#EA4335" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
              lineNumber: 70,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("path", { d: "M17.25 19.5H20.25C21.4926 19.5 22.5 18.4926 22.5 17.25V6.75L17.25 10.875V19.5Z", fill: "#4285F4" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
              lineNumber: 71,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("path", { d: "M1.5 6.75V17.25C1.5 18.4926 2.50736 19.5 3.75 19.5H6.75V10.875L1.5 6.75Z", fill: "#34A853" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
              lineNumber: 72,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("path", { d: "M17.25 4.5L12 8.25L6.75 4.5H3.75C2.71607 4.5 1.84883 5.19515 1.5843 6.13605L6.75 10.125L12 13.875L17.25 10.125L22.4157 6.13605C22.1512 5.19515 21.2839 4.5 20.25 4.5H17.25Z", fill: "#FBBC05" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
              lineNumber: 73,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("path", { d: "M17.25 4.5H20.25C21.4926 4.5 22.5 5.50736 22.5 6.75V7.125L17.25 10.875V4.5Z", fill: "#C5221F" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
              lineNumber: 74,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 69,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "absolute left-full ml-3 px-2.5 py-1 bg-black/90 border border-white/10 text-white text-xs font-mono rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300 whitespace-nowrap shadow-xl", children: "Email Me" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
            lineNumber: 77,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
        lineNumber: 64,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
    lineNumber: 10,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx",
    lineNumber: 9,
    columnNumber: 5
  }, this);
}
_c = SocialDock;
var _c;
$RefreshReg$(_c, "SocialDock");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/SocialDock.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JZO0FBZFosd0JBQXdCQSxXQUFXLEVBQUVDLGVBQWdDLEdBQUc7QUFDdEUsU0FDRSx1QkFBQyxXQUFNLFdBQVUseUVBQ2YsaUNBQUMsU0FBSSxXQUFVLHNLQUdiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFFBQU87QUFBQSxRQUNQLEtBQUk7QUFBQSxRQUNKLFdBQVU7QUFBQSxRQUNWLGNBQVc7QUFBQSxRQUVYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdCQUF1QixTQUFRLGFBQzVDLGlDQUFDLFVBQUssR0FBRSw2aUNBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaWpDLEtBRG5qQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxVQUFLLFdBQVUsMFBBQXdQLHdCQUF4UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUE7QUFBQTtBQUFBLE1BYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxRQUFPO0FBQUEsUUFDUCxLQUFJO0FBQUEsUUFDSixXQUFVO0FBQUEsUUFDVixjQUFXO0FBQUEsUUFFWDtBQUFBLGlDQUFDLFNBQUksV0FBVSx3QkFBdUIsU0FBUSxhQUM1QyxpQ0FBQyxVQUFLLEdBQUUseVVBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNlUsS0FEL1U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxXQUFVLDBQQUF3UCx3QkFBeFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBO0FBQUE7QUFBQSxNQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWNBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsUUFBTztBQUFBLFFBQ1AsS0FBSTtBQUFBLFFBQ0osV0FBVTtBQUFBLFFBQ1YsY0FBVztBQUFBLFFBRVg7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0JBQXVCLFNBQVEsYUFDNUMsaUNBQUMsVUFBSyxHQUFFLCtzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtdEIsS0FEcnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFVBQUssV0FBVSwwUEFBd1Asc0JBQXhRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBO0FBQUEsTUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNBO0FBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBQ1YsY0FBVztBQUFBLFFBRVg7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZUFBYyxTQUFRLGFBQVksTUFBSyxRQUNwRDtBQUFBLG1DQUFDLFVBQUssR0FBRSw0T0FBMk8sTUFBSyxhQUF4UDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpUTtBQUFBLFlBQ2pRLHVCQUFDLFVBQUssR0FBRSxrRkFBaUYsTUFBSyxhQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLFlBQ3ZHLHVCQUFDLFVBQUssR0FBRSw0RUFBMkUsTUFBSyxhQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRztBQUFBLFlBQ2pHLHVCQUFDLFVBQUssR0FBRSwrS0FBOEssTUFBSyxhQUEzTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvTTtBQUFBLFlBQ3BNLHVCQUFDLFVBQUssR0FBRSwrRUFBOEUsTUFBSyxhQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRztBQUFBLGVBTHRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUVBLHVCQUFDLFVBQUssV0FBVSwwUEFBd1Asd0JBQXhRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBO0FBQUEsTUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnQkE7QUFBQSxPQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0VBLEtBekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwRUE7QUFFSjtBQUFDQyxLQTlFdUJGO0FBQVUsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNvY2lhbERvY2siLCJvbkNvbnRhY3RDbGljayIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNvY2lhbERvY2sudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmludGVyZmFjZSBTb2NpYWxEb2NrUHJvcHMge1xuICBvbkNvbnRhY3RDbGljaz86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNvY2lhbERvY2soeyBvbkNvbnRhY3RDbGljayB9OiBTb2NpYWxEb2NrUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwiZml4ZWQgbGVmdC0wIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB6LTQwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjMDUwNTA1XS84NSBiYWNrZHJvcC1ibHVyLXhsIGJvcmRlciBib3JkZXItbC0wIGJvcmRlci13aGl0ZS8yMCByb3VuZGVkLXItMnhsIHB5LTMgcHgtMiBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMy41IHNoYWRvdy1bMF8xMHB4XzMwcHhfcmdiYSgwLDAsMCwwLjgpXVwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFdoYXRzQXBwICovfVxuICAgICAgICA8YSBcbiAgICAgICAgICBocmVmPVwiaHR0cHM6Ly93YS5tZS8rOTQ3NDA2MjkwMjBcIiBcbiAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIiBcbiAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSB3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1bIzI1RDM2Nl0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTEwIGhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiV2hhdHNBcHBcIlxuICAgICAgICA+XG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01IGZpbGwtY3VycmVudFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNLjA1NyAyNGwxLjY4Ny02LjE2M2MtMS4wNDEtMS44MDQtMS41ODgtMy44NDktMS41ODctNS45NDYuMDAzLTYuNTU2IDUuMzM4LTExLjg5MSAxMS44OTMtMTEuODkxIDMuMTgxLjAwMSA2LjE2NyAxLjI0IDguNDEzIDMuNDg4IDIuMjQ1IDIuMjQ4IDMuNDgxIDUuMjM2IDMuNDggOC40MTQtLjAwMyA2LjU1Ny01LjMzOCAxMS44OTItMTEuODkzIDExLjg5Mi0xLjk5LS4wMDEtMy45NTEtLjUtNS42ODgtMS40NDhsLTYuMzA1IDEuNjU0em02LjU5Ny0zLjgwN2MxLjY3Ni45OTUgMy4yNzYgMS41OTEgNS4zOTIgMS41OTIgNS40NDggMCA5Ljg4Ni00LjQzNCA5Ljg4OS05Ljg4NS4wMDItNS40NjItNC40MTUtOS44OS05Ljg4MS05Ljg5Mi01LjQ1MiAwLTkuODg3IDQuNDM0LTkuODg5IDkuODg0LS4wMDEgMi4yMjUuNjUxIDMuODkxIDEuNzQ2IDUuNjM0bC0uOTk5IDMuNjQ4IDMuNzQyLS45ODF6bTExLjM4Ny01LjQ2NGMtLjA3NC0uMTI0LS4yNzItLjE5OC0uNTctLjM0Ny0uMjk3LS4xNDktMS43NTgtLjg2OC0yLjAzMS0uOTY3LS4yNzItLjA5OS0uNDctLjE0OS0uNjY5LjE0OS0uMTk4LjI5Ny0uNzY4Ljk2Ny0uOTQxIDEuMTY1LS4xNzMuMTk4LS4zNDcuMjIzLS42NDQuMDc0LS4yOTctLjE0OS0xLjI1NS0uNDYyLTIuMzktMS40NzUtLjg4My0uNzg4LTEuNDgtMS43NjEtMS42NTMtMi4wNTktLjE3My0uMjk3LS4wMTgtLjQ1OC4xMy0uNjA2LjEzNC0uMTMzLjI5Ny0uMzQ3LjQ0Ni0uNTIxLjE1MS0uMTcyLjItLjI5Ni4zLS40OTUuMDk5LS4xOTguMDUtLjM3Mi0uMDI1LS41MjEtLjA3NS0uMTQ4LS42NjktMS42MTEtLjkxNi0yLjIwNi0uMjQyLS41NzktLjQ4Ny0uNTAxLS42NjktLjUxbC0uNTctLjAxYy0uMTk4IDAtLjUyLjA3NC0uNzkyLjM3MnMtMS4wNCAxLjAxNi0xLjA0IDIuNDc5IDEuMDY1IDIuODc2IDEuMjEzIDMuMDc0Yy4xNDkuMTk4IDIuMDk1IDMuMiA1LjA3NiA0LjQ4Ny43MDkuMzA2IDEuMjYzLjQ4OSAxLjY5NC42MjYuNzEyLjIyNiAxLjM2LjE5NCAxLjg3Mi4xMTguNTcxLS4wODUgMS43NTgtLjcxOSAyLjAwNi0xLjQxMy4yNDgtLjY5NS4yNDgtMS4yOS4xNzMtMS40MTR6XCIvPlxuICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIHsvKiBUb29sdGlwICovfVxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtZnVsbCBtbC0zIHB4LTIuNSBweS0xIGJnLWJsYWNrLzkwIGJvcmRlciBib3JkZXItd2hpdGUvMTAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtbW9ubyByb3VuZGVkLWxnIG9wYWNpdHktMCBwb2ludGVyLWV2ZW50cy1ub25lIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHdoaXRlc3BhY2Utbm93cmFwIHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgV2hhdHNBcHBcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvYT5cblxuICAgICAgICB7LyogTGlua2VkSW4gKi99XG4gICAgICAgIDxhIFxuICAgICAgICAgIGhyZWY9XCJodHRwczovL3d3dy5saW5rZWRpbi5jb20vaW4vc2FzdW5kdWwvXCIgXG4gICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCIgXG4gICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgdy0xMCBoLTEwIHJvdW5kZWQteGwgYmctWyMwQTY2QzJdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LWxnIGhvdmVyOnNjYWxlLTExMCBob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkxpbmtlZEluXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNSBmaWxsLWN1cnJlbnRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICA8cGF0aCBkPVwiTTE5IDBoLTE0Yy0yLjc2MSAwLTUgMi4yMzktNSA1djE0YzAgMi43NjEgMi4yMzkgNSA1IDVoMTRjMi43NjIgMCA1LTIuMjM5IDUtNXYtMTRjMC0yLjc2MS0yLjIzOC01LTUtNXptLTExIDE5aC0zdi0xMWgzdjExem0tMS41LTEyLjI2OGMtLjk2NiAwLTEuNzUtLjc5LTEuNzUtMS43NjRzLjc4NC0xLjc2NCAxLjc1LTEuNzY0IDEuNzUuNzkgMS43NSAxLjc2NC0uNzgzIDEuNzY0LTEuNzUgMS43NjR6bTEzLjUgMTIuMjY4aC0zdi01LjYwNGMwLTMuMzY4LTQtMy4xMTMtNCAwdjUuNjA0aC0zdi0xMWgzdjEuNzY1YzEuMzk2LTIuNTg2IDctMi43NzcgNyAyLjQ3NnY2Ljc1OXpcIi8+XG4gICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgey8qIFRvb2x0aXAgKi99XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC1mdWxsIG1sLTMgcHgtMi41IHB5LTEgYmctYmxhY2svOTAgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1tb25vIHJvdW5kZWQtbGcgb3BhY2l0eS0wIHBvaW50ZXItZXZlbnRzLW5vbmUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgd2hpdGVzcGFjZS1ub3dyYXAgc2hhZG93LXhsXCI+XG4gICAgICAgICAgICBMaW5rZWRJblxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9hPlxuXG4gICAgICAgIHsvKiBHaXRIdWIgKi99XG4gICAgICAgIDxhIFxuICAgICAgICAgIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vU2FzdWR1bFwiIFxuICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiIFxuICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIHctMTAgaC0xMCByb3VuZGVkLXhsIGJnLVsjMTgxNzE3XSBib3JkZXIgYm9yZGVyLXdoaXRlLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LWxnIGhvdmVyOnNjYWxlLTExMCBob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkdpdEh1YlwiXG4gICAgICAgID5cbiAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTUgZmlsbC1jdXJyZW50XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgICAgICAgPHBhdGggZD1cIk0xMiAwYy02LjYyNiAwLTEyIDUuMzczLTEyIDEyIDAgNS4zMDIgMy40MzggOS44IDguMjA3IDExLjM4Ny41OTkuMTExLjc5My0uMjYxLjc5My0uNTc3di0yLjIzNGMtMy4zMzguNzI2LTQuMDMzLTEuNDE2LTQuMDMzLTEuNDE2LS41NDYtMS4zODctMS4zMzMtMS43NTYtMS4zMzMtMS43NTYtMS4wODktLjc0NS4wODMtLjcyOS4wODMtLjcyOSAxLjIwNS4wODQgMS44MzkgMS4yMzcgMS44MzkgMS4yMzcgMS4wNyAxLjgzNCAyLjgwNyAxLjMwNCAzLjQ5Mi45OTcuMTA3LS43NzUuNDE4LTEuMzA1Ljc2Mi0xLjYwNC0yLjY2NS0uMzA1LTUuNDY3LTEuMzM0LTUuNDY3LTUuOTMxIDAtMS4zMTEuNDY5LTIuMzgxIDEuMjM2LTMuMjIxLS4xMjQtLjMwMy0uNTM1LTEuNTI0LjExNy0zLjE3NiAwIDAgMS4wMDgtLjMyMiAzLjMwMSAxLjIzLjk1Ny0uMjY2IDEuOTgzLS4zOTkgMy4wMDMtLjQwNCAxLjAyLjAwNSAyLjA0Ny4xMzggMy4wMDYuNDA0IDIuMjkxLTEuNTUyIDMuMjk3LTEuMjMgMy4yOTctMS4yMy42NTMgMS42NTMuMjQyIDIuODc0LjExOCAzLjE3Ni43Ny44NCAxLjIzNSAxLjkxMSAxLjIzNSAzLjIyMSAwIDQuNjA5LTIuODA3IDUuNjI0LTUuNDc5IDUuOTIxLjQzLjM3Mi44MjMgMS4xMDIuODIzIDIuMjIydjMuMjkzYzAgLjMxOS4xOTIuNjk0LjgwMS41NzYgNC43NjUtMS41ODkgOC4xOTktNi4wODYgOC4xOTktMTEuMzg2IDAtNi42MjctNS4zNzMtMTItMTItMTJ6XCIvPlxuICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIHsvKiBUb29sdGlwICovfVxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtZnVsbCBtbC0zIHB4LTIuNSBweS0xIGJnLWJsYWNrLzkwIGJvcmRlciBib3JkZXItd2hpdGUvMTAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtbW9ubyByb3VuZGVkLWxnIG9wYWNpdHktMCBwb2ludGVyLWV2ZW50cy1ub25lIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHdoaXRlc3BhY2Utbm93cmFwIHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgR2l0SHViXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2E+XG5cbiAgICAgICAgey8qIEdtYWlsICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25Db250YWN0Q2xpY2t9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgdy0xMCBoLTEwIHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci13aGl0ZS8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTEwIGhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiRW1haWwgTWVcIlxuICAgICAgICA+XG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUuNSBoLTUuNVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiPlxuICAgICAgICAgICAgPHBhdGggZD1cIk0yMi41IDYuNzVWMTcuMjVDMjIuNSAxOC40OTI2IDIxLjQ5MjYgMTkuNSAyMC4yNSAxOS41SDE3LjI1VjExLjI1TDEyIDE1TDYuNzUgMTEuMjVWMTkuNUgzLjc1QzIuNTA3MzYgMTkuNSAxLjUgMTguNDkyNiAxLjUgMTcuMjVWNi43NUMxLjUgNS41MDczNiAyLjUwNzM2IDQuNSAzLjc1IDQuNUg0Ljg3NUwxMiA5Ljc1TDE5LjEyNSA0LjVIMjAuMjVDMjEuNDkyNiA0LjUgMjIuNSA1LjUwNzM2IDIyLjUgNi43NVpcIiBmaWxsPVwiI0VBNDMzNVwiLz5cbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTcuMjUgMTkuNUgyMC4yNUMyMS40OTI2IDE5LjUgMjIuNSAxOC40OTI2IDIyLjUgMTcuMjVWNi43NUwxNy4yNSAxMC44NzVWMTkuNVpcIiBmaWxsPVwiIzQyODVGNFwiLz5cbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMS41IDYuNzVWMTcuMjVDMS41IDE4LjQ5MjYgMi41MDczNiAxOS41IDMuNzUgMTkuNUg2Ljc1VjEwLjg3NUwxLjUgNi43NVpcIiBmaWxsPVwiIzM0QTg1M1wiLz5cbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTcuMjUgNC41TDEyIDguMjVMNi43NSA0LjVIMy43NUMyLjcxNjA3IDQuNSAxLjg0ODgzIDUuMTk1MTUgMS41ODQzIDYuMTM2MDVMNi43NSAxMC4xMjVMMTIgMTMuODc1TDE3LjI1IDEwLjEyNUwyMi40MTU3IDYuMTM2MDVDMjIuMTUxMiA1LjE5NTE1IDIxLjI4MzkgNC41IDIwLjI1IDQuNUgxNy4yNVpcIiBmaWxsPVwiI0ZCQkMwNVwiLz5cbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTcuMjUgNC41SDIwLjI1QzIxLjQ5MjYgNC41IDIyLjUgNS41MDczNiAyMi41IDYuNzVWNy4xMjVMMTcuMjUgMTAuODc1VjQuNVpcIiBmaWxsPVwiI0M1MjIxRlwiLz5cbiAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICB7LyogVG9vbHRpcCAqL31cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LWZ1bGwgbWwtMyBweC0yLjUgcHktMSBiZy1ibGFjay85MCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LW1vbm8gcm91bmRlZC1sZyBvcGFjaXR5LTAgcG9pbnRlci1ldmVudHMtbm9uZSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCB3aGl0ZXNwYWNlLW5vd3JhcCBzaGFkb3cteGxcIj5cbiAgICAgICAgICAgIEVtYWlsIE1lXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9hc2lkZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovV29yay9TYXN1ZHVsL3Nhc2Evc2FzdW5kdWwtcG9ydGZvbGlvL2NvbXBvbmVudHMvU29jaWFsRG9jay50c3gifQ==