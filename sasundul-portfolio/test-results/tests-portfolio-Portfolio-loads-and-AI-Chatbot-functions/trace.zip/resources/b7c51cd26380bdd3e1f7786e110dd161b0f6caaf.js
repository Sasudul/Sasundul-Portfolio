import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/ProjectModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { X, ArrowUpRight, Github, Globe, Lock } from "/node_modules/.vite/deps/lucide-react.js?v=5088fc54";
export default function ProjectModal({ project, onClose }) {
  _s();
  const overlayRef = useRef(null);
  const containerRef = useRef(null);
  const [toast, setToast] = useState(null);
  useGSAP(() => {
    document.body.style.overflow = "hidden";
    const tl = gsap.timeline();
    tl.to(overlayRef.current, {
      opacity: 1,
      duration: 0.5,
      ease: "power2.out"
    }).fromTo(containerRef.current, {
      y: "100%",
      opacity: 0
    }, {
      y: "0%",
      opacity: 1,
      duration: 0.8,
      ease: "power4.out"
    }, "-=0.3").from(".modal-element", {
      y: 40,
      opacity: 0,
      stagger: 0.1,
      duration: 0.8,
      ease: "power3.out"
    }, "-=0.4");
    return () => {
      document.body.style.overflow = "";
    };
  }, []);
  const handleClose = () => {
    const tl = gsap.timeline({ onComplete: onClose });
    tl.to(containerRef.current, {
      y: "100%",
      opacity: 0,
      duration: 0.6,
      ease: "power3.in"
    }).to(overlayRef.current, {
      opacity: 0,
      duration: 0.4,
      ease: "power2.in"
    }, "-=0.2");
  };
  const handleLiveClick = (e) => {
    e.preventDefault();
    if (project.liveUrl && project.liveUrl !== "#" && project.liveUrl.startsWith("http")) {
      window.open(project.liveUrl, "_blank", "noopener,noreferrer");
    } else {
      showToast("Live Preview Coming Soon", false);
    }
  };
  const handleGithubClick = (e) => {
    e.preventDefault();
    if (project.githubUrl && project.githubUrl !== "#" && project.githubUrl.startsWith("http")) {
      window.open(project.githubUrl, "_blank", "noopener,noreferrer");
    } else {
      showToast("Private Repository — Coming Soon", true);
    }
  };
  const showToast = (message, isLock = false) => {
    setToast({ message, isLock });
    setTimeout(() => setToast(null), 3e3);
  };
  const hasLiveUrl = Boolean(project.liveUrl && project.liveUrl !== "#" && project.liveUrl.startsWith("http"));
  const hasGithubUrl = Boolean(project.githubUrl && project.githubUrl !== "#" && project.githubUrl.startsWith("http"));
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: overlayRef,
      className: "fixed inset-0 z-[100] bg-black/95 flex items-end md:items-center justify-center backdrop-blur-xl opacity-0 overflow-y-auto overflow-x-hidden pt-20 pb-0 md:py-10 px-0 md:px-6 cursor-auto",
      children: [
        toast && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-8 left-1/2 -translate-x-1/2 z-[200] px-6 py-3 bg-[#0d0d0d]/95 border border-white/20 text-white font-mono text-xs font-bold uppercase tracking-widest rounded-full shadow-[0_10px_40px_rgba(0,0,0,0.9)] backdrop-blur-2xl flex items-center gap-3 animate-bounce", children: [
          toast.isLock ? /* @__PURE__ */ jsxDEV(Lock, { size: 15, className: "text-white/80" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
            lineNumber: 93,
            columnNumber: 27
          }, this) : /* @__PURE__ */ jsxDEV(Globe, { size: 15, className: "text-white/80" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
            lineNumber: 93,
            columnNumber: 74
          }, this),
          toast.message
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
          lineNumber: 92,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "fixed inset-0 cursor-pointer",
            onClick: handleClose
          },
          void 0,
          false,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
            lineNumber: 98,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            ref: containerRef,
            className: "relative w-full max-w-6xl bg-[#0a0a0a] md:border border-white/10 md:rounded-[40px] rounded-t-[40px] shadow-2xl z-10 flex flex-col md:flex-row overflow-hidden min-h-[80vh] md:min-h-0",
            children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleClose,
                  className: "absolute top-6 right-6 text-white bg-white/10 hover:bg-white/20 p-4 rounded-full transition-all hover:rotate-90 z-50 backdrop-blur-md border border-white/10 cursor-pointer",
                  children: /* @__PURE__ */ jsxDEV(X, { size: 24 }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                    lineNumber: 111,
                    columnNumber: 11
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 107,
                  columnNumber: 9
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/2 relative bg-[#111] min-h-[300px] md:min-h-full modal-element flex-shrink-0 overflow-hidden flex items-center justify-center", children: [
                /* @__PURE__ */ jsxDEV("img", { src: project.image, alt: project.title, className: "absolute inset-0 w-full h-full object-cover filter blur-2xl opacity-40 scale-125" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 116,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("img", { src: project.image, alt: project.title, className: "relative z-10 w-full h-full object-contain p-4" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 117,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-t from-[#0a0a0a]/80 via-transparent to-transparent z-20 pointer-events-none" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 118,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                lineNumber: 115,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/2 p-8 md:p-16 flex flex-col justify-center bg-[#0a0a0a] relative z-10", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "modal-element", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-white/60 text-xs font-mono uppercase font-bold tracking-widest mb-6 flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-8 h-[1.5px] bg-white/40" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                      lineNumber: 125,
                      columnNumber: 15
                    }, this),
                    project.category
                  ] }, void 0, true, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                    lineNumber: 124,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "text-5xl md:text-7xl font-display font-bold uppercase tracking-tighter text-white mb-6 leading-[0.85]", children: project.title }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                    lineNumber: 128,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 123,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "modal-element mb-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-300 text-base md:text-lg font-medium leading-relaxed font-sans", children: project.description || `A comprehensive deep-dive into ${project.title}. Designed with an emphasis on seamless user experience, high-performance architecture, and elegant visual aesthetics.` }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 132,
                  columnNumber: 13
                }, this) }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 131,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "modal-element grid grid-cols-2 gap-8 mb-10 border-y border-white/10 py-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-gray-400 text-xs font-mono uppercase tracking-widest mb-3", children: "Technologies" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                      lineNumber: 139,
                      columnNumber: 15
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: project.tech.split("•").map(
                      (t) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-white uppercase tracking-widest bg-white/5 px-3 py-1 rounded-full border border-white/10", children: t.trim() }, t, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                        lineNumber: 142,
                        columnNumber: 17
                      }, this)
                    ) }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                      lineNumber: 140,
                      columnNumber: 15
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                    lineNumber: 138,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-gray-400 text-xs font-mono uppercase tracking-widest mb-3", children: "Year & Role" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                      lineNumber: 147,
                      columnNumber: 15
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-white font-mono text-sm uppercase", children: [
                      project.year || "2025",
                      " • Lead Developer"
                    ] }, void 0, true, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                      lineNumber: 148,
                      columnNumber: 15
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                    lineNumber: 146,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 137,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "modal-element flex items-center gap-4 mt-auto", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: handleLiveClick,
                      className: `flex-1 py-4 px-6 uppercase font-bold font-mono text-xs tracking-widest transition-all duration-300 flex items-center justify-center gap-3 rounded-full cursor-pointer ${hasLiveUrl ? "bg-white text-black hover:bg-white/90 shadow-lg" : "bg-white/10 text-white hover:bg-white/20 border border-white/20"}`,
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { children: hasLiveUrl ? "Live Preview" : "Live Preview (Coming Soon)" }, void 0, false, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                          lineNumber: 162,
                          columnNumber: 15
                        }, this),
                        /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 18 }, void 0, false, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                          lineNumber: 163,
                          columnNumber: 15
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                      lineNumber: 154,
                      columnNumber: 13
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: handleGithubClick,
                      className: `w-14 h-14 rounded-full border flex items-center justify-center transition-all cursor-pointer ${hasGithubUrl ? "border-white/30 text-white hover:bg-white hover:text-black" : "border-white/15 text-white/50 hover:border-white/40 hover:text-white bg-white/5"}`,
                      title: hasGithubUrl ? "View Source Code on GitHub" : "Private Repository / Coming Soon",
                      children: /* @__PURE__ */ jsxDEV(Github, { size: 22 }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                        lineNumber: 175,
                        columnNumber: 15
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                      lineNumber: 166,
                      columnNumber: 13
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                  lineNumber: 153,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
                lineNumber: 122,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
            lineNumber: 103,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx",
      lineNumber: 86,
      columnNumber: 5
    },
    this
  );
}
_s(ProjectModal, "wpMnRsCdOTjhTuLaxUlxv1ymvUo=", false, function() {
  return [useGSAP];
});
_c = ProjectModal;
var _c;
$RefreshReg$(_c, "ProjectModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ProjectModal.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEYwQjs7QUE1RjFCLFNBQVNBLFFBQVFDLGdCQUFnQjtBQUNqQyxTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsR0FBR0MsY0FBY0MsUUFBUUMsT0FBT0MsWUFBWTtBQUdyRCx3QkFBd0JDLGFBQWEsRUFBRUMsU0FBU0MsUUFBbUQsR0FBRztBQUFBQyxLQUFBO0FBQ3BHLFFBQU1DLGFBQWFiLE9BQXVCLElBQUk7QUFDOUMsUUFBTWMsZUFBZWQsT0FBdUIsSUFBSTtBQUNoRCxRQUFNLENBQUNlLE9BQU9DLFFBQVEsSUFBSWYsU0FBdUQsSUFBSTtBQUVyRkMsVUFBUSxNQUFNO0FBRVplLGFBQVNDLEtBQUtDLE1BQU1DLFdBQVc7QUFFL0IsVUFBTUMsS0FBS2xCLEtBQUttQixTQUFTO0FBQ3pCRCxPQUFHRSxHQUFHVixXQUFXVyxTQUFTO0FBQUEsTUFDeEJDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLElBQ1IsQ0FBQyxFQUNBQyxPQUFPZCxhQUFhVSxTQUFTO0FBQUEsTUFDNUJLLEdBQUc7QUFBQSxNQUNISixTQUFTO0FBQUEsSUFDWCxHQUFHO0FBQUEsTUFDREksR0FBRztBQUFBLE1BQ0hKLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLElBQ1IsR0FBRyxPQUFPLEVBQ1RHLEtBQUssa0JBQWtCO0FBQUEsTUFDdEJELEdBQUc7QUFBQSxNQUNISixTQUFTO0FBQUEsTUFDVE0sU0FBUztBQUFBLE1BQ1RMLFVBQVU7QUFBQSxNQUNWQyxNQUFNO0FBQUEsSUFDUixHQUFHLE9BQU87QUFFVixXQUFPLE1BQU07QUFDWFYsZUFBU0MsS0FBS0MsTUFBTUMsV0FBVztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNWSxjQUFjQSxNQUFNO0FBQ3hCLFVBQU1YLEtBQUtsQixLQUFLbUIsU0FBUyxFQUFFVyxZQUFZdEIsUUFBUSxDQUFDO0FBQ2hEVSxPQUFHRSxHQUFHVCxhQUFhVSxTQUFTO0FBQUEsTUFDMUJLLEdBQUc7QUFBQSxNQUNISixTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxJQUNSLENBQUMsRUFDQUosR0FBR1YsV0FBV1csU0FBUztBQUFBLE1BQ3RCQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLE1BQU07QUFBQSxJQUNSLEdBQUcsT0FBTztBQUFBLEVBQ1o7QUFFQSxRQUFNTyxrQkFBa0JBLENBQUNDLE1BQXdCO0FBQy9DQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUkxQixRQUFRMkIsV0FBVzNCLFFBQVEyQixZQUFZLE9BQU8zQixRQUFRMkIsUUFBUUMsV0FBVyxNQUFNLEdBQUc7QUFDcEZDLGFBQU9DLEtBQUs5QixRQUFRMkIsU0FBUyxVQUFVLHFCQUFxQjtBQUFBLElBQzlELE9BQU87QUFDTEksZ0JBQVUsNEJBQTRCLEtBQUs7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxvQkFBb0JBLENBQUNQLE1BQXdCO0FBQ2pEQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUkxQixRQUFRaUMsYUFBYWpDLFFBQVFpQyxjQUFjLE9BQU9qQyxRQUFRaUMsVUFBVUwsV0FBVyxNQUFNLEdBQUc7QUFDMUZDLGFBQU9DLEtBQUs5QixRQUFRaUMsV0FBVyxVQUFVLHFCQUFxQjtBQUFBLElBQ2hFLE9BQU87QUFDTEYsZ0JBQVUsb0NBQW9DLElBQUk7QUFBQSxJQUNwRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNQSxZQUFZQSxDQUFDRyxTQUFpQkMsU0FBUyxVQUFVO0FBQ3JEN0IsYUFBUyxFQUFFNEIsU0FBU0MsT0FBTyxDQUFDO0FBQzVCQyxlQUFXLE1BQU05QixTQUFTLElBQUksR0FBRyxHQUFJO0FBQUEsRUFDdkM7QUFFQSxRQUFNK0IsYUFBYUMsUUFBUXRDLFFBQVEyQixXQUFXM0IsUUFBUTJCLFlBQVksT0FBTzNCLFFBQVEyQixRQUFRQyxXQUFXLE1BQU0sQ0FBQztBQUMzRyxRQUFNVyxlQUFlRCxRQUFRdEMsUUFBUWlDLGFBQWFqQyxRQUFRaUMsY0FBYyxPQUFPakMsUUFBUWlDLFVBQVVMLFdBQVcsTUFBTSxDQUFDO0FBRW5ILFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUt6QjtBQUFBQSxNQUNMLFdBQVU7QUFBQSxNQUdURTtBQUFBQSxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsOFFBQ1pBO0FBQUFBLGdCQUFNOEIsU0FBUyx1QkFBQyxRQUFLLE1BQU0sSUFBSSxXQUFVLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxJQUFNLHVCQUFDLFNBQU0sTUFBTSxJQUFJLFdBQVUsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsVUFDeEc5QixNQUFNNkI7QUFBQUEsYUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUdGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTWjtBQUFBQTtBQUFBQSxVQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdDO0FBQUEsUUFFRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsS0FBS2xCO0FBQUFBLFlBQ0wsV0FBVTtBQUFBLFlBRVY7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTa0I7QUFBQUEsa0JBQ1QsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVk7QUFBQTtBQUFBLGdCQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsK0lBQ2I7QUFBQSx1Q0FBQyxTQUFJLEtBQUt0QixRQUFRd0MsT0FBTyxLQUFLeEMsUUFBUXlDLE9BQU8sV0FBVSxzRkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUk7QUFBQSxnQkFDekksdUJBQUMsU0FBSSxLQUFLekMsUUFBUXdDLE9BQU8sS0FBS3hDLFFBQVF5QyxPQUFPLFdBQVUsb0RBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVHO0FBQUEsZ0JBQ3ZHLHVCQUFDLFNBQUksV0FBVSxpSEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2SDtBQUFBLG1CQUgvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsb0dBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsK0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRDO0FBQUEsb0JBQzNDekMsUUFBUTBDO0FBQUFBLHVCQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUseUdBQXlHMUMsa0JBQVF5QyxTQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxSTtBQUFBLHFCQUx2STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUNiLGlDQUFDLE9BQUUsV0FBVSw0RUFDVnpDLGtCQUFRMkMsZUFBZSxrQ0FBa0MzQyxRQUFReUMsS0FBSyw0SEFEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsNEVBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsUUFBRyxXQUFVLGtFQUFpRSw0QkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkY7QUFBQSxvQkFDM0YsdUJBQUMsU0FBSSxXQUFVLHdCQUNaekMsa0JBQVE0QyxLQUFLQyxNQUFNLEdBQUcsRUFBRUM7QUFBQUEsc0JBQUksQ0FBQUMsTUFDMUIsdUJBQUMsVUFBYSxXQUFVLHlHQUF5R0EsWUFBRUMsS0FBSyxLQUE3SEQsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwSTtBQUFBLG9CQUM1SSxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSxrRUFBaUUsMkJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBGO0FBQUEsb0JBQzFGLHVCQUFDLE9BQUUsV0FBVSwwQ0FBMEMvQztBQUFBQSw4QkFBUWlELFFBQVE7QUFBQSxzQkFBTztBQUFBLHlCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRjtBQUFBLHVCQUZqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVN6QjtBQUFBQSxzQkFDVCxXQUFXLHlLQUNUYSxhQUNJLG9EQUNBLGlFQUFpRTtBQUFBLHNCQUd2RTtBQUFBLCtDQUFDLFVBQU1BLHVCQUFhLGlCQUFpQixnQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBa0U7QUFBQSx3QkFDbEUsdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF1QjtBQUFBO0FBQUE7QUFBQSxvQkFUekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBU0w7QUFBQUEsc0JBQ1QsV0FBVyxnR0FDVE8sZUFDSSwrREFDQSxpRkFBaUY7QUFBQSxzQkFFdkYsT0FBT0EsZUFBZSwrQkFBK0I7QUFBQSxzQkFFckQsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUI7QUFBQTtBQUFBLG9CQVRuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxxQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3QkE7QUFBQSxtQkF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5REE7QUFBQTtBQUFBO0FBQUEsVUE1RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBNkVBO0FBQUE7QUFBQTtBQUFBLElBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQStGQTtBQUVKO0FBQUNyQyxHQWhMdUJILGNBQVk7QUFBQSxVQUtsQ1AsT0FBTztBQUFBO0FBQUEwRCxLQUxlbkQ7QUFBWSxJQUFBbUQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVJlZiIsInVzZVN0YXRlIiwidXNlR1NBUCIsImdzYXAiLCJYIiwiQXJyb3dVcFJpZ2h0IiwiR2l0aHViIiwiR2xvYmUiLCJMb2NrIiwiUHJvamVjdE1vZGFsIiwicHJvamVjdCIsIm9uQ2xvc2UiLCJfcyIsIm92ZXJsYXlSZWYiLCJjb250YWluZXJSZWYiLCJ0b2FzdCIsInNldFRvYXN0IiwiZG9jdW1lbnQiLCJib2R5Iiwic3R5bGUiLCJvdmVyZmxvdyIsInRsIiwidGltZWxpbmUiLCJ0byIsImN1cnJlbnQiLCJvcGFjaXR5IiwiZHVyYXRpb24iLCJlYXNlIiwiZnJvbVRvIiwieSIsImZyb20iLCJzdGFnZ2VyIiwiaGFuZGxlQ2xvc2UiLCJvbkNvbXBsZXRlIiwiaGFuZGxlTGl2ZUNsaWNrIiwiZSIsInByZXZlbnREZWZhdWx0IiwibGl2ZVVybCIsInN0YXJ0c1dpdGgiLCJ3aW5kb3ciLCJvcGVuIiwic2hvd1RvYXN0IiwiaGFuZGxlR2l0aHViQ2xpY2siLCJnaXRodWJVcmwiLCJtZXNzYWdlIiwiaXNMb2NrIiwic2V0VGltZW91dCIsImhhc0xpdmVVcmwiLCJCb29sZWFuIiwiaGFzR2l0aHViVXJsIiwiaW1hZ2UiLCJ0aXRsZSIsImNhdGVnb3J5IiwiZGVzY3JpcHRpb24iLCJ0ZWNoIiwic3BsaXQiLCJtYXAiLCJ0IiwidHJpbSIsInllYXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9qZWN0TW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VHU0FQIH0gZnJvbSAnQGdzYXAvcmVhY3QnO1xuaW1wb3J0IGdzYXAgZnJvbSAnZ3NhcCc7XG5pbXBvcnQgeyBYLCBBcnJvd1VwUmlnaHQsIEdpdGh1YiwgR2xvYmUsIExvY2sgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgUHJvamVjdCB9IGZyb20gJy4uL0FwcCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByb2plY3RNb2RhbCh7IHByb2plY3QsIG9uQ2xvc2UgfTogeyBwcm9qZWN0OiBQcm9qZWN0LCBvbkNsb3NlOiAoKSA9PiB2b2lkIH0pIHtcbiAgY29uc3Qgb3ZlcmxheVJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG4gIGNvbnN0IGNvbnRhaW5lclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG4gIGNvbnN0IFt0b2FzdCwgc2V0VG9hc3RdID0gdXNlU3RhdGU8eyBtZXNzYWdlOiBzdHJpbmc7IGlzTG9jaz86IGJvb2xlYW4gfSB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUdTQVAoKCkgPT4ge1xuICAgIC8vIFByZXZlbnQgc2Nyb2xsIG9uIGJvZHlcbiAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gXCJoaWRkZW5cIjtcblxuICAgIGNvbnN0IHRsID0gZ3NhcC50aW1lbGluZSgpO1xuICAgIHRsLnRvKG92ZXJsYXlSZWYuY3VycmVudCwge1xuICAgICAgb3BhY2l0eTogMSxcbiAgICAgIGR1cmF0aW9uOiAwLjUsXG4gICAgICBlYXNlOiAncG93ZXIyLm91dCdcbiAgICB9KVxuICAgIC5mcm9tVG8oY29udGFpbmVyUmVmLmN1cnJlbnQsIHtcbiAgICAgIHk6ICcxMDAlJyxcbiAgICAgIG9wYWNpdHk6IDAsXG4gICAgfSwge1xuICAgICAgeTogJzAlJyxcbiAgICAgIG9wYWNpdHk6IDEsXG4gICAgICBkdXJhdGlvbjogMC44LFxuICAgICAgZWFzZTogJ3Bvd2VyNC5vdXQnXG4gICAgfSwgXCItPTAuM1wiKVxuICAgIC5mcm9tKCcubW9kYWwtZWxlbWVudCcsIHtcbiAgICAgIHk6IDQwLFxuICAgICAgb3BhY2l0eTogMCxcbiAgICAgIHN0YWdnZXI6IDAuMSxcbiAgICAgIGR1cmF0aW9uOiAwLjgsXG4gICAgICBlYXNlOiAncG93ZXIzLm91dCdcbiAgICB9LCBcIi09MC40XCIpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcIlwiO1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZUNsb3NlID0gKCkgPT4ge1xuICAgIGNvbnN0IHRsID0gZ3NhcC50aW1lbGluZSh7IG9uQ29tcGxldGU6IG9uQ2xvc2UgfSk7XG4gICAgdGwudG8oY29udGFpbmVyUmVmLmN1cnJlbnQsIHtcbiAgICAgIHk6ICcxMDAlJyxcbiAgICAgIG9wYWNpdHk6IDAsXG4gICAgICBkdXJhdGlvbjogMC42LFxuICAgICAgZWFzZTogJ3Bvd2VyMy5pbidcbiAgICB9KVxuICAgIC50byhvdmVybGF5UmVmLmN1cnJlbnQsIHtcbiAgICAgIG9wYWNpdHk6IDAsXG4gICAgICBkdXJhdGlvbjogMC40LFxuICAgICAgZWFzZTogJ3Bvd2VyMi5pbidcbiAgICB9LCBcIi09MC4yXCIpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxpdmVDbGljayA9IChlOiBSZWFjdC5Nb3VzZUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmIChwcm9qZWN0LmxpdmVVcmwgJiYgcHJvamVjdC5saXZlVXJsICE9PSAnIycgJiYgcHJvamVjdC5saXZlVXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xuICAgICAgd2luZG93Lm9wZW4ocHJvamVjdC5saXZlVXJsLCAnX2JsYW5rJywgJ25vb3BlbmVyLG5vcmVmZXJyZXInKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2hvd1RvYXN0KCdMaXZlIFByZXZpZXcgQ29taW5nIFNvb24nLCBmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUdpdGh1YkNsaWNrID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKHByb2plY3QuZ2l0aHViVXJsICYmIHByb2plY3QuZ2l0aHViVXJsICE9PSAnIycgJiYgcHJvamVjdC5naXRodWJVcmwuc3RhcnRzV2l0aCgnaHR0cCcpKSB7XG4gICAgICB3aW5kb3cub3Blbihwcm9qZWN0LmdpdGh1YlVybCwgJ19ibGFuaycsICdub29wZW5lcixub3JlZmVycmVyJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNob3dUb2FzdCgnUHJpdmF0ZSBSZXBvc2l0b3J5IOKAlCBDb21pbmcgU29vbicsIHRydWUpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBzaG93VG9hc3QgPSAobWVzc2FnZTogc3RyaW5nLCBpc0xvY2sgPSBmYWxzZSkgPT4ge1xuICAgIHNldFRvYXN0KHsgbWVzc2FnZSwgaXNMb2NrIH0pO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VG9hc3QobnVsbCksIDMwMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhc0xpdmVVcmwgPSBCb29sZWFuKHByb2plY3QubGl2ZVVybCAmJiBwcm9qZWN0LmxpdmVVcmwgIT09ICcjJyAmJiBwcm9qZWN0LmxpdmVVcmwuc3RhcnRzV2l0aCgnaHR0cCcpKTtcbiAgY29uc3QgaGFzR2l0aHViVXJsID0gQm9vbGVhbihwcm9qZWN0LmdpdGh1YlVybCAmJiBwcm9qZWN0LmdpdGh1YlVybCAhPT0gJyMnICYmIHByb2plY3QuZ2l0aHViVXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IFxuICAgICAgcmVmPXtvdmVybGF5UmVmfSBcbiAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bMTAwXSBiZy1ibGFjay85NSBmbGV4IGl0ZW1zLWVuZCBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmFja2Ryb3AtYmx1ci14bCBvcGFjaXR5LTAgb3ZlcmZsb3cteS1hdXRvIG92ZXJmbG93LXgtaGlkZGVuIHB0LTIwIHBiLTAgbWQ6cHktMTAgcHgtMCBtZDpweC02IGN1cnNvci1hdXRvXCJcbiAgICA+XG4gICAgICB7LyogVG9hc3QgTm90aWZpY2F0aW9uICovfVxuICAgICAge3RvYXN0ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtOCBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHotWzIwMF0gcHgtNiBweS0zIGJnLVsjMGQwZDBkXS85NSBib3JkZXIgYm9yZGVyLXdoaXRlLzIwIHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3Qgcm91bmRlZC1mdWxsIHNoYWRvdy1bMF8xMHB4XzQwcHhfcmdiYSgwLDAsMCwwLjkpXSBiYWNrZHJvcC1ibHVyLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBhbmltYXRlLWJvdW5jZVwiPlxuICAgICAgICAgIHt0b2FzdC5pc0xvY2sgPyA8TG9jayBzaXplPXsxNX0gY2xhc3NOYW1lPVwidGV4dC13aGl0ZS84MFwiIC8+IDogPEdsb2JlIHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzgwXCIgLz59XG4gICAgICAgICAge3RvYXN0Lm1lc3NhZ2V9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlfVxuICAgICAgPjwvZGl2PlxuICAgICAgXG4gICAgICA8ZGl2IFxuICAgICAgICByZWY9e2NvbnRhaW5lclJlZn1cbiAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LTZ4bCBiZy1bIzBhMGEwYV0gbWQ6Ym9yZGVyIGJvcmRlci13aGl0ZS8xMCBtZDpyb3VuZGVkLVs0MHB4XSByb3VuZGVkLXQtWzQwcHhdIHNoYWRvdy0yeGwgei0xMCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG92ZXJmbG93LWhpZGRlbiBtaW4taC1bODB2aF0gbWQ6bWluLWgtMFwiXG4gICAgICA+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2V9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTYgcmlnaHQtNiB0ZXh0LXdoaXRlIGJnLXdoaXRlLzEwIGhvdmVyOmJnLXdoaXRlLzIwIHAtNCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgaG92ZXI6cm90YXRlLTkwIHotNTAgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxYIHNpemU9ezI0fSAvPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogTGVmdCBTaWRlOiBJbWFnZSAvIE1lZGlhICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvMiByZWxhdGl2ZSBiZy1bIzExMV0gbWluLWgtWzMwMHB4XSBtZDptaW4taC1mdWxsIG1vZGFsLWVsZW1lbnQgZmxleC1zaHJpbmstMCBvdmVyZmxvdy1oaWRkZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICA8aW1nIHNyYz17cHJvamVjdC5pbWFnZX0gYWx0PXtwcm9qZWN0LnRpdGxlfSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIGZpbHRlciBibHVyLTJ4bCBvcGFjaXR5LTQwIHNjYWxlLTEyNVwiIC8+XG4gICAgICAgICAgPGltZyBzcmM9e3Byb2plY3QuaW1hZ2V9IGFsdD17cHJvamVjdC50aXRsZX0gY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCB3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb250YWluIHAtNFwiIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWdyYWRpZW50LXRvLXQgZnJvbS1bIzBhMGEwYV0vODAgdmlhLXRyYW5zcGFyZW50IHRvLXRyYW5zcGFyZW50IHotMjAgcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUmlnaHQgU2lkZTogRGV0YWlscyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWQ6dy0xLzIgcC04IG1kOnAtMTYgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBiZy1bIzBhMGEwYV0gcmVsYXRpdmUgei0xMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtZWxlbWVudFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzYwIHRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSBmb250LWJvbGQgdHJhY2tpbmctd2lkZXN0IG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy04IGgtWzEuNXB4XSBiZy13aGl0ZS80MFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAge3Byb2plY3QuY2F0ZWdvcnl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTV4bCBtZDp0ZXh0LTd4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy10aWdodGVyIHRleHQtd2hpdGUgbWItNiBsZWFkaW5nLVswLjg1XVwiPntwcm9qZWN0LnRpdGxlfTwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWVsZW1lbnQgbWItOFwiPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTMwMCB0ZXh0LWJhc2UgbWQ6dGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLXJlbGF4ZWQgZm9udC1zYW5zXCI+XG4gICAgICAgICAgICAgIHtwcm9qZWN0LmRlc2NyaXB0aW9uIHx8IGBBIGNvbXByZWhlbnNpdmUgZGVlcC1kaXZlIGludG8gJHtwcm9qZWN0LnRpdGxlfS4gRGVzaWduZWQgd2l0aCBhbiBlbXBoYXNpcyBvbiBzZWFtbGVzcyB1c2VyIGV4cGVyaWVuY2UsIGhpZ2gtcGVyZm9ybWFuY2UgYXJjaGl0ZWN0dXJlLCBhbmQgZWxlZ2FudCB2aXN1YWwgYWVzdGhldGljcy5gfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1lbGVtZW50IGdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTggbWItMTAgYm9yZGVyLXkgYm9yZGVyLXdoaXRlLzEwIHB5LTZcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgbWItM1wiPlRlY2hub2xvZ2llczwvaDQ+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICB7cHJvamVjdC50ZWNoLnNwbGl0KCfigKInKS5tYXAodCA9PiAoXG4gICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXt0fSBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBiZy13aGl0ZS81IHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci13aGl0ZS8xMFwiPnt0LnRyaW0oKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LXhzIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IG1iLTNcIj5ZZWFyICYgUm9sZTwvaDQ+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1tb25vIHRleHQtc20gdXBwZXJjYXNlXCI+e3Byb2plY3QueWVhciB8fCAnMjAyNSd9IOKAoiBMZWFkIERldmVsb3BlcjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtZWxlbWVudCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtdC1hdXRvXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxpdmVDbGlja31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTQgcHgtNiB1cHBlcmNhc2UgZm9udC1ib2xkIGZvbnQtbW9ubyB0ZXh0LXhzIHRyYWNraW5nLXdpZGVzdCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgcm91bmRlZC1mdWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgaGFzTGl2ZVVybCBcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIHRleHQtYmxhY2sgaG92ZXI6Ymctd2hpdGUvOTAgc2hhZG93LWxnJyBcbiAgICAgICAgICAgICAgICAgIDogJ2JnLXdoaXRlLzEwIHRleHQtd2hpdGUgaG92ZXI6Ymctd2hpdGUvMjAgYm9yZGVyIGJvcmRlci13aGl0ZS8yMCdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPntoYXNMaXZlVXJsID8gJ0xpdmUgUHJldmlldycgOiAnTGl2ZSBQcmV2aWV3IChDb21pbmcgU29vbiknfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUdpdGh1YkNsaWNrfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTE0IGgtMTQgcm91bmRlZC1mdWxsIGJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGhhc0dpdGh1YlVybCBcbiAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci13aGl0ZS8zMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLXdoaXRlIGhvdmVyOnRleHQtYmxhY2snIFxuICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXdoaXRlLzE1IHRleHQtd2hpdGUvNTAgaG92ZXI6Ym9yZGVyLXdoaXRlLzQwIGhvdmVyOnRleHQtd2hpdGUgYmctd2hpdGUvNSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgIHRpdGxlPXtoYXNHaXRodWJVcmwgPyAnVmlldyBTb3VyY2UgQ29kZSBvbiBHaXRIdWInIDogJ1ByaXZhdGUgUmVwb3NpdG9yeSAvIENvbWluZyBTb29uJ31cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEdpdGh1YiBzaXplPXsyMn0gLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L1dvcmsvU2FzdWR1bC9zYXNhL3Nhc3VuZHVsLXBvcnRmb2xpby9jb21wb25lbnRzL1Byb2plY3RNb2RhbC50c3gifQ==