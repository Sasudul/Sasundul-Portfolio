import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/PixelBlast.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "D:/Work/Sasudul/sasa/sasundul-portfolio/components/PixelBlast.css"
const __vite__css = ".pixel-blast-container {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n  z-index: 0; /* Sit behind the content */\n  pointer-events: auto; /* Allow interaction */\n}\n\n.pixel-blast-container canvas {\n  display: block;\n  width: 100%;\n  height: 100%;\n  outline: none;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))