import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/WorkShowcase.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { ExternalLink } from "/node_modules/.vite/deps/lucide-react.js?v=5088fc54";
export default function WorkShowcase({ projects, onProjectClick }) {
  _s();
  const [activeIndex, setActiveIndex] = useState(0);
  const sectionRef = useRef(null);
  useGSAP(() => {
    gsap.fromTo(".work-showcase-title", {
      y: 30,
      opacity: 0
    }, {
      y: 0,
      opacity: 1,
      duration: 0.8,
      ease: "power3.out",
      scrollTrigger: {
        trigger: sectionRef.current,
        start: "top 75%"
      }
    });
    gsap.fromTo(".work-showcase-card", {
      y: 50,
      opacity: 0,
      scale: 0.96
    }, {
      y: 0,
      opacity: 1,
      scale: 1,
      duration: 1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: ".work-showcase-card",
        start: "top 80%"
      }
    });
  }, { scope: sectionRef });
  const goTo = (index) => {
    if (index === activeIndex) return;
    setActiveIndex(index);
  };
  const goNext = () => goTo((activeIndex + 1) % projects.length);
  const goPrev = () => goTo((activeIndex - 1 + projects.length) % projects.length);
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (["INPUT", "TEXTAREA"].includes(e.target?.tagName)) return;
      if (e.key === "ArrowLeft") {
        goPrev();
      } else if (e.key === "ArrowRight") {
        goNext();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeIndex, projects.length]);
  const activeProject = projects[activeIndex];
  return /* @__PURE__ */ jsxDEV("section", { ref: sectionRef, id: "work", className: "relative min-h-screen py-10 px-4 md:px-12 flex flex-col justify-between overflow-hidden bg-[#050505] text-white", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "w-full py-3 overflow-hidden border-b border-white/10 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "marquee__inner", style: { "--marquee-duration": "18s" }, children: [...Array(8)].map(
      (_, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 px-6 flex-shrink-0", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono uppercase tracking-widest text-white/50 whitespace-nowrap", children: "Featured Case Studies" }, void 0, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
          lineNumber: 83,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("svg", { width: "16", height: "12", viewBox: "0 0 125 95", fill: "none", className: "text-white/30", children: [
          /* @__PURE__ */ jsxDEV("path", { d: "M73.6748 89.7824L116.207 47.2501L73.6748 4.71783", stroke: "currentColor", strokeWidth: "12", strokeMiterlimit: "10" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 85,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("path", { d: "M116.207 47.25L0.762451 47.25", stroke: "currentColor", strokeWidth: "12", strokeMiterlimit: "10" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 86,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
          lineNumber: 84,
          columnNumber: 15
        }, this)
      ] }, i, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
        lineNumber: 82,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
      lineNumber: 80,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-0 pointer-events-none overflow-hidden", children: [
      projects.map(
        (p, i) => /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: p.image,
            alt: "",
            className: `absolute inset-0 w-full h-full object-cover filter blur-[100px] scale-125 transition-opacity duration-1000 ${i === activeIndex ? "opacity-35" : "opacity-0"}`
          },
          `ambient-${p.id}`,
          false,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 96,
            columnNumber: 9
          },
          this
        )
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-b from-[#050505]/70 via-transparent to-[#050505]/90" }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
        lineNumber: 103,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 max-w-7xl mx-auto w-full flex flex-col items-center gap-4 my-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "work-showcase-title flex flex-col md:flex-row items-center justify-between w-full gap-4 px-2", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-white/60 text-xs font-mono font-bold uppercase tracking-widest flex items-center gap-2 mb-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-6 h-[2px] bg-white/40" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
              lineNumber: 113,
              columnNumber: 15
            }, this),
            "Project ",
            String(activeIndex + 1).padStart(2, "0"),
            " / ",
            String(projects.length).padStart(2, "0"),
            " • ",
            activeProject.category
          ] }, void 0, true, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 112,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl md:text-5xl font-display font-bold uppercase tracking-tighter text-white", children: activeProject.title }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 116,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
          lineNumber: 111,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-gray-400 uppercase tracking-widest hidden md:inline-block", children: activeProject.tech }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 122,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => onProjectClick(activeProject),
              className: "flex items-center gap-2 text-xs font-bold uppercase tracking-widest bg-white/10 hover:bg-white text-white hover:text-black border border-white/20 px-5 py-2.5 rounded-full transition-all duration-300 backdrop-blur-md cursor-pointer",
              children: [
                "Explore Project ",
                /* @__PURE__ */ jsxDEV(ExternalLink, { size: 14 }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
                  lineNumber: 127,
                  columnNumber: 31
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
              lineNumber: 123,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
          lineNumber: 121,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => onProjectClick(activeProject),
          className: "work-showcase-card group relative w-full max-w-6xl aspect-[16/9] max-h-[62vh] rounded-2xl md:rounded-3xl overflow-hidden border border-white/15 bg-black/60 shadow-[0_20px_60px_rgba(0,0,0,0.6)] backdrop-blur-md cursor-pointer transition-all duration-500 hover:border-white/40 hover:shadow-[0_25px_80px_rgba(255,255,255,0.08)] flex items-center justify-center p-2 md:p-4",
          children: [
            projects.map(
              (p, i) => /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: p.image,
                  alt: p.title,
                  className: `w-full h-full object-contain transition-all duration-700 rounded-xl ${i === activeIndex ? "opacity-100 scale-100" : "opacity-0 scale-98 absolute inset-0"}`
                },
                p.id,
                false,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
                  lineNumber: 138,
                  columnNumber: 11
                },
                this
              )
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6 pointer-events-none", children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold uppercase tracking-widest text-white bg-black/60 border border-white/20 px-5 py-2 rounded-full backdrop-blur-md shadow-lg", children: "Click to Open Full View" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
              lineNumber: 148,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
              lineNumber: 147,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
          lineNumber: 133,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "w-full flex items-center justify-center overflow-x-auto pb-2 pt-1 hide-scrollbar px-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: projects.map(
        (p, i) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => goTo(i),
            className: `relative flex-shrink-0 w-20 h-14 md:w-28 md:h-18 rounded-xl overflow-hidden border transition-all duration-500 cursor-pointer ${i === activeIndex ? "border-white ring-2 ring-white/30 scale-105 opacity-100 shadow-lg shadow-white/10" : "border-white/10 opacity-40 hover:opacity-80"}`,
            children: /* @__PURE__ */ jsxDEV("img", { src: p.image, alt: p.title, className: "w-full h-full object-cover transition-transform duration-500 hover:scale-105" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
              lineNumber: 163,
              columnNumber: 17
            }, this)
          },
          p.id,
          false,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 158,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
        lineNumber: 156,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
        lineNumber: 155,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-8 md:gap-12 mt-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: goPrev,
            className: "text-white/60 hover:text-white text-xs md:text-sm font-mono uppercase tracking-widest transition-all duration-300 flex items-center gap-2 cursor-pointer group py-2",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "group-hover:-translate-x-1.5 transition-transform duration-300", children: "←" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
                lineNumber: 175,
                columnNumber: 13
              }, this),
              " PREV"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 171,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => onProjectClick(activeProject),
            className: "text-xs md:text-sm font-mono uppercase tracking-widest text-white/80 hover:text-white border border-white/20 hover:border-white/50 hover:bg-white/10 px-8 py-2.5 rounded-full transition-all duration-300 backdrop-blur-md cursor-pointer shadow-sm",
            children: "EXPLORE"
          },
          void 0,
          false,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 178,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: goNext,
            className: "text-white/60 hover:text-white text-xs md:text-sm font-mono uppercase tracking-widest transition-all duration-300 flex items-center gap-2 cursor-pointer group py-2",
            children: [
              "NEXT ",
              /* @__PURE__ */ jsxDEV("span", { className: "group-hover:translate-x-1.5 transition-transform duration-300", children: "→" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
                lineNumber: 189,
                columnNumber: 18
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
            lineNumber: 185,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
        lineNumber: 170,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
      lineNumber: 107,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx",
    lineNumber: 77,
    columnNumber: 5
  }, this);
}
_s(WorkShowcase, "PWSgeX2U5pmBxXaafOzlBzqMfMU=", false, function() {
  return [useGSAP];
});
_c = WorkShowcase;
var _c;
$RefreshReg$(_c, "WorkShowcase");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/WorkShowcase.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZjOztBQWxGZCxTQUFTQSxVQUFVQyxRQUFRQyxpQkFBaUI7QUFDNUMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxVQUFVO0FBRWpCLFNBQVNDLG9CQUFvQjtBQVE3Qix3QkFBd0JDLGFBQWEsRUFBRUMsVUFBVUMsZUFBa0MsR0FBRztBQUFBQyxLQUFBO0FBQ3BGLFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJWCxTQUFTLENBQUM7QUFDaEQsUUFBTVksYUFBYVgsT0FBb0IsSUFBSTtBQUUzQ0UsVUFBUSxNQUFNO0FBQ1pDLFNBQUtTLE9BQU8sd0JBQXdCO0FBQUEsTUFDbENDLEdBQUc7QUFBQSxNQUNIQyxTQUFTO0FBQUEsSUFDWCxHQUFHO0FBQUEsTUFDREQsR0FBRztBQUFBLE1BQ0hDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLE1BQ05DLGVBQWU7QUFBQSxRQUNiQyxTQUFTUCxXQUFXUTtBQUFBQSxRQUNwQkMsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGLENBQUM7QUFFRGpCLFNBQUtTLE9BQU8sdUJBQXVCO0FBQUEsTUFDakNDLEdBQUc7QUFBQSxNQUNIQyxTQUFTO0FBQUEsTUFDVE8sT0FBTztBQUFBLElBQ1QsR0FBRztBQUFBLE1BQ0RSLEdBQUc7QUFBQSxNQUNIQyxTQUFTO0FBQUEsTUFDVE8sT0FBTztBQUFBLE1BQ1BOLFVBQVU7QUFBQSxNQUNWQyxNQUFNO0FBQUEsTUFDTkMsZUFBZTtBQUFBLFFBQ2JDLFNBQVM7QUFBQSxRQUNURSxPQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxFQUFFRSxPQUFPWCxXQUFXLENBQUM7QUFFeEIsUUFBTVksT0FBT0EsQ0FBQ0MsVUFBa0I7QUFDOUIsUUFBSUEsVUFBVWYsWUFBYTtBQUMzQkMsbUJBQWVjLEtBQUs7QUFBQSxFQUN0QjtBQUVBLFFBQU1DLFNBQVNBLE1BQU1GLE1BQU1kLGNBQWMsS0FBS0gsU0FBU29CLE1BQU07QUFDN0QsUUFBTUMsU0FBU0EsTUFBTUosTUFBTWQsY0FBYyxJQUFJSCxTQUFTb0IsVUFBVXBCLFNBQVNvQixNQUFNO0FBRy9FekIsWUFBVSxNQUFNO0FBQ2QsVUFBTTJCLGdCQUFnQkEsQ0FBQ0MsTUFBcUI7QUFFMUMsVUFBSSxDQUFDLFNBQVMsVUFBVSxFQUFFQyxTQUFVRCxFQUFFRSxRQUF3QkMsT0FBTyxFQUFHO0FBRXhFLFVBQUlILEVBQUVJLFFBQVEsYUFBYTtBQUN6Qk4sZUFBTztBQUFBLE1BQ1QsV0FBV0UsRUFBRUksUUFBUSxjQUFjO0FBQ2pDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQVMsV0FBT0MsaUJBQWlCLFdBQVdQLGFBQWE7QUFDaEQsV0FBTyxNQUFNTSxPQUFPRSxvQkFBb0IsV0FBV1IsYUFBYTtBQUFBLEVBQ2xFLEdBQUcsQ0FBQ25CLGFBQWFILFNBQVNvQixNQUFNLENBQUM7QUFFakMsUUFBTVcsZ0JBQWdCL0IsU0FBU0csV0FBVztBQUUxQyxTQUNFLHVCQUFDLGFBQVEsS0FBS0UsWUFBWSxJQUFHLFFBQU8sV0FBVSxtSEFFNUM7QUFBQSwyQkFBQyxTQUFJLFdBQVUsNkRBQ2IsaUNBQUMsU0FBSSxXQUFVLGtCQUFpQixPQUFPLEVBQUUsc0JBQXNCLE1BQU0sR0FDbEUsV0FBQyxHQUFHMkIsTUFBTSxDQUFDLENBQUMsRUFBRUM7QUFBQUEsTUFBSSxDQUFDQyxHQUFHQyxNQUNyQix1QkFBQyxTQUFZLFdBQVUsOENBQ3JCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLCtFQUE4RSxxQ0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSDtBQUFBLFFBQ25ILHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGNBQWEsTUFBSyxRQUFPLFdBQVUsaUJBQ3JFO0FBQUEsaUNBQUMsVUFBSyxHQUFFLG9EQUFtRCxRQUFPLGdCQUFlLGFBQVksTUFBSyxrQkFBaUIsUUFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUg7QUFBQSxVQUN2SCx1QkFBQyxVQUFLLEdBQUUsaUNBQWdDLFFBQU8sZ0JBQWUsYUFBWSxNQUFLLGtCQUFpQixRQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLGFBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTFFBLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsSUFDRCxLQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDREQUNabkM7QUFBQUEsZUFBU2lDO0FBQUFBLFFBQUksQ0FBQ0csR0FBR0QsTUFDaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLEtBQUtDLEVBQUVDO0FBQUFBLFlBQ1AsS0FBSTtBQUFBLFlBQ0osV0FBVyw4R0FBOEdGLE1BQU1oQyxjQUFjLGVBQWUsV0FBVztBQUFBO0FBQUEsVUFIbEssV0FBV2lDLEVBQUVFLEVBQUU7QUFBQSxVQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTRLO0FBQUEsTUFFN0s7QUFBQSxNQUNELHVCQUFDLFNBQUksV0FBVSx5RkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9HO0FBQUEsU0FUdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsbUZBR2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0dBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG9HQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDZCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLFlBQU07QUFBQSxZQUN2Q0MsT0FBT3BDLGNBQWMsQ0FBQyxFQUFFcUMsU0FBUyxHQUFHLEdBQUc7QUFBQSxZQUFFO0FBQUEsWUFBSUQsT0FBT3ZDLFNBQVNvQixNQUFNLEVBQUVvQixTQUFTLEdBQUcsR0FBRztBQUFBLFlBQUU7QUFBQSxZQUFJVCxjQUFjVTtBQUFBQSxlQUZuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUscUZBQ1hWLHdCQUFjVyxTQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxvRkFBb0ZYLHdCQUFjWSxRQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1SDtBQUFBLFVBQ3ZIO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU0xQyxlQUFlOEIsYUFBYTtBQUFBLGNBQzNDLFdBQVU7QUFBQSxjQUF3TztBQUFBO0FBQUEsZ0JBRWxPLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUI7QUFBQTtBQUFBO0FBQUEsWUFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxNQUdBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU05QixlQUFlOEIsYUFBYTtBQUFBLFVBQzNDLFdBQVU7QUFBQSxVQUVUL0I7QUFBQUEscUJBQVNpQztBQUFBQSxjQUFJLENBQUNHLEdBQUdELE1BQ2hCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLEtBQUtDLEVBQUVDO0FBQUFBLGtCQUNQLEtBQUtELEVBQUVNO0FBQUFBLGtCQUNQLFdBQVcsdUVBQXVFUCxNQUFNaEMsY0FBYywwQkFBMEIscUNBQXFDO0FBQUE7QUFBQSxnQkFIaEtpQyxFQUFFRTtBQUFBQSxnQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTBLO0FBQUEsWUFFM0s7QUFBQSxZQUdELHVCQUFDLFNBQUksV0FBVSwyTUFDYixpQ0FBQyxVQUFLLFdBQVUsK0lBQTZJLHVDQUE3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBO0FBQUE7QUFBQSxRQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFtQkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx5RkFDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ1p0QyxtQkFBU2lDO0FBQUFBLFFBQUksQ0FBQ0csR0FBR0QsTUFDaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFNBQVMsTUFBTWxCLEtBQUtrQixDQUFDO0FBQUEsWUFDckIsV0FBVyxpSUFBaUlBLE1BQU1oQyxjQUFjLHNGQUFzRiw2Q0FBNkM7QUFBQSxZQUVuUyxpQ0FBQyxTQUFJLEtBQUtpQyxFQUFFQyxPQUFPLEtBQUtELEVBQUVNLE9BQU8sV0FBVSxrRkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUg7QUFBQTtBQUFBLFVBSnBITixFQUFFRTtBQUFBQSxVQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLE1BQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTakI7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFVBQUssV0FBVSxrRUFBaUUsaUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsY0FBTztBQUFBO0FBQUE7QUFBQSxVQUozRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTXBCLGVBQWU4QixhQUFhO0FBQUEsWUFDM0MsV0FBVTtBQUFBLFlBQXFQO0FBQUE7QUFBQSxVQUZqUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNaO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQXFLO0FBQUE7QUFBQSxjQUUxSyx1QkFBQyxVQUFLLFdBQVUsaUVBQWdFLGlCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRjtBQUFBO0FBQUE7QUFBQSxVQUp4RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0ZBO0FBQUEsT0FwSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFIQTtBQUVKO0FBQUNqQixHQXZMdUJILGNBQVk7QUFBQSxVQUlsQ0gsT0FBTztBQUFBO0FBQUFnRCxLQUplN0M7QUFBWSxJQUFBNkM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlUmVmIiwidXNlRWZmZWN0IiwidXNlR1NBUCIsImdzYXAiLCJFeHRlcm5hbExpbmsiLCJXb3JrU2hvd2Nhc2UiLCJwcm9qZWN0cyIsIm9uUHJvamVjdENsaWNrIiwiX3MiLCJhY3RpdmVJbmRleCIsInNldEFjdGl2ZUluZGV4Iiwic2VjdGlvblJlZiIsImZyb21UbyIsInkiLCJvcGFjaXR5IiwiZHVyYXRpb24iLCJlYXNlIiwic2Nyb2xsVHJpZ2dlciIsInRyaWdnZXIiLCJjdXJyZW50Iiwic3RhcnQiLCJzY2FsZSIsInNjb3BlIiwiZ29UbyIsImluZGV4IiwiZ29OZXh0IiwibGVuZ3RoIiwiZ29QcmV2IiwiaGFuZGxlS2V5RG93biIsImUiLCJpbmNsdWRlcyIsInRhcmdldCIsInRhZ05hbWUiLCJrZXkiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImFjdGl2ZVByb2plY3QiLCJBcnJheSIsIm1hcCIsIl8iLCJpIiwicCIsImltYWdlIiwiaWQiLCJTdHJpbmciLCJwYWRTdGFydCIsImNhdGVnb3J5IiwidGl0bGUiLCJ0ZWNoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiV29ya1Nob3djYXNlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VHU0FQIH0gZnJvbSAnQGdzYXAvcmVhY3QnO1xuaW1wb3J0IGdzYXAgZnJvbSAnZ3NhcCc7XG5pbXBvcnQgeyBTY3JvbGxUcmlnZ2VyIH0gZnJvbSAnZ3NhcC9TY3JvbGxUcmlnZ2VyJztcbmltcG9ydCB7IEV4dGVybmFsTGluayB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBQcm9qZWN0IH0gZnJvbSAnLi4vQXBwJztcblxuaW50ZXJmYWNlIFdvcmtTaG93Y2FzZVByb3BzIHtcbiAgcHJvamVjdHM6IFByb2plY3RbXTtcbiAgb25Qcm9qZWN0Q2xpY2s6IChwcm9qZWN0OiBQcm9qZWN0KSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBXb3JrU2hvd2Nhc2UoeyBwcm9qZWN0cywgb25Qcm9qZWN0Q2xpY2sgfTogV29ya1Nob3djYXNlUHJvcHMpIHtcbiAgY29uc3QgW2FjdGl2ZUluZGV4LCBzZXRBY3RpdmVJbmRleF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3Qgc2VjdGlvblJlZiA9IHVzZVJlZjxIVE1MRWxlbWVudD4obnVsbCk7XG5cbiAgdXNlR1NBUCgoKSA9PiB7XG4gICAgZ3NhcC5mcm9tVG8oJy53b3JrLXNob3djYXNlLXRpdGxlJywge1xuICAgICAgeTogMzAsXG4gICAgICBvcGFjaXR5OiAwLFxuICAgIH0sIHtcbiAgICAgIHk6IDAsXG4gICAgICBvcGFjaXR5OiAxLFxuICAgICAgZHVyYXRpb246IDAuOCxcbiAgICAgIGVhc2U6ICdwb3dlcjMub3V0JyxcbiAgICAgIHNjcm9sbFRyaWdnZXI6IHtcbiAgICAgICAgdHJpZ2dlcjogc2VjdGlvblJlZi5jdXJyZW50LFxuICAgICAgICBzdGFydDogJ3RvcCA3NSUnLFxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgZ3NhcC5mcm9tVG8oJy53b3JrLXNob3djYXNlLWNhcmQnLCB7XG4gICAgICB5OiA1MCxcbiAgICAgIG9wYWNpdHk6IDAsXG4gICAgICBzY2FsZTogMC45NixcbiAgICB9LCB7XG4gICAgICB5OiAwLFxuICAgICAgb3BhY2l0eTogMSxcbiAgICAgIHNjYWxlOiAxLFxuICAgICAgZHVyYXRpb246IDEsXG4gICAgICBlYXNlOiAncG93ZXIzLm91dCcsXG4gICAgICBzY3JvbGxUcmlnZ2VyOiB7XG4gICAgICAgIHRyaWdnZXI6ICcud29yay1zaG93Y2FzZS1jYXJkJyxcbiAgICAgICAgc3RhcnQ6ICd0b3AgODAlJyxcbiAgICAgIH1cbiAgICB9KTtcbiAgfSwgeyBzY29wZTogc2VjdGlvblJlZiB9KTtcblxuICBjb25zdCBnb1RvID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICBpZiAoaW5kZXggPT09IGFjdGl2ZUluZGV4KSByZXR1cm47XG4gICAgc2V0QWN0aXZlSW5kZXgoaW5kZXgpO1xuICB9O1xuXG4gIGNvbnN0IGdvTmV4dCA9ICgpID0+IGdvVG8oKGFjdGl2ZUluZGV4ICsgMSkgJSBwcm9qZWN0cy5sZW5ndGgpO1xuICBjb25zdCBnb1ByZXYgPSAoKSA9PiBnb1RvKChhY3RpdmVJbmRleCAtIDEgKyBwcm9qZWN0cy5sZW5ndGgpICUgcHJvamVjdHMubGVuZ3RoKTtcblxuICAvLyBFbmFibGUgS2V5Ym9hcmQgTGVmdCAmIFJpZ2h0IEFycm93IEtleSBOYXZpZ2F0aW9uXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICAvLyBEb24ndCB0cmlnZ2VyIGlmIHVzZXIgaXMgaW5zaWRlIGFuIGlucHV0IG9yIHRleHRhcmVhXG4gICAgICBpZiAoWydJTlBVVCcsICdURVhUQVJFQSddLmluY2x1ZGVzKChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCk/LnRhZ05hbWUpKSByZXR1cm47XG5cbiAgICAgIGlmIChlLmtleSA9PT0gJ0Fycm93TGVmdCcpIHtcbiAgICAgICAgZ29QcmV2KCk7XG4gICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dSaWdodCcpIHtcbiAgICAgICAgZ29OZXh0KCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gIH0sIFthY3RpdmVJbmRleCwgcHJvamVjdHMubGVuZ3RoXSk7XG5cbiAgY29uc3QgYWN0aXZlUHJvamVjdCA9IHByb2plY3RzW2FjdGl2ZUluZGV4XTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIHJlZj17c2VjdGlvblJlZn0gaWQ9XCJ3b3JrXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWluLWgtc2NyZWVuIHB5LTEwIHB4LTQgbWQ6cHgtMTIgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gb3ZlcmZsb3ctaGlkZGVuIGJnLVsjMDUwNTA1XSB0ZXh0LXdoaXRlXCI+XG4gICAgICB7LyogU2Nyb2xsLWRpcmVjdGlvbi1hd2FyZSBtYXJxdWVlIGRpdmlkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBweS0zIG92ZXJmbG93LWhpZGRlbiBib3JkZXItYiBib3JkZXItd2hpdGUvMTAgbWItNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcnF1ZWVfX2lubmVyXCIgc3R5bGU9e3sgJy0tbWFycXVlZS1kdXJhdGlvbic6ICcxOHMnIH0gYXMgYW55fT5cbiAgICAgICAgICB7Wy4uLkFycmF5KDgpXS5tYXAoKF8sIGkpID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNiBweC02IGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXdoaXRlLzUwIHdoaXRlc3BhY2Utbm93cmFwXCI+RmVhdHVyZWQgQ2FzZSBTdHVkaWVzPC9zcGFuPlxuICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxMlwiIHZpZXdCb3g9XCIwIDAgMTI1IDk1XCIgZmlsbD1cIm5vbmVcIiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzMwXCI+XG4gICAgICAgICAgICAgICAgPHBhdGggZD1cIk03My42NzQ4IDg5Ljc4MjRMMTE2LjIwNyA0Ny4yNTAxTDczLjY3NDggNC43MTc4M1wiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMTJcIiBzdHJva2VNaXRlcmxpbWl0PVwiMTBcIiAvPlxuICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTE2LjIwNyA0Ny4yNUwwLjc2MjQ1MSA0Ny4yNVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMTJcIiBzdHJva2VNaXRlcmxpbWl0PVwiMTBcIiAvPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRHluYW1pYyBBbWJpZW50IEJsdXIgQmFja2dyb3VuZCAoRmlsbHMgc2NyZWVuIGVkZ2UtdG8tZWRnZSB3aXRoIHByb2plY3QgYnJhbmQgZ2xvdykgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgei0wIHBvaW50ZXItZXZlbnRzLW5vbmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHtwcm9qZWN0cy5tYXAoKHAsIGkpID0+IChcbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICBrZXk9e2BhbWJpZW50LSR7cC5pZH1gfVxuICAgICAgICAgICAgc3JjPXtwLmltYWdlfVxuICAgICAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIGluc2V0LTAgdy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgZmlsdGVyIGJsdXItWzEwMHB4XSBzY2FsZS0xMjUgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTEwMDAgJHtpID09PSBhY3RpdmVJbmRleCA/ICdvcGFjaXR5LTM1JyA6ICdvcGFjaXR5LTAnfWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSl9XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ncmFkaWVudC10by1iIGZyb20tWyMwNTA1MDVdLzcwIHZpYS10cmFuc3BhcmVudCB0by1bIzA1MDUwNV0vOTBcIiAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNYWluIENvbnRlbnQgQXJlYSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBtYXgtdy03eGwgbXgtYXV0byB3LWZ1bGwgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTQgbXktYXV0b1wiPlxuICAgICAgICBcbiAgICAgICAgey8qIEhlYWRlciBJbmZvcm1hdGlvbiBCYXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid29yay1zaG93Y2FzZS10aXRsZSBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIGdhcC00IHB4LTJcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzYwIHRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy02IGgtWzJweF0gYmctd2hpdGUvNDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgIFByb2plY3Qge1N0cmluZyhhY3RpdmVJbmRleCArIDEpLnBhZFN0YXJ0KDIsICcwJyl9IC8ge1N0cmluZyhwcm9qZWN0cy5sZW5ndGgpLnBhZFN0YXJ0KDIsICcwJyl9IOKAoiB7YWN0aXZlUHJvamVjdC5jYXRlZ29yeX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIG1kOnRleHQtNXhsIGZvbnQtZGlzcGxheSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXRpZ2h0ZXIgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICB7YWN0aXZlUHJvamVjdC50aXRsZX1cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgaGlkZGVuIG1kOmlubGluZS1ibG9ja1wiPnthY3RpdmVQcm9qZWN0LnRlY2h9PC9zcGFuPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblByb2plY3RDbGljayhhY3RpdmVQcm9qZWN0KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBiZy13aGl0ZS8xMCBob3ZlcjpiZy13aGl0ZSB0ZXh0LXdoaXRlIGhvdmVyOnRleHQtYmxhY2sgYm9yZGVyIGJvcmRlci13aGl0ZS8yMCBweC01IHB5LTIuNSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJhY2tkcm9wLWJsdXItbWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBFeHBsb3JlIFByb2plY3QgPEV4dGVybmFsTGluayBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ2VudHJhbCBGdWxsIE1vY2t1cCBQcmVzZW50YXRpb24gQ2FyZCAoMTAwJSBVbmNyb3BwZWQsIENyaXNwIFZpZXcpICovfVxuICAgICAgICA8ZGl2IFxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUHJvamVjdENsaWNrKGFjdGl2ZVByb2plY3QpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cIndvcmstc2hvd2Nhc2UtY2FyZCBncm91cCByZWxhdGl2ZSB3LWZ1bGwgbWF4LXctNnhsIGFzcGVjdC1bMTYvOV0gbWF4LWgtWzYydmhdIHJvdW5kZWQtMnhsIG1kOnJvdW5kZWQtM3hsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IGJnLWJsYWNrLzYwIHNoYWRvdy1bMF8yMHB4XzYwcHhfcmdiYSgwLDAsMCwwLjYpXSBiYWNrZHJvcC1ibHVyLW1kIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCBob3Zlcjpib3JkZXItd2hpdGUvNDAgaG92ZXI6c2hhZG93LVswXzI1cHhfODBweF9yZ2JhKDI1NSwyNTUsMjU1LDAuMDgpXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTIgbWQ6cC00XCJcbiAgICAgICAgPlxuICAgICAgICAgIHtwcm9qZWN0cy5tYXAoKHAsIGkpID0+IChcbiAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAga2V5PXtwLmlkfVxuICAgICAgICAgICAgICBzcmM9e3AuaW1hZ2V9XG4gICAgICAgICAgICAgIGFsdD17cC50aXRsZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGgtZnVsbCBvYmplY3QtY29udGFpbiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi03MDAgcm91bmRlZC14bCAke2kgPT09IGFjdGl2ZUluZGV4ID8gJ29wYWNpdHktMTAwIHNjYWxlLTEwMCcgOiAnb3BhY2l0eS0wIHNjYWxlLTk4IGFic29sdXRlIGluc2V0LTAnfWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkpfVxuXG4gICAgICAgICAgey8qIEhvdmVyIEhpbnQgT3ZlcmxheSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctZ3JhZGllbnQtdG8tdCBmcm9tLWJsYWNrLzYwIHZpYS10cmFuc3BhcmVudCB0by10cmFuc3BhcmVudCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMCBmbGV4IGl0ZW1zLWVuZCBqdXN0aWZ5LWNlbnRlciBwYi02IHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC13aGl0ZSBiZy1ibGFjay82MCBib3JkZXIgYm9yZGVyLXdoaXRlLzIwIHB4LTUgcHktMiByb3VuZGVkLWZ1bGwgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICAgICAgQ2xpY2sgdG8gT3BlbiBGdWxsIFZpZXdcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIERpc3BsYXkgVGh1bWJuYWlsIFJvbGwgKDExIFRodW1ibmFpbHMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy14LWF1dG8gcGItMiBwdC0xIGhpZGUtc2Nyb2xsYmFyIHB4LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICB7cHJvamVjdHMubWFwKChwLCBpKSA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e3AuaWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZ29UbyhpKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBmbGV4LXNocmluay0wIHctMjAgaC0xNCBtZDp3LTI4IG1kOmgtMTggcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCBjdXJzb3ItcG9pbnRlciAke2kgPT09IGFjdGl2ZUluZGV4ID8gJ2JvcmRlci13aGl0ZSByaW5nLTIgcmluZy13aGl0ZS8zMCBzY2FsZS0xMDUgb3BhY2l0eS0xMDAgc2hhZG93LWxnIHNoYWRvdy13aGl0ZS8xMCcgOiAnYm9yZGVyLXdoaXRlLzEwIG9wYWNpdHktNDAgaG92ZXI6b3BhY2l0eS04MCd9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtwLmltYWdlfSBhbHQ9e3AudGl0bGV9IGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMCBob3ZlcjpzY2FsZS0xMDVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTmF2aWdhdGlvbiBCYXIgYmVsb3cgRGlzcGxheSBSb2xsOiDihpAgUFJFViB8IEVYUExPUkUgfCBORVhUIOKGkiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtOCBtZDpnYXAtMTIgbXQtMlwiPlxuICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICBvbkNsaWNrPXtnb1ByZXZ9IFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC13aGl0ZS82MCBob3Zlcjp0ZXh0LXdoaXRlIHRleHQteHMgbWQ6dGV4dC1zbSBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgZ3JvdXAgcHktMlwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JvdXAtaG92ZXI6LXRyYW5zbGF0ZS14LTEuNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIj7ihpA8L3NwYW4+IFBSRVZcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICBcbiAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25Qcm9qZWN0Q2xpY2soYWN0aXZlUHJvamVjdCl9IFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBtZDp0ZXh0LXNtIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtd2hpdGUvODAgaG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXdoaXRlLzIwIGhvdmVyOmJvcmRlci13aGl0ZS81MCBob3ZlcjpiZy13aGl0ZS8xMCBweC04IHB5LTIuNSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJhY2tkcm9wLWJsdXItbWQgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXNtXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBFWFBMT1JFXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgXG4gICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgIG9uQ2xpY2s9e2dvTmV4dH0gXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzYwIGhvdmVyOnRleHQtd2hpdGUgdGV4dC14cyBtZDp0ZXh0LXNtIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciBncm91cCBweS0yXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBORVhUIDxzcGFuIGNsYXNzTmFtZT1cImdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEuNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIj7ihpI8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L1dvcmsvU2FzdWR1bC9zYXNhL3Nhc3VuZHVsLXBvcnRmb2xpby9jb21wb25lbnRzL1dvcmtTaG93Y2FzZS50c3gifQ==