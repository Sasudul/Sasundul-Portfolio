import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/AiChatbot.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { X, Send, Mic, MicOff, MessageSquare, RotateCcw, Sparkles, GripHorizontal, Square } from "/node_modules/.vite/deps/lucide-react.js?v=5088fc54";
import { streamChat, clearChatHistory } from "/components/aiService.ts?t=1786214954375";
import { getRandomChips } from "/components/aiPersona.ts?t=1786214954375";
import { useVoice } from "/components/useVoice.ts?t=1786214606820";
import "/components/AiChatbot.css?t=1786214630237";
const AVATAR_URL = "/avatar.png";
function FormattedMessageText({ text }) {
  const cleanedText = text.replace(/^[\d]+\.\s+\*\*/gm, "**").replace(/^[-•]\s+\*\*/gm, "**");
  const paragraphs = cleanedText.split(/\n\s*\n/);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 leading-relaxed", children: paragraphs.map((paragraph, pIdx) => {
    const parts = paragraph.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g);
    return /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-white/90", children: parts.map((part, i) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return /* @__PURE__ */ jsxDEV("strong", { className: "font-semibold text-white", children: part.slice(2, -2) }, i, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 44,
          columnNumber: 19
        }, this);
      }
      if (part.startsWith("*") && part.endsWith("*")) {
        return /* @__PURE__ */ jsxDEV("em", { className: "italic text-white/85", children: part.slice(1, -1) }, i, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 51,
          columnNumber: 19
        }, this);
      }
      if (part.startsWith("`") && part.endsWith("`")) {
        return /* @__PURE__ */ jsxDEV("code", { className: "bg-white/10 px-1.5 py-0.5 rounded font-mono text-[12px] text-white", children: part.slice(1, -1) }, i, false, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 58,
          columnNumber: 19
        }, this);
      }
      return part;
    }) }, pIdx, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
      lineNumber: 40,
      columnNumber: 11
    }, this);
  }) }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
}
_c = FormattedMessageText;
export default function AiChatbot() {
  _s();
  const [panelState, setPanelState] = useState("closed");
  const [mode, setMode] = useState("text");
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [terminalMode, setTerminalMode] = useState(false);
  const [chips, setChips] = useState([]);
  const [hasGreeted, setHasGreeted] = useState(false);
  const [autoListenAfterSpeech, setAutoListenAfterSpeech] = useState(true);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const panelRef = useRef(null);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const waveformRef = useRef(null);
  const waveformAnimRef = useRef(0);
  const modeRef = useRef(mode);
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);
  const voice = useVoice({
    onSpeechEnd: () => {
      if (modeRef.current === "voice" && autoListenAfterSpeech) {
        setTimeout(() => {
          if (modeRef.current === "voice") {
            voice.startListening();
          }
        }, 400);
      }
    },
    onInterrupted: () => {
      console.log("AI voice interrupted by user");
    }
  });
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isThinking]);
  useEffect(() => {
    setChips(getRandomChips(4));
  }, []);
  useEffect(() => {
    if (mode !== "voice" || panelState !== "open") return;
    const bars = waveformRef.current?.children;
    if (!bars) return;
    const animate = () => {
      const level = voice.getAudioLevel();
      for (let i = 0; i < bars.length; i++) {
        const bar = bars[i];
        const rand = Math.random();
        const h = voice.isListening ? 6 + (level * 240 + rand * 20) * (1 - Math.abs(i - 7) / 9) : voice.isSpeaking ? 8 + Math.sin(Date.now() / 100 + i) * 14 + rand * 10 : 4 + rand * 4;
        bar.style.height = `${Math.min(Math.max(h, 4), 36)}px`;
      }
      waveformAnimRef.current = requestAnimationFrame(animate);
    };
    animate();
    return () => {
      if (waveformAnimRef.current) cancelAnimationFrame(waveformAnimRef.current);
    };
  }, [mode, panelState, voice.isListening, voice.isSpeaking]);
  useEffect(() => {
    if (!voice.isListening && voice.transcript && mode === "voice") {
      handleSend(voice.transcript);
    }
  }, [voice.isListening]);
  const handlePointerDown = (e) => {
    if (e.target.closest("button")) return;
    isDraggingRef.current = true;
    dragStartRef.current = {
      x: e.clientX - dragOffset.x,
      y: e.clientY - dragOffset.y
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const handlePointerMove = (e) => {
    if (!isDraggingRef.current) return;
    setDragOffset({
      x: e.clientX - dragStartRef.current.x,
      y: e.clientY - dragStartRef.current.y
    });
  };
  const handlePointerUp = (e) => {
    isDraggingRef.current = false;
  };
  const openPanel = useCallback(() => {
    setPanelState("open");
    setDragOffset({ x: 0, y: 0 });
    requestAnimationFrame(() => {
      if (panelRef.current) {
        gsap.fromTo(
          panelRef.current,
          { opacity: 0, scale: 0.88, y: 40 },
          { opacity: 1, scale: 1, y: 0, duration: 0.45, ease: "back.out(1.4)" }
        );
      }
    });
    if (!hasGreeted) {
      setHasGreeted(true);
      setMessages([{
        id: "greeting",
        role: "ai",
        text: "Yo! I'm Sasa. Ask me anything about my projects, tech stack, or design process."
      }]);
    }
    setTimeout(() => inputRef.current?.focus(), 400);
  }, [hasGreeted]);
  const closePanel = useCallback(() => {
    if (panelRef.current) {
      gsap.to(panelRef.current, {
        opacity: 0,
        scale: 0.88,
        y: 30,
        duration: 0.28,
        ease: "power2.in",
        onComplete: () => setPanelState("closed")
      });
    }
    voice.stopListening();
    voice.stopSpeaking();
  }, [voice]);
  const handleReset = () => {
    clearChatHistory();
    setMessages([{
      id: `reset-${Date.now()}`,
      role: "ai",
      text: "Fresh chat! What do you wanna talk about?"
    }]);
    setChips(getRandomChips(4));
  };
  const handleSend = useCallback(async (text) => {
    const message = (text || inputValue).trim();
    if (!message || isThinking) return;
    if (voice.isSpeaking) {
      voice.stopSpeaking();
    }
    if (message.toLowerCase() === "/terminal") {
      setTerminalMode((prev) => !prev);
      setMessages((prev) => [...prev, {
        id: `sys-${Date.now()}`,
        role: "system",
        text: terminalMode ? "← Exited terminal mode" : "→ Terminal mode activated"
      }]);
      setInputValue("");
      return;
    }
    const userMsg = {
      id: `user-${Date.now()}`,
      role: "user",
      text: message
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsThinking(true);
    setChips(getRandomChips(4));
    const aiMsgId = `ai-${Date.now()}`;
    let fullText = "";
    try {
      for await (const chunk of streamChat(message)) {
        fullText += chunk;
        setMessages((prev) => {
          const existing = prev.find((m) => m.id === aiMsgId);
          if (existing) {
            return prev.map((m) => m.id === aiMsgId ? { ...m, text: fullText, isStreaming: true } : m);
          }
          return [...prev, { id: aiMsgId, role: "ai", text: fullText, isStreaming: true }];
        });
      }
      setMessages(
        (prev) => prev.map((m) => m.id === aiMsgId ? { ...m, isStreaming: false } : m)
      );
      if (mode === "voice" && fullText) {
        voice.speak(fullText);
      }
    } catch (error) {
      console.error("Chat error:", error);
      setMessages((prev) => [...prev, {
        id: aiMsgId,
        role: "ai",
        text: "Something broke on my end. Try sending your message again.",
        isStreaming: false
      }]);
    }
    setIsThinking(false);
  }, [inputValue, isThinking, mode, terminalMode, voice]);
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  const toggleVoice = useCallback(() => {
    if (voice.isSpeaking) {
      voice.stopSpeaking();
    } else if (voice.isListening) {
      voice.stopListening();
    } else {
      voice.startListening();
    }
  }, [voice]);
  if (panelState === "closed") {
    return /* @__PURE__ */ jsxDEV(
      "button",
      {
        className: "ai-orb group",
        onClick: openPanel,
        "aria-label": "Talk to Sasa",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ai-orb__avatar-wrapper", children: /* @__PURE__ */ jsxDEV(
            "img",
            {
              src: AVATAR_URL,
              alt: "Sasa Avatar",
              className: "ai-orb__avatar-img"
            },
            void 0,
            false,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 329,
              columnNumber: 11
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 328,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ai-orb__pulse" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 335,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ai-orb__tooltip", children: "Talk to Sasa" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 336,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
        lineNumber: 323,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: panelRef,
      className: `ai-panel ${terminalMode ? "terminal-mode" : ""}`,
      "data-lenis-prevent": "true",
      style: {
        transform: `translate(${dragOffset.x}px, ${dragOffset.y}px)`
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "ai-panel__header select-none",
            onPointerDown: handlePointerDown,
            onPointerMove: handlePointerMove,
            onPointerUp: handlePointerUp,
            title: "Click and drag to move chat window",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "ai-panel__identity", children: [
                /* @__PURE__ */ jsxDEV(GripHorizontal, { size: 16, className: "text-white/30 cursor-grab active:cursor-grabbing hover:text-white/60 transition-colors" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 359,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "ai-panel__avatar-frame", children: /* @__PURE__ */ jsxDEV("img", { src: AVATAR_URL, alt: "Sasa Wanasinghe", className: "w-full h-full object-cover" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 361,
                  columnNumber: 13
                }, this) }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 360,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "ai-panel__name flex items-center gap-1.5", children: [
                    terminalMode ? "sasundul.sh" : "Sasa",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] px-1.5 py-0.5 rounded-full bg-white/10 text-white/70 font-mono", children: "AI" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 366,
                      columnNumber: 15
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                    lineNumber: 364,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "ai-panel__status", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "ai-panel__status-dot" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 369,
                      columnNumber: 15
                    }, this),
                    isThinking ? "Thinking..." : voice.isSpeaking ? "Speaking (tap to stop)" : voice.isListening ? "Listening..." : "Online"
                  ] }, void 0, true, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                    lineNumber: 368,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 363,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 358,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    className: "ai-panel__icon-btn",
                    onClick: handleReset,
                    title: "Reset conversation",
                    children: /* @__PURE__ */ jsxDEV(RotateCcw, { size: 14 }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 381,
                      columnNumber: 13
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                    lineNumber: 376,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("button", { className: "ai-panel__close", onClick: closePanel, title: "Close chat", children: /* @__PURE__ */ jsxDEV(X, { size: 16 }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 384,
                  columnNumber: 13
                }, this) }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 383,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 375,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 351,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "ai-mode-toggle", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `ai-mode-toggle__btn ${mode === "text" ? "ai-mode-toggle__btn--active" : ""}`,
              onClick: () => {
                setMode("text");
                voice.stopListening();
                voice.stopSpeaking();
              },
              children: [
                /* @__PURE__ */ jsxDEV(MessageSquare, { size: 14 }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 395,
                  columnNumber: 11
                }, this),
                "Text Chat"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 391,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `ai-mode-toggle__btn ${mode === "voice" ? "ai-mode-toggle__btn--active" : ""}`,
              onClick: () => {
                setMode("voice");
                voice.startListening();
              },
              children: [
                /* @__PURE__ */ jsxDEV(Mic, { size: 14 }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 402,
                  columnNumber: 11
                }, this),
                "Sasa Voice Call"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 398,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 390,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "ai-messages",
            "data-lenis-prevent": "true",
            "data-lenis-prevent-wheel": "true",
            "data-lenis-prevent-touch": "true",
            children: [
              messages.map(
                (msg) => /* @__PURE__ */ jsxDEV("div", { className: `ai-msg-row ai-msg-row--${msg.role}`, children: [
                  msg.role === "ai" && !terminalMode && /* @__PURE__ */ jsxDEV("img", { src: AVATAR_URL, alt: "Sasa", className: "ai-msg__avatar" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                    lineNumber: 417,
                    columnNumber: 11
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: `ai-msg ai-msg--${msg.role}`, children: [
                    /* @__PURE__ */ jsxDEV(FormattedMessageText, { text: msg.text }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 420,
                      columnNumber: 15
                    }, this),
                    msg.isStreaming && /* @__PURE__ */ jsxDEV("span", { className: "ai-cursor" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 421,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                    lineNumber: 419,
                    columnNumber: 13
                  }, this)
                ] }, msg.id, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 415,
                  columnNumber: 9
                }, this)
              ),
              isThinking && !messages.find((m) => m.isStreaming) && /* @__PURE__ */ jsxDEV("div", { className: "ai-msg-row ai-msg-row--ai", children: [
                !terminalMode && /* @__PURE__ */ jsxDEV("img", { src: AVATAR_URL, alt: "Sasa", className: "ai-msg__avatar" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 428,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "ai-typing", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "ai-typing__label", children: terminalMode ? "processing" : "Sasa is thinking" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                    lineNumber: 430,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "ai-typing__dots", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "ai-typing__dot" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 434,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "ai-typing__dot" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 435,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "ai-typing__dot" }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                      lineNumber: 436,
                      columnNumber: 17
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                    lineNumber: 433,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 429,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 427,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 442,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 408,
            columnNumber: 7
          },
          this
        ),
        messages.length <= 2 && !isThinking && /* @__PURE__ */ jsxDEV("div", { className: "ai-chips", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full text-[10px] font-mono uppercase tracking-widest text-white/40 mb-1 px-1 flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { size: 11, className: "text-white/60" }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 449,
              columnNumber: 13
            }, this),
            " Suggested topics:"
          ] }, void 0, true, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 448,
            columnNumber: 11
          }, this),
          chips.map(
            (chip, i) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: "ai-chip",
                onClick: () => handleSend(chip),
                children: chip
              },
              i,
              false,
              {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 452,
                columnNumber: 9
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 447,
          columnNumber: 7
        }, this),
        mode === "text" && /* @__PURE__ */ jsxDEV("div", { className: "ai-input-bar", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: inputRef,
              type: "text",
              className: "ai-input-bar__field",
              placeholder: terminalMode ? "$ type a command or question..." : "Ask me anything about Sasa...",
              value: inputValue,
              onChange: (e) => setInputValue(e.target.value),
              onKeyDown: handleKeyDown,
              maxLength: 500,
              autoComplete: "off"
            },
            void 0,
            false,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 466,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "ai-input-bar__send",
              onClick: () => handleSend(),
              disabled: !inputValue.trim() || isThinking,
              title: "Send message",
              children: /* @__PURE__ */ jsxDEV(Send, { size: 15 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 483,
                columnNumber: 13
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 477,
              columnNumber: 11
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 465,
          columnNumber: 7
        }, this),
        mode === "voice" && (voice.isSupported ? /* @__PURE__ */ jsxDEV("div", { className: "ai-voice-area", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center justify-center py-2", children: /* @__PURE__ */ jsxDEV("div", { className: `ai-voice-avatar-ring ${voice.isListening ? "ai-voice-avatar-ring--listening" : voice.isSpeaking ? "ai-voice-avatar-ring--speaking" : ""}`, children: /* @__PURE__ */ jsxDEV("img", { src: AVATAR_URL, alt: "Sasa Avatar", className: "w-20 h-20 rounded-full object-cover p-1 bg-black/60 border border-white/20" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 495,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 494,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 493,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ai-voice-area__transcript", children: voice.isListening ? voice.transcript || "Listening... speak anytime" : voice.isSpeaking ? 'Speaking (tap stop or say "stop" to interrupt)...' : voice.error || "Hands-free voice active. Say something!" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 500,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ai-waveform", ref: waveformRef, children: Array.from({ length: 15 }).map(
            (_, i) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `ai-waveform__bar ${voice.isListening ? "ai-waveform__bar--active" : voice.isSpeaking ? "ai-waveform__bar--speaking" : ""}`,
                style: { height: "4px" }
              },
              i,
              false,
              {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 511,
                columnNumber: 11
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 509,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: voice.isSpeaking ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: "ai-mic-btn ai-mic-btn--speaking-stop flex items-center gap-2 px-6 w-auto rounded-full bg-red-600/30 border-red-500 text-red-400 hover:bg-red-600/50",
              onClick: () => voice.stopSpeaking(),
              title: "Stop AI speech (or just start talking)",
              children: [
                /* @__PURE__ */ jsxDEV(Square, { size: 16, fill: "currentColor" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 527,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono uppercase font-bold tracking-wider", children: "Stop Speaking" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                  lineNumber: 528,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 522,
              columnNumber: 11
            },
            this
          ) : /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `ai-mic-btn ${voice.isListening ? "ai-mic-btn--active" : ""}`,
              onClick: toggleVoice,
              disabled: isThinking,
              title: voice.isListening ? "Pause microphone" : "Start hands-free voice call",
              children: voice.isListening ? /* @__PURE__ */ jsxDEV(MicOff, { size: 22 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 537,
                columnNumber: 40
              }, this) : /* @__PURE__ */ jsxDEV(Mic, { size: 22 }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
                lineNumber: 537,
                columnNumber: 63
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
              lineNumber: 531,
              columnNumber: 11
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 520,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 491,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "ai-voice-unsupported", children: [
          "Voice conversation is best supported in Chrome, Edge, or Safari.",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 544,
            columnNumber: 77
          }, this),
          "Switch to ",
          /* @__PURE__ */ jsxDEV("b", { children: "Text Chat" }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
            lineNumber: 545,
            columnNumber: 23
          }, this),
          " mode to continue!"
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
          lineNumber: 543,
          columnNumber: 7
        }, this))
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx",
      lineNumber: 342,
      columnNumber: 5
    },
    this
  );
}
_s(AiChatbot, "SaKpiVVwVpaXj5ZqOQQKPoY1owc=", false, function() {
  return [useVoice];
});
_c2 = AiChatbot;
var _c, _c2;
$RefreshReg$(_c, "FormattedMessageText");
$RefreshReg$(_c2, "AiChatbot");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AiChatbot.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNrQjs7QUF0Q2xCLFNBQVNBLFVBQVVDLFFBQVFDLFdBQVdDLG1CQUFtQjtBQUN6RCxPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLEdBQUdDLE1BQU1DLEtBQUtDLFFBQVFDLGVBQXdCQyxXQUFXQyxVQUFVQyxnQkFBZ0JDLGNBQWM7QUFDMUcsU0FBU0MsWUFBWUMsd0JBQXdCO0FBQzdDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBTztBQVlQLE1BQU1DLGFBQWE7QUFHbkIsU0FBU0MscUJBQXFCLEVBQUVDLEtBQXVCLEdBQUc7QUFDeEQsUUFBTUMsY0FBY0QsS0FDakJFLFFBQVEscUJBQXFCLElBQUksRUFDakNBLFFBQVEsa0JBQWtCLElBQUk7QUFFakMsUUFBTUMsYUFBYUYsWUFBWUcsTUFBTSxTQUFTO0FBRTlDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNaRCxxQkFBV0UsSUFBSSxDQUFDQyxXQUFXQyxTQUFTO0FBQ25DLFVBQU1DLFFBQVFGLFVBQVVGLE1BQU0sOEJBQThCO0FBRTVELFdBQ0UsdUJBQUMsT0FBYSxXQUFVLDZCQUNyQkksZ0JBQU1ILElBQUksQ0FBQ0ksTUFBTUMsTUFBTTtBQUN0QixVQUFJRCxLQUFLRSxXQUFXLElBQUksS0FBS0YsS0FBS0csU0FBUyxJQUFJLEdBQUc7QUFDaEQsZUFDRSx1QkFBQyxZQUFlLFdBQVUsNEJBQ3ZCSCxlQUFLSSxNQUFNLEdBQUcsRUFBRSxLQUROSCxHQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRUo7QUFDQSxVQUFJRCxLQUFLRSxXQUFXLEdBQUcsS0FBS0YsS0FBS0csU0FBUyxHQUFHLEdBQUc7QUFDOUMsZUFDRSx1QkFBQyxRQUFXLFdBQVUsd0JBQ25CSCxlQUFLSSxNQUFNLEdBQUcsRUFBRSxLQURWSCxHQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRUo7QUFDQSxVQUFJRCxLQUFLRSxXQUFXLEdBQUcsS0FBS0YsS0FBS0csU0FBUyxHQUFHLEdBQUc7QUFDOUMsZUFDRSx1QkFBQyxVQUFhLFdBQVUsc0VBQ3JCSCxlQUFLSSxNQUFNLEdBQUcsRUFBRSxLQURSSCxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BRUo7QUFDQSxhQUFPRDtBQUFBQSxJQUNULENBQUMsS0F4QktGLE1BQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLEVBRUosQ0FBQyxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRUo7QUFBQ08sS0EzQ1FmO0FBNkNULHdCQUF3QmdCLFlBQVk7QUFBQUMsS0FBQTtBQUNsQyxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSXRDLFNBQXFCLFFBQVE7QUFDakUsUUFBTSxDQUFDdUMsTUFBTUMsT0FBTyxJQUFJeEMsU0FBbUIsTUFBTTtBQUNqRCxRQUFNLENBQUN5QyxVQUFVQyxXQUFXLElBQUkxQyxTQUEyQixFQUFFO0FBQzdELFFBQU0sQ0FBQzJDLFlBQVlDLGFBQWEsSUFBSTVDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM2QyxZQUFZQyxhQUFhLElBQUk5QyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDK0MsY0FBY0MsZUFBZSxJQUFJaEQsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ2lELE9BQU9DLFFBQVEsSUFBSWxELFNBQW1CLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUQsWUFBWUMsYUFBYSxJQUFJcEQsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ3FELHVCQUF1QkMsd0JBQXdCLElBQUl0RCxTQUFTLElBQUk7QUFHdkUsUUFBTSxDQUFDdUQsWUFBWUMsYUFBYSxJQUFJeEQsU0FBbUMsRUFBRXlELEdBQUcsR0FBR0MsR0FBRyxFQUFFLENBQUM7QUFDckYsUUFBTUMsZ0JBQWdCMUQsT0FBTyxLQUFLO0FBQ2xDLFFBQU0yRCxlQUFlM0QsT0FBaUMsRUFBRXdELEdBQUcsR0FBR0MsR0FBRyxFQUFFLENBQUM7QUFFcEUsUUFBTUcsV0FBVzVELE9BQXVCLElBQUk7QUFDNUMsUUFBTTZELGlCQUFpQjdELE9BQXVCLElBQUk7QUFDbEQsUUFBTThELFdBQVc5RCxPQUF5QixJQUFJO0FBQzlDLFFBQU0rRCxjQUFjL0QsT0FBdUIsSUFBSTtBQUMvQyxRQUFNZ0Usa0JBQWtCaEUsT0FBZSxDQUFDO0FBQ3hDLFFBQU1pRSxVQUFVakUsT0FBT3NDLElBQUk7QUFFM0JyQyxZQUFVLE1BQU07QUFDZGdFLFlBQVFDLFVBQVU1QjtBQUFBQSxFQUNwQixHQUFHLENBQUNBLElBQUksQ0FBQztBQUdULFFBQU02QixRQUFRbkQsU0FBUztBQUFBLElBQ3JCb0QsYUFBYUEsTUFBTTtBQUVqQixVQUFJSCxRQUFRQyxZQUFZLFdBQVdkLHVCQUF1QjtBQUN4RGlCLG1CQUFXLE1BQU07QUFDZixjQUFJSixRQUFRQyxZQUFZLFNBQVM7QUFDL0JDLGtCQUFNRyxlQUFlO0FBQUEsVUFDdkI7QUFBQSxRQUNGLEdBQUcsR0FBRztBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUEsSUFDQUMsZUFBZUEsTUFBTTtBQUVuQkMsY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0YsQ0FBQztBQUdEeEUsWUFBVSxNQUFNO0FBQ2Q0RCxtQkFBZUssU0FBU1EsZUFBZSxFQUFFQyxVQUFVLFNBQVMsQ0FBQztBQUFBLEVBQy9ELEdBQUcsQ0FBQ25DLFVBQVVJLFVBQVUsQ0FBQztBQUd6QjNDLFlBQVUsTUFBTTtBQUNkZ0QsYUFBU2xDLGVBQWUsQ0FBQyxDQUFDO0FBQUEsRUFDNUIsR0FBRyxFQUFFO0FBR0xkLFlBQVUsTUFBTTtBQUNkLFFBQUlxQyxTQUFTLFdBQVdGLGVBQWUsT0FBUTtBQUUvQyxVQUFNd0MsT0FBT2IsWUFBWUcsU0FBU1c7QUFDbEMsUUFBSSxDQUFDRCxLQUFNO0FBRVgsVUFBTUUsVUFBVUEsTUFBTTtBQUNwQixZQUFNQyxRQUFRWixNQUFNYSxjQUFjO0FBQ2xDLGVBQVNuRCxJQUFJLEdBQUdBLElBQUkrQyxLQUFLSyxRQUFRcEQsS0FBSztBQUNwQyxjQUFNcUQsTUFBTU4sS0FBSy9DLENBQUM7QUFDbEIsY0FBTXNELE9BQU9DLEtBQUtDLE9BQU87QUFDekIsY0FBTUMsSUFBSW5CLE1BQU1vQixjQUNaLEtBQUtSLFFBQVEsTUFBTUksT0FBTyxPQUFPLElBQUlDLEtBQUtJLElBQUkzRCxJQUFJLENBQUMsSUFBSSxLQUN2RHNDLE1BQU1zQixhQUNKLElBQUlMLEtBQUtNLElBQUlDLEtBQUtDLElBQUksSUFBSSxNQUFNL0QsQ0FBQyxJQUFJLEtBQUtzRCxPQUFPLEtBQ2pELElBQUlBLE9BQU87QUFDakJELFlBQUlXLE1BQU1DLFNBQVMsR0FBR1YsS0FBS1csSUFBSVgsS0FBS1ksSUFBSVYsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDcEQ7QUFDQXRCLHNCQUFnQkUsVUFBVStCLHNCQUFzQm5CLE9BQU87QUFBQSxJQUN6RDtBQUNBQSxZQUFRO0FBRVIsV0FBTyxNQUFNO0FBQ1gsVUFBSWQsZ0JBQWdCRSxRQUFTZ0Msc0JBQXFCbEMsZ0JBQWdCRSxPQUFPO0FBQUEsSUFDM0U7QUFBQSxFQUNGLEdBQUcsQ0FBQzVCLE1BQU1GLFlBQVkrQixNQUFNb0IsYUFBYXBCLE1BQU1zQixVQUFVLENBQUM7QUFHMUR4RixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNrRSxNQUFNb0IsZUFBZXBCLE1BQU1nQyxjQUFjN0QsU0FBUyxTQUFTO0FBQzlEOEQsaUJBQVdqQyxNQUFNZ0MsVUFBVTtBQUFBLElBQzdCO0FBQUEsRUFDRixHQUFHLENBQUNoQyxNQUFNb0IsV0FBVyxDQUFDO0FBR3RCLFFBQU1jLG9CQUFvQkEsQ0FBQ0MsTUFBMEI7QUFDbkQsUUFBS0EsRUFBRUMsT0FBdUJDLFFBQVEsUUFBUSxFQUFHO0FBQ2pEOUMsa0JBQWNRLFVBQVU7QUFDeEJQLGlCQUFhTyxVQUFVO0FBQUEsTUFDckJWLEdBQUc4QyxFQUFFRyxVQUFVbkQsV0FBV0U7QUFBQUEsTUFDMUJDLEdBQUc2QyxFQUFFSSxVQUFVcEQsV0FBV0c7QUFBQUEsSUFDNUI7QUFDQSxJQUFDNkMsRUFBRUssY0FBOEJDLGtCQUFrQk4sRUFBRU8sU0FBUztBQUFBLEVBQ2hFO0FBRUEsUUFBTUMsb0JBQW9CQSxDQUFDUixNQUEwQjtBQUNuRCxRQUFJLENBQUM1QyxjQUFjUSxRQUFTO0FBQzVCWCxrQkFBYztBQUFBLE1BQ1pDLEdBQUc4QyxFQUFFRyxVQUFVOUMsYUFBYU8sUUFBUVY7QUFBQUEsTUFDcENDLEdBQUc2QyxFQUFFSSxVQUFVL0MsYUFBYU8sUUFBUVQ7QUFBQUEsSUFDdEMsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNc0Qsa0JBQWtCQSxDQUFDVCxNQUEwQjtBQUNqRDVDLGtCQUFjUSxVQUFVO0FBQUEsRUFDMUI7QUFHQSxRQUFNOEMsWUFBWTlHLFlBQVksTUFBTTtBQUNsQ21DLGtCQUFjLE1BQU07QUFDcEJrQixrQkFBYyxFQUFFQyxHQUFHLEdBQUdDLEdBQUcsRUFBRSxDQUFDO0FBRTVCd0MsMEJBQXNCLE1BQU07QUFDMUIsVUFBSXJDLFNBQVNNLFNBQVM7QUFDcEIvRCxhQUFLOEc7QUFBQUEsVUFBT3JELFNBQVNNO0FBQUFBLFVBQ25CLEVBQUVnRCxTQUFTLEdBQUdDLE9BQU8sTUFBTTFELEdBQUcsR0FBRztBQUFBLFVBQ2pDLEVBQUV5RCxTQUFTLEdBQUdDLE9BQU8sR0FBRzFELEdBQUcsR0FBRzJELFVBQVUsTUFBTUMsTUFBTSxnQkFBZ0I7QUFBQSxRQUN0RTtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFFRCxRQUFJLENBQUNuRSxZQUFZO0FBQ2ZDLG9CQUFjLElBQUk7QUFDbEJWLGtCQUFZLENBQUM7QUFBQSxRQUNYNkUsSUFBSTtBQUFBLFFBQ0pDLE1BQU07QUFBQSxRQUNOcEcsTUFBTTtBQUFBLE1BQ1IsQ0FBQyxDQUFDO0FBQUEsSUFDSjtBQUVBa0QsZUFBVyxNQUFNUCxTQUFTSSxTQUFTc0QsTUFBTSxHQUFHLEdBQUc7QUFBQSxFQUNqRCxHQUFHLENBQUN0RSxVQUFVLENBQUM7QUFFZixRQUFNdUUsYUFBYXZILFlBQVksTUFBTTtBQUNuQyxRQUFJMEQsU0FBU00sU0FBUztBQUNwQi9ELFdBQUt1SCxHQUFHOUQsU0FBU00sU0FBUztBQUFBLFFBQ3hCZ0QsU0FBUztBQUFBLFFBQUdDLE9BQU87QUFBQSxRQUFNMUQsR0FBRztBQUFBLFFBQzVCMkQsVUFBVTtBQUFBLFFBQU1DLE1BQU07QUFBQSxRQUN0Qk0sWUFBWUEsTUFBTXRGLGNBQWMsUUFBUTtBQUFBLE1BQzFDLENBQUM7QUFBQSxJQUNIO0FBQ0E4QixVQUFNeUQsY0FBYztBQUNwQnpELFVBQU0wRCxhQUFhO0FBQUEsRUFDckIsR0FBRyxDQUFDMUQsS0FBSyxDQUFDO0FBR1YsUUFBTTJELGNBQWNBLE1BQU07QUFDeEJoSCxxQkFBaUI7QUFDakIyQixnQkFBWSxDQUFDO0FBQUEsTUFDWDZFLElBQUksU0FBUzNCLEtBQUtDLElBQUksQ0FBQztBQUFBLE1BQ3ZCMkIsTUFBTTtBQUFBLE1BQ05wRyxNQUFNO0FBQUEsSUFDUixDQUFDLENBQUM7QUFDRjhCLGFBQVNsQyxlQUFlLENBQUMsQ0FBQztBQUFBLEVBQzVCO0FBR0EsUUFBTXFGLGFBQWFsRyxZQUFZLE9BQU9pQixTQUFrQjtBQUN0RCxVQUFNNEcsV0FBVzVHLFFBQVF1QixZQUFZc0YsS0FBSztBQUMxQyxRQUFJLENBQUNELFdBQVduRixXQUFZO0FBRzVCLFFBQUl1QixNQUFNc0IsWUFBWTtBQUNwQnRCLFlBQU0wRCxhQUFhO0FBQUEsSUFDckI7QUFFQSxRQUFJRSxRQUFRRSxZQUFZLE1BQU0sYUFBYTtBQUN6Q2xGLHNCQUFnQixDQUFBbUYsU0FBUSxDQUFDQSxJQUFJO0FBQzdCekYsa0JBQVksQ0FBQXlGLFNBQVEsQ0FBQyxHQUFHQSxNQUFNO0FBQUEsUUFDNUJaLElBQUksT0FBTzNCLEtBQUtDLElBQUksQ0FBQztBQUFBLFFBQ3JCMkIsTUFBTTtBQUFBLFFBQ05wRyxNQUFNMkIsZUFBZSwyQkFBMkI7QUFBQSxNQUNsRCxDQUFDLENBQUM7QUFDRkgsb0JBQWMsRUFBRTtBQUNoQjtBQUFBLElBQ0Y7QUFFQSxVQUFNd0YsVUFBMEI7QUFBQSxNQUM5QmIsSUFBSSxRQUFRM0IsS0FBS0MsSUFBSSxDQUFDO0FBQUEsTUFDdEIyQixNQUFNO0FBQUEsTUFDTnBHLE1BQU00RztBQUFBQSxJQUNSO0FBQ0F0RixnQkFBWSxDQUFBeUYsU0FBUSxDQUFDLEdBQUdBLE1BQU1DLE9BQU8sQ0FBQztBQUN0Q3hGLGtCQUFjLEVBQUU7QUFDaEJFLGtCQUFjLElBQUk7QUFFbEJJLGFBQVNsQyxlQUFlLENBQUMsQ0FBQztBQUUxQixVQUFNcUgsVUFBVSxNQUFNekMsS0FBS0MsSUFBSSxDQUFDO0FBQ2hDLFFBQUl5QyxXQUFXO0FBRWYsUUFBSTtBQUNGLHVCQUFpQkMsU0FBU3pILFdBQVdrSCxPQUFPLEdBQUc7QUFDN0NNLG9CQUFZQztBQUNaN0Ysb0JBQVksQ0FBQXlGLFNBQVE7QUFDbEIsZ0JBQU1LLFdBQVdMLEtBQUtNLEtBQUssQ0FBQUMsTUFBS0EsRUFBRW5CLE9BQU9jLE9BQU87QUFDaEQsY0FBSUcsVUFBVTtBQUNaLG1CQUFPTCxLQUFLMUcsSUFBSSxDQUFBaUgsTUFBS0EsRUFBRW5CLE9BQU9jLFVBQVUsRUFBRSxHQUFHSyxHQUFHdEgsTUFBTWtILFVBQVVLLGFBQWEsS0FBSyxJQUFJRCxDQUFDO0FBQUEsVUFDekY7QUFDQSxpQkFBTyxDQUFDLEdBQUdQLE1BQU0sRUFBRVosSUFBSWMsU0FBU2IsTUFBTSxNQUFNcEcsTUFBTWtILFVBQVVLLGFBQWEsS0FBSyxDQUFDO0FBQUEsUUFDakYsQ0FBQztBQUFBLE1BQ0g7QUFFQWpHO0FBQUFBLFFBQVksQ0FBQXlGLFNBQ1ZBLEtBQUsxRyxJQUFJLENBQUFpSCxNQUFLQSxFQUFFbkIsT0FBT2MsVUFBVSxFQUFFLEdBQUdLLEdBQUdDLGFBQWEsTUFBTSxJQUFJRCxDQUFDO0FBQUEsTUFDbkU7QUFHQSxVQUFJbkcsU0FBUyxXQUFXK0YsVUFBVTtBQUNoQ2xFLGNBQU13RSxNQUFNTixRQUFRO0FBQUEsTUFDdEI7QUFBQSxJQUNGLFNBQVNPLE9BQU87QUFDZHBFLGNBQVFvRSxNQUFNLGVBQWVBLEtBQUs7QUFDbENuRyxrQkFBWSxDQUFBeUYsU0FBUSxDQUFDLEdBQUdBLE1BQU07QUFBQSxRQUM1QlosSUFBSWM7QUFBQUEsUUFDSmIsTUFBTTtBQUFBLFFBQ05wRyxNQUFNO0FBQUEsUUFDTnVILGFBQWE7QUFBQSxNQUNmLENBQUMsQ0FBQztBQUFBLElBQ0o7QUFFQTdGLGtCQUFjLEtBQUs7QUFBQSxFQUNyQixHQUFHLENBQUNILFlBQVlFLFlBQVlOLE1BQU1RLGNBQWNxQixLQUFLLENBQUM7QUFFdEQsUUFBTTBFLGdCQUFnQkEsQ0FBQ3ZDLE1BQTJCO0FBQ2hELFFBQUlBLEVBQUV3QyxRQUFRLFdBQVcsQ0FBQ3hDLEVBQUV5QyxVQUFVO0FBQ3BDekMsUUFBRTBDLGVBQWU7QUFDakI1QyxpQkFBVztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBRUEsUUFBTTZDLGNBQWMvSSxZQUFZLE1BQU07QUFDcEMsUUFBSWlFLE1BQU1zQixZQUFZO0FBRXBCdEIsWUFBTTBELGFBQWE7QUFBQSxJQUNyQixXQUFXMUQsTUFBTW9CLGFBQWE7QUFDNUJwQixZQUFNeUQsY0FBYztBQUFBLElBQ3RCLE9BQU87QUFDTHpELFlBQU1HLGVBQWU7QUFBQSxJQUN2QjtBQUFBLEVBQ0YsR0FBRyxDQUFDSCxLQUFLLENBQUM7QUFHVixNQUFJL0IsZUFBZSxVQUFVO0FBQzNCLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLFNBQVM0RTtBQUFBQSxRQUNULGNBQVc7QUFBQSxRQUVYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxLQUFLL0Y7QUFBQUEsY0FDTCxLQUFJO0FBQUEsY0FDSixXQUFVO0FBQUE7QUFBQSxZQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdnQyxLQUpsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFDL0IsdUJBQUMsVUFBSyxXQUFVLG1CQUFrQiw0QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQTtBQUFBO0FBQUEsTUFiaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY0E7QUFBQSxFQUVKO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsS0FBSzJDO0FBQUFBLE1BQ0wsV0FBVyxZQUFZZCxlQUFlLGtCQUFrQixFQUFFO0FBQUEsTUFDMUQsc0JBQW1CO0FBQUEsTUFDbkIsT0FBTztBQUFBLFFBQ0xvRyxXQUFXLGFBQWE1RixXQUFXRSxDQUFDLE9BQU9GLFdBQVdHLENBQUM7QUFBQSxNQUN6RDtBQUFBLE1BR0E7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsZUFBZTRDO0FBQUFBLFlBQ2YsZUFBZVM7QUFBQUEsWUFDZixhQUFhQztBQUFBQSxZQUNiLE9BQU07QUFBQSxZQUVOO0FBQUEscUNBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsdUNBQUMsa0JBQWUsTUFBTSxJQUFJLFdBQVUsNEZBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRIO0FBQUEsZ0JBQzVILHVCQUFDLFNBQUksV0FBVSwwQkFDYixpQ0FBQyxTQUFJLEtBQUs5RixZQUFZLEtBQUksbUJBQWtCLFdBQVUsZ0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtGLEtBRHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxXQUFVLDRDQUNaNkI7QUFBQUEsbUNBQWUsZ0JBQWdCO0FBQUEsb0JBQ2hDLHVCQUFDLFVBQUssV0FBVSw2RUFBNEUsa0JBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThGO0FBQUEsdUJBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsMEJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNDO0FBQUEsb0JBQ3JDRixhQUFhLGdCQUFnQnVCLE1BQU1zQixhQUFhLDJCQUEyQnRCLE1BQU1vQixjQUFjLGlCQUFpQjtBQUFBLHVCQUZuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFTdUM7QUFBQUEsb0JBQ1QsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLGFBQVUsTUFBTSxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQjtBQUFBO0FBQUEsa0JBTHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBLHVCQUFDLFlBQU8sV0FBVSxtQkFBa0IsU0FBU0wsWUFBWSxPQUFNLGNBQzdELGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBO0FBQUE7QUFBQSxVQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQ0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLHVCQUF1Qm5GLFNBQVMsU0FBUyxnQ0FBZ0MsRUFBRTtBQUFBLGNBQ3RGLFNBQVMsTUFBTTtBQUFFQyx3QkFBUSxNQUFNO0FBQUc0QixzQkFBTXlELGNBQWM7QUFBR3pELHNCQUFNMEQsYUFBYTtBQUFBLGNBQUc7QUFBQSxjQUUvRTtBQUFBLHVDQUFDLGlCQUFjLE1BQU0sTUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsdUJBQXVCdkYsU0FBUyxVQUFVLGdDQUFnQyxFQUFFO0FBQUEsY0FDdkYsU0FBUyxNQUFNO0FBQUVDLHdCQUFRLE9BQU87QUFBRzRCLHNCQUFNRyxlQUFlO0FBQUEsY0FBRztBQUFBLGNBRTNEO0FBQUEsdUNBQUMsT0FBSSxNQUFNLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixzQkFBbUI7QUFBQSxZQUNuQiw0QkFBeUI7QUFBQSxZQUN6Qiw0QkFBeUI7QUFBQSxZQUV4QjlCO0FBQUFBLHVCQUFTaEI7QUFBQUEsZ0JBQUksQ0FBQTJILFFBQ1osdUJBQUMsU0FBaUIsV0FBVywwQkFBMEJBLElBQUk1QixJQUFJLElBQzVENEI7QUFBQUEsc0JBQUk1QixTQUFTLFFBQVEsQ0FBQ3pFLGdCQUNyQix1QkFBQyxTQUFJLEtBQUs3QixZQUFZLEtBQUksUUFBTyxXQUFVLG9CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRDtBQUFBLGtCQUU3RCx1QkFBQyxTQUFJLFdBQVcsa0JBQWtCa0ksSUFBSTVCLElBQUksSUFDeEM7QUFBQSwyQ0FBQyx3QkFBcUIsTUFBTTRCLElBQUloSSxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQztBQUFBLG9CQUNwQ2dJLElBQUlULGVBQWUsdUJBQUMsVUFBSyxXQUFVLGVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUEsdUJBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFQUVMsSUFBSTdCLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGNBQ0Q7QUFBQSxjQUVBMUUsY0FBYyxDQUFDSixTQUFTZ0csS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxXQUFXLEtBQzlDLHVCQUFDLFNBQUksV0FBVSw2QkFDWjtBQUFBLGlCQUFDNUYsZ0JBQWdCLHVCQUFDLFNBQUksS0FBSzdCLFlBQVksS0FBSSxRQUFPLFdBQVUsb0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJEO0FBQUEsZ0JBQzdFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLG9CQUNiNkIseUJBQWUsZUFBZSxzQkFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSxvQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSxvQkFDaEMsdUJBQUMsVUFBSyxXQUFVLG9CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLG9CQUNoQyx1QkFBQyxVQUFLLFdBQVUsb0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBSGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBR0YsdUJBQUMsU0FBSSxLQUFLZSxrQkFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBO0FBQUE7QUFBQSxVQWxDM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUNBO0FBQUEsUUFHQ3JCLFNBQVN5QyxVQUFVLEtBQUssQ0FBQ3JDLGNBQ3hCLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRHQUNiO0FBQUEsbUNBQUMsWUFBUyxNQUFNLElBQUksV0FBVSxtQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUFHO0FBQUEsZUFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NJLE1BQU14QjtBQUFBQSxZQUFJLENBQUM0SCxNQUFNdkgsTUFDaEI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUyxNQUFNdUUsV0FBV2dELElBQUk7QUFBQSxnQkFFN0JBO0FBQUFBO0FBQUFBLGNBSkl2SDtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFVBQ0Q7QUFBQSxhQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBSURTLFNBQVMsVUFDUix1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsS0FBS3dCO0FBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsYUFBYWhCLGVBQWUsb0NBQW9DO0FBQUEsY0FDaEUsT0FBT0o7QUFBQUEsY0FDUCxVQUFVLENBQUE0RCxNQUFLM0QsY0FBYzJELEVBQUVDLE9BQU84QyxLQUFLO0FBQUEsY0FDM0MsV0FBV1I7QUFBQUEsY0FDWCxXQUFXO0FBQUEsY0FDWCxjQUFhO0FBQUE7QUFBQSxZQVRmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNvQjtBQUFBLFVBRXBCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU16QyxXQUFXO0FBQUEsY0FDMUIsVUFBVSxDQUFDMUQsV0FBV3NGLEtBQUssS0FBS3BGO0FBQUFBLGNBQ2hDLE9BQU07QUFBQSxjQUVOLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQTtBQUFBLFlBTmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBSUROLFNBQVMsWUFDUjZCLE1BQU1tRixjQUNKLHVCQUFDLFNBQUksV0FBVSxpQkFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxrREFDYixpQ0FBQyxTQUFJLFdBQVcsd0JBQXdCbkYsTUFBTW9CLGNBQWMsb0NBQW9DcEIsTUFBTXNCLGFBQWEsbUNBQW1DLEVBQUUsSUFDdEosaUNBQUMsU0FBSSxLQUFLeEUsWUFBWSxLQUFJLGVBQWMsV0FBVSxnRkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEgsS0FEaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSw2QkFDWmtELGdCQUFNb0IsY0FDSHBCLE1BQU1nQyxjQUFjLCtCQUNwQmhDLE1BQU1zQixhQUNKLHNEQUNBdEIsTUFBTXlFLFNBQVMsNkNBTHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxlQUFjLEtBQUs3RSxhQUMvQndGLGdCQUFNQyxLQUFLLEVBQUV2RSxRQUFRLEdBQUcsQ0FBQyxFQUFFekQ7QUFBQUEsWUFBSSxDQUFDaUksR0FBRzVILE1BQ2xDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVyxvQkFBb0JzQyxNQUFNb0IsY0FBYyw2QkFBNkJwQixNQUFNc0IsYUFBYSwrQkFBK0IsRUFBRTtBQUFBLGdCQUNwSSxPQUFPLEVBQUVLLFFBQVEsTUFBTTtBQUFBO0FBQUEsY0FGbEJqRTtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHMkI7QUFBQSxVQUU1QixLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwyQkFDWnNDLGdCQUFNc0IsYUFDTDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNdEIsTUFBTTBELGFBQWE7QUFBQSxjQUNsQyxPQUFNO0FBQUEsY0FFTjtBQUFBLHVDQUFDLFVBQU8sTUFBTSxJQUFJLE1BQUssa0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsZ0JBQ3JDLHVCQUFDLFVBQUssV0FBVSx3REFBdUQsNkJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9GO0FBQUE7QUFBQTtBQUFBLFlBTnRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BLElBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsY0FBYzFELE1BQU1vQixjQUFjLHVCQUF1QixFQUFFO0FBQUEsY0FDdEUsU0FBUzBEO0FBQUFBLGNBQ1QsVUFBVXJHO0FBQUFBLGNBQ1YsT0FBT3VCLE1BQU1vQixjQUFjLHFCQUFxQjtBQUFBLGNBRS9DcEIsZ0JBQU1vQixjQUFjLHVCQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCLElBQU0sdUJBQUMsT0FBSSxNQUFNLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYztBQUFBO0FBQUEsWUFONUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0EsS0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxhQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0RBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUFzQjtBQUFBO0FBQUEsVUFDNkIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFHO0FBQUE7QUFBQSxVQUN6RCx1QkFBQyxPQUFFLHlCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxVQUFJO0FBQUEsYUFGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUE7QUFBQTtBQUFBLElBNU1OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQStNQTtBQUVKO0FBQUNwRCxHQS9kdUJELFdBQVM7QUFBQSxVQTRCakJsQixRQUFRO0FBQUE7QUFBQTBJLE1BNUJBeEg7QUFBUyxJQUFBRCxJQUFBeUg7QUFBQUMsYUFBQTFILElBQUE7QUFBQTBILGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJlZiIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwiZ3NhcCIsIlgiLCJTZW5kIiwiTWljIiwiTWljT2ZmIiwiTWVzc2FnZVNxdWFyZSIsIlJvdGF0ZUNjdyIsIlNwYXJrbGVzIiwiR3JpcEhvcml6b250YWwiLCJTcXVhcmUiLCJzdHJlYW1DaGF0IiwiY2xlYXJDaGF0SGlzdG9yeSIsImdldFJhbmRvbUNoaXBzIiwidXNlVm9pY2UiLCJBVkFUQVJfVVJMIiwiRm9ybWF0dGVkTWVzc2FnZVRleHQiLCJ0ZXh0IiwiY2xlYW5lZFRleHQiLCJyZXBsYWNlIiwicGFyYWdyYXBocyIsInNwbGl0IiwibWFwIiwicGFyYWdyYXBoIiwicElkeCIsInBhcnRzIiwicGFydCIsImkiLCJzdGFydHNXaXRoIiwiZW5kc1dpdGgiLCJzbGljZSIsIl9jIiwiQWlDaGF0Ym90IiwiX3MiLCJwYW5lbFN0YXRlIiwic2V0UGFuZWxTdGF0ZSIsIm1vZGUiLCJzZXRNb2RlIiwibWVzc2FnZXMiLCJzZXRNZXNzYWdlcyIsImlucHV0VmFsdWUiLCJzZXRJbnB1dFZhbHVlIiwiaXNUaGlua2luZyIsInNldElzVGhpbmtpbmciLCJ0ZXJtaW5hbE1vZGUiLCJzZXRUZXJtaW5hbE1vZGUiLCJjaGlwcyIsInNldENoaXBzIiwiaGFzR3JlZXRlZCIsInNldEhhc0dyZWV0ZWQiLCJhdXRvTGlzdGVuQWZ0ZXJTcGVlY2giLCJzZXRBdXRvTGlzdGVuQWZ0ZXJTcGVlY2giLCJkcmFnT2Zmc2V0Iiwic2V0RHJhZ09mZnNldCIsIngiLCJ5IiwiaXNEcmFnZ2luZ1JlZiIsImRyYWdTdGFydFJlZiIsInBhbmVsUmVmIiwibWVzc2FnZXNFbmRSZWYiLCJpbnB1dFJlZiIsIndhdmVmb3JtUmVmIiwid2F2ZWZvcm1BbmltUmVmIiwibW9kZVJlZiIsImN1cnJlbnQiLCJ2b2ljZSIsIm9uU3BlZWNoRW5kIiwic2V0VGltZW91dCIsInN0YXJ0TGlzdGVuaW5nIiwib25JbnRlcnJ1cHRlZCIsImNvbnNvbGUiLCJsb2ciLCJzY3JvbGxJbnRvVmlldyIsImJlaGF2aW9yIiwiYmFycyIsImNoaWxkcmVuIiwiYW5pbWF0ZSIsImxldmVsIiwiZ2V0QXVkaW9MZXZlbCIsImxlbmd0aCIsImJhciIsInJhbmQiLCJNYXRoIiwicmFuZG9tIiwiaCIsImlzTGlzdGVuaW5nIiwiYWJzIiwiaXNTcGVha2luZyIsInNpbiIsIkRhdGUiLCJub3ciLCJzdHlsZSIsImhlaWdodCIsIm1pbiIsIm1heCIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsImNhbmNlbEFuaW1hdGlvbkZyYW1lIiwidHJhbnNjcmlwdCIsImhhbmRsZVNlbmQiLCJoYW5kbGVQb2ludGVyRG93biIsImUiLCJ0YXJnZXQiLCJjbG9zZXN0IiwiY2xpZW50WCIsImNsaWVudFkiLCJjdXJyZW50VGFyZ2V0Iiwic2V0UG9pbnRlckNhcHR1cmUiLCJwb2ludGVySWQiLCJoYW5kbGVQb2ludGVyTW92ZSIsImhhbmRsZVBvaW50ZXJVcCIsIm9wZW5QYW5lbCIsImZyb21UbyIsIm9wYWNpdHkiLCJzY2FsZSIsImR1cmF0aW9uIiwiZWFzZSIsImlkIiwicm9sZSIsImZvY3VzIiwiY2xvc2VQYW5lbCIsInRvIiwib25Db21wbGV0ZSIsInN0b3BMaXN0ZW5pbmciLCJzdG9wU3BlYWtpbmciLCJoYW5kbGVSZXNldCIsIm1lc3NhZ2UiLCJ0cmltIiwidG9Mb3dlckNhc2UiLCJwcmV2IiwidXNlck1zZyIsImFpTXNnSWQiLCJmdWxsVGV4dCIsImNodW5rIiwiZXhpc3RpbmciLCJmaW5kIiwibSIsImlzU3RyZWFtaW5nIiwic3BlYWsiLCJlcnJvciIsImhhbmRsZUtleURvd24iLCJrZXkiLCJzaGlmdEtleSIsInByZXZlbnREZWZhdWx0IiwidG9nZ2xlVm9pY2UiLCJ0cmFuc2Zvcm0iLCJtc2ciLCJjaGlwIiwidmFsdWUiLCJpc1N1cHBvcnRlZCIsIkFycmF5IiwiZnJvbSIsIl8iLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWlDaGF0Ym90LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZBcbi8vIEFJIENIQVRCT1Qg4oCUIFNhc3VuZHVsIChTYXNhKSBEaWdpdGFsIFR3aW5cbi8vIFNpcmktc3R5bGUgSGFuZHMtRnJlZSBWb2ljZSBDb252ZXJzYXRpb24sIEJhcmdlLUluIEludGVycnVwdGlvbiwgRHJhZ2dhYmxlIFVJXG4vLyDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZDilZBcblxuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBnc2FwIGZyb20gJ2dzYXAnO1xuaW1wb3J0IHsgWCwgU2VuZCwgTWljLCBNaWNPZmYsIE1lc3NhZ2VTcXVhcmUsIFZvbHVtZVgsIFJvdGF0ZUNjdywgU3BhcmtsZXMsIEdyaXBIb3Jpem9udGFsLCBTcXVhcmUgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgc3RyZWFtQ2hhdCwgY2xlYXJDaGF0SGlzdG9yeSB9IGZyb20gJy4vYWlTZXJ2aWNlJztcbmltcG9ydCB7IGdldFJhbmRvbUNoaXBzIH0gZnJvbSAnLi9haVBlcnNvbmEnO1xuaW1wb3J0IHsgdXNlVm9pY2UgfSBmcm9tICcuL3VzZVZvaWNlJztcbmltcG9ydCAnLi9BaUNoYXRib3QuY3NzJztcblxudHlwZSBDaGF0TW9kZSA9ICd0ZXh0JyB8ICd2b2ljZSc7XG50eXBlIFBhbmVsU3RhdGUgPSAnY2xvc2VkJyB8ICdvcGVuJztcblxuaW50ZXJmYWNlIERpc3BsYXlNZXNzYWdlIHtcbiAgaWQ6IHN0cmluZztcbiAgcm9sZTogJ3VzZXInIHwgJ2FpJyB8ICdzeXN0ZW0nO1xuICB0ZXh0OiBzdHJpbmc7XG4gIGlzU3RyZWFtaW5nPzogYm9vbGVhbjtcbn1cblxuY29uc3QgQVZBVEFSX1VSTCA9ICcvYXZhdGFyLnBuZyc7XG5cbi8vIOKUgOKUgCBDbGVhbiAmIFJlbmRlciBUZXh0IGNsZWFubHkgd2l0aG91dCByYXcgKiogYXN0ZXJpc2tzIOKUgOKUgFxuZnVuY3Rpb24gRm9ybWF0dGVkTWVzc2FnZVRleHQoeyB0ZXh0IH06IHsgdGV4dDogc3RyaW5nIH0pIHtcbiAgY29uc3QgY2xlYW5lZFRleHQgPSB0ZXh0XG4gICAgLnJlcGxhY2UoL15bXFxkXStcXC5cXHMrXFwqXFwqL2dtLCAnKionKVxuICAgIC5yZXBsYWNlKC9eWy3igKJdXFxzK1xcKlxcKi9nbSwgJyoqJyk7XG5cbiAgY29uc3QgcGFyYWdyYXBocyA9IGNsZWFuZWRUZXh0LnNwbGl0KC9cXG5cXHMqXFxuLyk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgIHtwYXJhZ3JhcGhzLm1hcCgocGFyYWdyYXBoLCBwSWR4KSA9PiB7XG4gICAgICAgIGNvbnN0IHBhcnRzID0gcGFyYWdyYXBoLnNwbGl0KC8oXFwqXFwqLio/XFwqXFwqfFxcKi4qP1xcKnxgLio/YCkvZyk7XG5cbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8cCBrZXk9e3BJZHh9IGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtd2hpdGUvOTBcIj5cbiAgICAgICAgICAgIHtwYXJ0cy5tYXAoKHBhcnQsIGkpID0+IHtcbiAgICAgICAgICAgICAgaWYgKHBhcnQuc3RhcnRzV2l0aCgnKionKSAmJiBwYXJ0LmVuZHNXaXRoKCcqKicpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcga2V5PXtpfSBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge3BhcnQuc2xpY2UoMiwgLTIpfVxuICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAocGFydC5zdGFydHNXaXRoKCcqJykgJiYgcGFydC5lbmRzV2l0aCgnKicpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxlbSBrZXk9e2l9IGNsYXNzTmFtZT1cIml0YWxpYyB0ZXh0LXdoaXRlLzg1XCI+XG4gICAgICAgICAgICAgICAgICAgIHtwYXJ0LnNsaWNlKDEsIC0xKX1cbiAgICAgICAgICAgICAgICAgIDwvZW0+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAocGFydC5zdGFydHNXaXRoKCdgJykgJiYgcGFydC5lbmRzV2l0aCgnYCcpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxjb2RlIGtleT17aX0gY2xhc3NOYW1lPVwiYmctd2hpdGUvMTAgcHgtMS41IHB5LTAuNSByb3VuZGVkIGZvbnQtbW9ubyB0ZXh0LVsxMnB4XSB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtwYXJ0LnNsaWNlKDEsIC0xKX1cbiAgICAgICAgICAgICAgICAgIDwvY29kZT5cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBwYXJ0O1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9wPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFpQ2hhdGJvdCgpIHtcbiAgY29uc3QgW3BhbmVsU3RhdGUsIHNldFBhbmVsU3RhdGVdID0gdXNlU3RhdGU8UGFuZWxTdGF0ZT4oJ2Nsb3NlZCcpO1xuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxDaGF0TW9kZT4oJ3RleHQnKTtcbiAgY29uc3QgW21lc3NhZ2VzLCBzZXRNZXNzYWdlc10gPSB1c2VTdGF0ZTxEaXNwbGF5TWVzc2FnZVtdPihbXSk7XG4gIGNvbnN0IFtpbnB1dFZhbHVlLCBzZXRJbnB1dFZhbHVlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzVGhpbmtpbmcsIHNldElzVGhpbmtpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbdGVybWluYWxNb2RlLCBzZXRUZXJtaW5hbE1vZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY2hpcHMsIHNldENoaXBzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG4gIGNvbnN0IFtoYXNHcmVldGVkLCBzZXRIYXNHcmVldGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2F1dG9MaXN0ZW5BZnRlclNwZWVjaCwgc2V0QXV0b0xpc3RlbkFmdGVyU3BlZWNoXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gIC8vIERyYWdnaW5nIFN0YXRlXG4gIGNvbnN0IFtkcmFnT2Zmc2V0LCBzZXREcmFnT2Zmc2V0XSA9IHVzZVN0YXRlPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfT4oeyB4OiAwLCB5OiAwIH0pO1xuICBjb25zdCBpc0RyYWdnaW5nUmVmID0gdXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgZHJhZ1N0YXJ0UmVmID0gdXNlUmVmPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfT4oeyB4OiAwLCB5OiAwIH0pO1xuXG4gIGNvbnN0IHBhbmVsUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgbWVzc2FnZXNFbmRSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBpbnB1dFJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcbiAgY29uc3Qgd2F2ZWZvcm1SZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCB3YXZlZm9ybUFuaW1SZWYgPSB1c2VSZWY8bnVtYmVyPigwKTtcbiAgY29uc3QgbW9kZVJlZiA9IHVzZVJlZihtb2RlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIG1vZGVSZWYuY3VycmVudCA9IG1vZGU7XG4gIH0sIFttb2RlXSk7XG5cbiAgLy8gVm9pY2UgRW5naW5lIHdpdGggY29udGludW91cyBjYWxsIGNhbGxiYWNrc1xuICBjb25zdCB2b2ljZSA9IHVzZVZvaWNlKHtcbiAgICBvblNwZWVjaEVuZDogKCkgPT4ge1xuICAgICAgLy8gSGFuZHMtZnJlZSB2b2ljZSBsb29wOiBhZnRlciBBSSBmaW5pc2hlcyBzcGVha2luZywgYXV0by1saXN0ZW4gZm9yIG5leHQgdXNlciBpbnB1dCBpZiBpbiB2b2ljZSBtb2RlXG4gICAgICBpZiAobW9kZVJlZi5jdXJyZW50ID09PSAndm9pY2UnICYmIGF1dG9MaXN0ZW5BZnRlclNwZWVjaCkge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBpZiAobW9kZVJlZi5jdXJyZW50ID09PSAndm9pY2UnKSB7XG4gICAgICAgICAgICB2b2ljZS5zdGFydExpc3RlbmluZygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSwgNDAwKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uSW50ZXJydXB0ZWQ6ICgpID0+IHtcbiAgICAgIC8vIFVzZXIgaW50ZXJydXB0ZWQgQUkgc3BlZWNoXG4gICAgICBjb25zb2xlLmxvZygnQUkgdm9pY2UgaW50ZXJydXB0ZWQgYnkgdXNlcicpO1xuICAgIH0sXG4gIH0pO1xuXG4gIC8vIFNjcm9sbCB0byBib3R0b20gd2hlbiBtZXNzYWdlcyBjaGFuZ2VcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBtZXNzYWdlc0VuZFJlZi5jdXJyZW50Py5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgfSwgW21lc3NhZ2VzLCBpc1RoaW5raW5nXSk7XG5cbiAgLy8gR2VuZXJhdGUgcmFuZG9tIGNoaXBzIG9uIG1vdW50XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0Q2hpcHMoZ2V0UmFuZG9tQ2hpcHMoNCkpO1xuICB9LCBbXSk7XG5cbiAgLy8gV2F2ZWZvcm0gYW5pbWF0aW9uIGxvb3AgZm9yIHZvaWNlIG1vZGVcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAobW9kZSAhPT0gJ3ZvaWNlJyB8fCBwYW5lbFN0YXRlICE9PSAnb3BlbicpIHJldHVybjtcblxuICAgIGNvbnN0IGJhcnMgPSB3YXZlZm9ybVJlZi5jdXJyZW50Py5jaGlsZHJlbjtcbiAgICBpZiAoIWJhcnMpIHJldHVybjtcblxuICAgIGNvbnN0IGFuaW1hdGUgPSAoKSA9PiB7XG4gICAgICBjb25zdCBsZXZlbCA9IHZvaWNlLmdldEF1ZGlvTGV2ZWwoKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYmFycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBiYXIgPSBiYXJzW2ldIGFzIEhUTUxFbGVtZW50O1xuICAgICAgICBjb25zdCByYW5kID0gTWF0aC5yYW5kb20oKTtcbiAgICAgICAgY29uc3QgaCA9IHZvaWNlLmlzTGlzdGVuaW5nXG4gICAgICAgICAgPyA2ICsgKGxldmVsICogMjQwICsgcmFuZCAqIDIwKSAqICgxIC0gTWF0aC5hYnMoaSAtIDcpIC8gOSlcbiAgICAgICAgICA6IHZvaWNlLmlzU3BlYWtpbmdcbiAgICAgICAgICAgID8gOCArIE1hdGguc2luKERhdGUubm93KCkgLyAxMDAgKyBpKSAqIDE0ICsgcmFuZCAqIDEwXG4gICAgICAgICAgICA6IDQgKyByYW5kICogNDtcbiAgICAgICAgYmFyLnN0eWxlLmhlaWdodCA9IGAke01hdGgubWluKE1hdGgubWF4KGgsIDQpLCAzNil9cHhgO1xuICAgICAgfVxuICAgICAgd2F2ZWZvcm1BbmltUmVmLmN1cnJlbnQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoYW5pbWF0ZSk7XG4gICAgfTtcbiAgICBhbmltYXRlKCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKHdhdmVmb3JtQW5pbVJlZi5jdXJyZW50KSBjYW5jZWxBbmltYXRpb25GcmFtZSh3YXZlZm9ybUFuaW1SZWYuY3VycmVudCk7XG4gICAgfTtcbiAgfSwgW21vZGUsIHBhbmVsU3RhdGUsIHZvaWNlLmlzTGlzdGVuaW5nLCB2b2ljZS5pc1NwZWFraW5nXSk7XG5cbiAgLy8gQXV0by1zdWJtaXQgdm9pY2UgdHJhbnNjcmlwdCB3aGVuIGxpc3RlbmluZyBzdG9wc1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghdm9pY2UuaXNMaXN0ZW5pbmcgJiYgdm9pY2UudHJhbnNjcmlwdCAmJiBtb2RlID09PSAndm9pY2UnKSB7XG4gICAgICBoYW5kbGVTZW5kKHZvaWNlLnRyYW5zY3JpcHQpO1xuICAgIH1cbiAgfSwgW3ZvaWNlLmlzTGlzdGVuaW5nXSk7XG5cbiAgLy8g4pSA4pSAIERyYWcgSGFuZGxlcnMg4pSA4pSAXG4gIGNvbnN0IGhhbmRsZVBvaW50ZXJEb3duID0gKGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgIGlmICgoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLmNsb3Nlc3QoJ2J1dHRvbicpKSByZXR1cm47XG4gICAgaXNEcmFnZ2luZ1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICBkcmFnU3RhcnRSZWYuY3VycmVudCA9IHtcbiAgICAgIHg6IGUuY2xpZW50WCAtIGRyYWdPZmZzZXQueCxcbiAgICAgIHk6IGUuY2xpZW50WSAtIGRyYWdPZmZzZXQueSxcbiAgICB9O1xuICAgIChlLmN1cnJlbnRUYXJnZXQgYXMgSFRNTEVsZW1lbnQpLnNldFBvaW50ZXJDYXB0dXJlKGUucG9pbnRlcklkKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVQb2ludGVyTW92ZSA9IChlOiBSZWFjdC5Qb2ludGVyRXZlbnQpID0+IHtcbiAgICBpZiAoIWlzRHJhZ2dpbmdSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIHNldERyYWdPZmZzZXQoe1xuICAgICAgeDogZS5jbGllbnRYIC0gZHJhZ1N0YXJ0UmVmLmN1cnJlbnQueCxcbiAgICAgIHk6IGUuY2xpZW50WSAtIGRyYWdTdGFydFJlZi5jdXJyZW50LnksXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUG9pbnRlclVwID0gKGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgIGlzRHJhZ2dpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xuICB9O1xuXG4gIC8vIOKUgOKUgCBQYW5lbCBPcGVuL0Nsb3NlIOKUgOKUgFxuICBjb25zdCBvcGVuUGFuZWwgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0UGFuZWxTdGF0ZSgnb3BlbicpO1xuICAgIHNldERyYWdPZmZzZXQoeyB4OiAwLCB5OiAwIH0pO1xuXG4gICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgIGlmIChwYW5lbFJlZi5jdXJyZW50KSB7XG4gICAgICAgIGdzYXAuZnJvbVRvKHBhbmVsUmVmLmN1cnJlbnQsXG4gICAgICAgICAgeyBvcGFjaXR5OiAwLCBzY2FsZTogMC44OCwgeTogNDAgfSxcbiAgICAgICAgICB7IG9wYWNpdHk6IDEsIHNjYWxlOiAxLCB5OiAwLCBkdXJhdGlvbjogMC40NSwgZWFzZTogJ2JhY2sub3V0KDEuNCknIH1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGlmICghaGFzR3JlZXRlZCkge1xuICAgICAgc2V0SGFzR3JlZXRlZCh0cnVlKTtcbiAgICAgIHNldE1lc3NhZ2VzKFt7XG4gICAgICAgIGlkOiAnZ3JlZXRpbmcnLFxuICAgICAgICByb2xlOiAnYWknLFxuICAgICAgICB0ZXh0OiBcIllvISBJJ20gU2FzYS4gQXNrIG1lIGFueXRoaW5nIGFib3V0IG15IHByb2plY3RzLCB0ZWNoIHN0YWNrLCBvciBkZXNpZ24gcHJvY2Vzcy5cIixcbiAgICAgIH1dKTtcbiAgICB9XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCksIDQwMCk7XG4gIH0sIFtoYXNHcmVldGVkXSk7XG5cbiAgY29uc3QgY2xvc2VQYW5lbCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAocGFuZWxSZWYuY3VycmVudCkge1xuICAgICAgZ3NhcC50byhwYW5lbFJlZi5jdXJyZW50LCB7XG4gICAgICAgIG9wYWNpdHk6IDAsIHNjYWxlOiAwLjg4LCB5OiAzMCxcbiAgICAgICAgZHVyYXRpb246IDAuMjgsIGVhc2U6ICdwb3dlcjIuaW4nLFxuICAgICAgICBvbkNvbXBsZXRlOiAoKSA9PiBzZXRQYW5lbFN0YXRlKCdjbG9zZWQnKSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICB2b2ljZS5zdG9wTGlzdGVuaW5nKCk7XG4gICAgdm9pY2Uuc3RvcFNwZWFraW5nKCk7XG4gIH0sIFt2b2ljZV0pO1xuXG4gIC8vIFJlc2V0IGNvbnZlcnNhdGlvblxuICBjb25zdCBoYW5kbGVSZXNldCA9ICgpID0+IHtcbiAgICBjbGVhckNoYXRIaXN0b3J5KCk7XG4gICAgc2V0TWVzc2FnZXMoW3tcbiAgICAgIGlkOiBgcmVzZXQtJHtEYXRlLm5vdygpfWAsXG4gICAgICByb2xlOiAnYWknLFxuICAgICAgdGV4dDogXCJGcmVzaCBjaGF0ISBXaGF0IGRvIHlvdSB3YW5uYSB0YWxrIGFib3V0P1wiLFxuICAgIH1dKTtcbiAgICBzZXRDaGlwcyhnZXRSYW5kb21DaGlwcyg0KSk7XG4gIH07XG5cbiAgLy8g4pSA4pSAIFNlbmQgTWVzc2FnZSDilIDilIBcbiAgY29uc3QgaGFuZGxlU2VuZCA9IHVzZUNhbGxiYWNrKGFzeW5jICh0ZXh0Pzogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgbWVzc2FnZSA9ICh0ZXh0IHx8IGlucHV0VmFsdWUpLnRyaW0oKTtcbiAgICBpZiAoIW1lc3NhZ2UgfHwgaXNUaGlua2luZykgcmV0dXJuO1xuXG4gICAgLy8gQkFSR0UtSU46IElmIEFJIGlzIHNwZWFraW5nIHdoaWxlIHVzZXIgc2VuZHMgbmV3IHRleHQgb3Igc3BlZWNoLCBTVE9QIEFJIHNwZWVjaCBpbnN0YW50bHkhXG4gICAgaWYgKHZvaWNlLmlzU3BlYWtpbmcpIHtcbiAgICAgIHZvaWNlLnN0b3BTcGVha2luZygpO1xuICAgIH1cblxuICAgIGlmIChtZXNzYWdlLnRvTG93ZXJDYXNlKCkgPT09ICcvdGVybWluYWwnKSB7XG4gICAgICBzZXRUZXJtaW5hbE1vZGUocHJldiA9PiAhcHJldik7XG4gICAgICBzZXRNZXNzYWdlcyhwcmV2ID0+IFsuLi5wcmV2LCB7XG4gICAgICAgIGlkOiBgc3lzLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICByb2xlOiAnc3lzdGVtJyxcbiAgICAgICAgdGV4dDogdGVybWluYWxNb2RlID8gJ+KGkCBFeGl0ZWQgdGVybWluYWwgbW9kZScgOiAn4oaSIFRlcm1pbmFsIG1vZGUgYWN0aXZhdGVkJyxcbiAgICAgIH1dKTtcbiAgICAgIHNldElucHV0VmFsdWUoJycpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHVzZXJNc2c6IERpc3BsYXlNZXNzYWdlID0ge1xuICAgICAgaWQ6IGB1c2VyLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgcm9sZTogJ3VzZXInLFxuICAgICAgdGV4dDogbWVzc2FnZSxcbiAgICB9O1xuICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gWy4uLnByZXYsIHVzZXJNc2ddKTtcbiAgICBzZXRJbnB1dFZhbHVlKCcnKTtcbiAgICBzZXRJc1RoaW5raW5nKHRydWUpO1xuXG4gICAgc2V0Q2hpcHMoZ2V0UmFuZG9tQ2hpcHMoNCkpO1xuXG4gICAgY29uc3QgYWlNc2dJZCA9IGBhaS0ke0RhdGUubm93KCl9YDtcbiAgICBsZXQgZnVsbFRleHQgPSAnJztcblxuICAgIHRyeSB7XG4gICAgICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIHN0cmVhbUNoYXQobWVzc2FnZSkpIHtcbiAgICAgICAgZnVsbFRleHQgKz0gY2h1bms7XG4gICAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4ge1xuICAgICAgICAgIGNvbnN0IGV4aXN0aW5nID0gcHJldi5maW5kKG0gPT4gbS5pZCA9PT0gYWlNc2dJZCk7XG4gICAgICAgICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICAgICAgICByZXR1cm4gcHJldi5tYXAobSA9PiBtLmlkID09PSBhaU1zZ0lkID8geyAuLi5tLCB0ZXh0OiBmdWxsVGV4dCwgaXNTdHJlYW1pbmc6IHRydWUgfSA6IG0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gWy4uLnByZXYsIHsgaWQ6IGFpTXNnSWQsIHJvbGU6ICdhaScsIHRleHQ6IGZ1bGxUZXh0LCBpc1N0cmVhbWluZzogdHJ1ZSB9XTtcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT5cbiAgICAgICAgcHJldi5tYXAobSA9PiBtLmlkID09PSBhaU1zZ0lkID8geyAuLi5tLCBpc1N0cmVhbWluZzogZmFsc2UgfSA6IG0pXG4gICAgICApO1xuXG4gICAgICAvLyBWb2ljZSBtb2RlOiBzcGVhayByZXNwb25zZSBvdXQgbG91ZCAoY29uY2lzZSBzcGVlY2ggb3V0cHV0KVxuICAgICAgaWYgKG1vZGUgPT09ICd2b2ljZScgJiYgZnVsbFRleHQpIHtcbiAgICAgICAgdm9pY2Uuc3BlYWsoZnVsbFRleHQpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdDaGF0IGVycm9yOicsIGVycm9yKTtcbiAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gWy4uLnByZXYsIHtcbiAgICAgICAgaWQ6IGFpTXNnSWQsXG4gICAgICAgIHJvbGU6ICdhaScsXG4gICAgICAgIHRleHQ6IFwiU29tZXRoaW5nIGJyb2tlIG9uIG15IGVuZC4gVHJ5IHNlbmRpbmcgeW91ciBtZXNzYWdlIGFnYWluLlwiLFxuICAgICAgICBpc1N0cmVhbWluZzogZmFsc2UsXG4gICAgICB9XSk7XG4gICAgfVxuXG4gICAgc2V0SXNUaGlua2luZyhmYWxzZSk7XG4gIH0sIFtpbnB1dFZhbHVlLCBpc1RoaW5raW5nLCBtb2RlLCB0ZXJtaW5hbE1vZGUsIHZvaWNlXSk7XG5cbiAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBSZWFjdC5LZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgaWYgKGUua2V5ID09PSAnRW50ZXInICYmICFlLnNoaWZ0S2V5KSB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBoYW5kbGVTZW5kKCk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHRvZ2dsZVZvaWNlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmICh2b2ljZS5pc1NwZWFraW5nKSB7XG4gICAgICAvLyBUYXBwaW5nIG1pYyB3aGlsZSBBSSBzcGVha3MgY2FuY2VscyBzcGVlY2ggaW1tZWRpYXRlbHkhXG4gICAgICB2b2ljZS5zdG9wU3BlYWtpbmcoKTtcbiAgICB9IGVsc2UgaWYgKHZvaWNlLmlzTGlzdGVuaW5nKSB7XG4gICAgICB2b2ljZS5zdG9wTGlzdGVuaW5nKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZvaWNlLnN0YXJ0TGlzdGVuaW5nKCk7XG4gICAgfVxuICB9LCBbdm9pY2VdKTtcblxuICAvLyBGbG9hdGluZyBPcmIgRkFCIChDbG9zZWQgc3RhdGUpXG4gIGlmIChwYW5lbFN0YXRlID09PSAnY2xvc2VkJykge1xuICAgIHJldHVybiAoXG4gICAgICA8YnV0dG9uXG4gICAgICAgIGNsYXNzTmFtZT1cImFpLW9yYiBncm91cFwiXG4gICAgICAgIG9uQ2xpY2s9e29wZW5QYW5lbH1cbiAgICAgICAgYXJpYS1sYWJlbD1cIlRhbGsgdG8gU2FzYVwiXG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktb3JiX19hdmF0YXItd3JhcHBlclwiPlxuICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgIHNyYz17QVZBVEFSX1VSTH1cbiAgICAgICAgICAgIGFsdD1cIlNhc2EgQXZhdGFyXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFpLW9yYl9fYXZhdGFyLWltZ1wiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFpLW9yYl9fcHVsc2VcIiAvPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhaS1vcmJfX3Rvb2x0aXBcIj5UYWxrIHRvIFNhc2E8L3NwYW4+XG4gICAgICA8L2J1dHRvbj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICByZWY9e3BhbmVsUmVmfVxuICAgICAgY2xhc3NOYW1lPXtgYWktcGFuZWwgJHt0ZXJtaW5hbE1vZGUgPyAndGVybWluYWwtbW9kZScgOiAnJ31gfVxuICAgICAgZGF0YS1sZW5pcy1wcmV2ZW50PVwidHJ1ZVwiXG4gICAgICBzdHlsZT17e1xuICAgICAgICB0cmFuc2Zvcm06IGB0cmFuc2xhdGUoJHtkcmFnT2Zmc2V0Lnh9cHgsICR7ZHJhZ09mZnNldC55fXB4KWAsXG4gICAgICB9fVxuICAgID5cbiAgICAgIHsvKiDilIDilIAgRHJhZ2dhYmxlIEhlYWRlciBCYXIg4pSA4pSAICovfVxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJhaS1wYW5lbF9faGVhZGVyIHNlbGVjdC1ub25lXCJcbiAgICAgICAgb25Qb2ludGVyRG93bj17aGFuZGxlUG9pbnRlckRvd259XG4gICAgICAgIG9uUG9pbnRlck1vdmU9e2hhbmRsZVBvaW50ZXJNb3ZlfVxuICAgICAgICBvblBvaW50ZXJVcD17aGFuZGxlUG9pbnRlclVwfVxuICAgICAgICB0aXRsZT1cIkNsaWNrIGFuZCBkcmFnIHRvIG1vdmUgY2hhdCB3aW5kb3dcIlxuICAgICAgPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFpLXBhbmVsX19pZGVudGl0eVwiPlxuICAgICAgICAgIDxHcmlwSG9yaXpvbnRhbCBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC13aGl0ZS8zMCBjdXJzb3ItZ3JhYiBhY3RpdmU6Y3Vyc29yLWdyYWJiaW5nIGhvdmVyOnRleHQtd2hpdGUvNjAgdHJhbnNpdGlvbi1jb2xvcnNcIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktcGFuZWxfX2F2YXRhci1mcmFtZVwiPlxuICAgICAgICAgICAgPGltZyBzcmM9e0FWQVRBUl9VUkx9IGFsdD1cIlNhc2EgV2FuYXNpbmdoZVwiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhaS1wYW5lbF9fbmFtZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIHt0ZXJtaW5hbE1vZGUgPyAnc2FzdW5kdWwuc2gnIDogJ1Nhc2EnfVxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHB4LTEuNSBweS0wLjUgcm91bmRlZC1mdWxsIGJnLXdoaXRlLzEwIHRleHQtd2hpdGUvNzAgZm9udC1tb25vXCI+QUk8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktcGFuZWxfX3N0YXR1c1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhaS1wYW5lbF9fc3RhdHVzLWRvdFwiIC8+XG4gICAgICAgICAgICAgIHtpc1RoaW5raW5nID8gJ1RoaW5raW5nLi4uJyA6IHZvaWNlLmlzU3BlYWtpbmcgPyAnU3BlYWtpbmcgKHRhcCB0byBzdG9wKScgOiB2b2ljZS5pc0xpc3RlbmluZyA/ICdMaXN0ZW5pbmcuLi4nIDogJ09ubGluZSd9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWktcGFuZWxfX2ljb24tYnRuXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlc2V0fVxuICAgICAgICAgICAgdGl0bGU9XCJSZXNldCBjb252ZXJzYXRpb25cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxSb3RhdGVDY3cgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhaS1wYW5lbF9fY2xvc2VcIiBvbkNsaWNrPXtjbG9zZVBhbmVsfSB0aXRsZT1cIkNsb3NlIGNoYXRcIj5cbiAgICAgICAgICAgIDxYIHNpemU9ezE2fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Lyog4pSA4pSAIE1vZGUgVG9nZ2xlIOKUgOKUgCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktbW9kZS10b2dnbGVcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGNsYXNzTmFtZT17YGFpLW1vZGUtdG9nZ2xlX19idG4gJHttb2RlID09PSAndGV4dCcgPyAnYWktbW9kZS10b2dnbGVfX2J0bi0tYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRNb2RlKCd0ZXh0Jyk7IHZvaWNlLnN0b3BMaXN0ZW5pbmcoKTsgdm9pY2Uuc3RvcFNwZWFraW5nKCk7IH19XG4gICAgICAgID5cbiAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBzaXplPXsxNH0gLz5cbiAgICAgICAgICBUZXh0IENoYXRcbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBjbGFzc05hbWU9e2BhaS1tb2RlLXRvZ2dsZV9fYnRuICR7bW9kZSA9PT0gJ3ZvaWNlJyA/ICdhaS1tb2RlLXRvZ2dsZV9fYnRuLS1hY3RpdmUnIDogJyd9YH1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldE1vZGUoJ3ZvaWNlJyk7IHZvaWNlLnN0YXJ0TGlzdGVuaW5nKCk7IH19XG4gICAgICAgID5cbiAgICAgICAgICA8TWljIHNpemU9ezE0fSAvPlxuICAgICAgICAgIFNhc2EgVm9pY2UgQ2FsbFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Lyog4pSA4pSAIE1lc3NhZ2VzIEFyZWEg4pSA4pSAICovfVxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJhaS1tZXNzYWdlc1wiXG4gICAgICAgIGRhdGEtbGVuaXMtcHJldmVudD1cInRydWVcIlxuICAgICAgICBkYXRhLWxlbmlzLXByZXZlbnQtd2hlZWw9XCJ0cnVlXCJcbiAgICAgICAgZGF0YS1sZW5pcy1wcmV2ZW50LXRvdWNoPVwidHJ1ZVwiXG4gICAgICA+XG4gICAgICAgIHttZXNzYWdlcy5tYXAobXNnID0+IChcbiAgICAgICAgICA8ZGl2IGtleT17bXNnLmlkfSBjbGFzc05hbWU9e2BhaS1tc2ctcm93IGFpLW1zZy1yb3ctLSR7bXNnLnJvbGV9YH0+XG4gICAgICAgICAgICB7bXNnLnJvbGUgPT09ICdhaScgJiYgIXRlcm1pbmFsTW9kZSAmJiAoXG4gICAgICAgICAgICAgIDxpbWcgc3JjPXtBVkFUQVJfVVJMfSBhbHQ9XCJTYXNhXCIgY2xhc3NOYW1lPVwiYWktbXNnX19hdmF0YXJcIiAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgYWktbXNnIGFpLW1zZy0tJHttc2cucm9sZX1gfT5cbiAgICAgICAgICAgICAgPEZvcm1hdHRlZE1lc3NhZ2VUZXh0IHRleHQ9e21zZy50ZXh0fSAvPlxuICAgICAgICAgICAgICB7bXNnLmlzU3RyZWFtaW5nICYmIDxzcGFuIGNsYXNzTmFtZT1cImFpLWN1cnNvclwiIC8+fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuXG4gICAgICAgIHtpc1RoaW5raW5nICYmICFtZXNzYWdlcy5maW5kKG0gPT4gbS5pc1N0cmVhbWluZykgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktbXNnLXJvdyBhaS1tc2ctcm93LS1haVwiPlxuICAgICAgICAgICAgeyF0ZXJtaW5hbE1vZGUgJiYgPGltZyBzcmM9e0FWQVRBUl9VUkx9IGFsdD1cIlNhc2FcIiBjbGFzc05hbWU9XCJhaS1tc2dfX2F2YXRhclwiIC8+fVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhaS10eXBpbmdcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWktdHlwaW5nX19sYWJlbFwiPlxuICAgICAgICAgICAgICAgIHt0ZXJtaW5hbE1vZGUgPyAncHJvY2Vzc2luZycgOiAnU2FzYSBpcyB0aGlua2luZyd9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhaS10eXBpbmdfX2RvdHNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhaS10eXBpbmdfX2RvdFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWktdHlwaW5nX19kb3RcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFpLXR5cGluZ19fZG90XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICA8ZGl2IHJlZj17bWVzc2FnZXNFbmRSZWZ9IC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIOKUgOKUgCBDb250ZXh0IENoaXBzIOKUgOKUgCAqL31cbiAgICAgIHttZXNzYWdlcy5sZW5ndGggPD0gMiAmJiAhaXNUaGlua2luZyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktY2hpcHNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LVsxMHB4XSBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXdoaXRlLzQwIG1iLTEgcHgtMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MTF9IGNsYXNzTmFtZT1cInRleHQtd2hpdGUvNjBcIiAvPiBTdWdnZXN0ZWQgdG9waWNzOlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtjaGlwcy5tYXAoKGNoaXAsIGkpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhaS1jaGlwXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VuZChjaGlwKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2NoaXB9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7Lyog4pSA4pSAIFRleHQgSW5wdXQgKFRleHQgTW9kZSkg4pSA4pSAICovfVxuICAgICAge21vZGUgPT09ICd0ZXh0JyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktaW5wdXQtYmFyXCI+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICByZWY9e2lucHV0UmVmfVxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWktaW5wdXQtYmFyX19maWVsZFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj17dGVybWluYWxNb2RlID8gJyQgdHlwZSBhIGNvbW1hbmQgb3IgcXVlc3Rpb24uLi4nIDogJ0FzayBtZSBhbnl0aGluZyBhYm91dCBTYXNhLi4uJ31cbiAgICAgICAgICAgIHZhbHVlPXtpbnB1dFZhbHVlfVxuICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0SW5wdXRWYWx1ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBvbktleURvd249e2hhbmRsZUtleURvd259XG4gICAgICAgICAgICBtYXhMZW5ndGg9ezUwMH1cbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9mZlwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhaS1pbnB1dC1iYXJfX3NlbmRcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VuZCgpfVxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFpbnB1dFZhbHVlLnRyaW0oKSB8fCBpc1RoaW5raW5nfVxuICAgICAgICAgICAgdGl0bGU9XCJTZW5kIG1lc3NhZ2VcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTZW5kIHNpemU9ezE1fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiDilIDilIAgVm9pY2UgSW5wdXQgKFZvaWNlIENhbGwgTW9kZSkg4pSA4pSAICovfVxuICAgICAge21vZGUgPT09ICd2b2ljZScgJiYgKFxuICAgICAgICB2b2ljZS5pc1N1cHBvcnRlZCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFpLXZvaWNlLWFyZWFcIj5cbiAgICAgICAgICAgIHsvKiBDZW50ZXIgQXZhdGFyIFZpc3VhbGl6ZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BhaS12b2ljZS1hdmF0YXItcmluZyAke3ZvaWNlLmlzTGlzdGVuaW5nID8gJ2FpLXZvaWNlLWF2YXRhci1yaW5nLS1saXN0ZW5pbmcnIDogdm9pY2UuaXNTcGVha2luZyA/ICdhaS12b2ljZS1hdmF0YXItcmluZy0tc3BlYWtpbmcnIDogJyd9YH0+XG4gICAgICAgICAgICAgICAgPGltZyBzcmM9e0FWQVRBUl9VUkx9IGFsdD1cIlNhc2EgQXZhdGFyXCIgY2xhc3NOYW1lPVwidy0yMCBoLTIwIHJvdW5kZWQtZnVsbCBvYmplY3QtY292ZXIgcC0xIGJnLWJsYWNrLzYwIGJvcmRlciBib3JkZXItd2hpdGUvMjBcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTGl2ZSB0cmFuc2NyaXB0IC8gc3RhdHVzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhaS12b2ljZS1hcmVhX190cmFuc2NyaXB0XCI+XG4gICAgICAgICAgICAgIHt2b2ljZS5pc0xpc3RlbmluZ1xuICAgICAgICAgICAgICAgID8gdm9pY2UudHJhbnNjcmlwdCB8fCAnTGlzdGVuaW5nLi4uIHNwZWFrIGFueXRpbWUnXG4gICAgICAgICAgICAgICAgOiB2b2ljZS5pc1NwZWFraW5nXG4gICAgICAgICAgICAgICAgICA/ICdTcGVha2luZyAodGFwIHN0b3Agb3Igc2F5IFwic3RvcFwiIHRvIGludGVycnVwdCkuLi4nXG4gICAgICAgICAgICAgICAgICA6IHZvaWNlLmVycm9yIHx8ICdIYW5kcy1mcmVlIHZvaWNlIGFjdGl2ZS4gU2F5IHNvbWV0aGluZyEnfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBXYXZlZm9ybSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktd2F2ZWZvcm1cIiByZWY9e3dhdmVmb3JtUmVmfT5cbiAgICAgICAgICAgICAge0FycmF5LmZyb20oeyBsZW5ndGg6IDE1IH0pLm1hcCgoXywgaSkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFpLXdhdmVmb3JtX19iYXIgJHt2b2ljZS5pc0xpc3RlbmluZyA/ICdhaS13YXZlZm9ybV9fYmFyLS1hY3RpdmUnIDogdm9pY2UuaXNTcGVha2luZyA/ICdhaS13YXZlZm9ybV9fYmFyLS1zcGVha2luZycgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiAnNHB4JyB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBNaWMgLyBJbnRlcnJ1cHRpb24gQ29udHJvbHMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIHt2b2ljZS5pc1NwZWFraW5nID8gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFpLW1pYy1idG4gYWktbWljLWJ0bi0tc3BlYWtpbmctc3RvcCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC02IHctYXV0byByb3VuZGVkLWZ1bGwgYmctcmVkLTYwMC8zMCBib3JkZXItcmVkLTUwMCB0ZXh0LXJlZC00MDAgaG92ZXI6YmctcmVkLTYwMC81MFwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2ljZS5zdG9wU3BlYWtpbmcoKX1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU3RvcCBBSSBzcGVlY2ggKG9yIGp1c3Qgc3RhcnQgdGFsa2luZylcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTcXVhcmUgc2l6ZT17MTZ9IGZpbGw9XCJjdXJyZW50Q29sb3JcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIGZvbnQtYm9sZCB0cmFja2luZy13aWRlclwiPlN0b3AgU3BlYWtpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYWktbWljLWJ0biAke3ZvaWNlLmlzTGlzdGVuaW5nID8gJ2FpLW1pYy1idG4tLWFjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlVm9pY2V9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNUaGlua2luZ31cbiAgICAgICAgICAgICAgICAgIHRpdGxlPXt2b2ljZS5pc0xpc3RlbmluZyA/ICdQYXVzZSBtaWNyb3Bob25lJyA6ICdTdGFydCBoYW5kcy1mcmVlIHZvaWNlIGNhbGwnfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHt2b2ljZS5pc0xpc3RlbmluZyA/IDxNaWNPZmYgc2l6ZT17MjJ9IC8+IDogPE1pYyBzaXplPXsyMn0gLz59XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFpLXZvaWNlLXVuc3VwcG9ydGVkXCI+XG4gICAgICAgICAgICBWb2ljZSBjb252ZXJzYXRpb24gaXMgYmVzdCBzdXBwb3J0ZWQgaW4gQ2hyb21lLCBFZGdlLCBvciBTYWZhcmkuPGJyIC8+XG4gICAgICAgICAgICBTd2l0Y2ggdG8gPGI+VGV4dCBDaGF0PC9iPiBtb2RlIHRvIGNvbnRpbnVlIVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApXG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9Xb3JrL1Nhc3VkdWwvc2FzYS9zYXN1bmR1bC1wb3J0Zm9saW8vY29tcG9uZW50cy9BaUNoYXRib3QudHN4In0=