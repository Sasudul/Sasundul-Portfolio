import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/ExpertiseSection.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { ScrollTrigger } from "/node_modules/.vite/deps/gsap_ScrollTrigger.js?v=5088fc54";
import { ArrowUpRight } from "/node_modules/.vite/deps/lucide-react.js?v=5088fc54";
import PixelBlast from "/components/PixelBlast.tsx";
gsap.registerPlugin(ScrollTrigger);
const EXPERTISE = [
  {
    id: 0,
    number: "01",
    title: "DESIGN",
    subtitle: "UI/UX & Brand Aesthetics",
    description: "Crafting clean, thoughtful layouts that balance visual aesthetics with intuitive usability. I focus on hierarchy, typography, spatial geometry, and brand identity to make digital products look and feel world-class.",
    tags: ["Figma", "UI/UX Design", "Wireframing", "Design Systems", "Design Tokens"],
    highlights: ["Pixel-Perfect Alignment", "Modern Design Tokens", "User Centric Workflows"]
  },
  {
    id: 1,
    number: "02",
    title: "DEVELOPMENT",
    subtitle: "Full-Stack Architecture & Performance",
    description: "Engineering fast, scalable, and maintainable full-stack applications with modern web stacks. From robust backends to smooth frontend user interfaces, every line of code is structured for performance.",
    tags: ["React 19", "Next.js", "TypeScript", "Spring Boot", "Tailwind CSS", "MySQL"],
    highlights: ["High-Performance Code", "Clean Modular Architecture", "Responsive Across Devices"]
  },
  {
    id: 2,
    number: "03",
    title: "INTERACTIONS",
    subtitle: "Motion, 3D & Micro-Animations",
    description: "Bringing static interfaces to life through fluid animations, scroll-driven reveals, and 3D interactions. Creating tactile, responsive feedback that engages users and leaves a lasting impression.",
    tags: ["GSAP", "ScrollTrigger", "Framer Motion", "Three.js / Canvas", "CSS Keyframes"],
    highlights: ["60fps Smooth Motion", "Interactive 3D Elements", "Tactile User Feedback"]
  }
];
export default function ExpertiseSection() {
  _s();
  const sectionRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const activeIndexRef = useRef(0);
  const isAnimatingRef = useRef(false);
  useEffect(() => {
    activeIndexRef.current = activeIndex;
  }, [activeIndex]);
  useGSAP(() => {
    const section = sectionRef.current;
    if (!section) return;
    ScrollTrigger.create({
      trigger: section,
      pin: true,
      start: "top top",
      end: "+=100%",
      scrub: 0.1,
      onUpdate: (self2) => {
        const progress = self2.progress;
        let index = 0;
        if (progress >= 0.6) index = 2;
        else if (progress >= 0.3) index = 1;
        if (index !== activeIndexRef.current) {
          activeIndexRef.current = index;
          setActiveIndex(index);
        }
      }
    });
  }, { scope: sectionRef });
  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    let deltaAccumulator = 0;
    let resetTimer = null;
    const handleWheel = (e) => {
      const rect = section.getBoundingClientRect();
      const isCentered = Math.abs(rect.top) < 25;
      if (!isCentered) return;
      const delta = e.deltaY;
      if (Math.abs(delta) < 5) return;
      deltaAccumulator += delta;
      clearTimeout(resetTimer);
      resetTimer = setTimeout(() => {
        deltaAccumulator = 0;
      }, 300);
      const THRESHOLD = 1e3;
      if (deltaAccumulator >= THRESHOLD && activeIndexRef.current < EXPERTISE.length - 1) {
        e.preventDefault();
        deltaAccumulator = 0;
        if (isAnimatingRef.current) return;
        isAnimatingRef.current = true;
        const next = activeIndexRef.current + 1;
        activeIndexRef.current = next;
        setActiveIndex(next);
        setTimeout(() => {
          isAnimatingRef.current = false;
        }, 500);
      } else if (deltaAccumulator <= -THRESHOLD && activeIndexRef.current > 0) {
        e.preventDefault();
        deltaAccumulator = 0;
        if (isAnimatingRef.current) return;
        isAnimatingRef.current = true;
        const prev = activeIndexRef.current - 1;
        activeIndexRef.current = prev;
        setActiveIndex(prev);
        setTimeout(() => {
          isAnimatingRef.current = false;
        }, 500);
      } else if (deltaAccumulator > 0 && activeIndexRef.current < EXPERTISE.length - 1 || deltaAccumulator < 0 && activeIndexRef.current > 0) {
        e.preventDefault();
      }
    };
    window.addEventListener("wheel", handleWheel, { passive: false });
    return () => window.removeEventListener("wheel", handleWheel);
  }, []);
  const activeItem = EXPERTISE[activeIndex];
  return /* @__PURE__ */ jsxDEV(
    "section",
    {
      ref: sectionRef,
      id: "expertise",
      className: "relative min-h-screen h-screen flex flex-col justify-between py-8 px-6 md:px-16 bg-[#050505] text-white overflow-hidden",
      children: [
        /* @__PURE__ */ jsxDEV(
          PixelBlast,
          {
            variant: "circle",
            color: "#707070",
            pixelSize: 3,
            patternDensity: 1.2,
            patternScale: 2,
            liquid: true,
            liquidStrength: 0.08,
            liquidRadius: 1,
            enableRipples: true,
            rippleIntensityScale: 1.2,
            rippleThickness: 0.1,
            rippleSpeed: 0.3,
            opacity: 0.25
          },
          void 0,
          false,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
            lineNumber: 145,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "max-w-7xl mx-auto w-full relative z-10 flex flex-col justify-between h-full py-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-b border-white/10 pb-5 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-mono uppercase tracking-widest text-white/50 flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-5 h-[1.5px] bg-white/40" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                  lineNumber: 167,
                  columnNumber: 15
                }, this),
                "Capabilities & Services"
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                lineNumber: 166,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl md:text-6xl font-display font-bold uppercase tracking-tighter text-white", children: "Expertise" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                lineNumber: 170,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
              lineNumber: 165,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "hidden md:flex items-center gap-3 font-mono text-sm", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-white font-bold text-lg", children: activeItem.number }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                lineNumber: 177,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-white/30", children: "/" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                lineNumber: 178,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-white/40", children: "03" }, void 0, false, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                lineNumber: 179,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
              lineNumber: 176,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
            lineNumber: 164,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center my-auto", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-5 flex flex-col gap-4", children: EXPERTISE.map((item, idx) => {
              const isActive = activeIndex === idx;
              return /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    activeIndexRef.current = idx;
                    setActiveIndex(idx);
                  },
                  className: `group text-left p-5 md:p-6 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between ${isActive ? "bg-white/10 border-white/30 shadow-[0_10px_30px_rgba(255,255,255,0.05)] backdrop-blur-xl translate-x-2" : "bg-white/[0.02] border-white/5 opacity-50 hover:opacity-80 hover:border-white/15"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: `font-mono text-sm font-bold transition-colors ${isActive ? "text-white" : "text-white/40"}`, children: item.number }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 203,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("h3", { className: `text-xl md:text-2xl font-display font-bold uppercase tracking-tight transition-colors ${isActive ? "text-white" : "text-white/60"}`, children: item.title }, void 0, false, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                          lineNumber: 207,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-mono text-white/40 mt-0.5", children: item.subtitle }, void 0, false, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                          lineNumber: 210,
                          columnNumber: 23
                        }, this)
                      ] }, void 0, true, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 206,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                      lineNumber: 202,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: `w-8 h-8 rounded-full border flex items-center justify-center transition-all ${isActive ? "border-white bg-white text-black rotate-45" : "border-white/20 text-white/40 group-hover:border-white/50"}`, children: /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 16 }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                      lineNumber: 216,
                      columnNumber: 21
                    }, this) }, void 0, false, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                      lineNumber: 214,
                      columnNumber: 19
                    }, this)
                  ]
                },
                item.number,
                true,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                  lineNumber: 191,
                  columnNumber: 17
                },
                this
              );
            }) }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
              lineNumber: 187,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-7 relative w-full min-h-[480px] md:min-h-[520px] rounded-3xl border border-white/15 bg-black/80 shadow-2xl backdrop-blur-2xl overflow-hidden", children: EXPERTISE.map((item, idx) => {
              const isActive = activeIndex === idx;
              return /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `exp-card-item absolute inset-0 p-6 sm:p-8 md:p-10 flex flex-col justify-between transition-all duration-500 ease-out ${isActive ? "opacity-100 scale-100 pointer-events-auto z-10 translate-y-0" : "opacity-0 scale-95 pointer-events-none z-0 translate-y-4"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-white/40 uppercase tracking-widest", children: item.subtitle }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 237,
                        columnNumber: 23
                      }, this) }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 236,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("h3", { className: "text-3xl md:text-5xl font-display font-bold uppercase tracking-tight text-white mb-3", children: item.title }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 243,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm md:text-base leading-relaxed text-white/75 font-sans mb-4", children: item.description }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 247,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5 my-3", children: item.highlights.map(
                        (h, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-xs font-mono text-white/70 bg-white/[0.03] border border-white/10 p-2.5 rounded-xl", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-white/60 flex-shrink-0" }, void 0, false, {
                            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                            lineNumber: 255,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: h }, void 0, false, {
                            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                            lineNumber: 256,
                            columnNumber: 27
                          }, this)
                        ] }, i, true, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                          lineNumber: 254,
                          columnNumber: 23
                        }, this)
                      ) }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 252,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                      lineNumber: 235,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-white/10 mt-4", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono uppercase tracking-widest text-white/40 block mb-2.5", children: "Technologies & Tools" }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 264,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: item.tags.map(
                        (tag) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono uppercase tracking-widest px-3 py-1.5 text-white/90 bg-white/5 border border-white/15 rounded-xl", children: tag }, tag, false, {
                          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                          lineNumber: 267,
                          columnNumber: 23
                        }, this)
                      ) }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                        lineNumber: 265,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                      lineNumber: 263,
                      columnNumber: 19
                    }, this)
                  ]
                },
                item.number,
                true,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
                  lineNumber: 228,
                  columnNumber: 17
                },
                this
              );
            }) }, void 0, false, {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
              lineNumber: 224,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
            lineNumber: 184,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 w-full pt-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full h-[2px] bg-white/10 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "h-full bg-white transition-all duration-500 rounded-full",
              style: { width: `${(activeIndex + 1) / EXPERTISE.length * 100}%` }
            },
            void 0,
            false,
            {
              fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
              lineNumber: 283,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
            lineNumber: 282,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
            lineNumber: 281,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
          lineNumber: 161,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx",
      lineNumber: 139,
      columnNumber: 5
    },
    this
  );
}
_s(ExpertiseSection, "f/ByLrehzcrTZcv3gUmlSU58dNI=", false, function() {
  return [useGSAP];
});
_c = ExpertiseSection;
var _c;
$RefreshReg$(_c, "ExpertiseSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ExpertiseSection.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0pNOztBQWhKTixTQUFTQSxRQUFRQyxVQUFVQyxpQkFBaUI7QUFDNUMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxVQUFVO0FBQ2pCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MsZ0JBQWdCO0FBRXZCSCxLQUFLSSxlQUFlSCxhQUFhO0FBRWpDLE1BQU1JLFlBQVk7QUFBQSxFQUNoQjtBQUFBLElBQ0VDLElBQUk7QUFBQSxJQUNKQyxRQUFRO0FBQUEsSUFDUkMsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxhQUFhO0FBQUEsSUFDYkMsTUFBTSxDQUFDLFNBQVMsZ0JBQWdCLGVBQWUsa0JBQWtCLGVBQWU7QUFBQSxJQUNoRkMsWUFBWSxDQUFDLDJCQUEyQix3QkFBd0Isd0JBQXdCO0FBQUEsRUFDMUY7QUFBQSxFQUNBO0FBQUEsSUFDRU4sSUFBSTtBQUFBLElBQ0pDLFFBQVE7QUFBQSxJQUNSQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLElBQ1ZDLGFBQWE7QUFBQSxJQUNiQyxNQUFNLENBQUMsWUFBWSxXQUFXLGNBQWMsZUFBZSxnQkFBZ0IsT0FBTztBQUFBLElBQ2xGQyxZQUFZLENBQUMseUJBQXlCLDhCQUE4QiwyQkFBMkI7QUFBQSxFQUNqRztBQUFBLEVBQ0E7QUFBQSxJQUNFTixJQUFJO0FBQUEsSUFDSkMsUUFBUTtBQUFBLElBQ1JDLE9BQU87QUFBQSxJQUNQQyxVQUFVO0FBQUEsSUFDVkMsYUFBYTtBQUFBLElBQ2JDLE1BQU0sQ0FBQyxRQUFRLGlCQUFpQixpQkFBaUIscUJBQXFCLGVBQWU7QUFBQSxJQUNyRkMsWUFBWSxDQUFDLHVCQUF1QiwyQkFBMkIsdUJBQXVCO0FBQUEsRUFDeEY7QUFBQztBQUdILHdCQUF3QkMsbUJBQW1CO0FBQUFDLEtBQUE7QUFDekMsUUFBTUMsYUFBYW5CLE9BQW9CLElBQUk7QUFDM0MsUUFBTSxDQUFDb0IsYUFBYUMsY0FBYyxJQUFJcEIsU0FBUyxDQUFDO0FBQ2hELFFBQU1xQixpQkFBaUJ0QixPQUFPLENBQUM7QUFDL0IsUUFBTXVCLGlCQUFpQnZCLE9BQU8sS0FBSztBQUduQ0UsWUFBVSxNQUFNO0FBQ2RvQixtQkFBZUUsVUFBVUo7QUFBQUEsRUFDM0IsR0FBRyxDQUFDQSxXQUFXLENBQUM7QUFHaEJqQixVQUFRLE1BQU07QUFDWixVQUFNc0IsVUFBVU4sV0FBV0s7QUFDM0IsUUFBSSxDQUFDQyxRQUFTO0FBRWRwQixrQkFBY3FCLE9BQU87QUFBQSxNQUNuQkMsU0FBU0Y7QUFBQUEsTUFDVEcsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLFVBQVVBLENBQUNDLFVBQVM7QUFDbEIsY0FBTUMsV0FBV0QsTUFBS0M7QUFDdEIsWUFBSUMsUUFBUTtBQUNaLFlBQUlELFlBQVksSUFBS0MsU0FBUTtBQUFBLGlCQUNwQkQsWUFBWSxJQUFLQyxTQUFRO0FBRWxDLFlBQUlBLFVBQVViLGVBQWVFLFNBQVM7QUFDcENGLHlCQUFlRSxVQUFVVztBQUN6QmQseUJBQWVjLEtBQUs7QUFBQSxRQUN0QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsRUFBRUMsT0FBT2pCLFdBQVcsQ0FBQztBQUd4QmpCLFlBQVUsTUFBTTtBQUNkLFVBQU11QixVQUFVTixXQUFXSztBQUMzQixRQUFJLENBQUNDLFFBQVM7QUFFZCxRQUFJWSxtQkFBbUI7QUFDdkIsUUFBSUMsYUFBa0I7QUFFdEIsVUFBTUMsY0FBY0EsQ0FBQ0MsTUFBa0I7QUFDckMsWUFBTUMsT0FBT2hCLFFBQVFpQixzQkFBc0I7QUFDM0MsWUFBTUMsYUFBYUMsS0FBS0MsSUFBSUosS0FBS0ssR0FBRyxJQUFJO0FBRXhDLFVBQUksQ0FBQ0gsV0FBWTtBQUVqQixZQUFNSSxRQUFRUCxFQUFFUTtBQUNoQixVQUFJSixLQUFLQyxJQUFJRSxLQUFLLElBQUksRUFBRztBQUV6QlYsMEJBQW9CVTtBQUVwQkUsbUJBQWFYLFVBQVU7QUFDdkJBLG1CQUFhWSxXQUFXLE1BQU07QUFDNUJiLDJCQUFtQjtBQUFBLE1BQ3JCLEdBQUcsR0FBRztBQUVOLFlBQU1jLFlBQVk7QUFHbEIsVUFBSWQsb0JBQW9CYyxhQUFhN0IsZUFBZUUsVUFBVWYsVUFBVTJDLFNBQVMsR0FBRztBQUNsRlosVUFBRWEsZUFBZTtBQUNqQmhCLDJCQUFtQjtBQUNuQixZQUFJZCxlQUFlQyxRQUFTO0FBQzVCRCx1QkFBZUMsVUFBVTtBQUN6QixjQUFNOEIsT0FBT2hDLGVBQWVFLFVBQVU7QUFDdENGLHVCQUFlRSxVQUFVOEI7QUFDekJqQyx1QkFBZWlDLElBQUk7QUFDbkJKLG1CQUFXLE1BQU07QUFBRTNCLHlCQUFlQyxVQUFVO0FBQUEsUUFBTyxHQUFHLEdBQUc7QUFBQSxNQUMzRCxXQUVTYSxvQkFBb0IsQ0FBQ2MsYUFBYTdCLGVBQWVFLFVBQVUsR0FBRztBQUNyRWdCLFVBQUVhLGVBQWU7QUFDakJoQiwyQkFBbUI7QUFDbkIsWUFBSWQsZUFBZUMsUUFBUztBQUM1QkQsdUJBQWVDLFVBQVU7QUFDekIsY0FBTStCLE9BQU9qQyxlQUFlRSxVQUFVO0FBQ3RDRix1QkFBZUUsVUFBVStCO0FBQ3pCbEMsdUJBQWVrQyxJQUFJO0FBQ25CTCxtQkFBVyxNQUFNO0FBQUUzQix5QkFBZUMsVUFBVTtBQUFBLFFBQU8sR0FBRyxHQUFHO0FBQUEsTUFDM0QsV0FFR2EsbUJBQW1CLEtBQUtmLGVBQWVFLFVBQVVmLFVBQVUyQyxTQUFTLEtBQ3BFZixtQkFBbUIsS0FBS2YsZUFBZUUsVUFBVSxHQUNsRDtBQUNBZ0IsVUFBRWEsZUFBZTtBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUVBRyxXQUFPQyxpQkFBaUIsU0FBU2xCLGFBQWEsRUFBRW1CLFNBQVMsTUFBTSxDQUFDO0FBQ2hFLFdBQU8sTUFBTUYsT0FBT0csb0JBQW9CLFNBQVNwQixXQUFXO0FBQUEsRUFDOUQsR0FBRyxFQUFFO0FBRUwsUUFBTXFCLGFBQWFuRCxVQUFVVyxXQUFXO0FBRXhDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUtEO0FBQUFBLE1BQ0wsSUFBRztBQUFBLE1BQ0gsV0FBVTtBQUFBLE1BR1Y7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsT0FBTTtBQUFBLFlBQ04sV0FBVztBQUFBLFlBQ1gsZ0JBQWdCO0FBQUEsWUFDaEIsY0FBYztBQUFBLFlBQ2QsUUFBUTtBQUFBLFlBQ1IsZ0JBQWdCO0FBQUEsWUFDaEIsY0FBYztBQUFBLFlBQ2QsZUFBZTtBQUFBLFlBQ2Ysc0JBQXNCO0FBQUEsWUFDdEIsaUJBQWlCO0FBQUEsWUFDakIsYUFBYTtBQUFBLFlBQ2IsU0FBUztBQUFBO0FBQUEsVUFiWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhZ0I7QUFBQSxRQUdoQix1QkFBQyxTQUFJLFdBQVUsb0ZBR2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLCtCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QztBQUFBLGdCQUFNO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxxRkFBbUYseUJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsZ0NBQWdDeUMscUJBQVdqRCxVQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGNBQ2xFLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsY0FDakMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixrQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxpQkFIcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUseUVBR2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUNBQ1pGLG9CQUFVb0QsSUFBSSxDQUFDQyxNQUFNQyxRQUFRO0FBQzVCLG9CQUFNQyxXQUFXNUMsZ0JBQWdCMkM7QUFDakMscUJBQ0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsU0FBUyxNQUFNO0FBQ2J6QyxtQ0FBZUUsVUFBVXVDO0FBQ3pCMUMsbUNBQWUwQyxHQUFHO0FBQUEsa0JBQ3BCO0FBQUEsa0JBQ0EsV0FBVyw4SEFBOEhDLFdBQ3JJLDJHQUNBLGtGQUFrRjtBQUFBLGtCQUd0RjtBQUFBLDJDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZDQUFDLFVBQUssV0FBVyxpREFBaURBLFdBQVcsZUFBZSxlQUFlLElBQ3hHRixlQUFLbkQsVUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FDQztBQUFBLCtDQUFDLFFBQUcsV0FBVyx5RkFBeUZxRCxXQUFXLGVBQWUsZUFBZSxJQUM5SUYsZUFBS2xELFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBLHVCQUFDLE9BQUUsV0FBVSwwQ0FBMENrRCxlQUFLakQsWUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBcUU7QUFBQSwyQkFKdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBLHlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVUE7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVcsK0VBQStFbUQsV0FBVywrQ0FBK0MsMkRBQTJELElBRWxOLGlDQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUIsS0FGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBO0FBQUE7QUFBQSxnQkF6QktGLEtBQUtuRDtBQUFBQSxnQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMkJBO0FBQUEsWUFFSixDQUFDLEtBakNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0NBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsNEpBQ1pGLG9CQUFVb0QsSUFBSSxDQUFDQyxNQUFNQyxRQUFRO0FBQzVCLG9CQUFNQyxXQUFXNUMsZ0JBQWdCMkM7QUFDakMscUJBQ0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVyx3SEFBd0hDLFdBQy9ILGlFQUNBLDBEQUEwRDtBQUFBLGtCQUc5RDtBQUFBLDJDQUFDLFNBQ0M7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxVQUFLLFdBQVUsNkRBQ2JGLGVBQUtqRCxZQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUlBO0FBQUEsc0JBR0EsdUJBQUMsUUFBRyxXQUFVLHdGQUNYaUQsZUFBS2xELFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUVBLHVCQUFDLE9BQUUsV0FBVSxxRUFDVmtELGVBQUtoRCxlQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ1pnRCxlQUFLOUMsV0FBVzZDO0FBQUFBLHdCQUFJLENBQUNJLEdBQUdDLE1BQ3ZCLHVCQUFDLFNBQVksV0FBVSxtSEFDckI7QUFBQSxpREFBQyxVQUFLLFdBQVUsd0RBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXFFO0FBQUEsMEJBQ3JFLHVCQUFDLFVBQUssV0FBVSxZQUFZRCxlQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE4QjtBQUFBLDZCQUZ0QkMsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUdBO0FBQUEsc0JBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU9BO0FBQUEseUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBeUJBO0FBQUEsb0JBR0EsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsNkNBQUMsVUFBSyxXQUFVLDBFQUF5RSxvQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkc7QUFBQSxzQkFDN0csdUJBQUMsU0FBSSxXQUFVLHdCQUNaSixlQUFLL0MsS0FBSzhDO0FBQUFBLHdCQUFJLENBQUFNLFFBQ2IsdUJBQUMsVUFBZSxXQUFVLHNIQUN2QkEsaUJBRFFBLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFNQTtBQUFBLHlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBU0E7QUFBQTtBQUFBO0FBQUEsZ0JBM0NLTCxLQUFLbkQ7QUFBQUEsZ0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTZDQTtBQUFBLFlBRUosQ0FBQyxLQW5ESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBLGVBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEZBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPLEVBQUV5RCxPQUFPLElBQUtoRCxjQUFjLEtBQUtYLFVBQVUyQyxTQUFVLEdBQUcsSUFBSTtBQUFBO0FBQUEsWUFGckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRXVFLEtBSHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUEvSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlJQTtBQUFBO0FBQUE7QUFBQSxJQXZKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF5SkE7QUFFSjtBQUFDbEMsR0E5UHVCRCxrQkFBZ0I7QUFBQSxVQVl0Q2QsT0FBTztBQUFBO0FBQUFrRSxLQVplcEQ7QUFBZ0IsSUFBQW9EO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VSZWYiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUdTQVAiLCJnc2FwIiwiU2Nyb2xsVHJpZ2dlciIsIkFycm93VXBSaWdodCIsIlBpeGVsQmxhc3QiLCJyZWdpc3RlclBsdWdpbiIsIkVYUEVSVElTRSIsImlkIiwibnVtYmVyIiwidGl0bGUiLCJzdWJ0aXRsZSIsImRlc2NyaXB0aW9uIiwidGFncyIsImhpZ2hsaWdodHMiLCJFeHBlcnRpc2VTZWN0aW9uIiwiX3MiLCJzZWN0aW9uUmVmIiwiYWN0aXZlSW5kZXgiLCJzZXRBY3RpdmVJbmRleCIsImFjdGl2ZUluZGV4UmVmIiwiaXNBbmltYXRpbmdSZWYiLCJjdXJyZW50Iiwic2VjdGlvbiIsImNyZWF0ZSIsInRyaWdnZXIiLCJwaW4iLCJzdGFydCIsImVuZCIsInNjcnViIiwib25VcGRhdGUiLCJzZWxmIiwicHJvZ3Jlc3MiLCJpbmRleCIsInNjb3BlIiwiZGVsdGFBY2N1bXVsYXRvciIsInJlc2V0VGltZXIiLCJoYW5kbGVXaGVlbCIsImUiLCJyZWN0IiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwiaXNDZW50ZXJlZCIsIk1hdGgiLCJhYnMiLCJ0b3AiLCJkZWx0YSIsImRlbHRhWSIsImNsZWFyVGltZW91dCIsInNldFRpbWVvdXQiLCJUSFJFU0hPTEQiLCJsZW5ndGgiLCJwcmV2ZW50RGVmYXVsdCIsIm5leHQiLCJwcmV2Iiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiYWN0aXZlSXRlbSIsIm1hcCIsIml0ZW0iLCJpZHgiLCJpc0FjdGl2ZSIsImgiLCJpIiwidGFnIiwid2lkdGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFeHBlcnRpc2VTZWN0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSZWYsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VHU0FQIH0gZnJvbSAnQGdzYXAvcmVhY3QnO1xuaW1wb3J0IGdzYXAgZnJvbSAnZ3NhcCc7XG5pbXBvcnQgeyBTY3JvbGxUcmlnZ2VyIH0gZnJvbSAnZ3NhcC9TY3JvbGxUcmlnZ2VyJztcbmltcG9ydCB7IEFycm93VXBSaWdodCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgUGl4ZWxCbGFzdCBmcm9tICcuL1BpeGVsQmxhc3QnO1xuXG5nc2FwLnJlZ2lzdGVyUGx1Z2luKFNjcm9sbFRyaWdnZXIpO1xuXG5jb25zdCBFWFBFUlRJU0UgPSBbXG4gIHtcbiAgICBpZDogMCxcbiAgICBudW1iZXI6ICcwMScsXG4gICAgdGl0bGU6ICdERVNJR04nLFxuICAgIHN1YnRpdGxlOiAnVUkvVVggJiBCcmFuZCBBZXN0aGV0aWNzJyxcbiAgICBkZXNjcmlwdGlvbjogJ0NyYWZ0aW5nIGNsZWFuLCB0aG91Z2h0ZnVsIGxheW91dHMgdGhhdCBiYWxhbmNlIHZpc3VhbCBhZXN0aGV0aWNzIHdpdGggaW50dWl0aXZlIHVzYWJpbGl0eS4gSSBmb2N1cyBvbiBoaWVyYXJjaHksIHR5cG9ncmFwaHksIHNwYXRpYWwgZ2VvbWV0cnksIGFuZCBicmFuZCBpZGVudGl0eSB0byBtYWtlIGRpZ2l0YWwgcHJvZHVjdHMgbG9vayBhbmQgZmVlbCB3b3JsZC1jbGFzcy4nLFxuICAgIHRhZ3M6IFsnRmlnbWEnLCAnVUkvVVggRGVzaWduJywgJ1dpcmVmcmFtaW5nJywgJ0Rlc2lnbiBTeXN0ZW1zJywgJ0Rlc2lnbiBUb2tlbnMnXSxcbiAgICBoaWdobGlnaHRzOiBbJ1BpeGVsLVBlcmZlY3QgQWxpZ25tZW50JywgJ01vZGVybiBEZXNpZ24gVG9rZW5zJywgJ1VzZXIgQ2VudHJpYyBXb3JrZmxvd3MnXVxuICB9LFxuICB7XG4gICAgaWQ6IDEsXG4gICAgbnVtYmVyOiAnMDInLFxuICAgIHRpdGxlOiAnREVWRUxPUE1FTlQnLFxuICAgIHN1YnRpdGxlOiAnRnVsbC1TdGFjayBBcmNoaXRlY3R1cmUgJiBQZXJmb3JtYW5jZScsXG4gICAgZGVzY3JpcHRpb246ICdFbmdpbmVlcmluZyBmYXN0LCBzY2FsYWJsZSwgYW5kIG1haW50YWluYWJsZSBmdWxsLXN0YWNrIGFwcGxpY2F0aW9ucyB3aXRoIG1vZGVybiB3ZWIgc3RhY2tzLiBGcm9tIHJvYnVzdCBiYWNrZW5kcyB0byBzbW9vdGggZnJvbnRlbmQgdXNlciBpbnRlcmZhY2VzLCBldmVyeSBsaW5lIG9mIGNvZGUgaXMgc3RydWN0dXJlZCBmb3IgcGVyZm9ybWFuY2UuJyxcbiAgICB0YWdzOiBbJ1JlYWN0IDE5JywgJ05leHQuanMnLCAnVHlwZVNjcmlwdCcsICdTcHJpbmcgQm9vdCcsICdUYWlsd2luZCBDU1MnLCAnTXlTUUwnXSxcbiAgICBoaWdobGlnaHRzOiBbJ0hpZ2gtUGVyZm9ybWFuY2UgQ29kZScsICdDbGVhbiBNb2R1bGFyIEFyY2hpdGVjdHVyZScsICdSZXNwb25zaXZlIEFjcm9zcyBEZXZpY2VzJ11cbiAgfSxcbiAge1xuICAgIGlkOiAyLFxuICAgIG51bWJlcjogJzAzJyxcbiAgICB0aXRsZTogJ0lOVEVSQUNUSU9OUycsXG4gICAgc3VidGl0bGU6ICdNb3Rpb24sIDNEICYgTWljcm8tQW5pbWF0aW9ucycsXG4gICAgZGVzY3JpcHRpb246ICdCcmluZ2luZyBzdGF0aWMgaW50ZXJmYWNlcyB0byBsaWZlIHRocm91Z2ggZmx1aWQgYW5pbWF0aW9ucywgc2Nyb2xsLWRyaXZlbiByZXZlYWxzLCBhbmQgM0QgaW50ZXJhY3Rpb25zLiBDcmVhdGluZyB0YWN0aWxlLCByZXNwb25zaXZlIGZlZWRiYWNrIHRoYXQgZW5nYWdlcyB1c2VycyBhbmQgbGVhdmVzIGEgbGFzdGluZyBpbXByZXNzaW9uLicsXG4gICAgdGFnczogWydHU0FQJywgJ1Njcm9sbFRyaWdnZXInLCAnRnJhbWVyIE1vdGlvbicsICdUaHJlZS5qcyAvIENhbnZhcycsICdDU1MgS2V5ZnJhbWVzJ10sXG4gICAgaGlnaGxpZ2h0czogWyc2MGZwcyBTbW9vdGggTW90aW9uJywgJ0ludGVyYWN0aXZlIDNEIEVsZW1lbnRzJywgJ1RhY3RpbGUgVXNlciBGZWVkYmFjayddXG4gIH0sXG5dO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBFeHBlcnRpc2VTZWN0aW9uKCkge1xuICBjb25zdCBzZWN0aW9uUmVmID0gdXNlUmVmPEhUTUxFbGVtZW50PihudWxsKTtcbiAgY29uc3QgW2FjdGl2ZUluZGV4LCBzZXRBY3RpdmVJbmRleF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgYWN0aXZlSW5kZXhSZWYgPSB1c2VSZWYoMCk7XG4gIGNvbnN0IGlzQW5pbWF0aW5nUmVmID0gdXNlUmVmKGZhbHNlKTtcblxuICAvLyBLZWVwIHJlZiBzeW5jaHJvbml6ZWQgd2l0aCBzdGF0ZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGFjdGl2ZUluZGV4UmVmLmN1cnJlbnQgPSBhY3RpdmVJbmRleDtcbiAgfSwgW2FjdGl2ZUluZGV4XSk7XG5cbiAgLy8gR1NBUCBQaW5uaW5nXG4gIHVzZUdTQVAoKCkgPT4ge1xuICAgIGNvbnN0IHNlY3Rpb24gPSBzZWN0aW9uUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzZWN0aW9uKSByZXR1cm47XG5cbiAgICBTY3JvbGxUcmlnZ2VyLmNyZWF0ZSh7XG4gICAgICB0cmlnZ2VyOiBzZWN0aW9uLFxuICAgICAgcGluOiB0cnVlLFxuICAgICAgc3RhcnQ6ICd0b3AgdG9wJyxcbiAgICAgIGVuZDogJys9MTAwJScsXG4gICAgICBzY3J1YjogMC4xLFxuICAgICAgb25VcGRhdGU6IChzZWxmKSA9PiB7XG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gc2VsZi5wcm9ncmVzcztcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgaWYgKHByb2dyZXNzID49IDAuNikgaW5kZXggPSAyO1xuICAgICAgICBlbHNlIGlmIChwcm9ncmVzcyA+PSAwLjMpIGluZGV4ID0gMTtcblxuICAgICAgICBpZiAoaW5kZXggIT09IGFjdGl2ZUluZGV4UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICBhY3RpdmVJbmRleFJlZi5jdXJyZW50ID0gaW5kZXg7XG4gICAgICAgICAgc2V0QWN0aXZlSW5kZXgoaW5kZXgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH0sIHsgc2NvcGU6IHNlY3Rpb25SZWYgfSk7XG5cbiAgLy8gMi1Ob3RjaCBXaGVlbCBFdmVudCBPYnNlcnZlclxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHNlY3Rpb24gPSBzZWN0aW9uUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzZWN0aW9uKSByZXR1cm47XG5cbiAgICBsZXQgZGVsdGFBY2N1bXVsYXRvciA9IDA7XG4gICAgbGV0IHJlc2V0VGltZXI6IGFueSA9IG51bGw7XG5cbiAgICBjb25zdCBoYW5kbGVXaGVlbCA9IChlOiBXaGVlbEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCByZWN0ID0gc2VjdGlvbi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIGNvbnN0IGlzQ2VudGVyZWQgPSBNYXRoLmFicyhyZWN0LnRvcCkgPCAyNTtcblxuICAgICAgaWYgKCFpc0NlbnRlcmVkKSByZXR1cm47XG5cbiAgICAgIGNvbnN0IGRlbHRhID0gZS5kZWx0YVk7XG4gICAgICBpZiAoTWF0aC5hYnMoZGVsdGEpIDwgNSkgcmV0dXJuO1xuXG4gICAgICBkZWx0YUFjY3VtdWxhdG9yICs9IGRlbHRhO1xuXG4gICAgICBjbGVhclRpbWVvdXQocmVzZXRUaW1lcik7XG4gICAgICByZXNldFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGRlbHRhQWNjdW11bGF0b3IgPSAwO1xuICAgICAgfSwgMzAwKTtcblxuICAgICAgY29uc3QgVEhSRVNIT0xEID0gMTAwMDtcblxuICAgICAgLy8gU2Nyb2xsaW5nIERvd25cbiAgICAgIGlmIChkZWx0YUFjY3VtdWxhdG9yID49IFRIUkVTSE9MRCAmJiBhY3RpdmVJbmRleFJlZi5jdXJyZW50IDwgRVhQRVJUSVNFLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBkZWx0YUFjY3VtdWxhdG9yID0gMDtcbiAgICAgICAgaWYgKGlzQW5pbWF0aW5nUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgaXNBbmltYXRpbmdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGNvbnN0IG5leHQgPSBhY3RpdmVJbmRleFJlZi5jdXJyZW50ICsgMTtcbiAgICAgICAgYWN0aXZlSW5kZXhSZWYuY3VycmVudCA9IG5leHQ7XG4gICAgICAgIHNldEFjdGl2ZUluZGV4KG5leHQpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHsgaXNBbmltYXRpbmdSZWYuY3VycmVudCA9IGZhbHNlOyB9LCA1MDApO1xuICAgICAgfVxuICAgICAgLy8gU2Nyb2xsaW5nIFVwXG4gICAgICBlbHNlIGlmIChkZWx0YUFjY3VtdWxhdG9yIDw9IC1USFJFU0hPTEQgJiYgYWN0aXZlSW5kZXhSZWYuY3VycmVudCA+IDApIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBkZWx0YUFjY3VtdWxhdG9yID0gMDtcbiAgICAgICAgaWYgKGlzQW5pbWF0aW5nUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICAgICAgaXNBbmltYXRpbmdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGNvbnN0IHByZXYgPSBhY3RpdmVJbmRleFJlZi5jdXJyZW50IC0gMTtcbiAgICAgICAgYWN0aXZlSW5kZXhSZWYuY3VycmVudCA9IHByZXY7XG4gICAgICAgIHNldEFjdGl2ZUluZGV4KHByZXYpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHsgaXNBbmltYXRpbmdSZWYuY3VycmVudCA9IGZhbHNlOyB9LCA1MDApO1xuICAgICAgfVxuICAgICAgZWxzZSBpZiAoXG4gICAgICAgIChkZWx0YUFjY3VtdWxhdG9yID4gMCAmJiBhY3RpdmVJbmRleFJlZi5jdXJyZW50IDwgRVhQRVJUSVNFLmxlbmd0aCAtIDEpIHx8XG4gICAgICAgIChkZWx0YUFjY3VtdWxhdG9yIDwgMCAmJiBhY3RpdmVJbmRleFJlZi5jdXJyZW50ID4gMClcbiAgICAgICkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd3aGVlbCcsIGhhbmRsZVdoZWVsLCB7IHBhc3NpdmU6IGZhbHNlIH0pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignd2hlZWwnLCBoYW5kbGVXaGVlbCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBhY3RpdmVJdGVtID0gRVhQRVJUSVNFW2FjdGl2ZUluZGV4XTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uXG4gICAgICByZWY9e3NlY3Rpb25SZWZ9XG4gICAgICBpZD1cImV4cGVydGlzZVwiXG4gICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4taC1zY3JlZW4gaC1zY3JlZW4gZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcHktOCBweC02IG1kOnB4LTE2IGJnLVsjMDUwNTA1XSB0ZXh0LXdoaXRlIG92ZXJmbG93LWhpZGRlblwiXG4gICAgPlxuICAgICAgey8qIEJhY2tncm91bmQgQW1iaWVudCBQaXhlbCBCbGFzdCAqL31cbiAgICAgIDxQaXhlbEJsYXN0XG4gICAgICAgIHZhcmlhbnQ9XCJjaXJjbGVcIlxuICAgICAgICBjb2xvcj1cIiM3MDcwNzBcIlxuICAgICAgICBwaXhlbFNpemU9ezN9XG4gICAgICAgIHBhdHRlcm5EZW5zaXR5PXsxLjJ9XG4gICAgICAgIHBhdHRlcm5TY2FsZT17Mi4wfVxuICAgICAgICBsaXF1aWQ9e3RydWV9XG4gICAgICAgIGxpcXVpZFN0cmVuZ3RoPXswLjA4fVxuICAgICAgICBsaXF1aWRSYWRpdXM9ezEuMH1cbiAgICAgICAgZW5hYmxlUmlwcGxlcz17dHJ1ZX1cbiAgICAgICAgcmlwcGxlSW50ZW5zaXR5U2NhbGU9ezEuMn1cbiAgICAgICAgcmlwcGxlVGhpY2tuZXNzPXswLjF9XG4gICAgICAgIHJpcHBsZVNwZWVkPXswLjN9XG4gICAgICAgIG9wYWNpdHk9ezAuMjV9XG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHctZnVsbCByZWxhdGl2ZSB6LTEwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGgtZnVsbCBweS00XCI+XG5cbiAgICAgICAgey8qIEhlYWRlciBiYXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXdoaXRlLzEwIHBiLTUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXdoaXRlLzUwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtWzEuNXB4XSBiZy13aGl0ZS80MFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgQ2FwYWJpbGl0aWVzICYgU2VydmljZXNcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtNHhsIG1kOnRleHQtNnhsIGZvbnQtZGlzcGxheSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXRpZ2h0ZXIgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBFeHBlcnRpc2VcbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ291bnRlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBtZDpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmb250LW1vbm8gdGV4dC1zbVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC1sZ1wiPnthY3RpdmVJdGVtLm51bWJlcn08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzMwXCI+Lzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtd2hpdGUvNDBcIj4wMzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1haW4gU2hvd2Nhc2UgR3JpZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtOCBsZzpnYXAtMTIgaXRlbXMtY2VudGVyIG15LWF1dG9cIj5cblxuICAgICAgICAgIHsvKiBMZWZ0IENvbHVtbjogU2VydmljZSBTZWxlY3RvciBUYWJzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNSBmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICAgICAgICB7RVhQRVJUSVNFLm1hcCgoaXRlbSwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlSW5kZXggPT09IGlkeDtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ubnVtYmVyfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmVJbmRleFJlZi5jdXJyZW50ID0gaWR4O1xuICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVJbmRleChpZHgpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIHRleHQtbGVmdCBwLTUgbWQ6cC02IHJvdW5kZWQtMnhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuICR7aXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUvMTAgYm9yZGVyLXdoaXRlLzMwIHNoYWRvdy1bMF8xMHB4XzMwcHhfcmdiYSgyNTUsMjU1LDI1NSwwLjA1KV0gYmFja2Ryb3AtYmx1ci14bCB0cmFuc2xhdGUteC0yJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZS9bMC4wMl0gYm9yZGVyLXdoaXRlLzUgb3BhY2l0eS01MCBob3ZlcjpvcGFjaXR5LTgwIGhvdmVyOmJvcmRlci13aGl0ZS8xNSdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bmb250LW1vbm8gdGV4dC1zbSBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgJHtpc0FjdGl2ZSA/ICd0ZXh0LXdoaXRlJyA6ICd0ZXh0LXdoaXRlLzQwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5udW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPXtgdGV4dC14bCBtZDp0ZXh0LTJ4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy10aWdodCB0cmFuc2l0aW9uLWNvbG9ycyAke2lzQWN0aXZlID8gJ3RleHQtd2hpdGUnIDogJ3RleHQtd2hpdGUvNjAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXdoaXRlLzQwIG10LTAuNVwiPntpdGVtLnN1YnRpdGxlfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTggaC04IHJvdW5kZWQtZnVsbCBib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtpc0FjdGl2ZSA/ICdib3JkZXItd2hpdGUgYmctd2hpdGUgdGV4dC1ibGFjayByb3RhdGUtNDUnIDogJ2JvcmRlci13aGl0ZS8yMCB0ZXh0LXdoaXRlLzQwIGdyb3VwLWhvdmVyOmJvcmRlci13aGl0ZS81MCdcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICA8QXJyb3dVcFJpZ2h0IHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBSaWdodCBDb2x1bW46IEFjdGl2ZSBDYXJkIFZpZXdwb3J0ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyByZWxhdGl2ZSB3LWZ1bGwgbWluLWgtWzQ4MHB4XSBtZDptaW4taC1bNTIwcHhdIHJvdW5kZWQtM3hsIGJvcmRlciBib3JkZXItd2hpdGUvMTUgYmctYmxhY2svODAgc2hhZG93LTJ4bCBiYWNrZHJvcC1ibHVyLTJ4bCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIHtFWFBFUlRJU0UubWFwKChpdGVtLCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBhY3RpdmVJbmRleCA9PT0gaWR4O1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5udW1iZXJ9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BleHAtY2FyZC1pdGVtIGFic29sdXRlIGluc2V0LTAgcC02IHNtOnAtOCBtZDpwLTEwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCBlYXNlLW91dCAke2lzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgID8gJ29wYWNpdHktMTAwIHNjYWxlLTEwMCBwb2ludGVyLWV2ZW50cy1hdXRvIHotMTAgdHJhbnNsYXRlLXktMCdcbiAgICAgICAgICAgICAgICAgICAgOiAnb3BhY2l0eS0wIHNjYWxlLTk1IHBvaW50ZXItZXZlbnRzLW5vbmUgei0wIHRyYW5zbGF0ZS15LTQnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtd2hpdGUvNDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc3VidGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogVGl0bGUgJiBEZXNjcmlwdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtM3hsIG1kOnRleHQtNXhsIGZvbnQtZGlzcGxheSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXRpZ2h0IHRleHQtd2hpdGUgbWItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbWQ6dGV4dC1iYXNlIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXdoaXRlLzc1IGZvbnQtc2FucyBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgICB7LyogSGlnaGxpZ2h0cyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0yLjUgbXktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmhpZ2hsaWdodHMubWFwKChoLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LW1vbm8gdGV4dC13aGl0ZS83MCBiZy13aGl0ZS9bMC4wM10gYm9yZGVyIGJvcmRlci13aGl0ZS8xMCBwLTIuNSByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy13aGl0ZS82MCBmbGV4LXNocmluay0wXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntofTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogQ29yZSBTdGFjayBUYWdzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci13aGl0ZS8xMCBtdC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC13aGl0ZS80MCBibG9jayBtYi0yLjVcIj5UZWNobm9sb2dpZXMgJiBUb29sczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRhZ3MubWFwKHRhZyA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e3RhZ30gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBweC0zIHB5LTEuNSB0ZXh0LXdoaXRlLzkwIGJnLXdoaXRlLzUgYm9yZGVyIGJvcmRlci13aGl0ZS8xNSByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0YWd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9vdGVyIFByb2dyZXNzIEJhciAoV2hpdGUgTGluZSkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCB3LWZ1bGwgcHQtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzJweF0gYmctd2hpdGUvMTAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgYmctd2hpdGUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHsoKGFjdGl2ZUluZGV4ICsgMSkgLyBFWFBFUlRJU0UubGVuZ3RoKSAqIDEwMH0lYCB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9Xb3JrL1Nhc3VkdWwvc2FzYS9zYXN1bmR1bC1wb3J0Zm9saW8vY29tcG9uZW50cy9FeHBlcnRpc2VTZWN0aW9uLnRzeCJ9