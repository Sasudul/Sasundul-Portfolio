import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/AboutSection.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useRef = __vite__cjsImport1_react["useRef"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { ScrollTrigger } from "/node_modules/.vite/deps/gsap_ScrollTrigger.js?v=5088fc54";
gsap.registerPlugin(ScrollTrigger);
export default function AboutSection() {
  _s();
  const sectionRef = useRef(null);
  useGSAP(() => {
    const words = gsap.utils.toArray(".about-word");
    gsap.fromTo(words, {
      opacity: 0.15
    }, {
      opacity: 1,
      stagger: 0.05,
      ease: "none",
      scrollTrigger: {
        trigger: sectionRef.current,
        start: "top 70%",
        end: "bottom 50%",
        scrub: 1
      }
    });
  }, { scope: sectionRef });
  const text = "Creates impactful digital experiences through design and full-stack development, evolving from a foundation in design into specialized React, Spring Boot, and modern frontend solutions that transform wireframes into refined, performance-driven experiences.";
  return /* @__PURE__ */ jsxDEV("section", { ref: sectionRef, className: "py-32 md:py-48 px-6 md:px-12", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-4xl mx-auto text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xl md:text-3xl lg:text-4xl font-sans font-medium leading-relaxed tracking-tight", style: { color: "var(--text)" }, children: text.split(" ").map(
    (word, i) => /* @__PURE__ */ jsxDEV("span", { className: "about-word inline-block mr-[0.3em]", children: word }, i, false, {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AboutSection.tsx",
      lineNumber: 36,
      columnNumber: 11
    }, this)
  ) }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AboutSection.tsx",
    lineNumber: 34,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AboutSection.tsx",
    lineNumber: 33,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AboutSection.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_s(AboutSection, "mpOs1qQcCKpcFvuTT9MC8POvKRs=", false, function() {
  return [useGSAP];
});
_c = AboutSection;
var _c;
$RefreshReg$(_c, "AboutSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/AboutSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/AboutSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/AboutSection.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNZOztBQW5DWixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsT0FBT0MsVUFBVTtBQUNqQixTQUFTQyxxQkFBcUI7QUFFOUJELEtBQUtFLGVBQWVELGFBQWE7QUFFakMsd0JBQXdCRSxlQUFlO0FBQUFDLEtBQUE7QUFDckMsUUFBTUMsYUFBYVAsT0FBb0IsSUFBSTtBQUUzQ0MsVUFBUSxNQUFNO0FBRVosVUFBTU8sUUFBUU4sS0FBS08sTUFBTUMsUUFBcUIsYUFBYTtBQUMzRFIsU0FBS1MsT0FBT0gsT0FBTztBQUFBLE1BQ2pCSSxTQUFTO0FBQUEsSUFDWCxHQUFHO0FBQUEsTUFDREEsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxNQUNUQyxNQUFNO0FBQUEsTUFDTkMsZUFBZTtBQUFBLFFBQ2JDLFNBQVNULFdBQVdVO0FBQUFBLFFBQ3BCQyxPQUFPO0FBQUEsUUFDUEMsS0FBSztBQUFBLFFBQ0xDLE9BQU87QUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLEVBQUVDLE9BQU9kLFdBQVcsQ0FBQztBQUV4QixRQUFNZSxPQUFPO0FBRWIsU0FDRSx1QkFBQyxhQUFRLEtBQUtmLFlBQVksV0FBVSxnQ0FDbEMsaUNBQUMsU0FBSSxXQUFVLGlDQUNiLGlDQUFDLE9BQUUsV0FBVSx3RkFBdUYsT0FBTyxFQUFFZ0IsT0FBTyxjQUFjLEdBQy9IRCxlQUFLRSxNQUFNLEdBQUcsRUFBRUM7QUFBQUEsSUFBSSxDQUFDQyxNQUFNQyxNQUMxQix1QkFBQyxVQUFhLFdBQVUsc0NBQ3JCRCxrQkFEUUMsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRUo7QUFBQ3JCLEdBcEN1QkQsY0FBWTtBQUFBLFVBR2xDSixPQUFPO0FBQUE7QUFBQTJCLEtBSGV2QjtBQUFZLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUmVmIiwidXNlR1NBUCIsImdzYXAiLCJTY3JvbGxUcmlnZ2VyIiwicmVnaXN0ZXJQbHVnaW4iLCJBYm91dFNlY3Rpb24iLCJfcyIsInNlY3Rpb25SZWYiLCJ3b3JkcyIsInV0aWxzIiwidG9BcnJheSIsImZyb21UbyIsIm9wYWNpdHkiLCJzdGFnZ2VyIiwiZWFzZSIsInNjcm9sbFRyaWdnZXIiLCJ0cmlnZ2VyIiwiY3VycmVudCIsInN0YXJ0IiwiZW5kIiwic2NydWIiLCJzY29wZSIsInRleHQiLCJjb2xvciIsInNwbGl0IiwibWFwIiwid29yZCIsImkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBYm91dFNlY3Rpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlR1NBUCB9IGZyb20gJ0Bnc2FwL3JlYWN0JztcclxuaW1wb3J0IGdzYXAgZnJvbSAnZ3NhcCc7XHJcbmltcG9ydCB7IFNjcm9sbFRyaWdnZXIgfSBmcm9tICdnc2FwL1Njcm9sbFRyaWdnZXInO1xyXG5cclxuZ3NhcC5yZWdpc3RlclBsdWdpbihTY3JvbGxUcmlnZ2VyKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFib3V0U2VjdGlvbigpIHtcclxuICBjb25zdCBzZWN0aW9uUmVmID0gdXNlUmVmPEhUTUxFbGVtZW50PihudWxsKTtcclxuXHJcbiAgdXNlR1NBUCgoKSA9PiB7XHJcbiAgICAvLyBXb3JkLWJ5LXdvcmQgcmV2ZWFsXHJcbiAgICBjb25zdCB3b3JkcyA9IGdzYXAudXRpbHMudG9BcnJheTxIVE1MRWxlbWVudD4oJy5hYm91dC13b3JkJyk7XHJcbiAgICBnc2FwLmZyb21Ubyh3b3Jkcywge1xyXG4gICAgICBvcGFjaXR5OiAwLjE1LFxyXG4gICAgfSwge1xyXG4gICAgICBvcGFjaXR5OiAxLFxyXG4gICAgICBzdGFnZ2VyOiAwLjA1LFxyXG4gICAgICBlYXNlOiAnbm9uZScsXHJcbiAgICAgIHNjcm9sbFRyaWdnZXI6IHtcclxuICAgICAgICB0cmlnZ2VyOiBzZWN0aW9uUmVmLmN1cnJlbnQsXHJcbiAgICAgICAgc3RhcnQ6ICd0b3AgNzAlJyxcclxuICAgICAgICBlbmQ6ICdib3R0b20gNTAlJyxcclxuICAgICAgICBzY3J1YjogMSxcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfSwgeyBzY29wZTogc2VjdGlvblJlZiB9KTtcclxuXHJcbiAgY29uc3QgdGV4dCA9IFwiQ3JlYXRlcyBpbXBhY3RmdWwgZGlnaXRhbCBleHBlcmllbmNlcyB0aHJvdWdoIGRlc2lnbiBhbmQgZnVsbC1zdGFjayBkZXZlbG9wbWVudCwgZXZvbHZpbmcgZnJvbSBhIGZvdW5kYXRpb24gaW4gZGVzaWduIGludG8gc3BlY2lhbGl6ZWQgUmVhY3QsIFNwcmluZyBCb290LCBhbmQgbW9kZXJuIGZyb250ZW5kIHNvbHV0aW9ucyB0aGF0IHRyYW5zZm9ybSB3aXJlZnJhbWVzIGludG8gcmVmaW5lZCwgcGVyZm9ybWFuY2UtZHJpdmVuIGV4cGVyaWVuY2VzLlwiO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gcmVmPXtzZWN0aW9uUmVmfSBjbGFzc05hbWU9XCJweS0zMiBtZDpweS00OCBweC02IG1kOnB4LTEyXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNHhsIG14LWF1dG8gdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIG1kOnRleHQtM3hsIGxnOnRleHQtNHhsIGZvbnQtc2FucyBmb250LW1lZGl1bSBsZWFkaW5nLXJlbGF4ZWQgdHJhY2tpbmctdGlnaHRcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQpJyB9fT5cclxuICAgICAgICAgIHt0ZXh0LnNwbGl0KCcgJykubWFwKCh3b3JkLCBpKSA9PiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwiYWJvdXQtd29yZCBpbmxpbmUtYmxvY2sgbXItWzAuM2VtXVwiPlxyXG4gICAgICAgICAgICAgIHt3b3JkfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJEOi9Xb3JrL1Nhc3VkdWwvc2FzYS9zYXN1bmR1bC1wb3J0Zm9saW8vY29tcG9uZW50cy9BYm91dFNlY3Rpb24udHN4In0=