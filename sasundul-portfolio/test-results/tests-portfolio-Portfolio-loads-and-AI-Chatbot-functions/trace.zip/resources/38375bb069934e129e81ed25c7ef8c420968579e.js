import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/ContactForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"];
import { useGSAP } from "/node_modules/.vite/deps/@gsap_react.js?v=5088fc54";
import gsap from "/node_modules/.vite/deps/gsap.js?v=5088fc54";
import { X, Send } from "/node_modules/.vite/deps/lucide-react.js?v=5088fc54";
export default function ContactForm({ onClose }) {
  _s();
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState("idle");
  const overlayRef = useRef(null);
  const formContainerRef = useRef(null);
  useGSAP(() => {
    const tl = gsap.timeline();
    tl.to(overlayRef.current, {
      opacity: 1,
      duration: 0.5,
      ease: "power2.out"
    }).from(".form-element", {
      y: 30,
      opacity: 0,
      stagger: 0.1,
      duration: 0.6,
      ease: "power3.out"
    }, "-=0.3");
  }, []);
  const handleClose = () => {
    gsap.to(overlayRef.current, {
      opacity: 0,
      duration: 0.4,
      ease: "power2.in",
      onComplete: onClose
    });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("submitting");
    try {
      const response = await fetch("https://formsubmit.co/ajax/sasuduln@gmail.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: formData.message,
          _subject: `New Portfolio Inquiry from ${formData.name}`
        })
      });
      if (response.ok) {
        setStatus("success");
        setTimeout(handleClose, 3e3);
      } else {
        setStatus("idle");
        alert("Could not send message automatically. Please email sasuduln@gmail.com directly.");
      }
    } catch (error) {
      console.error("Contact Form Error:", error);
      setStatus("idle");
      alert("Could not send message automatically. Please email sasuduln@gmail.com directly.");
    }
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref: overlayRef,
      className: "fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4 backdrop-blur-md opacity-0",
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "absolute inset-0 cursor-pointer",
            onClick: handleClose
          },
          void 0,
          false,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
            lineNumber: 74,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            ref: formContainerRef,
            className: "relative w-full max-w-2xl bg-[#0a0a0a] border border-white/15 rounded-3xl p-8 md:p-12 shadow-2xl z-10",
            children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleClose,
                  className: "absolute top-6 right-6 text-white/50 hover:text-white p-2 bg-white/5 hover:bg-white/10 rounded-full transition-all hover:rotate-90 form-element cursor-pointer",
                  children: /* @__PURE__ */ jsxDEV(X, { size: 24 }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                    lineNumber: 87,
                    columnNumber: 11
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 83,
                  columnNumber: 9
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-10 form-element", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-white/60 text-xs font-mono uppercase font-bold tracking-widest mb-4 flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-8 h-[1.5px] bg-white/40" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                    lineNumber: 92,
                    columnNumber: 13
                  }, this),
                  "Get In Touch"
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 91,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl md:text-5xl font-display font-bold uppercase tracking-tighter text-white", children: [
                  "Let's start a ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-white/60", children: "project" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                    lineNumber: 95,
                    columnNumber: 123
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 95,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                lineNumber: 90,
                columnNumber: 9
              }, this),
              status === "success" ? /* @__PURE__ */ jsxDEV("div", { className: "py-16 text-center form-element", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 bg-[#25D366]/20 border border-[#25D366]/40 rounded-full flex items-center justify-center mx-auto mb-6 text-[#25D366]", children: /* @__PURE__ */ jsxDEV(Send, { size: 36 }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 101,
                  columnNumber: 15
                }, this) }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 100,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-display font-bold uppercase text-white mb-2", children: "Message Sent Successfully!" }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 103,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-white/60 font-mono text-sm uppercase", children: "Thank you! I will get back to your inbox shortly." }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 104,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                lineNumber: 99,
                columnNumber: 9
              }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "form-element relative", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      required: true,
                      className: "w-full bg-transparent border-b border-white/20 pb-4 pt-6 px-2 text-white placeholder-transparent focus:outline-none focus:border-white peer transition-colors font-sans",
                      placeholder: "Name",
                      value: formData.name,
                      onChange: (e) => setFormData({ ...formData, name: e.target.value })
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                      lineNumber: 109,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("label", { className: "absolute left-2 top-6 text-white/40 text-xs font-mono uppercase font-bold tracking-widest peer-focus:-top-2 peer-focus:text-xs peer-focus:text-white transition-all peer-valid:-top-2 peer-valid:text-xs peer-valid:text-white/60 pointer-events-none", children: "Your Name" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                    lineNumber: 117,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 108,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-element relative", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "email",
                      required: true,
                      className: "w-full bg-transparent border-b border-white/20 pb-4 pt-6 px-2 text-white placeholder-transparent focus:outline-none focus:border-white peer transition-colors font-sans",
                      placeholder: "Email",
                      value: formData.email,
                      onChange: (e) => setFormData({ ...formData, email: e.target.value })
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                      lineNumber: 121,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("label", { className: "absolute left-2 top-6 text-white/40 text-xs font-mono uppercase font-bold tracking-widest peer-focus:-top-2 peer-focus:text-xs peer-focus:text-white transition-all peer-valid:-top-2 peer-valid:text-xs peer-valid:text-white/60 pointer-events-none", children: "Your Email Address" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                    lineNumber: 129,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 120,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-element relative", children: [
                  /* @__PURE__ */ jsxDEV(
                    "textarea",
                    {
                      required: true,
                      rows: 4,
                      className: "w-full bg-transparent border-b border-white/20 pb-4 pt-6 px-2 text-white placeholder-transparent focus:outline-none focus:border-white peer transition-colors resize-none font-sans",
                      placeholder: "Message",
                      value: formData.message,
                      onChange: (e) => setFormData({ ...formData, message: e.target.value })
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                      lineNumber: 133,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("label", { className: "absolute left-2 top-6 text-white/40 text-xs font-mono uppercase font-bold tracking-widest peer-focus:-top-2 peer-focus:text-xs peer-focus:text-white transition-all peer-valid:-top-2 peer-valid:text-xs peer-valid:text-white/60 pointer-events-none", children: "Project Details & Inquiry" }, void 0, false, {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                    lineNumber: 141,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 132,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-element pt-6", children: /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    disabled: status === "submitting",
                    className: "w-full py-5 bg-white text-black uppercase font-bold font-mono tracking-widest hover:bg-white/80 transition-all duration-300 flex items-center justify-center gap-4 group rounded-xl cursor-pointer",
                    children: [
                      status === "submitting" ? "Sending Message..." : "Send Message",
                      /* @__PURE__ */ jsxDEV(ArrowUpRight, { className: "group-hover:rotate-45 transition-transform" }, void 0, false, {
                        fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                        lineNumber: 151,
                        columnNumber: 17
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                    lineNumber: 145,
                    columnNumber: 15
                  },
                  this
                ) }, void 0, false, {
                  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                  lineNumber: 144,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
                lineNumber: 107,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
            lineNumber: 79,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
      lineNumber: 70,
      columnNumber: 5
    },
    this
  );
}
_s(ContactForm, "R7TnmQV0hQqRxdAZElI8a59mTOs=", false, function() {
  return [useGSAP];
});
_c = ContactForm;
const ArrowUpRight = ({ className = "" }) => /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className, children: [
  /* @__PURE__ */ jsxDEV("line", { x1: "7", y1: "17", x2: "17", y2: "7" }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
    lineNumber: 162,
    columnNumber: 201
  }, this),
  /* @__PURE__ */ jsxDEV("polyline", { points: "7 7 17 7 17 17" }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
    lineNumber: 162,
    columnNumber: 244
  }, this)
] }, void 0, true, {
  fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx",
  lineNumber: 162,
  columnNumber: 1
}, this);
_c2 = ArrowUpRight;
var _c, _c2;
$RefreshReg$(_c, "ContactForm");
$RefreshReg$(_c2, "ArrowUpRight");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Work/Sasudul/sasa/sasundul-portfolio/components/ContactForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVNOztBQXpFTixTQUFnQkEsVUFBVUMsY0FBYztBQUN4QyxTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsR0FBR0MsWUFBWTtBQUV4Qix3QkFBd0JDLFlBQVksRUFBRUMsUUFBaUMsR0FBRztBQUFBQyxLQUFBO0FBQ3hFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJVixTQUFTLEVBQUVXLE1BQU0sSUFBSUMsT0FBTyxJQUFJQyxTQUFTLEdBQUcsQ0FBQztBQUM3RSxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWYsU0FBNEMsTUFBTTtBQUM5RSxRQUFNZ0IsYUFBYWYsT0FBdUIsSUFBSTtBQUM5QyxRQUFNZ0IsbUJBQW1CaEIsT0FBdUIsSUFBSTtBQUVwREMsVUFBUSxNQUFNO0FBQ1osVUFBTWdCLEtBQUtmLEtBQUtnQixTQUFTO0FBQ3pCRCxPQUFHRSxHQUFHSixXQUFXSyxTQUFTO0FBQUEsTUFDeEJDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLElBQ1IsQ0FBQyxFQUFFQyxLQUFLLGlCQUFpQjtBQUFBLE1BQ3ZCQyxHQUFHO0FBQUEsTUFDSEosU0FBUztBQUFBLE1BQ1RLLFNBQVM7QUFBQSxNQUNUSixVQUFVO0FBQUEsTUFDVkMsTUFBTTtBQUFBLElBQ1IsR0FBRyxPQUFPO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxRQUFNSSxjQUFjQSxNQUFNO0FBQ3hCekIsU0FBS2lCLEdBQUdKLFdBQVdLLFNBQVM7QUFBQSxNQUMxQkMsU0FBUztBQUFBLE1BQ1RDLFVBQVU7QUFBQSxNQUNWQyxNQUFNO0FBQUEsTUFDTkssWUFBWXRCO0FBQUFBLElBQ2QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNdUIsZUFBZSxPQUFPQyxNQUF1QjtBQUNqREEsTUFBRUMsZUFBZTtBQUNqQmpCLGNBQVUsWUFBWTtBQUV0QixRQUFJO0FBQ0YsWUFBTWtCLFdBQVcsTUFBTUMsTUFBTSxpREFBaUQ7QUFBQSxRQUM1RUMsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFVBQ2hCLFVBQVU7QUFBQSxRQUNaO0FBQUEsUUFDQUMsTUFBTUMsS0FBS0MsVUFBVTtBQUFBLFVBQ25CNUIsTUFBTUYsU0FBU0U7QUFBQUEsVUFDZkMsT0FBT0gsU0FBU0c7QUFBQUEsVUFDaEJDLFNBQVNKLFNBQVNJO0FBQUFBLFVBQ2xCMkIsVUFBVSw4QkFBOEIvQixTQUFTRSxJQUFJO0FBQUEsUUFDdkQsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUVELFVBQUlzQixTQUFTUSxJQUFJO0FBQ2YxQixrQkFBVSxTQUFTO0FBQ25CMkIsbUJBQVdkLGFBQWEsR0FBSTtBQUFBLE1BQzlCLE9BQU87QUFDTGIsa0JBQVUsTUFBTTtBQUNoQjRCLGNBQU0saUZBQWlGO0FBQUEsTUFDekY7QUFBQSxJQUNGLFNBQVNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx1QkFBdUJBLEtBQUs7QUFDMUM3QixnQkFBVSxNQUFNO0FBQ2hCNEIsWUFBTSxpRkFBaUY7QUFBQSxJQUN6RjtBQUFBLEVBQ0Y7QUFFQSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxLQUFLM0I7QUFBQUEsTUFDTCxXQUFVO0FBQUEsTUFFVjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTWTtBQUFBQTtBQUFBQSxVQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdDO0FBQUEsUUFFRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsS0FBS1g7QUFBQUEsWUFDTCxXQUFVO0FBQUEsWUFFVjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVNXO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxLQUFFLE1BQU0sTUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFZO0FBQUE7QUFBQSxnQkFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG9HQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLCtCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QztBQUFBLGtCQUFNO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUscUZBQW9GO0FBQUE7QUFBQSxrQkFBYyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLHFCQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4SjtBQUFBLG1CQUxoSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FFQ2QsV0FBVyxZQUNWLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxrSUFDYixpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsNkRBQTRELDBDQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRztBQUFBLGdCQUNwRyx1QkFBQyxPQUFFLFdBQVUsNkNBQTRDLGlFQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRztBQUFBLG1CQUw1RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BLElBRUEsdUJBQUMsVUFBSyxVQUFVZ0IsY0FBYyxXQUFVLGFBQ3RDO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMO0FBQUEsc0JBQ0EsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPckIsU0FBU0U7QUFBQUEsc0JBQ2hCLFVBQVUsQ0FBQW9CLE1BQUtyQixZQUFZLEVBQUUsR0FBR0QsVUFBVUUsTUFBTW9CLEVBQUVlLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsb0JBTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNb0U7QUFBQSxrQkFFcEUsdUJBQUMsV0FBTSxXQUFVLHlQQUF3UCx5QkFBelE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa1I7QUFBQSxxQkFUcFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTDtBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osT0FBT3RDLFNBQVNHO0FBQUFBLHNCQUNoQixVQUFVLENBQUFtQixNQUFLckIsWUFBWSxFQUFFLEdBQUdELFVBQVVHLE9BQU9tQixFQUFFZSxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLG9CQU5uRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTXFFO0FBQUEsa0JBRXJFLHVCQUFDLFdBQU0sV0FBVSx5UEFBd1Asa0NBQXpRO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJSO0FBQUEscUJBVDdSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQztBQUFBLHNCQUNBLE1BQU07QUFBQSxzQkFDTixXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaLE9BQU90QyxTQUFTSTtBQUFBQSxzQkFDaEIsVUFBVSxDQUFBa0IsTUFBS3JCLFlBQVksRUFBRSxHQUFHRCxVQUFVSSxTQUFTa0IsRUFBRWUsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxvQkFOckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9DO0FBQUEsa0JBQ0QsdUJBQUMsV0FBTSxXQUFVLHlQQUF3UCx5Q0FBelE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa1M7QUFBQSxxQkFUcFM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsVUFBVWpDLFdBQVc7QUFBQSxvQkFDckIsV0FBVTtBQUFBLG9CQUVUQTtBQUFBQSxpQ0FBVyxlQUFlLHVCQUF1QjtBQUFBLHNCQUNsRCx1QkFBQyxnQkFBYSxXQUFVLGdEQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvRTtBQUFBO0FBQUE7QUFBQSxrQkFOdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStDQTtBQUFBO0FBQUE7QUFBQSxVQTNFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE2RUE7QUFBQTtBQUFBO0FBQUEsSUF0RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBdUZBO0FBRUo7QUFBQ04sR0F6SnVCRixhQUFXO0FBQUEsVUFNakNKLE9BQU87QUFBQTtBQUFBOEMsS0FOZTFDO0FBMkp4QixNQUFNMkMsZUFBZUEsQ0FBQyxFQUFFQyxZQUFZLEdBQTJCLE1BQzdELHVCQUFDLFNBQUksT0FBTSw4QkFBNkIsT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxTQUFRLFdBQXNCO0FBQUEseUJBQUMsVUFBSyxJQUFHLEtBQUksSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLE9BQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0M7QUFBQSxFQUFPLHVCQUFDLGNBQVMsUUFBTyxvQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFrQztBQUFBLEtBQXJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBZ1M7QUFDaFNDLE1BRklGO0FBQVksSUFBQUQsSUFBQUc7QUFBQUMsYUFBQUosSUFBQTtBQUFBSSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VHU0FQIiwiZ3NhcCIsIlgiLCJTZW5kIiwiQ29udGFjdEZvcm0iLCJvbkNsb3NlIiwiX3MiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwibmFtZSIsImVtYWlsIiwibWVzc2FnZSIsInN0YXR1cyIsInNldFN0YXR1cyIsIm92ZXJsYXlSZWYiLCJmb3JtQ29udGFpbmVyUmVmIiwidGwiLCJ0aW1lbGluZSIsInRvIiwiY3VycmVudCIsIm9wYWNpdHkiLCJkdXJhdGlvbiIsImVhc2UiLCJmcm9tIiwieSIsInN0YWdnZXIiLCJoYW5kbGVDbG9zZSIsIm9uQ29tcGxldGUiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJyZXNwb25zZSIsImZldGNoIiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwiX3N1YmplY3QiLCJvayIsInNldFRpbWVvdXQiLCJhbGVydCIsImVycm9yIiwiY29uc29sZSIsInRhcmdldCIsInZhbHVlIiwiX2MiLCJBcnJvd1VwUmlnaHQiLCJjbGFzc05hbWUiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29udGFjdEZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlR1NBUCB9IGZyb20gJ0Bnc2FwL3JlYWN0JztcbmltcG9ydCBnc2FwIGZyb20gJ2dzYXAnO1xuaW1wb3J0IHsgWCwgU2VuZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnRhY3RGb3JtKHsgb25DbG9zZSB9OiB7IG9uQ2xvc2U6ICgpID0+IHZvaWQgfSkge1xuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHsgbmFtZTogJycsIGVtYWlsOiAnJywgbWVzc2FnZTogJycgfSk7XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTwnaWRsZScgfCAnc3VibWl0dGluZycgfCAnc3VjY2Vzcyc+KCdpZGxlJyk7XG4gIGNvbnN0IG92ZXJsYXlSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBmb3JtQ29udGFpbmVyUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcblxuICB1c2VHU0FQKCgpID0+IHtcbiAgICBjb25zdCB0bCA9IGdzYXAudGltZWxpbmUoKTtcbiAgICB0bC50byhvdmVybGF5UmVmLmN1cnJlbnQsIHtcbiAgICAgIG9wYWNpdHk6IDEsXG4gICAgICBkdXJhdGlvbjogMC41LFxuICAgICAgZWFzZTogJ3Bvd2VyMi5vdXQnXG4gICAgfSkuZnJvbSgnLmZvcm0tZWxlbWVudCcsIHtcbiAgICAgIHk6IDMwLFxuICAgICAgb3BhY2l0eTogMCxcbiAgICAgIHN0YWdnZXI6IDAuMSxcbiAgICAgIGR1cmF0aW9uOiAwLjYsXG4gICAgICBlYXNlOiAncG93ZXIzLm91dCdcbiAgICB9LCBcIi09MC4zXCIpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlQ2xvc2UgPSAoKSA9PiB7XG4gICAgZ3NhcC50byhvdmVybGF5UmVmLmN1cnJlbnQsIHtcbiAgICAgIG9wYWNpdHk6IDAsXG4gICAgICBkdXJhdGlvbjogMC40LFxuICAgICAgZWFzZTogJ3Bvd2VyMi5pbicsXG4gICAgICBvbkNvbXBsZXRlOiBvbkNsb3NlXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRTdGF0dXMoJ3N1Ym1pdHRpbmcnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFwiaHR0cHM6Ly9mb3Jtc3VibWl0LmNvL2FqYXgvc2FzdWR1bG5AZ21haWwuY29tXCIsIHtcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgIFwiQWNjZXB0XCI6IFwiYXBwbGljYXRpb24vanNvblwiXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBuYW1lOiBmb3JtRGF0YS5uYW1lLFxuICAgICAgICAgIGVtYWlsOiBmb3JtRGF0YS5lbWFpbCxcbiAgICAgICAgICBtZXNzYWdlOiBmb3JtRGF0YS5tZXNzYWdlLFxuICAgICAgICAgIF9zdWJqZWN0OiBgTmV3IFBvcnRmb2xpbyBJbnF1aXJ5IGZyb20gJHtmb3JtRGF0YS5uYW1lfWBcbiAgICAgICAgfSlcbiAgICAgIH0pO1xuXG4gICAgICBpZiAocmVzcG9uc2Uub2spIHtcbiAgICAgICAgc2V0U3RhdHVzKCdzdWNjZXNzJyk7XG4gICAgICAgIHNldFRpbWVvdXQoaGFuZGxlQ2xvc2UsIDMwMDApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0U3RhdHVzKCdpZGxlJyk7XG4gICAgICAgIGFsZXJ0KFwiQ291bGQgbm90IHNlbmQgbWVzc2FnZSBhdXRvbWF0aWNhbGx5LiBQbGVhc2UgZW1haWwgc2FzdWR1bG5AZ21haWwuY29tIGRpcmVjdGx5LlwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkNvbnRhY3QgRm9ybSBFcnJvcjpcIiwgZXJyb3IpO1xuICAgICAgc2V0U3RhdHVzKCdpZGxlJyk7XG4gICAgICBhbGVydChcIkNvdWxkIG5vdCBzZW5kIG1lc3NhZ2UgYXV0b21hdGljYWxseS4gUGxlYXNlIGVtYWlsIHNhc3VkdWxuQGdtYWlsLmNvbSBkaXJlY3RseS5cIik7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcmVmPXtvdmVybGF5UmVmfVxuICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGJnLWJsYWNrLzkwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiYWNrZHJvcC1ibHVyLW1kIG9wYWNpdHktMFwiXG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2V9XG4gICAgICA+PC9kaXY+XG5cbiAgICAgIDxkaXZcbiAgICAgICAgcmVmPXtmb3JtQ29udGFpbmVyUmVmfVxuICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctMnhsIGJnLVsjMGEwYTBhXSBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IHJvdW5kZWQtM3hsIHAtOCBtZDpwLTEyIHNoYWRvdy0yeGwgei0xMFwiXG4gICAgICA+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbG9zZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNiByaWdodC02IHRleHQtd2hpdGUvNTAgaG92ZXI6dGV4dC13aGl0ZSBwLTIgYmctd2hpdGUvNSBob3ZlcjpiZy13aGl0ZS8xMCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgaG92ZXI6cm90YXRlLTkwIGZvcm0tZWxlbWVudCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBzaXplPXsyNH0gLz5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMCBmb3JtLWVsZW1lbnRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtd2hpdGUvNjAgdGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIGZvbnQtYm9sZCB0cmFja2luZy13aWRlc3QgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy04IGgtWzEuNXB4XSBiZy13aGl0ZS80MFwiPjwvc3Bhbj5cbiAgICAgICAgICAgIEdldCBJbiBUb3VjaFxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBtZDp0ZXh0LTV4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy10aWdodGVyIHRleHQtd2hpdGVcIj5MZXQncyBzdGFydCBhIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtd2hpdGUvNjBcIj5wcm9qZWN0PC9zcGFuPjwvaDI+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtzdGF0dXMgPT09ICdzdWNjZXNzJyA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTE2IHRleHQtY2VudGVyIGZvcm0tZWxlbWVudFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIwIGgtMjAgYmctWyMyNUQzNjZdLzIwIGJvcmRlciBib3JkZXItWyMyNUQzNjZdLzQwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTYgdGV4dC1bIzI1RDM2Nl1cIj5cbiAgICAgICAgICAgICAgPFNlbmQgc2l6ZT17MzZ9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWRpc3BsYXkgZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LXdoaXRlIG1iLTJcIj5NZXNzYWdlIFNlbnQgU3VjY2Vzc2Z1bGx5ITwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzYwIGZvbnQtbW9ubyB0ZXh0LXNtIHVwcGVyY2FzZVwiPlRoYW5rIHlvdSEgSSB3aWxsIGdldCBiYWNrIHRvIHlvdXIgaW5ib3ggc2hvcnRseS48L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZWxlbWVudCByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgYm9yZGVyLWIgYm9yZGVyLXdoaXRlLzIwIHBiLTQgcHQtNiBweC0yIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItdHJhbnNwYXJlbnQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci13aGl0ZSBwZWVyIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtc2Fuc1wiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOYW1lXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMiB0b3AtNiB0ZXh0LXdoaXRlLzQwIHRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSBmb250LWJvbGQgdHJhY2tpbmctd2lkZXN0IHBlZXItZm9jdXM6LXRvcC0yIHBlZXItZm9jdXM6dGV4dC14cyBwZWVyLWZvY3VzOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgcGVlci12YWxpZDotdG9wLTIgcGVlci12YWxpZDp0ZXh0LXhzIHBlZXItdmFsaWQ6dGV4dC13aGl0ZS82MCBwb2ludGVyLWV2ZW50cy1ub25lXCI+WW91ciBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZWxlbWVudCByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IGJvcmRlci1iIGJvcmRlci13aGl0ZS8yMCBwYi00IHB0LTYgcHgtMiB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXRyYW5zcGFyZW50IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItd2hpdGUgcGVlciB0cmFuc2l0aW9uLWNvbG9ycyBmb250LXNhbnNcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW1haWxcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbWFpbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBlbWFpbDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTIgdG9wLTYgdGV4dC13aGl0ZS80MCB0ZXh0LXhzIGZvbnQtbW9ubyB1cHBlcmNhc2UgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCBwZWVyLWZvY3VzOi10b3AtMiBwZWVyLWZvY3VzOnRleHQteHMgcGVlci1mb2N1czp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tYWxsIHBlZXItdmFsaWQ6LXRvcC0yIHBlZXItdmFsaWQ6dGV4dC14cyBwZWVyLXZhbGlkOnRleHQtd2hpdGUvNjAgcG9pbnRlci1ldmVudHMtbm9uZVwiPllvdXIgRW1haWwgQWRkcmVzczwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWVsZW1lbnQgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICByb3dzPXs0fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy10cmFuc3BhcmVudCBib3JkZXItYiBib3JkZXItd2hpdGUvMjAgcGItNCBwdC02IHB4LTIgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci10cmFuc3BhcmVudCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXdoaXRlIHBlZXIgdHJhbnNpdGlvbi1jb2xvcnMgcmVzaXplLW5vbmUgZm9udC1zYW5zXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1lc3NhZ2VcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5tZXNzYWdlfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIG1lc3NhZ2U6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICA+PC90ZXh0YXJlYT5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMiB0b3AtNiB0ZXh0LXdoaXRlLzQwIHRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSBmb250LWJvbGQgdHJhY2tpbmctd2lkZXN0IHBlZXItZm9jdXM6LXRvcC0yIHBlZXItZm9jdXM6dGV4dC14cyBwZWVyLWZvY3VzOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgcGVlci12YWxpZDotdG9wLTIgcGVlci12YWxpZDp0ZXh0LXhzIHBlZXItdmFsaWQ6dGV4dC13aGl0ZS82MCBwb2ludGVyLWV2ZW50cy1ub25lXCI+UHJvamVjdCBEZXRhaWxzICYgSW5xdWlyeTwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWVsZW1lbnQgcHQtNlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3N0YXR1cyA9PT0gJ3N1Ym1pdHRpbmcnfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS01IGJnLXdoaXRlIHRleHQtYmxhY2sgdXBwZXJjYXNlIGZvbnQtYm9sZCBmb250LW1vbm8gdHJhY2tpbmctd2lkZXN0IGhvdmVyOmJnLXdoaXRlLzgwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNCBncm91cCByb3VuZGVkLXhsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtzdGF0dXMgPT09ICdzdWJtaXR0aW5nJyA/ICdTZW5kaW5nIE1lc3NhZ2UuLi4nIDogJ1NlbmQgTWVzc2FnZSd9XG4gICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBjbGFzc05hbWU9XCJncm91cC1ob3Zlcjpyb3RhdGUtNDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBBcnJvd1VwUmlnaHQgPSAoeyBjbGFzc05hbWUgPSBcIlwiIH06IHsgY2xhc3NOYW1lPzogc3RyaW5nIH0pID0+IChcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIGNsYXNzTmFtZT17Y2xhc3NOYW1lfT48bGluZSB4MT1cIjdcIiB5MT1cIjE3XCIgeDI9XCIxN1wiIHkyPVwiN1wiPjwvbGluZT48cG9seWxpbmUgcG9pbnRzPVwiNyA3IDE3IDcgMTcgMTdcIj48L3BvbHlsaW5lPjwvc3ZnPlxuKTtcbiJdLCJmaWxlIjoiRDovV29yay9TYXN1ZHVsL3Nhc2Evc2FzdW5kdWwtcG9ydGZvbGlvL2NvbXBvbmVudHMvQ29udGFjdEZvcm0udHN4In0=