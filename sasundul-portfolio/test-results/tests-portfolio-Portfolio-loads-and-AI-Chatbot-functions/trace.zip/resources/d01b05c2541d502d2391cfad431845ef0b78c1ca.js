import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=5088fc54"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=5088fc54"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=5088fc54"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import App from "/App.tsx?t=1786214954375";
const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}
const root = ReactDOM.createRoot(rootElement);
root.render(
  /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/index.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "D:/Work/Sasudul/sasa/sasundul-portfolio/index.tsx",
    lineNumber: 12,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7QUFaSixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsU0FBUztBQUVoQixNQUFNQyxjQUFjQyxTQUFTQyxlQUFlLE1BQU07QUFDbEQsSUFBSSxDQUFDRixhQUFhO0FBQ2hCLFFBQU0sSUFBSUcsTUFBTSx5Q0FBeUM7QUFDM0Q7QUFFQSxNQUFNQyxPQUFPTixTQUFTTyxXQUFXTCxXQUFXO0FBQzVDSSxLQUFLRTtBQUFBQSxFQUNILHVCQUFDLE1BQU0sWUFBTixFQUNDLGlDQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFJLEtBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiQXBwIiwicm9vdEVsZW1lbnQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiRXJyb3IiLCJyb290IiwiY3JlYXRlUm9vdCIsInJlbmRlciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xyXG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwJztcclxuXHJcbmNvbnN0IHJvb3RFbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKTtcclxuaWYgKCFyb290RWxlbWVudCkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcIkNvdWxkIG5vdCBmaW5kIHJvb3QgZWxlbWVudCB0byBtb3VudCB0b1wiKTtcclxufVxyXG5cclxuY29uc3Qgcm9vdCA9IFJlYWN0RE9NLmNyZWF0ZVJvb3Qocm9vdEVsZW1lbnQpO1xyXG5yb290LnJlbmRlcihcclxuICA8UmVhY3QuU3RyaWN0TW9kZT5cclxuICAgIDxBcHAgLz5cclxuICA8L1JlYWN0LlN0cmljdE1vZGU+XHJcbik7Il0sImZpbGUiOiJEOi9Xb3JrL1Nhc3VkdWwvc2FzYS9zYXN1bmR1bC1wb3J0Zm9saW8vaW5kZXgudHN4In0=